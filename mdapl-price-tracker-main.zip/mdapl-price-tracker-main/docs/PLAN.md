# MDAPL Price Tracker: Retool to custom app migration plan

Source: the Retool app "Product Price Tracker" (`Product Price Tracker.zip`: main.rsx, functions.rsx, sidebar.rsx,
src/*.rsx, lib/*, metadata.json) and the 8 Retool workflows (`*.json` in this repo).
Design reference: terran-app (tokens, controls, tables, tabs, filters, stat strips, notices, dialogs, empty states,
sign-in, audit log), re-coloured for MDAPL: navy/ink instead of maroon, the Retool theme blue `#3170f9` used rarely
and only in a light shade.

Stack: React 18 + TypeScript + Vite + Tailwind 4, TanStack Query, react-router (HashRouter), lucide-react.
API: one Vercel function `api/main.ts` -> `server/router.ts` -> `server/routes/*`. Postgres via `pg`
(Supabase transaction pooler, port 6543). Without `DATABASE_URL` the server runs on PGlite with seed data (demo mode).

---

## 1. Resources

| Retool resource | What it does | New implementation |
|---|---|---|
| `retool_db` (Postgres, id c47681e5…) | All app data | Supabase Postgres via `pg` (`server/db.ts`), PGlite in demo mode |
| `Browserless v3` (REST, id 9b42e44e…) | Runs the Puppeteer scraper scripts (`POST /function?launch={"args":["--proxy-server=…"]}`) | `server/scrape/browserless.ts`, env `BROWSERLESS_URL`, `BROWSERLESS_TOKEN`, `SCRAPE_PROXY_SERVER` |
| Proxy credentials (hard-coded in the scraper scripts) | Residential proxy login (decodo) | env `SCRAPE_PROXY_USERNAME`, `SCRAPE_PROXY_PASSWORD`. **The Retool export holds these in plain text: rotate them.** |
| `Google Sheets` (id 624043c0…) | Reads `Products!A1:AZ`, writes `Products_Append!A2:AZ1000` | **Dropped.** The app is the product master: Products > Import (xlsx/csv preview + apply), Product master download, bulk edit; pricing calculated in `shared/pricing.ts` |
| Retool storage logo / madhukart.com logo | Sidebar brand | Wordmark; drop the real file at `public/brand/logo.png` to show it |
| ProxyJet dashboard link | "View Proxy Jet Balance" button | "Decodo Proxy Balance" (the proxy is Decodo; `PROXY_DASHBOARD_URL`) |
| Google Sheet link | "Add Products" / "Update Scraping Schedule" buttons | "Import" on Products; "Update Scraping Schedule" goes to Products (tick rows > Edit selected) |
| `current_user` (Retool auth) | Avatar in sidebar footer, nothing else | Own sign-in: `APP_USERS` (scrypt hashes) + `AUTH_SECRET` signed cookie |

## 2. Database

Tables (read from every query and workflow):

| Table | Columns used | Notes |
|---|---|---|
| product_categories | category_id, name, is_active, created_at, updated_at | soft delete via is_active |
| products | product_id, name, description, category_id, brand, hana_code, ph, mrp, gst_percent, direct_discount, dealer_landing, is_active, regular_scraping, scheduled_scraping, scraping_schedule_weekly, months_to_scrape, scraping_schedule_monthly, scheme_1..3, total_scheme, net_landing, dp_margin_percent, retail_margin_percent, retail_margin, mop, mop_scheme, trigger_price_percent, trigger_price, created_at, updated_at | The sheet sync never writes total_scheme, net_landing, retail_margin, mop, mop_scheme, trigger_price; they may be generated columns in Retool DB. The server reads `information_schema.columns.is_generated` and never writes generated columns. |
| product_links | product_link_id, product_id, channel_name, url, is_active, created_at, updated_at | unique (product_id, channel_name) |
| scrape_runs | run_id, created_at, run_date, status, type, channel_name | status Started / In Progress / Done (+ Failed) |
| scrape_run_batches | scrape_batch_id, scrape_run_id, channel_name, batch_number, batch_total_count, product_link_ids int[], status, attempt_count, locked_at, started_at, completed_at, error_message, created_at, updated_at | queue |
| scrape_results | scrape_result_id, price, mrp, discount, rating, reviews, seller, availability, product_link_id, scrape_run_id, created_at | unique (scrape_run_id, product_link_id) |
| mop_breach_reports | report_id, report_date, channel_name, total_products, breached_products, generated_by, generated_at, remarks, file_url | |
| **new** mop_breach_report_items | item_id, report_id, product_link_id, product_id, product_name, brand, category_name, price, mop, gap, seller, url, scraped_at | lines of a generated report, so the Excel is rebuilt on demand instead of a stored file |
| **new** audit_log | id, at, txid, actor, ip, user_agent, table_name, row_pk, action, old_data, new_data, restored_at, restored_by | trigger on every table |

Indexes on every foreign key / lookup column: products(category_id), products(is_active), product_links(product_id),
product_links(channel_name, is_active), scrape_results(product_link_id, created_at desc), scrape_results(scrape_run_id),
scrape_results(created_at), scrape_run_batches(scrape_run_id), scrape_run_batches(status, created_at, batch_number),
scrape_runs(run_date desc), mop_breach_reports(channel_name, report_date desc), mop_breach_report_items(report_id), plus
lower(name) / brand for search.

Startup (`server/schema.ts`): `create table if not exists` for missing tables only; `information_schema` check before
every `alter table … add column`; `set local lock_timeout = '3s'` around schema and trigger setup; triggers only
(re)created when missing or out of date; demo seed only when the database has no tables at all.

## 3. Screens -> pages

Sidebar keeps Retool's grouping: **Dashboard**; **PRODUCTS**: Product Categories, Products; **SCRAPING**: Scraping,
Scrape Product Results, MOP Breach Reports, Scrape Run Results. One extra group **SYSTEM**: Audit log.
Browser tab title on every page: `MDAPL Price Tracker`.

### 3.1 Dashboard (`Dashboard` screen) -> `#/`

| Retool element | New |
|---|---|
| Heading "Dashboard", divider | PageHeader "Dashboard" |
| Button "View Proxy Jet Balance" -> opens app.proxyjet.io | "Decodo Proxy Balance" -> dashboard.decodo.com |
| DateRange `dashboardDateRange` (default last 7 days -> today) | Themed DateRange, kept in the URL (`from`, `to`), same default |
| tabbedContainer4: tabs Amazon / Flipkart / Instamart / Zepto with 4 statistics | Channel tabs (`channel` in URL) + StatStrip, per channel: **Products breached** (latest price in range < MOP; the Retool tile pointed at a query that does not exist), **Unique products scraped** (`totalProductsScraped`: distinct links with a result in the range), **MOP breach rate** (breached / scraped; Retool tile pointed at a missing `activeChannels` query), **Links available** (`getAllProductLinks` count for the channel). The Retool tiles were only filled for Amazon; the new tiles work for every channel. |
| `averagePriceDrop` query (not bound in Retool) | Extra tile "Avg price change, last 7 days" |
| Line chart "Price Trend Over Time" (manual sample data; `linechartQuery` filters by a missing `category_filter`) | Real data from `linechartQuery` with a themed category picker (`category` in URL) |
| Bar chart "Channel Comparison" (`barchartQuery`: avg price per channel) | Bars, same query, limited to the date range |
| Line chart "Discount Over Time" (`avgDiscountOverTime`) | Line chart, same query, limited to the date range |
| Pie "Category Distribution" (`pieChartQuery`) | Donut-free split bar + legend (reference `Split`), same query |
| `query6` (JSON.stringify debug) | Dropped (debug only) |
| — | Integration pills top right: Database, Browserless, Proxy, one line |

Endpoint: `GET /api/dashboard?from&to&channel&category` (all queries in one `Promise.all`).

### 3.2 Product Categories (`productCategories` screen) -> `#/categories`, `#/categories/:id`

| Retool | New |
|---|---|
| `getProductcategories` (active, newest first) | `GET /api/categories?status&q&offset` (paged in SQL, counts per status) |
| Statistic "Total Product Categories" | StatStrip: categories, products in them, links |
| Search box `productCategoryTableSerachInput` (debounced, in URL) | Search in the filter bar (`q` in URL) |
| Table: S.NO, Name, Manage | Table: #, Name, Products, Active links, Updated; row opens detail |
| Toolbar Filter / Download / Refresh | Export menu (Excel with totals, CSV, Print), refresh on focus |
| "Add Product Category" -> `addProductCategoriesModal` -> `saveCategories` (disabled while empty) | "New category" dialog, `POST /api/categories` (name required, unique check) |
| "Manage" -> `editProductCategoryModal` -> `updateCategories` | Detail page: rename (`PATCH /api/categories/:id`), deactivate/reactivate, products in this category |
| — | Status tabs Active / Inactive / All (Retool only showed active) |

### 3.3 Products (`products` screen) -> `#/products`, `#/products/new`, `#/products/:id`

| Retool | New |
|---|---|
| `getProducts` (active products + category name) | `GET /api/products` paged in SQL (100 + Show more), filters brand, category, channel link, search, status tabs Active / Inactive / All |
| Statistic "Total Products" | StatStrip: products, with Amazon link, with Flipkart link, missing links |
| Select Brand / Category (uniq of loaded rows), search by name | Themed selects fed by light name-only endpoints (`/api/lookups/brands`, `/api/lookups/categories`), all in the URL |
| Table: S.NO, Name, Brand (tag), Category (tag), Hana code, MRP (INR), Manage, Amazon link, Flipkart link | Table: Name, Brand, Category, Hana code, MRP, MOP, Amazon / Flipkart link pills (open link in a new tab), row opens the product |
| "Add Products" -> opens the Google product sheet | "Add product", "Import", "Product master" download |
| "Sync Products" (no handler in Retool) | Runs the **Bulk Upsert Product Data** workflow: `POST /api/sync/products` |
| `addProductsModal` (+ `saveProducts`, `saveProductLinkJS`, `saveproductLinks`; not reachable in Retool) | "New product" page, `POST /api/products` (product + Amazon/Flipkart/Instamart/Zepto links in one transaction) |
| `editProductModal` (+ `updateProducts`, `updateProductLinkJs`, `updateProductLink`, `getProductLinks`) | Product detail page with sections Details, Product links, Scraping schedule, Product attributes (schemes), Pricing details; Save -> `PATCH /api/products/:id` (product + links upserted per channel in one transaction) |
| Edit modal fields that `updateProducts` never saved (regular scraping, weekly days, months, schemes, MOP, trigger price…) | Saved now (except generated columns) |
| "Delete" button (no handler; `deleteProducts` soft-deletes) | Delete with confirm dialog -> `DELETE /api/products/:id` (is_active = false, restorable in Audit log) |
| `modalFrame1` (links table, never opened) | "Product links" card on the detail page with link status and last scrape |
| — | "Price history" card: latest result per channel and recent scrapes |
| query3 / query4 (debug) | Dropped |

### 3.4 Scraping (`Scraping` screen) -> `#/scraping`

| Retool | New |
|---|---|
| Heading "Channel Scraping", "Update Scraping Schedule" (opens sheet) | Same button, opens Products for bulk schedule edit |
| Tabs Amazon / Flipkart / Instamart | Channel tabs Amazon / Flipkart / Instamart / Zepto (`channel` in URL) |
| Statistic "Total Links Available" (per channel) | StatStrip: links, active links, scraped today, never scraped |
| Brand / Category selects, product name search | Filter bar (URL) |
| `getChannelProductLinks` table, multi-select | Paged links table with row checkboxes; selection survives Show more |
| "Scrape Amazon Links" / "Scrape Flipkart Links" -> `scrapeAmazonLinks` / `scrapeFlipkartLinks` workflow run + notification + clear selection | "Scrape selected" -> `POST /api/scrape/on-demand` (creates an `On Demand` run + batches of the selected links, starts processing). Retool sent product_ids under a `products` key the workflow never read; the new call sends the link ids. Toast "Scraping N links started" with a link to the run. Retool's text promised an email that no workflow sends; the toast points to Scrape Run Results instead. |
| Instamart tab "Scrape Instamart Links" (no handler) | Instamart/Zepto: only channels with a scraper can start a run (Amazon, Flipkart, Zepto, Myntra scripts exist; Instamart has none) |
| — | "Start full run" -> **Create Scrape Run + Batches** workflow: `POST /api/scrape/runs` {channel, batch_size 1–45, mode all, run_type Manual} |

### 3.5 Scrape Product Results (`scrapeProductResults`) -> `#/results`, `#/results/:linkId` (split view)

| Retool | New |
|---|---|
| `getScrapeResults` (latest result per link inside the date range, active products and links, one channel) | `GET /api/results?channel&from&to&brand&category&product&q&availability&offset` — same latest-per-link logic, paged and counted in SQL |
| DateRange `dateRange1` (empty -> "Please select date…") | DateRange in URL, default last 7 days |
| Tabs Amazon / Flipkart / Zepto (Coming soon) / Instamart (Coming soon) | Channel tabs with counts; channels without data show the empty state |
| "{Channel} Links: N" | Headline numbers: results, in stock, out of stock / unavailable, below MOP, avg discount |
| Brand / Category / Product selects | Filter bar (URL), product select narrowed by category as in Retool |
| Table columns: Product, Brand, Category, Seller, Price, Availability, Scraped MRP, Scrape timestamp, URL, Dealer landing, Base MRP, Hana code, PH, Direct discount, Rating, Reviews, GST | Left list (product, price, availability pill, seller); right panel: the full record with every column above + price history of that link across the range |
| "Export to Excel" (sheet = channel, file `scrape_results_{channel}_{date}`) | Export menu (Excel/CSV/Print) with all columns, fetches every matching row on demand |
| "Generate MOP Breach Report" (in Retool just exported the same Excel) | Builds a real report: `POST /api/mop-reports` -> stores the report + breach lines, downloads its Excel |

### 3.6 MOP Breach Reports (`mopBreachReport`) -> `#/mop-reports`, `#/mop-reports/:id` (split view)

| Retool | New |
|---|---|
| `getAllMOPBreachReports` | `GET /api/mop-reports?channel&from&to&q&offset` (paged) |
| Date picker `date2` (not wired to the tables) | DateRange filter that works |
| Tabs Amazon / Flipkart / Instamart (filter channel_name) | Channel tabs All / Amazon / Flipkart / Instamart / Zepto with counts |
| Columns: Report date, Channel, Total products, Breached products, Generated by, Generated at, Remarks, "Download Report" (file_url) | Left list; right panel with the report, breach lines, remarks edit, Download (stored file_url for legacy reports, else Excel rebuilt from the lines) |

### 3.7 Scrape Run Results (`scrapeRunResults`) -> `#/runs`, `#/runs/:id` (split view)

| Retool | New |
|---|---|
| `getScrapeRunResults` (all runs) | `GET /api/runs?status&channel&type&from&to&offset` (paged, newest first) |
| DateRange `runDateFilter` (run_date >= start, <= end), Multiselect channel (placeholder options) | DateRange + channel + type filters (URL), status tabs Started / In Progress / Done / Failed |
| Columns Run date, Status, Created at, Type, Channel, "Details" (empty modal), "Download Report" (no handler) | Left list with status pills; right: run details, batches (status, attempts, errors), results of the run, Download report (Excel of the run's results), Retry failed batches |
| editProductModal3 / addProductsModal3 / modalFrame3 (copies bound to queries that do not exist) | Dropped (unreachable) |

### 3.8 New pages

* **Sign in** `#/login`: brand panel, email + password, show/hide, Caps Lock warning.
* **Audit log** `#/audit`: tabs All changes / Deleted, filters (record type, change, who, record #, date range), change
  detail dialog (who, device, IP, time, field-by-field before/after), restore deletions within 30 days.

## 4. Queries -> endpoints

| Retool query | Endpoint / server function |
|---|---|
| getProductcategories | `GET /api/categories`, `GET /api/lookups/categories` |
| saveCategories / updateCategories | `POST /api/categories`, `PATCH /api/categories/:id` |
| getProducts | `GET /api/products` |
| saveProducts + saveProductLinkJS + saveproductLinks | `POST /api/products` |
| updateProducts + updateProductLinkJs + updateProductLink | `PATCH /api/products/:id` |
| deleteProducts | `DELETE /api/products/:id` |
| getProductLinks | `GET /api/products/:id` (links included) |
| getAllProductLinks, getChannelProductLinks | `GET /api/links?channel…`, counts in `/api/dashboard` |
| totalProductsScraped, averagePriceDrop, linechartQuery, barchartQuery, avgDiscountOverTime, pieChartQuery | `GET /api/dashboard` |
| getScrapeResults | `GET /api/results`, `GET /api/results/:linkId` |
| getAllMOPBreachReports | `GET /api/mop-reports`, `GET /api/mop-reports/:id` |
| getScrapeRunResults | `GET /api/runs`, `GET /api/runs/:id` |
| scrapeAmazonLinks / scrapeFlipkartLinks (WorkflowRun) | `POST /api/scrape/on-demand` |
| query1..query6 (JS debug helpers) | Dropped |

## 5. Workflows -> server jobs

| Retool workflow | New |
|---|---|
| **Create Scrape Run + Batches** (webhook: channel_name, batch_size ≤45, mode, run_type) | `server/jobs/runs.ts createRun()`; `POST /api/scrape/runs` (UI) and `POST /api/hooks/create-run` (CRON_SECRET) |
| **Process Next Product Scrape Batch** (claim one batch, 30-min lock, route by channel, mark done, close run) | `server/jobs/batches.ts processNextBatch()` with the same SQL (`FOR UPDATE SKIP LOCKED`, stale lock 30 min); Vercel Cron `GET /api/cron/process-batch` daily (Hobby limit) as a safety net; the worker chains itself (`POST /api/hooks/process-batch`) while batches are pending, and is also kicked right after a run is created |
| **Batch Scraping of Products** (scheduled run per channel, 45 per batch, type Scheduled) | `GET /api/cron/scheduled-runs` daily (creates Amazon + Flipkart runs, batch 45, type Scheduled) |
| **Scrape Amazon / Flipkart / Myntra / Zepto Product Links** + subflow (Browserless script per channel, In Stock check, insert result, "No Data" row when not in stock, run status Done/In Progress) | `server/scrape/channels/*.ts` (scripts ported verbatim, credentials from env), `scrapeLink()` + `saveResult()` with the same rules (Amazon/Myntra/Zepto: not "In Stock" -> price 0, seller "No Data", availability "Currently Unavailable"; Flipkart: upsert on (run, link)) |
| **Bulk Upsert Product Data** (Google Sheet -> products + links upsert, then write Products_Append) | `POST /api/products/import` (`server/routes/productImport.ts`): same upsert from an uploaded file, with a preview |

Vercel function time: a batch scrapes links with concurrency 4 inside a 270 s budget; anything left stays in the
batch for the next tick (`attempt_count` grows; error recorded).

## 6. Design mapping (reference -> this app)

| Element | Reference | Here |
|---|---|---|
| Tokens | globals.css @theme | Same neutrals, status map, shadows, radii; brand = navy `#0f1b3d`/ink `#111827`; accent `#3170f9` only as `accent-soft` (#eef3ff) for selected row / active nav / selected tab count |
| Typography | Inter, 13.5 body, 20 page title, 14 card title, 15 dialog title, 22 KPI | Same (Inter via Google Fonts) |
| Buttons | .btn / .btn-primary / .btn-ghost / .btn-danger, 36 px, 32 px in tables | Same; primary = ink/navy |
| Focus | 2 px brand outline | 2 px neutral ink outline, neutral field ring |
| Inputs, dropdowns, date pickers | ui/Select, ui/DateInput, ui/DateRange, useFloating | Ported; never native |
| Tabs | .seg | One size everywhere, counts in neutral pill |
| Filter bar | FilterBar | Live filters (URL), Clear when active |
| Stat strip | StatStrip | Same; equal-height card |
| Tables | DataTable (hairline columns, totals, Export, Print, row actions, empty states) | Same; spare width goes to the widest text column (no blank filler column); "Show more" paging |
| Status | badge + dot | Pill: dot + soft fill + hairline; normal states neutral, amber/red only for attention |
| Notices | Notice | Same, page-level only, no global banners |
| Dialogs | Modal / ConfirmDialog | Same |
| Empty states | EmptyState | Same wording rules (nothing yet / filters hiding rows) |
| Sidebar | maroon, gold group heads, active = white/15 | navy, white/50 group heads, active = white/12, no side bars |
| Sign-in | AuthShell + SignInForm + PasswordField | Same structure in MDAPL navy |
| Audit log | page.tsx + AuditRow + audit SQL | Same SQL model; detail as a dialog |
| Charts | Charts.tsx | Bars, Split, plus a small SVG line chart |
| Dates | "09 Oct 2026", IST | Same `format.ts` |
| Export | exportTable.ts (exceljs) | Same, fed by an "all matching rows" endpoint |

## 7. Data migration

`scripts/migrate-retool-to-supabase.sh`: pg_dump 17 of the Retool DB to a file, rewrite `CREATE FUNCTION` to
`CREATE OR REPLACE FUNCTION`, restore with psql into Supabase (direct connection, port 5432), enable RLS on every
table, then print row counts per table old -> new.

## 8. Verification

Playwright script `scripts/verify.mjs`: every page at 1440 px and 390 px (screenshots in `docs/screenshots/`), and the
main flows end to end in demo mode: sign in, add category, add product with links, edit and delete product, restore it
from the Audit log, start a scrape run, process batches, open results, generate a MOP breach report, export Excel.

## Changes after the 1:1 port

- Daily scheduled run honours regular / scheduled scraping, weekdays, months and monthly dates (`shared/schedule.ts`); Retool queued every active link.
- MOP breach = scraped price below the trigger price (else MOP scheme, else MOP), one rule for dashboard, results, runs, reports and product pages.
- Google Sheet replaced by Products > Import / Product master / Edit selected; pricing calculated in `shared/pricing.ts`.
