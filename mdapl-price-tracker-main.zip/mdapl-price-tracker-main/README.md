# MDAPL Price Tracker

Custom-coded replacement for the Retool app "Product Price Tracker" and its 8 workflows: products and categories,
channel links, scraping runs (Browserless + residential proxy), scrape results per channel, MOP breach reports,
product import / bulk edit (replacing the Google product sheet), and an audit log of every change.

`docs/PLAN.md` maps every Retool screen, query, workflow and resource to its page, endpoint or job here.

## Stack

- React 18, TypeScript, Vite, Tailwind 4, TanStack Query, react-router (HashRouter), lucide-react
- One Vercel function (`api/main.ts`) routing to `server/routes/*`; Postgres through `pg` (Supabase transaction pooler)
- No `DATABASE_URL`: PGlite with realistic demo data (local development)

## Run locally

```bash
npm install
npm run dev          # API on :3001 (PGlite demo data), app on http://localhost:5173
```

Sign in with `demo@mdapl.local` / `demo1234` (demo mode only). In demo mode, scraping without a Browserless token
produces simulated prices so the whole flow can be tried. Copy `.env.example` to `.env` to point at a real database
or services.

Checks:

```bash
npm run typecheck
npm run build
node scripts/verify.mjs      # end-to-end run of the main flows (needs npm run dev)
node scripts/screens.mjs     # screenshots of every page, desktop and phone, into docs/screenshots
```

## Deploy (Vercel)

1. Import the repository in Vercel (framework: Vite; `vercel.json` sets the build, the `/api` rewrite, the function
   region `bom1` (Mumbai) and the crons). Put the function region next to the database: if the Supabase project is not
   in `ap-south-1`, change `regions` in `vercel.json` to the matching Vercel region.
2. Set the environment variables below (Production and Preview).
3. Copy the data (next section), then deploy. On first start the app adds what it needs (audit log, indexes,
   triggers, missing columns) without locking tables, and never seeds demo data into a database that has tables.

### Environment variables

| Variable | What it is | Where to get it |
|---|---|---|
| `DATABASE_URL` | Supabase **transaction pooler** URI, port 6543 | Supabase > Project Settings > Database > Connection string > Transaction pooler |
| `APP_USERS` | The first admin account(s), JSON with scrypt hashes | Run `npm run hash-password -- someone@mdapl.in "Full Name" admin` and put the printed object(s) in an array: `[{...}]`. Only used to create accounts that do not exist yet; after that, people are managed in the app (user menu > Team & access). |
| `AUTH_SECRET` | Signs the session cookie | `openssl rand -hex 32` |
| `CRON_SECRET` | Lets Vercel Cron call the queue worker | `openssl rand -hex 32` (Vercel sends it automatically to the crons) |
| `BROWSERLESS_URL` | Browserless base URL of your region | Browserless dashboard (same account as the Retool "Browserless v3" resource) |
| `BROWSERLESS_TOKEN` | Browserless API token | Browserless dashboard > API key |
| `SCRAPE_PROXY_SERVER` | Proxy for the browser, e.g. `http://in.decodo.com:10000` | Decodo (Smartproxy) dashboard > residential proxy endpoint |
| `SCRAPE_PROXY_USERNAME` / `SCRAPE_PROXY_PASSWORD` | Proxy login | Decodo dashboard > proxy users. **The Retool export had these written into the scraper scripts in plain text: create new ones and disable the old ones.** |
| `SCRAPE_DIRECT_CHANNELS` | Channels read from the scraping server's own address instead of the proxy, e.g. `instamart,zepto`. Their bot check hands the browser a test to pass and reload, and refuses it when the reload comes from a different address, which is what a rotating residential proxy does. Amazon and Flipkart keep the proxy. |
| `PROXY_DASHBOARD_URL` | Optional: link behind "Decodo Proxy Balance" on the dashboard | Defaults to https://dashboard.decodo.com/ |
| `SCRAPE_CONCURRENCY` | Optional: browsers open at once on Browserless, for all runs together (default 1: one link at a time) | Raise it only if the Browserless droplet is made bigger (about 1 per GB of RAM, and its `CONCURRENT` setting must allow it) |
| `SUPPORT_HUB_URL` | Help and support: the SBD support hub's address, e.g. `https://sbdsupport.vercel.app` | SmallBay Digital |
| `SUPPORT_HUB_KEY` | Help and support: this app's project key (Sensitive) | The hub's **Projects** page > Add project (the key is shown once) |

### Sign-in secrets from GitHub (optional)

Instead of creating `AUTH_SECRET`, `CRON_SECRET` and `APP_USERS` by hand, run **Actions > Set up Vercel sign-in**.
It writes them straight into the Vercel project's environment variables and never shows them in the log.

1. Add repository secrets: `VERCEL_TOKEN` (Vercel > Account Settings > Tokens), `VERCEL_PROJECT_ID`
   (Project > Settings > General), `VERCEL_TEAM_ID` (Team Settings > General; skip for a personal account).
2. Run it with `secrets` once: creates `AUTH_SECRET` and `CRON_SECRET` (kept on later runs unless `rotate`).
3. For each person: set the repository secret `USER_PASSWORD` to their password, then run `add_user` with their
   email, name and role. `remove_user` takes someone out; `list_users` shows who can sign in.
4. Redeploy in Vercel so the new values are used.

### Scraping schedule

`vercel.json` runs two daily crons (Vercel Hobby allows one run per day per cron):

- `/api/cron/scheduled-runs` at 00:30 UTC (6:00 AM IST): creates the scheduled Amazon and Flipkart runs
  (45 links per batch), like the Retool "Batch Scraping of Products" workflow, and starts working the queue.
- `/api/cron/process-batch` at 01:00 UTC (06:30 IST): a safety net that picks up anything still queued, including
  batches whose lock went stale.

The daily automatic run can be paused and switched back on from **Channel Scraping** (the banner at the top). While
paused, the 06:00 cron creates no run; on-demand and full runs still work. It starts paused after this update.

A single run can be paused and resumed from its page in **Scrape Run Results**: pages already loading finish, no new
link starts, and Resume carries on where it stopped. **Retry failed links** puts only the links without a price back in
the queue. Each page may take up to 270 s (a Vercel function runs at most 300 s), and a link that times out is tried once more
before it counts as failed; the run page lists every failed link with the reason in plain words.

For local testing, `SIMULATE_FAIL_RATE=0.5` (demo mode only) makes that share of simulated pages time out.

The queue does not wait for the next cron: each invocation works batches for about 4 minutes, and if batches are
still pending it hands over to a fresh invocation of `/api/hooks/process-batch` (authenticated with `CRON_SECRET`),
until the queue is empty. Runs started from the app begin the same way right away. `CRON_SECRET` must be set for
this hand-over. On Vercel Pro you can set the process-batch cron back to every few minutes (`*/5 * * * *`) as an
extra safety net.

## Copy the Retool database to Supabase

### 1. Get the two connection strings

**OLD_DATABASE_URL (Retool Database)**
1. In Retool, open **Database** (Retool Database) in the top bar.
2. Open **Settings** (or the **Connect** / connection details panel of the database).
3. Turn on external connections if Retool asks, then copy the **PostgreSQL connection string**, e.g.
   `postgresql://retool:PASSWORD@ep-xxxx.us-west-2.retooldb.com/retool?sslmode=require`.
   If it is shown as separate fields, build it as `postgresql://USER:PASSWORD@HOST:PORT/DATABASE?sslmode=require`.

**NEW_DATABASE_URL (Supabase)**
1. In the Supabase dashboard, open the project and click **Connect** (top bar).
2. Choose **Session pooler** (port 5432), copy the URI, e.g.
   `postgresql://postgres.abcdefgh:[YOUR-PASSWORD]@aws-0-ap-south-1.pooler.supabase.com:5432/postgres`.
3. Replace `[YOUR-PASSWORD]` with the database password (Project Settings > Database > Reset database password if
   unknown). If the password has characters like `@ : / ? # %`, URL-encode them (`@` -> `%40`).

Use the Session pooler here, not the Transaction pooler (6543) and not Direct connection (IPv6 only, which GitHub
runners cannot reach). The app itself later uses the Transaction pooler as `DATABASE_URL`.

### 2. Run it from GitHub (no local setup)

1. GitHub repo > **Settings** > **Secrets and variables** > **Actions** > **New repository secret**: add
   `OLD_DATABASE_URL` and `NEW_DATABASE_URL` with the strings above.
2. **Actions** > **Migrate Retool DB to Supabase** > **Run workflow**:
   - `check` first: tests both connections and lists the Retool tables with row counts. Nothing is written.
   - then `migrate`: dumps, restores in one transaction, enables RLS on every table, prints row counts old -> new
     (the run fails if any count differs). It refuses a Supabase project that already has tables unless `force`.
3. Remove the two secrets afterwards if you like; the app does not use them.

### Or run it on your own machine

```bash
export OLD_DATABASE_URL='postgresql://...retool...'
export NEW_DATABASE_URL='postgresql://...supabase session pooler...:5432/postgres'
./scripts/migrate-retool-to-supabase.sh
```

The script needs `pg_dump`/`psql` 17 (`PG_BIN=/usr/lib/postgresql/17/bin` if they are not first on PATH). It dumps
to a file in `migration-dumps/` first, turns functions into `CREATE OR REPLACE`, restores in one transaction, enables
row level security on every table, and prints the row count of every table, old against new.

## Audit log

A database trigger on every table records who (the signed-in user, or the scraper / scheduler), the device, the IP
address, the time and the field-by-field before/after of every insert, edit and delete. Admins see it under
System > Audit log, open any change in a dialog, and restore deletions for 30 days (everything deleted in the same
action comes back together).

## Products without the Google sheet

The app is the product master; the Google sheet is no longer read or written.

- **Pricing is calculated**: MOP = dealer landing x (100 + DP margin %), total scheme = scheme 1 + 2 + 3, net landing = dealer landing - total scheme,
  retail margin = net landing x retail margin %, MOP scheme = net landing + retail margin, trigger price = MOP scheme x (100 - trigger %).
  Change a % or a price and the rest follows (product page, bulk edit, import).
- **Products > Product master** downloads every product in the old sheet's columns.
- **Products > Import** takes that file (or the old sheet, a price list with HANA code / MRP / DP, or a HANA code + Amazon / Flipkart link list):
  pick the tab, check the column mapping, preview every change, then apply. Rows match on product_id, else HANA code; a blank cell changes nothing.
  When an old row has a blank % but a hard-coded margin (`=V2*0.2`), the % is worked out from the sheet's value so prices stay the same.
- **Products > tick rows > Edit selected** sets category, brand, PH, status, scraping schedule or any % on many products at once.

## Scraping schedule and MOP breaches

The daily scheduled run (06:00 IST, Vercel cron) takes, per channel, the active links of active products that are due today
(`shared/schedule.ts`, shown as "Due in today's scheduled run" on Scraping and as "Next scheduled scrape" on each product):

- **Regular scraping** ticked: every day.
- **Scheduled scraping** ticked: on the chosen weekdays (MON..SUN = 1..7) or monthly dates (30/31 fall on the month's last day),
  only in the chosen months (none = every month). No days and no dates = every day of those months.
- Neither: not in the daily run. "Start full run" (every active link, or only those due today) and on-demand scraping still take it.

Retool's "Batch Scraping of Products" ignored these fields and queued every active link; they are honoured now.

A price is a **MOP breach** when it is below the product's trigger price (MOP scheme less the trigger %), falling back to the MOP scheme,
then the MOP (`alertPrice` in `shared/pricing.ts`, `ALERT_PRICE` in `server/sql.ts`). Retool's "Generate MOP Breach Report" only exported results.

## Help and support

**Help and support** (bottom of the menu, above the signed-in user) is where people report a problem, ask a question
or ask for a change, follow the status and talk to the SmallBay Digital team in one thread. Requests are not stored
in this app: its server passes every `/api/support/*` call to the SBD support hub (`techatsbd/support`) with the
project key and the signed-in user's email and name; the team answers from the hub's Inbox. The key never reaches the
browser. Without `SUPPORT_HUB_URL` and `SUPPORT_HUB_KEY` the pages say "Support isn't connected yet".

To try it locally, run the hub with `npm run dev` in `techatsbd/support` (sample data; its sample key is
`sbd_demo_ssallp`) and start this app's API with `SUPPORT_HUB_URL=http://localhost:5173 SUPPORT_HUB_KEY=sbd_demo_ssallp`
(use the port the hub prints).

## Accounts and the user menu

The menu at the foot of the sidebar shows who is signed in and their role, and holds:

- **Team & access** (admins, also under System): add a person (name, work email, Staff or Admin), change a role, switch access off or on,
  or reset a forgotten password. New people and resets get a 14-character temporary password, shown once to the admin with a ready-to-send
  message; the person must choose their own password before anything else works (the API refuses other calls until then).
  Switching access off or resetting a password signs the person out everywhere. You cannot switch off yourself or remove the last admin.
- **Scraper connection** (admins): whether Browserless and the Decodo proxy are set (hosts only, never keys) and **Test connection**, which
  opens Decodo's IP check through Browserless and the proxy and shows the exit IP and country (it should be India).
- **Change password**: signs out your other devices; this one stays signed in.
- **Sign out**.

Staff use products, scraping, results and reports; admins also see Team & access, the scraper connection and the Audit log.
Accounts are in the `app_users` table; every change is in the Audit log as "Team member", with password changes recorded as
"password: changed" and never the hash. `scripts/verify-team.mjs` tests the whole flow against the demo API.

## Error monitoring (Sentry)

One Sentry project, `smallbay-digital/mdapl-web`, for both sides; every event carries the tag `side=browser` or `side=server`.

- **Browser** (`src/lib/sentry.ts`, imported first in `main.tsx`, production builds only): crashes (the page shows "Something went wrong"
  with Reload; error boundaries report with the component stack), page-load timings for 1 visit in 10. Environment = the site's hostname.
- **Server** (`server/sentry.ts`, started when `api/main.ts` loads, on Vercel or when `SENTRY_DSN` is set): unexpected API errors (500s)
  tagged `route` = `METHOD /api/path/:id` and the database error code, scraper batches with failing links (one issue per channel and kind
  of failure), batches stopped after 5 attempts, background queue failures. Expected answers (validation, not found, signed out) are not
  reported, and API errors are not reported twice by the browser. The function waits for delivery (`Sentry.flush(2000)`) before it ends,
  only when something was reported.
- **Who**: the signed-in person's account id and email (and role as a tag). Nothing else personal is collected: no cookies, headers, request
  bodies, SQL parameters, or search terms (also cut from the part of the address after `#`).
- **DSN**: in the code (a DSN only allows sending events; it is not a secret). `VITE_SENTRY_DSN` (build) and `SENTRY_DSN` (server) override it;
  an empty value switches that side off.
- **Releases**: events carry the Git commit (`VERCEL_GIT_COMMIT_SHA`).
- **Readable browser stack traces (optional)**: `SENTRY_AUTH_TOKEN` in the Vercel build environment uploads source maps to `mdapl-web`
  and removes them from the output.
- **Alerts**: "mdapl-web: email tech@ on new or returning errors" emails tech@smallbaydigital.com (new issue, regression, reappeared; 5 minutes).
- **Test**: user menu > Scraper connection > Error monitoring > **Send test errors** sends one browser and one server error; resolve them after.

## Products sheet, schedules and PDF

- **Products** is the product master as an editable sheet with every column of the old Google Sheet (product, scraping schedule, pricing,
  channel links). Click a cell to edit: Enter saves and moves down, Tab saves and moves right, Esc cancels, arrow keys move. Editors per
  column: dropdown (category, GST, status), type-ahead (brand, PH), tick box (regular / scheduled scraping), multiple choice (weekdays,
  months, monthly dates), number (prices, %) and link (Amazon, Flipkart, Instamart, Zepto, each in its own soft colour). Columns marked
  *calc* (MOP, total scheme, net landing, retail margin, MOP scheme, trigger price) are recalculated by the server on every save. Each
  save is one audited change. `scripts/verify-products.mjs` tests it.
- **Scraping > Update Scraping Schedule** opens the schedule (regular, scheduled, weekdays, months, dates) for the products behind the
  ticked links, or behind every link in the current list when none is ticked.
- **PDF**: every Export menu has PDF (A4 landscape: logo, title, filters, time, yellow header on every page, ₹ amounts, totals, clickable
  links, page numbers), and MOP breach reports, scrape runs and "Generate MOP Breach Report" offer Excel or PDF. jsPDF and the Inter font
  (`public/fonts`, SIL Open Font License, subset with the ₹ sign) load only when a PDF is made.
