import type { IncomingMessage, ServerResponse } from "node:http";
import { gzipSync } from "node:zlib";
import type { User } from "./auth.js";
import type { Actor } from "./db.js";

export type Req = {
  method: string;
  path: string;
  params: string[];
  query: URLSearchParams;
  body: any;
  headers: IncomingMessage["headers"];
  ip: string;
  user: User | null;
  /** The signed-in user as the audit trigger records them. */
  actor: Actor;
};

export type Res = { status?: number; body?: unknown; headers?: Record<string, string>; raw?: Buffer | string; contentType?: string };

/** An error whose message is safe to show the person (validation, not found, conflicts). */
export class HttpError extends Error {
  constructor(public status: number, message: string) { super(message); }
}
export const bad = (m: string) => new HttpError(400, m);
export const notFound = (m = "This record does not exist, or was deleted.") => new HttpError(404, m);

/** The JSON body; 2 MB at most, unless the route allows more (support attachments: 5 MB). */
export async function readBody(req: IncomingMessage & { body?: unknown }, max = 2_000_000): Promise<any> {
  if (req.body !== undefined) return typeof req.body === "string" ? safeJson(req.body) : req.body;
  if (req.method === "GET" || req.method === "HEAD") return undefined;
  const chunks: Buffer[] = [];
  let size = 0;
  for await (const c of req) { size += (c as Buffer).length; if (size > max) throw bad("The request is too large."); chunks.push(c as Buffer); }
  return chunks.length ? safeJson(Buffer.concat(chunks).toString("utf8")) : undefined;
}
const safeJson = (s: string) => { try { return JSON.parse(s); } catch { throw bad("The request body is not valid JSON."); } };

export function clientIp(req: IncomingMessage): string {
  const f = req.headers["x-forwarded-for"];
  return (Array.isArray(f) ? f[0] : f)?.split(",")[0].trim() || req.socket?.remoteAddress || "";
}

/** JSON out, gzipped when the client accepts it and it is worth it (Vercel caps responses at 4.5 MB). */
export function send(req: IncomingMessage, res: ServerResponse, r: Res) {
  const status = r.status ?? 200;
  let body: Buffer;
  let type = r.contentType ?? "application/json; charset=utf-8";
  if (r.raw !== undefined) body = Buffer.isBuffer(r.raw) ? r.raw : Buffer.from(r.raw);
  else body = Buffer.from(JSON.stringify(r.body ?? null));
  const headers: Record<string, string> = { "Content-Type": type, "Cache-Control": "no-store", ...(r.headers ?? {}) };
  if (body.length > 1024 && /\bgzip\b/.test(String(req.headers["accept-encoding"] ?? "")) && !headers["Content-Encoding"]) {
    body = gzipSync(body, { level: 6 });
    headers["Content-Encoding"] = "gzip";
    headers["Vary"] = "Accept-Encoding";
  }
  headers["Content-Length"] = String(body.length);
  res.writeHead(status, headers);
  res.end(body);
}

/** Query-string helpers with validation. */
export const q = {
  str: (sp: URLSearchParams, k: string, max = 200) => { const v = sp.get(k)?.trim(); return v ? v.slice(0, max) : null; },
  int: (sp: URLSearchParams, k: string) => { const v = Number(sp.get(k)); return Number.isInteger(v) && v > 0 ? v : null; },
  date: (sp: URLSearchParams, k: string) => { const v = sp.get(k); return validDate(v) ? v : null; },
  offset: (sp: URLSearchParams) => { const v = Number(sp.get("offset")); return Number.isInteger(v) && v > 0 ? Math.min(v, 1_000_000) : 0; },
  /** "only=3,7,9": the ticked rows of a list (exports of a selection); null when absent. */
  only: (sp: URLSearchParams) => { const v = (sp.get("only") ?? "").split(",").map(Number).filter((n) => Number.isInteger(n) && n > 0).slice(0, 5000); return v.length ? v : null; },
  /** Page size: `limit` (10 to 200, default 25); exports send all=1 for every row. */
  limit: (sp: URLSearchParams) => { if (sp.get("all") === "1") return 20000; const v = Number(sp.get("limit")); return Number.isInteger(v) && v > 0 ? Math.min(Math.max(v, 10), 200) : 25; },
};

export const CHANNELS = ["amazon", "flipkart", "instamart", "zepto"] as const;
export type Channel = (typeof CHANNELS)[number];
export const channelOf = (v: string | null): Channel | null => (v && (CHANNELS as readonly string[]).includes(v.toLowerCase()) ? (v.toLowerCase() as Channel) : null);
export const CHANNEL_LABEL: Record<string, string> = { amazon: "Amazon", flipkart: "Flipkart", instamart: "Instamart", zepto: "Zepto", myntra: "Myntra" };

/** Today in India time, 'YYYY-MM-DD', and n days before. */
/** YYYY-MM-DD that is a real calendar day (2026-02-31 is not; Postgres would reject it with a 500). */
export function validDate(v: unknown): v is string {
  if (typeof v !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(v)) return false;
  const d = new Date(`${v}T00:00:00Z`);
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === v;
}

export function istDay(offsetDays = 0) {
  const d = new Date(Date.now() + 5.5 * 3600_000 - offsetDays * 86400_000);
  return d.toISOString().slice(0, 10);
}
