// Light name-only endpoints for dropdowns, and integration status for the dashboard pills.
import type { Route } from "../router.js";
import { isDemo, query } from "../db.js";
import { channelOf, q } from "../http.js";
import { scraperSettings, scraperStatus, testConnection } from "../scrape/browserless.js";
import { report, sentryOn } from "../sentry.js";

export const routes: Route[] = [
  {
    // User menu > Scraper connection (admins): what is set, never the secrets themselves.
    method: "GET", path: /^\/api\/meta\/scraper$/, access: "admin",
    handler: async () => ({ ...scraperSettings(), sentry: sentryOn, dashboardUrl: process.env.PROXY_DASHBOARD_URL || "https://dashboard.decodo.com/" }),
  },
  {
    // Scraper connection > Error monitoring: one server test event (side=server) to mdapl-web, to confirm reporting after a deploy.
    method: "POST", path: /^\/api\/meta\/sentry-test$/, access: "admin",
    handler: async (r) => {
      const host = String(r.headers["x-forwarded-host"] ?? r.headers.host ?? "").split(",")[0].trim() || undefined;
      report(new Error("Test error from Scraper connection (safe to resolve)"), { tags: { check: "manual", route: "POST /api/meta/sentry-test" }, user: { id: r.user!.id, email: r.user!.email, role: r.user!.role }, host });
      return { sent: sentryOn };
    },
  },
  {
    method: "POST", path: /^\/api\/meta\/scraper-test$/, access: "admin",
    handler: async () => testConnection(),
  },
  {
    method: "GET", path: /^\/api\/lookups\/categories$/,
    handler: async () => query("select category_id id, name from product_categories where is_active order by name"),
  },
  {
    method: "GET", path: /^\/api\/lookups\/brands$/,
    handler: async () => (await query<{ brand: string }>("select distinct brand from products where brand is not null and btrim(brand) <> '' order by 1")).map((r) => r.brand),
  },
  {
    // Product heads in use, for the PH type-ahead in the products sheet.
    method: "GET", path: /^\/api\/lookups\/phs$/,
    handler: async () => (await query<{ ph: string }>("select distinct btrim(ph) ph from products where ph is not null and btrim(ph) <> '' order by 1")).map((r) => r.ph),
  },
  {
    // Product names for a picker, optionally narrowed by category and channel (as the old product select was).
    method: "GET", path: /^\/api\/lookups\/products$/,
    handler: async (r) => {
      const cat = q.int(r.query, "category"), ch = channelOf(r.query.get("channel"));
      return query(`select p.product_id id, p.name from products p
        where p.is_active and ($1::int is null or p.category_id = $1)
          and ($2::text is null or exists (select 1 from product_links pl where pl.product_id = p.product_id and pl.channel_name = $2))
        order by p.name`, [cat, ch]);
    },
  },
  {
    // Day (IST) of the newest scrape: pages default their date range to end there when scraping has stopped. Read from the created_at index.
    method: "GET", path: /^\/api\/meta\/latest-scrape$/,
    handler: async () => {
      const [r] = await query<{ day: string | null }>("select ((max(created_at)) at time zone 'Asia/Kolkata')::date::text as day from scrape_results");
      return { day: r?.day ?? null };
    },
  },
  {
    method: "GET", path: /^\/api\/meta\/integrations$/,
    handler: async () => {
      const db = await query("select 1").then(() => true).catch(() => false);
      const s = scraperStatus();
      return [
        { key: "database", label: isDemo() ? "Database (demo)" : "Database", ok: db },
        { key: "browserless", label: "Browserless", ok: s.browserless },
        { key: "proxy", label: "Proxy", ok: s.proxy },
      ];
    },
  },
  {
    method: "GET", path: /^\/api\/meta\/config$/,
    handler: async () => ({
      proxyDashboardUrl: process.env.PROXY_DASHBOARD_URL || "https://dashboard.decodo.com/",
    }),
  },
];
