// Product links per channel (Scraping page: getChannelProductLinks / getAllProductLinks), and switching a link on or off or changing its address.
import type { Route } from "../router.js";
import { query, tx } from "../db.js";
import { bad, channelOf, istDay, notFound, q } from "../http.js";
import { IST_DAY, like } from "../sql.js";
import { isDue, type Schedule } from "../../shared/schedule.js";
import { cleanUrl } from "../productFields.js";

// $1 is a channel name, or 'all' for every channel (the Scraping page's All tab).
const WHERE = `($1::text = 'all' or pl.channel_name = $1)
  and ($2::text is null or p.name ilike $2 or pl.url ilike $2 or p.hana_code ilike $2)
  and ($3::text is null or lower(p.brand) = lower($3))
  and ($4::int is null or p.category_id = $4)
  and ($5::text = 'all' or ($5 = 'active' and pl.is_active and coalesce(p.is_active, false)) or ($5 = 'inactive' and not (pl.is_active and coalesce(p.is_active, false))))
  and ($6::text is null or ($6 = 'never' and s.last_at is null) or ($6 = 'today' and s.last_day = $7::date) or ($6 = 'stale' and (s.last_day is null or s.last_day < $7::date)))
  and ($8::int[] is null or pl.product_link_id = any($8::int[]))`;
// Last scrape of each link: one index lookup per link (scrape_results_link_created_idx), not a pass over every result.
const LAST_JOIN = `left join lateral (select x.created_at last_at, ${IST_DAY("x.created_at")} last_day from scrape_results x
  where x.product_link_id = pl.product_link_id order by x.created_at desc limit 1) s on true`;

export const routes: Route[] = [
  {
    method: "GET", path: /^\/api\/links$/,
    handler: async (r) => {
      const channel = r.query.get("channel") === "all" ? "all" : channelOf(r.query.get("channel")) ?? "amazon";
      const status = ["inactive", "all"].includes(r.query.get("status") ?? "") ? r.query.get("status") : "active";
      const scraped = ["never", "today", "stale"].includes(r.query.get("scraped") ?? "") ? r.query.get("scraped") : null;
      // Ticked rows (only=, exports of a selection) ignore the other filters.
      const only = q.only(r.query);
      const args = only ? [channel, null, null, null, "all", null, istDay(0), only]
        : [channel, like(q.str(r.query, "q")), q.str(r.query, "brand"), q.int(r.query, "category"), status, scraped, istDay(0), null];
      const limit = q.limit(r.query), offset = q.offset(r.query);
      const idsOnly = r.query.get("ids") === "1";
      if (r.query.get("ids") === "products") {
        // Update Scraping Schedule: the products behind the matching links (or behind the given link ids).
        const linkIds = (r.query.get("links") ?? "").split(",").map(Number).filter((n) => Number.isInteger(n) && n > 0);
        const ids = linkIds.length
          ? await query<{ id: number }>("select distinct product_id id from product_links where product_link_id = any($1::int[]) and product_id is not null order by 1", [linkIds])
          : await query<{ id: number }>(`select distinct pl.product_id id from product_links pl left join products p on p.product_id = pl.product_id ${LAST_JOIN} where ${WHERE} and pl.product_id is not null order by 1`, args);
        return ids.map((x) => x.id);
      }
      if (idsOnly) {
        // "Select all matching" on the Scraping page: just the ids, no rows.
        const ids = await query<{ id: number }>(`select pl.product_link_id id from product_links pl left join products p on p.product_id = pl.product_id ${LAST_JOIN} where ${WHERE} order by pl.product_link_id`, args);
        return ids.map((x) => x.id);
      }
      const [rows, [c], perChannel, sched] = await Promise.all([
        query(`select pl.product_link_id, pl.product_id, pl.channel_name, pl.url, pl.is_active, pl.created_at, pl.updated_at,
            p.name product_name, p.brand, pc.name category_name, p.is_active product_is_active, s.last_at last_scraped_at
          from product_links pl left join products p on p.product_id = pl.product_id left join product_categories pc on pc.category_id = p.category_id ${LAST_JOIN}
          where ${WHERE} order by pl.product_link_id limit ${limit} offset ${offset}`, args),
        query(`select count(*) filter (where ${WHERE})::int total,
            count(*) filter (where ($1 = 'all' or pl.channel_name = $1) and pl.is_active and coalesce(p.is_active, false))::int active,
            count(*) filter (where ($1 = 'all' or pl.channel_name = $1) and not (pl.is_active and coalesce(p.is_active, false)))::int inactive,
            count(*) filter (where ($1 = 'all' or pl.channel_name = $1))::int "all",
            count(*) filter (where ($1 = 'all' or pl.channel_name = $1) and s.last_day = $7::date)::int today,
            count(*) filter (where ($1 = 'all' or pl.channel_name = $1) and s.last_at is null)::int never
          from product_links pl left join products p on p.product_id = pl.product_id ${LAST_JOIN}`, args),
        query("select channel_name, count(*)::int n from product_links group by 1"),
        query<Schedule>(`select p.regular_scraping, p.scheduled_scraping, p.scraping_schedule_weekly, p.months_to_scrape, p.scraping_schedule_monthly
          from product_links pl join products p on p.product_id = pl.product_id where ($1 = 'all' or pl.channel_name = $1) and pl.is_active and p.is_active`, [channel]),
      ]);
      return {
        rows, total: c.total, counts: { active: c.active, inactive: c.inactive, all: c.all },
        stats: { all: c.all, active: c.active, today: c.today, never: c.never, due: sched.filter((x) => isDue(x)).length },
        channels: Object.fromEntries(perChannel.map((x) => [x.channel_name, x.n])),
      };
    },
  },
  {
    method: "PATCH", path: /^\/api\/links\/(\d+)$/,
    handler: async (r) => {
      // Switch a link on or off, and/or change its address (Scraping page, inline edit).
      const active = typeof r.body?.is_active === "boolean" ? r.body.is_active : null;
      const url = r.body?.url !== undefined ? cleanUrl(r.body.url) : null;
      if (r.body?.url !== undefined && !url) throw bad("Enter the link's web address.");
      if (active === null && !url) throw bad("Nothing to change.");
      const [row] = await tx(r.actor, (t) => t("update product_links set is_active = coalesce($2, is_active), url = coalesce($3, url), updated_at = now() where product_link_id = $1 returning *",
        [Number(r.params[0]), active, url]));
      if (!row) throw notFound();
      return row;
    },
  },
];
