// The Products page filters (status, search, brand, category, links), shared by the list and the product master download.
import { q } from "../http.js";
import { like } from "../sql.js";

export const LIST_WHERE = `($1::text = 'all' or p.is_active = ($1 = 'active'))
  and ($2::text is null or p.name ilike $2 or p.hana_code ilike $2 or p.brand ilike $2)
  and ($3::text is null or lower(p.brand) = lower($3))
  and ($4::int is null or p.category_id = $4)
  -- Link filters: any number of them, and a product matching any one of them is shown.
  and ($5::text[] is null or cardinality($5::text[]) = 0 or exists (
    select 1 from unnest($5::text[]) f where
         (f = 'missing' and coalesce(l.links, 0) = 0)
      or (f = 'any' and coalesce(l.links, 0) > 0)
      or (left(f, 3) = 'no_' and not coalesce(l.channels, '{}') @> array[substr(f, 4)])
      or (left(f, 4) = 'has_' and coalesce(l.channels, '{}') @> array[substr(f, 5)])))
  and ($6::int[] is null or p.product_id = any($6::int[]))`;
export const LINKS_JOIN = `left join (
  select product_id, count(*) filter (where is_active) links, array_agg(channel_name) filter (where is_active) channels,
    max(url) filter (where is_active and channel_name = 'amazon') amazon_url, max(url) filter (where is_active and channel_name = 'flipkart') flipkart_url,
    max(url) filter (where is_active and channel_name = 'instamart') instamart_url, max(url) filter (where is_active and channel_name = 'zepto') zepto_url
  from product_links group by product_id) l on l.product_id = p.product_id`;

/** The link filters in the query string ("has_amazon,no_flipkart"), only the names the page offers. */
const LINK_FILTERS = new Set(["any", "missing", ...["amazon", "flipkart", "instamart", "zepto"].flatMap((c) => [`has_${c}`, `no_${c}`])]);
function linkFilters(sp: URLSearchParams): string[] | null {
  const list = [...new Set((sp.get("link") ?? "").split(",").map((x) => x.trim()).filter((x) => LINK_FILTERS.has(x)))];
  return list.length ? list : null;
}

/** $1..$6 of LIST_WHERE from the query string (status defaults to active). Ticked rows (only=) ignore the other filters. */
export function listArgs(sp: URLSearchParams) {
  const only = q.only(sp);
  if (only) return ["all", null, null, null, null, only];
  const status = ["inactive", "all"].includes(sp.get("status") ?? "") ? sp.get("status") : "active";
  return [status, like(q.str(sp, "q")), q.str(sp, "brand"), q.int(sp, "category"), linkFilters(sp), null];
}
