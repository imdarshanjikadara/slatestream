// Scrape Run Results (getScrapeRunResults) and one run with its batches and results.
import type { Route } from "../router.js";
import { query } from "../db.js";
import { channelOf, notFound, q } from "../http.js";
import { ALERT_PRICE, BELOW, IST_FROM, IST_TO } from "../sql.js";
import { queuePosition } from "../jobs/queue.js";

const STATUSES = ["started", "in progress", "paused", "done", "failed", "aborted"];
const WHERE = `($1::text is null or lower(coalesce(r.status, '')) = $1)
  and ($2::text is null or r.channel_name = $2)
  and ($3::text is null or lower(coalesce(r.type, '')) = $3)
  and ${IST_FROM("r.run_date", "$4")} and ${IST_TO("r.run_date", "$5")}`;
// Batch and result counts of each run, looked up per run through the scrape_run_id indexes.
const AGG = `left join lateral (select count(*) batches, count(*) filter (where status = 'done') done, count(*) filter (where status = 'failed') failed,
    count(*) filter (where status in ('pending','running')) open, coalesce(sum(cardinality(product_link_ids)), 0) links
  from scrape_run_batches x where x.scrape_run_id = r.run_id) b on true
  left join lateral (select count(*) results, count(*) filter (where availability = 'In Stock') in_stock from scrape_results x where x.scrape_run_id = r.run_id) s on true`;

export const routes: Route[] = [
  {
    method: "GET", path: /^\/api\/runs$/,
    handler: async (r) => {
      const status = STATUSES.includes((r.query.get("status") ?? "").toLowerCase()) ? r.query.get("status")!.toLowerCase() : null;
      const type = q.str(r.query, "type")?.toLowerCase() ?? null;
      const rest = [channelOf(r.query.get("channel")), type, q.date(r.query, "from"), q.date(r.query, "to")];
      const limit = q.limit(r.query), offset = q.offset(r.query);
      const [rows, [s], counts] = await Promise.all([
        query(`select r.*, coalesce(b.batches, 0)::int batches, coalesce(b.done, 0)::int batches_done, coalesce(b.failed, 0)::int batches_failed, coalesce(b.open, 0)::int batches_open,
            greatest(coalesce(b.links, 0), coalesce(s.results, 0))::int links, coalesce(s.results, 0)::int results, coalesce(s.in_stock, 0)::int in_stock
          from scrape_runs r ${AGG} where ${WHERE} order by r.run_date desc, r.run_id desc limit ${limit} offset ${offset}`, [status, ...rest]),
        // Totals over every matching run: one pass over each table, not a lookup per run.
        query(`with m as (select r.run_id from scrape_runs r where ${WHERE})
          select (select count(*) from m)::int total,
            (select count(*) from scrape_results x where x.scrape_run_id in (select run_id from m))::int results,
            (select coalesce(sum(cardinality(product_link_ids)), 0) from scrape_run_batches x where x.scrape_run_id in (select run_id from m))::int links,
            (select count(*) from scrape_run_batches x where x.status = 'failed' and x.scrape_run_id in (select run_id from m))::int failed_batches`, [status, ...rest]),
        query(`select lower(coalesce(r.status, '')) status, count(*)::int n from scrape_runs r where ${WHERE.replace("($1::text is null or lower(coalesce(r.status, '')) = $1)", "($1::text is null or true)")} group by 1`, [null, ...rest]),
      ]);
      return { rows, total: s.total, stats: s, counts: Object.fromEntries(counts.map((c) => [c.status, c.n])) };
    },
  },
  {
    method: "GET", path: /^\/api\/runs\/(\d+)$/,
    handler: async (r) => {
      const id = Number(r.params[0]);
      const [[run], batches, results, queue, failures, [now]] = await Promise.all([
        query(`select r.*, coalesce(b.batches, 0)::int batches, coalesce(b.done, 0)::int batches_done, coalesce(b.failed, 0)::int batches_failed,
            coalesce(b.open, 0)::int batches_open, greatest(coalesce(b.links, 0), coalesce(s.results, 0))::int links, coalesce(s.results, 0)::int results, coalesce(s.in_stock, 0)::int in_stock
          from scrape_runs r ${AGG} where r.run_id = $1`, [id]),
        query(`select scrape_batch_id, batch_number, batch_total_count, cardinality(product_link_ids)::int links, status, attempt_count, locked_at, started_at, completed_at, error_message
          from scrape_run_batches where scrape_run_id = $1 order by batch_number`, [id]),
        query(`select sr.scrape_result_id, sr.created_at, sr.price, sr.mrp, sr.discount, sr.availability, sr.seller, sr.rating, sr.reviews,
            pl.product_link_id, pl.channel_name, pl.url, p.product_id, p.name product_name, p.brand, p.mop, ${ALERT_PRICE()} alert_price, pc.name category_name,
            ${BELOW("sr.price")} below_mop
          from scrape_results sr join product_links pl on pl.product_link_id = sr.product_link_id
          join products p on p.product_id = pl.product_id left join product_categories pc on pc.category_id = p.category_id
          where sr.scrape_run_id = $1 order by p.name limit ${r.query.get("all") === "1" ? 20000 : 500}`, [id]),
        queuePosition(id),
        // Links without a result and why (the last error of each). "retrying" when its batch is queued or running again.
        query(`select (e.key)::int product_link_id, e.value->>'error' error, coalesce((e.value->>'tries')::int, 1) tries, e.value->>'at' failed_at,
            b.batch_number, b.status in ('pending', 'running') retrying, pl.url, pl.channel_name, p.product_id, p.name product_name, p.brand, p.hana_code, pc.name category_name
          from scrape_run_batches b cross join lateral jsonb_each(coalesce(b.link_errors, '{}'::jsonb)) e
          left join product_links pl on pl.product_link_id = (e.key)::int left join products p on p.product_id = pl.product_id
          left join product_categories pc on pc.category_id = p.category_id
          where b.scrape_run_id = $1 and not exists (select 1 from scrape_results x where x.scrape_run_id = $1 and x.product_link_id = (e.key)::int)
          order by b.batch_number, 1`, [id]),
        // The link loading right now (one at a time), with its product.
        query(`select b.current_link_id product_link_id, b.current_try try, b.current_at started_at, b.batch_number, p.name product_name
          from scrape_run_batches b left join product_links pl on pl.product_link_id = b.current_link_id left join products p on p.product_id = pl.product_id
          where b.scrape_run_id = $1 and b.status = 'running' and b.current_link_id is not null order by b.current_at desc limit 1`, [id]),
      ]);
      if (!run) throw notFound();
      return { run, batches, results, queue, failures, now: now ?? null };
    },
  },
];
