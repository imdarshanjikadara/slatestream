import type { Route } from "../router.js";
import { generatedColumns, query, tx } from "../db.js";
import { bad, notFound, q } from "../http.js";
import { clean, saveLinks, withPricing } from "../productFields.js";
import { bulkRoute, importRoute, masterRoute } from "./productImport.js";
import { LINKS_JOIN, LIST_WHERE, listArgs } from "./productFilters.js";

export const routes: Route[] = [
  masterRoute, importRoute, bulkRoute,
  {
    // getProducts, filtered, searched, counted and paged in the database.
    method: "GET", path: /^\/api\/products$/,
    handler: async (r) => {
      const args = listArgs(r.query);
      const limit = q.limit(r.query), offset = q.offset(r.query);
      // "Select all matching" for bulk edit: only the ids.
      if (r.query.get("ids") === "1") return (await query<{ id: number }>(`select p.product_id id from products p ${LINKS_JOIN} where ${LIST_WHERE} order by p.product_id`, args)).map((x) => x.id);
      const [rows, [c]] = await Promise.all([
        // Every column: the Products page is an editable sheet of the whole product master.
        query(`select p.*, pc.name category_name,
            coalesce(l.links, 0)::int links, l.amazon_url, l.flipkart_url, l.instamart_url, l.zepto_url
          from products p left join product_categories pc on pc.category_id = p.category_id ${LINKS_JOIN}
          where ${LIST_WHERE} order by p.product_id limit ${limit} offset ${offset}`, args),
        query(`select count(*) filter (where ${LIST_WHERE})::int total,
            count(*) filter (where p.is_active)::int active, count(*) filter (where not p.is_active)::int inactive, count(*)::int "all",
            count(*) filter (where ${LIST_WHERE} and l.amazon_url is not null)::int with_amazon,
            count(*) filter (where ${LIST_WHERE} and l.flipkart_url is not null)::int with_flipkart,
            count(*) filter (where ${LIST_WHERE} and coalesce(l.links, 0) = 0)::int no_links
          from products p ${LINKS_JOIN}`, args),
      ]);
      return { rows, total: c.total, counts: { active: c.active, inactive: c.inactive, all: c.all }, stats: { total: c.total, withAmazon: c.with_amazon, withFlipkart: c.with_flipkart, noLinks: c.no_links } };
    },
  },
  {
    method: "GET", path: /^\/api\/products\/(\d+)$/,
    handler: async (r) => {
      const id = Number(r.params[0]);
      const [[product], links, history, gen] = await Promise.all([
        query("select p.*, pc.name category_name from products p left join product_categories pc on pc.category_id = p.category_id where p.product_id = $1", [id]),
        query(`select pl.*, s.price last_price, s.availability last_availability, s.seller last_seller, s.created_at last_scraped_at, coalesce(n.n, 0)::int scrapes
          from product_links pl
          left join lateral (select price, availability, seller, created_at from scrape_results sr where sr.product_link_id = pl.product_link_id order by created_at desc limit 1) s on true
          left join (select product_link_id, count(*) n from scrape_results where product_link_id in (select product_link_id from product_links where product_id = $1) group by 1) n on n.product_link_id = pl.product_link_id
          where pl.product_id = $1 order by array_position(array['amazon','flipkart','instamart','zepto']::text[], pl.channel_name), pl.product_link_id`, [id]),
        query(`select sr.scrape_result_id, sr.created_at, sr.price, sr.mrp, sr.discount, sr.availability, sr.seller, sr.rating, sr.reviews, pl.channel_name, sr.scrape_run_id
          from scrape_results sr join product_links pl on pl.product_link_id = sr.product_link_id
          where pl.product_id = $1 order by sr.created_at desc limit 60`, [id]),
        generatedColumns("products"),
      ]);
      if (!product) throw notFound();
      return { product, links, history, generated: [...gen] };
    },
  },
  {
    // saveProducts + saveProductLinkJS in one transaction.
    method: "POST", path: /^\/api\/products$/,
    handler: async (r) => {
      const data = await withPricing(clean(r.body ?? {}, true));
      const keys = Object.keys(data);
      const row = await tx(r.actor, async (t) => {
        const [p] = await t(`insert into products (${keys.join(", ")}, is_active, created_at, updated_at) values (${keys.map((_, i) => `$${i + 1}`).join(", ")}, true, now(), now()) returning *`, keys.map((k) => data[k]));
        await saveLinks(t, p.product_id, r.body?.links);
        return p;
      });
      return { status: 201, body: row };
    },
  },
  {
    // updateProducts + updateProductLinkJs (now also saving schedule, schemes and pricing, which the old app showed but never saved).
    method: "PATCH", path: /^\/api\/products\/(\d+)$/,
    handler: async (r) => {
      const id = Number(r.params[0]);
      const [current] = await query("select * from products where product_id = $1", [id]);
      if (!current) throw notFound();
      const data = await withPricing(clean(r.body ?? {}, false), current);
      if (typeof r.body?.is_active === "boolean") data.is_active = r.body.is_active;
      // A schedule set by hand ends a pause (Your Schedule).
      if ("regular_scraping" in data || "scheduled_scraping" in data) data.paused_mode = null;
      const keys = Object.keys(data);
      const row = await tx(r.actor, async (t) => {
        const [p] = keys.length
          ? await t(`update products set ${keys.map((k, i) => `${k} = $${i + 2}`).join(", ")}, updated_at = now() where product_id = $1 returning *`, [id, ...keys.map((k) => data[k])])
          : await t("select * from products where product_id = $1", [id]);
        if (!p) throw notFound();
        await saveLinks(t, id, r.body?.links);
        return p;
      });
      return row;
    },
  },
  {
    // Delete the selected products for good: their links and the links' scrape history go with them.
    // Products and links are restorable from the Audit log for 30 days; the scrape history is not (it is not audited).
    method: "POST", path: /^\/api\/products\/delete$/,
    handler: async (r) => {
      const ids: number[] = [...new Set((Array.isArray(r.body?.ids) ? r.body.ids : []).map(Number).filter((n: number) => Number.isInteger(n) && n > 0))] as number[];
      if (!ids.length) throw bad("Select at least one product.");
      if (ids.length > 5000) throw bad("Delete at most 5,000 products at a time.");
      return tx(r.actor, async (t) => {
        const [res] = await t<{ n: number }>(`with l as (select product_link_id from product_links where product_id = any($1::int[]))
          , d as (delete from scrape_results where product_link_id in (select product_link_id from l) returning 1) select count(*)::int n from d`, [ids]);
        const links = await t("delete from product_links where product_id = any($1::int[]) returning product_link_id", [ids]);
        const rows = await t("delete from products where product_id = any($1::int[]) returning product_id", [ids]);
        return { deleted: rows.length, links: links.length, results: res?.n ?? 0 };
      });
    },
  },
  {
    // deleteProducts: soft delete (is_active = false); restorable from the Audit log.
    method: "DELETE", path: /^\/api\/products\/(\d+)$/,
    handler: async (r) => {
      const [row] = await tx(r.actor, (t) => t("update products set is_active = false, updated_at = now() where product_id = $1 returning product_id, name", [Number(r.params[0])]));
      if (!row) throw notFound();
      return row;
    },
  },
];
