// Scrape Product Results (getScrapeResults): the latest scrape of every active link inside the date range, per channel.
import type { Route } from "../router.js";
import { query } from "../db.js";
import { channelOf, istDay, notFound, q, type Req } from "../http.js";
import { ALERT_PRICE, IST_RANGE, RESULT_COLS, latestCte, like } from "../sql.js";

export function resultFilters(r: Req) {
  return {
    // "all" is every channel in one list (the All channels tab), so one export holds them together.
    channel: r.query.get("channel") === "all" ? "all" : channelOf(r.query.get("channel")) ?? "amazon",
    from: q.date(r.query, "from") ?? istDay(7),
    to: q.date(r.query, "to") ?? istDay(0),
    brand: q.str(r.query, "brand"),
    category: q.int(r.query, "category"),
    product: q.int(r.query, "product"),
    search: like(q.str(r.query, "q")),
    stock: ["in", "out"].includes(r.query.get("stock") ?? "") ? r.query.get("stock") : null,
    mop: r.query.get("mop") === "below" ? "below" : null,
  };
}

/** The base set for one channel: $1 from, $2 to, $3 channel. Filters are $4.. */
export const BASE = `with ${latestCte("$1", "$2")},
  base as (
    select ${RESULT_COLS}
    from latest sr
    join product_links pl on sr.product_link_id = pl.product_link_id
    join products p on pl.product_id = p.product_id
    left join product_categories pc on p.category_id = pc.category_id
    where p.is_active and pl.is_active)`;
export const FILTER = `($3::text = 'all' or channel_name = $3)
  and ($4::text is null or lower(brand) = lower($4))
  and ($5::int is null or category_id = $5)
  and ($6::int is null or product_id = $6)
  and ($7::text is null or product_name ilike $7 or seller ilike $7 or hana_code ilike $7)
  and ($8::text is null or ($8 = 'in' and availability = 'In Stock') or ($8 = 'out' and coalesce(availability, '') <> 'In Stock'))
  and ($9::text is null or below_mop)`;

export const routes: Route[] = [
  {
    method: "GET", path: /^\/api\/results$/,
    handler: async (r) => {
      const f = resultFilters(r);
      const args = [f.from, f.to, f.channel, f.brand, f.category, f.product, f.search, f.stock, f.mop];
      const limit = q.limit(r.query), offset = q.offset(r.query);
      const [rows, [s], perChannel] = await Promise.all([
        query(`${BASE} select * from base where ${FILTER} order by product_name, product_link_id limit ${limit} offset ${offset}`, args),
        query(`${BASE} select count(*)::int total,
            count(*) filter (where availability = 'In Stock')::int in_stock,
            count(*) filter (where coalesce(availability, '') <> 'In Stock')::int not_in_stock,
            count(*) filter (where below_mop)::int below_mop,
            round(avg(discount) filter (where price > 0)::numeric, 1) avg_discount
          from base where ${FILTER}`, args),
        query(`${BASE} select channel_name, count(*)::int n from base group by 1`, [f.from, f.to]),
      ]);
      return { rows, total: s.total, stats: s, channels: Object.fromEntries(perChannel.map((x) => [x.channel_name, x.n])), from: f.from, to: f.to, channel: f.channel };
    },
  },
  {
    // One link: the latest result in the range (every column) and its price history in that range.
    method: "GET", path: /^\/api\/results\/(\d+)$/,
    handler: async (r) => {
      const id = Number(r.params[0]);
      const from = q.date(r.query, "from") ?? istDay(7), to = q.date(r.query, "to") ?? istDay(0);
      const [[link], history] = await Promise.all([
        query(`select pl.product_link_id, pl.channel_name, pl.url, pl.is_active link_is_active, p.product_id, p.name product_name, p.brand, p.dealer_landing, p.mrp base_mrp,
            p.hana_code, p.ph, p.direct_discount, p.gst_percent, p.mop, p.mop_scheme, p.trigger_price, ${ALERT_PRICE()} alert_price, pc.name category_name
          from product_links pl join products p on p.product_id = pl.product_id left join product_categories pc on pc.category_id = p.category_id
          where pl.product_link_id = $1`, [id]),
        query(`select sr.scrape_result_id, sr.created_at, sr.price, sr.mrp, sr.discount, sr.availability, sr.seller, sr.rating, sr.reviews, sr.scrape_run_id
          from scrape_results sr where sr.product_link_id = $1 and ${IST_RANGE("sr.created_at", "$2", "$3")}
          order by sr.created_at desc limit 500`, [id, from, to]),
      ]);
      if (!link) throw notFound();
      return { link, latest: history[0] ?? null, history };
    },
  },
];
