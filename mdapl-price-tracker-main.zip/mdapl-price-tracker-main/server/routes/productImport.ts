// Replaces the Google product sheet: download the product master in the sheet's column layout, import any version of it
// (or a price list / link list) with a preview of every change, and edit many products at once.
import type { Route } from "../router.js";
import { query, tx, type Q } from "../db.js";
import { CHANNELS, bad } from "../http.js";
import { FIELDS, LABEL, cleanUrl, cleanValue, saveLinks, withPricing } from "../productFields.js";
import { DERIVED, computePricing } from "../../shared/pricing.js";
import { LINKS_JOIN, LIST_WHERE, listArgs } from "./productFilters.js";

/** The sheet's columns, in its order. Import accepts any subset of them (plus a few aliases, matched in the browser). */
export const MASTER_COLUMNS = ["product_id", "name", "brand", "category_name", "hana_code", "product_is_active", "regular_scraping", "scheduled_scraping",
  "scraping_schedule_weekly", "months_to_scrape", "scraping_schedule_monthly", "category_id", "mrp", "direct_discount", "dealer_landing", "dp_margin_percent", "mop",
  "scheme_1", "scheme_2", "scheme_3", "total_scheme", "net_landing", "retail_margin_percent", "retail_margin", "mop_scheme", "trigger_price_percent", "trigger_price",
  "gst_percent", "ph", "amazon_product_link_id", "amazon_url", "flipkart_product_link_id", "flipkart_url", "instamart_product_link_id", "instamart_url",
  "zepto_product_link_id", "zepto_url"];

const MAX_ROWS = 5000;
const hanaKey = (v: unknown) => String(v ?? "").trim().replace(/\.0+$/, "").toUpperCase();
// Empty, or a placeholder people type for "nothing" ("-", "--", "NA", "N/A", "#N/A", "nil").
const blank = (v: unknown) => v === null || v === undefined || /^(|-+|n\/?a|#n\/a|nil|none|null)$/i.test(String(v).trim());
const same = (a: unknown, b: unknown) => {
  if ((a === null || a === undefined || a === "") && (b === null || b === undefined || b === "")) return true;
  if (typeof a === "number" || typeof b === "number") return Math.abs(Number(a ?? 0) - Number(b ?? 0)) < 0.005;
  if (typeof a === "boolean" || typeof b === "boolean") return Boolean(a) === Boolean(b);
  return String(a ?? "") === String(b ?? "");
};

type Change = { field: string; label: string; from: unknown; to: unknown };
type Planned = { row: number; action: "create" | "update" | "unchanged" | "error" | "duplicate"; product_id: number | null; name: string | null; changes: Change[]; error?: string;
  /** Parts of the row that could not be applied, while the rest of it still can (a link already on another product). */ notes?: string[];
  data?: Record<string, unknown>; links?: Record<string, string>; newCategory?: string };

const num = (v: unknown) => (typeof v === "number" ? v : blank(v) ? NaN : Number(String(v).replace(/[₹,\s]/g, "")));
const r2 = (n: number) => Math.round(n * 100) / 100;
/** Old sheet rows often hard-code the margin ("=V2*0.2", "=Y2*0.95") and leave the % cell blank. When a % is blank here and on the product,
 *  work it out from the value the sheet calculated, so MOP scheme and trigger price stay what the sheet showed. */
function fillPercents(r: Record<string, unknown>, data: Record<string, unknown>, cur: any) {
  const fill = (pct: string, from: string, solve: (x: number, p: ReturnType<typeof computePricing>) => number, ok: (n: number) => boolean) => {
    if (!blank(r[pct]) || (cur && cur[pct] !== null && cur[pct] !== undefined)) return;
    const x = num(r[from]);
    if (!Number.isFinite(x) || x <= 0) return;
    const n = r2(solve(x, computePricing({ ...(cur ?? {}), ...data })));
    if (Number.isFinite(n) && ok(n)) data[pct] = n;
  };
  fill("dp_margin_percent", "__calc_mop", (x) => (x / num(data.dealer_landing ?? cur?.dealer_landing) - 1) * 100, (n) => n > 0 && n <= 100);
  fill("retail_margin_percent", "__calc_retail_margin", (x, p) => (x / Number(p.net_landing)) * 100, (n) => n > 0 && n <= 100);
  fill("trigger_price_percent", "__calc_trigger_price", (x, p) => (1 - x / Number(p.mop_scheme)) * 100, (n) => n > 0 && n < 100);
}

const nameKey = (v: unknown) => String(v ?? "").trim().replace(/\s+/g, " ").toLowerCase();
/** A product page address without its tracking query string, so the same Amazon or Flipkart page matches however it was copied. */
const urlKey = (v: string) => { try { const u = new URL(v); return `${u.hostname.replace(/^www\./, "")}${u.pathname.replace(/\/+$/, "")}`.toLowerCase(); } catch { return v.toLowerCase(); } };

/** A product is never added twice: a row that would add a product already saved (same name, hana code or channel link), or the
 *  same new product twice in one file, is a duplicate. It is not added; with `updateDuplicates` it updates the saved product. */
async function plan(rows: Record<string, unknown>[], createMissing: boolean, updateDuplicates = false) {
  const [products, cats, links] = await Promise.all([
    query("select * from products"),
    query<{ category_id: number; name: string }>("select category_id, name from product_categories"),
    query<{ product_id: number; channel_name: string; url: string }>("select product_id, channel_name, url from product_links where is_active"),
  ]);
  const byId = new Map(products.map((p) => [Number(p.product_id), p]));
  const byHana = new Map<string, any[]>();
  for (const p of products) if (p.hana_code) { const k = hanaKey(p.hana_code); byHana.set(k, [...(byHana.get(k) ?? []), p]); }
  const catByName = new Map(cats.map((c) => [c.name.trim().toLowerCase(), c.category_id]));
  const catIds = new Set(cats.map((c) => c.category_id));
  const linkOf = new Map(links.map((l) => [`${l.product_id}:${l.channel_name}`, l.url]));
  const byName = new Map<string, any[]>();
  for (const p of products) if (p.name) { const k = nameKey(p.name); byName.set(k, [...(byName.get(k) ?? []), p]); }
  const linkOwner = new Map(links.map((l) => [`${l.channel_name}:${urlKey(l.url)}`, Number(l.product_id)]));
  const newInFile = new Map<string, number>();   // name / hana / link of products added by earlier rows of this file -> row
  const seen = new Map<number, number>();
  const out: Planned[] = [];

  rows.forEach((raw, i) => {
    const rowNo = Number(raw.__row) || i + 2;
    const r = Object.fromEntries(Object.entries(raw).filter(([k]) => k !== "__row"));
    if (Object.entries(r).every(([k, v]) => k.startsWith("__calc_") || blank(v))) return;
    const p: Planned = { row: rowNo, action: "update", product_id: null, name: blank(r.name) ? null : String(r.name).trim(), changes: [] };
    try {
      // Which product: product_id first, else hana code.
      let cur: any = null;
      const id = blank(r.product_id) ? null : Math.trunc(Number(r.product_id));
      if (id !== null && !Number.isFinite(id)) throw bad(`product_id "${r.product_id}" is not a number.`);
      if (id !== null) cur = byId.get(id) ?? null;
      else if (!blank(r.hana_code)) {
        const m = byHana.get(hanaKey(r.hana_code)) ?? [];
        if (m.length > 1) throw bad(`Hana code ${hanaKey(r.hana_code)} belongs to ${m.length} products (#${m.map((x) => x.product_id).join(", #")}); add a product_id column to say which.`);
        cur = m[0] ?? null;
      } else if (blank(r.name)) throw bad("No product_id, hana code or name, so the row cannot be matched.");
      // Would add a product: is it already saved under another id (same hana code, name or link)?
      if (!cur) {
        const rowUrls = CHANNELS.flatMap((ch) => (blank(r[`${ch}_url`]) ? [] : [[ch, urlKey(cleanUrl(r[`${ch}_url`])!)] as const]));
        const why: [any, string][] = [];
        if (!blank(r.hana_code)) for (const x of byHana.get(hanaKey(r.hana_code)) ?? []) why.push([x, "same hana code"]);
        if (!blank(r.name)) for (const x of byName.get(nameKey(r.name)) ?? []) why.push([x, "same name"]);
        for (const [ch, u] of rowUrls) { const o = linkOwner.get(`${ch}:${u}`); if (o && byId.has(o)) why.push([byId.get(o), `same ${ch[0].toUpperCase()}${ch.slice(1)} link`]); }
        if (why.length) {
          const dup = why[0][0], reasons = [...new Set(why.filter(([x]) => x.product_id === dup.product_id).map(([, w]) => w))].join(", ");
          if (updateDuplicates && new Set(why.map(([x]) => x.product_id)).size === 1) cur = dup;
          else {
            p.action = "duplicate"; p.product_id = dup.product_id; p.name = blank(r.name) ? dup.name : String(r.name).trim();
            p.error = `Already saved as product #${dup.product_id} "${dup.name}" (${reasons}). Not added again.`
              + (new Set(why.map(([x]) => x.product_id)).size > 1 ? " It also matches other products; put the right product_id in the row to update one." : " Tick \"Update the saved product\" to apply this row's values to it instead.");
            out.push(p); return;
          }
        } else {
          // The same new product twice in this file.
          const keys = [!blank(r.hana_code) && `h:${hanaKey(r.hana_code)}`, !blank(r.name) && `n:${nameKey(r.name)}`, ...rowUrls.map(([ch, u]) => `l:${ch}:${u}`)].filter(Boolean) as string[];
          const earlier = keys.map((k) => newInFile.get(k)).find((x) => x !== undefined);
          if (earlier !== undefined) { p.action = "duplicate"; p.error = `Same new product as row ${earlier} of this file. Only that row adds it.`; out.push(p); return; }
          for (const k of keys) newInFile.set(k, rowNo);
        }
      }
      if (!cur) {
        if (!createMissing) throw bad(id !== null ? `No product #${id}. Tick "Add new products" to create it.` : `No product with hana code ${hanaKey(r.hana_code) || "(none)"}. Tick "Add new products" to create it.`);
        p.action = "create";
      } else p.action = "update";
      if (cur) {
        if (seen.has(cur.product_id)) throw bad(`Product #${cur.product_id} is already changed by row ${seen.get(cur.product_id)}.`);
        seen.set(cur.product_id, rowNo);
        p.product_id = cur.product_id; p.name = cur.name;
      } else if (id !== null) p.product_id = id;

      // Fields: a blank cell means "leave as it is" (for a new product: the default).
      const data: Record<string, unknown> = {};
      for (const k of Object.keys(FIELDS)) {
        if (k === "category_id" || !(k in r) || blank(r[k])) continue;
        data[k] = cleanValue(k, r[k]);
      }
      if ("product_is_active" in r && !blank(r.product_is_active)) {
        const v = String(r.product_is_active).trim().toLowerCase();
        if (!["true", "false", "yes", "no", "1", "0"].includes(v)) throw bad(`product_is_active must be TRUE or FALSE (got "${r.product_is_active}").`);
        data.is_active = ["true", "yes", "1"].includes(v);
      }
      // Category: by id, else by name (a new name becomes a new category when adding is allowed).
      const cidIn = blank(r.category_id) ? null : Math.trunc(Number(r.category_id));
      if (cidIn !== null && catIds.has(cidIn)) data.category_id = cidIn;
      else if (cidIn !== null && blank(r.category_name)) throw bad(`Category #${r.category_id} does not exist.`);
      else if (!blank(r.category_name)) {
        const cid = catByName.get(String(r.category_name).trim().toLowerCase());
        if (cid) data.category_id = cid;
        else if (createMissing) p.newCategory = String(r.category_name).trim();
        else throw bad(`Category "${r.category_name}" does not exist. Tick "Add new products" to create it, or fix the name.`);
      }
      // A hana code is one product's: changing a product to another product's code is refused.
      if (data.hana_code) { const o = (byHana.get(hanaKey(data.hana_code)) ?? []).find((x) => x.product_id !== cur?.product_id); if (o) throw bad(`Hana code ${hanaKey(data.hana_code)} already belongs to product #${o.product_id} "${o.name}".`); }
      // Old sheets often tick both; a product is scraped every day or on a schedule, and regular always won.
      if (data.regular_scraping === true) data.scheduled_scraping = false;
      else if (data.scheduled_scraping === true) data.regular_scraping = false;
      fillPercents(r, data, cur);
      if (p.action === "create") {
        if (!data.name) throw bad("A new product needs a name.");
        if (!data.category_id && !p.newCategory) throw bad("A new product needs a category (category_id or category_name).");
      }
      const linksIn: Record<string, string> = {};
      for (const ch of CHANNELS) {
        const v = r[`${ch}_url`];
        if (blank(v)) continue;
        const url = cleanUrl(v)!;
        const owner = linkOwner.get(`${ch}:${urlKey(url)}`);
        // A link belongs to one product. Rather than losing the whole row, the link is left where it is and the row says so.
        if (owner && owner !== cur?.product_id) {
          (p.notes ??= []).push(`${ch[0].toUpperCase()}${ch.slice(1)} link not changed: it is already on product #${owner} "${byId.get(owner)?.name ?? ""}". A link belongs to one product; remove it from the other product first, or take this column out of the file.`);
          continue;
        }
        if (!cur || !same(linkOf.get(`${cur.product_id}:${ch}`), url)) linksIn[ch] = url;
      }

      // What changes, field by field (calculated pricing included, so MOP changes are visible before applying).
      for (const [k, v] of Object.entries(data)) if (!cur || !same(cur[k], v)) p.changes.push({ field: k, label: LABEL[k] ?? k, from: cur?.[k] ?? null, to: v });
      if (p.newCategory) p.changes.push({ field: "category_id", label: "Category", from: null, to: `${p.newCategory} (new category)` });
      for (const [ch, url] of Object.entries(linksIn)) p.changes.push({ field: `${ch}_url`, label: `${ch[0].toUpperCase()}${ch.slice(1)} link`, from: cur ? linkOf.get(`${cur.product_id}:${ch}`) ?? null : null, to: url });
      const before = cur ? computePricing(cur) : null, after = computePricing({ ...(cur ?? {}), ...data });
      for (const k of DERIVED) if (!before || !same(before[k], after[k])) if (cur ? !same(cur[k], after[k]) : true) p.changes.push({ field: k, label: `${LABEL[k]} (calculated)`, from: cur?.[k] ?? null, to: after[k] });
      if (cur && !p.changes.length) p.action = "unchanged";
      p.data = Object.fromEntries(Object.entries(data).filter(([k, v]) => !cur || !same(cur[k], v)));
      p.links = linksIn;
    } catch (e) {
      p.action = "error"; p.error = (e as Error).message; p.changes = [];
    }
    out.push(p);
  });
  return { planned: out, byId };
}

async function apply(t: Q, planned: Planned[], byId: Map<number, any>) {
  const newCats = new Map<string, number>();
  let created = 0, updated = 0;
  for (const p of planned) {
    if (p.action !== "create" && p.action !== "update") continue;
    const data = { ...(p.data ?? {}) };
    if (p.newCategory) {
      const key = p.newCategory.toLowerCase();
      if (!newCats.has(key)) {
        const [c] = await t("insert into product_categories (name, is_active, created_at, updated_at) values ($1, true, now(), now()) returning category_id", [p.newCategory]);
        newCats.set(key, c.category_id);
      }
      data.category_id = newCats.get(key);
    }
    if (p.action === "create") {
      const row = await withPricing(data, undefined, t);
      if (p.product_id) row.product_id = p.product_id;
      if (!("is_active" in row)) row.is_active = true;
      const keys = Object.keys(row);
      const [x] = await t(`insert into products (${keys.join(", ")}, created_at, updated_at) values (${keys.map((_, i) => `$${i + 1}`).join(", ")}, now(), now()) returning product_id`, keys.map((k) => row[k]));
      p.product_id = x.product_id;
      created++;
    } else if (Object.keys(data).length) {
      const row = await withPricing(data, byId.get(p.product_id!), t);
      const keys = Object.keys(row);
      await t(`update products set ${keys.map((k, i) => `${k} = $${i + 2}`).join(", ")}, updated_at = now() where product_id = $1`, [p.product_id, ...keys.map((k) => row[k])]);
      updated++;
    } else updated++;
    await saveLinks(t, p.product_id!, p.links, false);
  }
  if (created) await t("select setval(pg_get_serial_sequence('products', 'product_id'), greatest((select max(product_id) from products), 1))");
  return { created, updated, categories: newCats.size };
}

export const masterRoute: Route = {
  // The product master in the sheet's column layout: the products matching the Products page filters
  // (no filters in the query string: every product, active or not).
  method: "GET", path: /^\/api\/products\/master$/,
  handler: async (r) => {
    const filtered = ["status", "q", "brand", "category", "link", "only"].some((k) => r.query.get(k));
    const args = filtered ? listArgs(r.query) : ["all", null, null, null, null, null];
    const rows = await query(`select p.product_id, p.name, p.brand, c.name category_name, p.hana_code, p.is_active product_is_active, p.regular_scraping, p.scheduled_scraping,
        p.scraping_schedule_weekly, p.months_to_scrape, p.scraping_schedule_monthly, p.category_id, p.mrp, p.direct_discount, p.dealer_landing, p.dp_margin_percent, p.mop,
        p.scheme_1, p.scheme_2, p.scheme_3, p.total_scheme, p.net_landing, p.retail_margin_percent, p.retail_margin, p.mop_scheme, p.trigger_price_percent, p.trigger_price,
        p.gst_percent, p.ph,
        max(pl.product_link_id) filter (where pl.channel_name = 'amazon' and pl.is_active) amazon_product_link_id, max(pl.url) filter (where pl.channel_name = 'amazon' and pl.is_active) amazon_url,
        max(pl.product_link_id) filter (where pl.channel_name = 'flipkart' and pl.is_active) flipkart_product_link_id, max(pl.url) filter (where pl.channel_name = 'flipkart' and pl.is_active) flipkart_url,
        max(pl.product_link_id) filter (where pl.channel_name = 'instamart' and pl.is_active) instamart_product_link_id, max(pl.url) filter (where pl.channel_name = 'instamart' and pl.is_active) instamart_url,
        max(pl.product_link_id) filter (where pl.channel_name = 'zepto' and pl.is_active) zepto_product_link_id, max(pl.url) filter (where pl.channel_name = 'zepto' and pl.is_active) zepto_url
      from products p left join product_categories c on p.category_id = c.category_id left join product_links pl on p.product_id = pl.product_id
      where p.product_id in (select p.product_id from products p ${LINKS_JOIN} where ${LIST_WHERE})
      group by p.product_id, c.name order by p.product_id`, args);
    return { columns: MASTER_COLUMNS, rows };
  },
};

export const importRoute: Route = {
  // Preview (apply: false) or apply (apply: true) an import. Rows come already mapped to the master's column names.
  method: "POST", path: /^\/api\/products\/import$/,
  handler: async (r) => {
    const rows = r.body?.rows;
    if (!Array.isArray(rows) || !rows.length) throw bad("The file has no rows to import.");
    if (rows.length > MAX_ROWS) throw bad(`Import at most ${MAX_ROWS} rows at a time.`);
    const createMissing = !!r.body?.createMissing;
    const { planned, byId } = await plan(rows, createMissing, !!r.body?.updateDuplicates);
    const count = (a: string) => planned.filter((p) => p.action === a).length;
    const summary = { rows: planned.length, create: count("create"), update: count("update"), unchanged: count("unchanged"), errors: count("error"), duplicates: count("duplicate"),
      notes: planned.filter((p) => p.notes?.length).length };
    if (!r.body?.apply) return { summary, rows: planned.map(({ data, links, ...p }) => p) };
    if (!summary.create && !summary.update) throw bad("Nothing to change: every row matches what is already saved.");
    const res = await tx(r.actor, (t) => apply(t, planned, byId));
    return { summary, applied: res };
  },
};

const BULK_FIELDS = ["category_id", "brand", "ph", "regular_scraping", "scheduled_scraping", "scraping_schedule_weekly", "months_to_scrape", "scraping_schedule_monthly", "scrape_time",
  "gst_percent", "direct_discount", "dp_margin_percent", "retail_margin_percent", "trigger_price_percent"];

export const bulkRoute: Route = {
  // Edit many products at once: the same values for every selected product.
  method: "POST", path: /^\/api\/products\/bulk$/,
  handler: async (r) => {
    const ids: number[] = [...new Set((Array.isArray(r.body?.ids) ? r.body.ids : []).map(Number).filter((n: number) => Number.isInteger(n) && n > 0))] as number[];
    if (!ids.length) throw bad("Select at least one product.");
    if (ids.length > 5000) throw bad("Edit at most 5,000 products at a time.");
    const set = r.body?.set ?? {};
    const data: Record<string, unknown> = {};
    for (const k of BULK_FIELDS) if (k in set) data[k] = cleanValue(k, set[k]);
    if ("category_id" in data && !data.category_id) throw bad("Choose a category.");
    if (typeof set.is_active === "boolean") data.is_active = set.is_active;
    if ("regular_scraping" in data || "scheduled_scraping" in data) data.paused_mode = null; // a schedule set by hand ends a pause
    if (!Object.keys(data).length) throw bad("Choose at least one thing to change.");
    const current = await query("select * from products where product_id = any($1::int[])", [ids]);
    const n = await tx(r.actor, async (t) => {
      for (const cur of current) {
        const row = await withPricing(data, cur, t);
        const keys = Object.keys(row);
        await t(`update products set ${keys.map((k, i) => `${k} = $${i + 2}`).join(", ")}, updated_at = now() where product_id = $1`, [cur.product_id, ...keys.map((k) => row[k])]);
      }
      return current.length;
    });
    return { updated: n };
  },
};
