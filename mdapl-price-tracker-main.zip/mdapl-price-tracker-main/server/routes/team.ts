// Team & access. Everyone signed in sees who has access; only admins change it: add and remove people, set their
// role, switch access off, give a temporary password or set a new one. Staff change only their own password
// (user menu > Change password). A temporary password is shown once to the admin.
import type { Route } from "../router.js";
import { query, tx } from "../db.js";
import { bad, notFound } from "../http.js";
import { hashPassword, passwordProblem, refreshAccount, temporaryPassword } from "../auth.js";

const COLS = "user_id, email, name, role, is_active, must_change_password, last_sign_in_at, created_at, updated_at";
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

async function otherActiveAdmins(userId: number) {
  const [{ n }] = await query<{ n: number }>("select count(*)::int n from app_users where role = 'admin' and is_active and user_id <> $1", [userId]);
  return n;
}

export const routes: Route[] = [
  {
    method: "GET", path: /^\/api\/team$/,
    handler: async () => query(`select ${COLS} from app_users order by is_active desc, lower(name)`),
  },
  {
    method: "POST", path: /^\/api\/team$/, access: "admin",
    handler: async (r) => {
      const email = String(r.body?.email ?? "").trim().toLowerCase(), name = String(r.body?.name ?? "").trim();
      const role = r.body?.role === "admin" ? "admin" : "staff";
      if (!EMAIL.test(email)) throw bad("Enter a valid email address.");
      if (!name) throw bad("Enter the person's name.");
      const [exists] = await query("select is_active from app_users where email = $1", [email]);
      if (exists) throw bad(exists.is_active ? "This person already has access." : "This person is in the list with access switched off. Switch it back on instead.");
      const password = temporaryPassword();
      const [user] = await tx(r.actor, (t) => t(`insert into app_users (email, name, role, password_hash, must_change_password) values ($1, $2, $3, $4, true) returning ${COLS}`,
        [email, name, role, hashPassword(password)]));
      await refreshAccount(email);
      return { status: 201, body: { user, temporaryPassword: password } };
    },
  },
  {
    method: "PATCH", path: /^\/api\/team\/(\d+)$/, access: "admin",
    handler: async (r) => {
      const id = Number(r.params[0]);
      const [cur] = await query<{ user_id: number; email: string; role: string; is_active: boolean }>("select user_id, email, role, is_active from app_users where user_id = $1", [id]);
      if (!cur) throw notFound();
      const self = cur.user_id === r.user!.id;
      const set: Record<string, unknown> = {};
      if (typeof r.body?.name === "string") { if (!r.body.name.trim()) throw bad("Enter the person's name."); set.name = r.body.name.trim(); }
      if (r.body?.role === "admin" || r.body?.role === "staff") set.role = r.body.role;
      if (typeof r.body?.is_active === "boolean") set.is_active = r.body.is_active;
      if (!Object.keys(set).length) throw bad("Nothing to change.");
      if (self && (("role" in set && set.role !== cur.role) || set.is_active === false)) throw bad("You cannot change your own role or switch off your own access. Ask another admin.");
      const losesAdmin = cur.role === "admin" && cur.is_active && (set.role === "staff" || set.is_active === false);
      if (losesAdmin && !(await otherActiveAdmins(id))) throw bad("At least one active admin is needed. Make someone else an admin first.");
      const keys = Object.keys(set);
      // Switching access off also ends the person's open sessions.
      const bump = set.is_active === false ? ", session_version = session_version + 1, session_grace_until = null" : "";
      const [user] = await tx(r.actor, (t) => t(`update app_users set ${keys.map((k, i) => `${k} = $${i + 2}`).join(", ")}${bump}, updated_at = now() where user_id = $1 returning ${COLS}`,
        [id, ...keys.map((k) => set[k])]));
      await refreshAccount(cur.email);
      return user;
    },
  },
  {
    // New temporary password for someone who forgot theirs; their open sessions end.
    method: "POST", path: /^\/api\/team\/(\d+)\/reset-password$/, access: "admin",
    handler: async (r) => {
      const id = Number(r.params[0]);
      if (id === r.user!.id) throw bad("Use Change password for your own password.");
      const password = temporaryPassword();
      const [user] = await tx(r.actor, (t) => t(`update app_users set password_hash = $2, must_change_password = true, session_version = session_version + 1, session_grace_until = null, updated_at = now()
        where user_id = $1 and is_active returning ${COLS}`, [id, hashPassword(password)]));
      if (!user) throw bad("Switch this person's access on first.");
      await refreshAccount(user.email);
      return { user, temporaryPassword: password };
    },
  },
  {
    // An admin sets someone's password (e.g. read out on a call). By default they are asked to choose their own at
    // their next sign-in; their open sessions end either way.
    method: "POST", path: /^\/api\/team\/(\d+)\/password$/, access: "admin",
    handler: async (r) => {
      const id = Number(r.params[0]);
      if (id === r.user!.id) throw bad("Use Change password for your own password.");
      const password = String(r.body?.password ?? "");
      const [cur] = await query<{ email: string }>("select email from app_users where user_id = $1", [id]);
      if (!cur) throw notFound();
      const problem = passwordProblem(password, cur.email);
      if (problem) throw bad(problem);
      const mustChange = r.body?.must_change !== false;
      const [user] = await tx(r.actor, (t) => t(`update app_users set password_hash = $2, must_change_password = $3, session_version = session_version + 1, session_grace_until = null, updated_at = now()
        where user_id = $1 and is_active returning ${COLS}`, [id, hashPassword(password), mustChange]));
      if (!user) throw bad("Switch this person's access on first.");
      await refreshAccount(user.email);
      return { user };
    },
  },
  {
    // Remove someone for good. Their past changes stay in the Audit log under their email.
    method: "DELETE", path: /^\/api\/team\/(\d+)$/, access: "admin",
    handler: async (r) => {
      const id = Number(r.params[0]);
      if (id === r.user!.id) throw bad("You cannot remove yourself. Ask another admin.");
      const [cur] = await query<{ email: string; role: string; is_active: boolean }>("select email, role, is_active from app_users where user_id = $1", [id]);
      if (!cur) throw notFound();
      if (cur.role === "admin" && cur.is_active && !(await otherActiveAdmins(id))) throw bad("At least one active admin is needed. Make someone else an admin first.");
      await tx(r.actor, (t) => t("delete from app_users where user_id = $1", [id]));
      await refreshAccount(cur.email);
      return { removed: true };
    },
  },
];
