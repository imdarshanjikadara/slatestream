// Help and support: every call is passed to the SBD support hub (SUPPORT_HUB_URL, SUPPORT_HUB_KEY), where the team
// answers. This app stores nothing about requests. The browser only ever calls /api/support/*; the key stays here.
import type { Route } from "../router.js";
import { HttpError, type Req, type Res } from "../http.js";

const hub = () => ({ url: (process.env.SUPPORT_HUB_URL ?? "").trim().replace(/\/+$/, ""), key: (process.env.SUPPORT_HUB_KEY ?? "").trim() });

/** ":id" must be a whole number. */
const id = (v: string | undefined) => {
  const n = Number(v);
  if (!Number.isInteger(n) || n <= 0) throw new HttpError(400, "Not a valid request number.");
  return n;
};

// Passes one call to the hub for the signed-in user. The hub trusts the user named here because the project key
// proves the call comes from this server. Its status, JSON or file bytes come back unchanged.
async function toHub(r: Req, method: "GET" | "POST", path: string, body?: unknown): Promise<Res> {
  const { url, key } = hub();
  if (!url || !key) return { status: 503, body: { error: "Support isn't connected yet" } };
  const user = r.user;
  if (!user?.email?.includes("@")) throw new HttpError(403, "Sign in to use support");
  let res: Response;
  try {
    res = await fetch(`${url}/api/v1/${path}`, {
      method,
      headers: {
        Authorization: `Bearer ${key}`,
        "X-Support-User": user.email,
        "X-Support-User-Name": encodeURIComponent(user.name || user.email),
        ...(body !== undefined ? { "Content-Type": "application/json" } : {}),
      },
      body: body !== undefined ? JSON.stringify(body) : undefined,
      signal: AbortSignal.timeout(25_000),
    });
  } catch {
    return { status: 502, body: { error: "Support can't be reached right now. Try again in a minute." } };
  }
  if (res.status === 401) return { status: 502, body: { error: "Support isn't connected properly (project key refused)" } };
  const type = res.headers.get("content-type") ?? "";
  if (type.includes("application/json")) {
    const json = await res.json().catch(() => null);
    return { status: res.status, body: res.ok ? json : { error: (json as { error?: string } | null)?.error ?? "Support request failed" } };
  }
  if (!res.ok) return { status: res.status, body: { error: "Support request failed" } };
  // A file: its type, name and bytes, as the hub sent them.
  const disposition = res.headers.get("content-disposition");
  return { status: res.status, raw: Buffer.from(await res.arrayBuffer()), contentType: type || "application/octet-stream",
    headers: disposition ? { "Content-Disposition": disposition } : undefined };
}

const qs = (sp: URLSearchParams) => (sp.toString() ? `?${sp}` : "");

export const routes: Route[] = [
  { method: "GET", path: /^\/api\/support\/summary$/, handler: (r) => toHub(r, "GET", "summary") },
  { method: "GET", path: /^\/api\/support\/tickets$/, handler: (r) => toHub(r, "GET", `tickets${qs(r.query)}`) },
  { method: "POST", path: /^\/api\/support\/tickets$/, handler: (r) => toHub(r, "POST", "tickets", r.body ?? {}) },
  { method: "GET", path: /^\/api\/support\/tickets\/([^/]+)$/, handler: (r) => toHub(r, "GET", `tickets/${id(r.params[0])}`) },
  { method: "POST", path: /^\/api\/support\/tickets\/([^/]+)\/messages$/, handler: (r) => toHub(r, "POST", `tickets/${id(r.params[0])}/messages`, r.body ?? {}) },
  // Files go up as base64 JSON (up to ~4 MB): the router allows 5 MB on this path.
  { method: "POST", path: /^\/api\/support\/tickets\/([^/]+)\/attachments$/, handler: (r) => toHub(r, "POST", `tickets/${id(r.params[0])}/attachments`, r.body ?? {}) },
  { method: "POST", path: /^\/api\/support\/tickets\/([^/]+)\/status$/, handler: (r) => toHub(r, "POST", `tickets/${id(r.params[0])}/status`, r.body ?? {}) },
  { method: "GET", path: /^\/api\/support\/attachments\/([^/]+)$/, handler: (r) => toHub(r, "GET", `attachments/${id(r.params[0])}`) },
];
