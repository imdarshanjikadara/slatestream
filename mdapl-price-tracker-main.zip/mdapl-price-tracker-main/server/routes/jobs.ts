// Scraping runs and the queue worker (Vercel Cron).
import type { Route } from "../router.js";
import { CONCURRENCY, abortRun, channelSpeed, createRun, createRuns, dailyRuns, kickLocal, pauseRun, processQueue, queueStalled, resumeRun, retryFailed, scheduledRuns, setDailyRuns } from "../jobs/queue.js";
import { channelOf } from "../http.js";
import { bad } from "../http.js";
import { flushSentry, report } from "../sentry.js";
import { query } from "../db.js";

/** Work the queue for one function's time budget; if batches are still waiting, hand over to a fresh invocation.
 *  Vercel Hobby only allows daily crons, so a run keeps going by chaining invocations instead of a 5-minute cron. */
async function work(budgetMs: number) {
  const out = await processQueue(budgetMs);
  const [{ n }] = await query<{ n: number }>(`select count(*)::int n from scrape_run_batches x where status = 'pending'
    and not exists (select 1 from scrape_runs r where r.run_id = x.scrape_run_id and r.status in ('Paused', 'Aborted'))`);
  // Hand over to a fresh invocation when this one worked and batches are still waiting, or when a lane has waiting
  // batches and no worker. An invocation that found its lanes busy stops: the busy worker hands over itself.
  const worked = out.some((r: any) => r.status !== "done");
  if ((worked && n > 0) || (await queueStalled())) await continueLater();
  return { processed: out, pending: n };
}

async function continueLater() {
  const host = process.env.VERCEL_PROJECT_PRODUCTION_URL || process.env.VERCEL_URL;
  const secret = process.env.CRON_SECRET;
  if (!process.env.VERCEL || !host || !secret) return;
  // Only wait until the request is handed over; the next invocation runs on its own.
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), 3000);
  await fetch(`https://${host}/api/hooks/process-batch`, { method: "POST", headers: { Authorization: `Bearer ${secret}`, "Content-Type": "application/json" }, body: "{}", signal: ctl.signal })
    .catch(() => {}).finally(() => clearTimeout(t));
}

/** Keep the queue moving after a run is created: in-process locally, `waitUntil` on Vercel. */
async function kick() {
  if (!process.env.VERCEL) return kickLocal();
  try {
    const { waitUntil } = await import("@vercel/functions");
    // Background work outlives the request, so it delivers its own error reports when it ends.
    // The function stops at 300 s from the request; the work leaves room for the request itself and the hand-over.
    waitUntil(work(270_000).catch((e) => { console.error("[queue]", e); report(e, { tags: { area: "queue" } }); }).finally(flushSentry));
  } catch (e) {
    console.error("[queue] waitUntil unavailable", e);
  }
}

export const routes: Route[] = [
  {
    // "Create Scrape Run + Batches" from the Scraping page.
    method: "POST", path: /^\/api\/scrape\/runs$/,
    handler: async (r) => {
      const out = await createRuns({ channel: r.body?.channel, batchSize: r.body?.batch_size ?? 20, mode: r.body?.mode ?? "all", runType: r.body?.run_type ?? "Manual" }, r.actor);
      await kick();
      return { status: 201, body: out };
    },
  },
  {
    // On-demand scrape of selected links (the old app: scrapeAmazonLinks / scrapeFlipkartLinks).
    method: "POST", path: /^\/api\/scrape\/on-demand$/,
    handler: async (r) => {
      const ids = Array.isArray(r.body?.link_ids) ? r.body.link_ids : [];
      if (!ids.length) throw bad("Select at least one link.");
      if (ids.length > 5000) throw bad("Select at most 5,000 links at a time.");
      const out = await createRuns({ channel: r.body?.channel, batchSize: 20, runType: "On Demand", linkIds: ids }, r.actor);
      await kick();
      return { status: 201, body: out };
    },
  },
  {
    method: "POST", path: /^\/api\/runs\/(\d+)\/retry$/,
    handler: async (r) => {
      const n = await retryFailed(Number(r.params[0]), r.actor);
      if (n) await kick();
      return { requeued: n };
    },
  },
  {
    method: "POST", path: /^\/api\/runs\/(\d+)\/pause$/,
    handler: async (r) => { await pauseRun(Number(r.params[0]), r.actor); return { paused: true }; },
  },
  {
    method: "POST", path: /^\/api\/runs\/(\d+)\/abort$/,
    handler: async (r) => { await abortRun(Number(r.params[0]), r.actor); return { aborted: true }; },
  },
  {
    method: "POST", path: /^\/api\/runs\/(\d+)\/resume$/,
    handler: async (r) => { await resumeRun(Number(r.params[0]), r.actor); await kick(); return { resumed: true }; },
  },
  {
    // The daily automatic runs (scheduled-runs cron): paused or on.
    method: "GET", path: /^\/api\/scrape\/daily$/,
    handler: async () => dailyRuns(),
  },
  {
    method: "POST", path: /^\/api\/scrape\/daily$/,
    handler: async (r) => {
      if (typeof r.body?.paused !== "boolean") throw bad("Say whether the daily runs are paused (paused: true or false).");
      return setDailyRuns(r.body.paused, r.actor);
    },
  },
  // Webhook equivalents of the old workflows (CRON_SECRET bearer).
  { method: "POST", path: /^\/api\/hooks\/create-run$/, access: "cron",
    handler: async (r) => { const out = await createRun({ channel: r.body?.channel_name, batchSize: r.body?.batch_size, mode: r.body?.mode, runType: r.body?.run_type }, r.actor); await kick(); return out; } },
  { method: "POST", path: /^\/api\/hooks\/process-batch$/, access: "cron", handler: async () => work(285_000) },
  // Vercel Cron (GET with the CRON_SECRET bearer).
  { method: "GET", path: /^\/api\/cron\/process-batch$/, access: "cron", handler: async () => work(285_000) },
  {
    // How long scraping n links of a channel would take now: the channel's measured speed and the links already queued.
    method: "GET", path: /^\/api\/scrape\/estimate$/,
    handler: async (r) => {
      const channel = channelOf(r.query.get("channel"));
      const [{ sec, pageSec, measured }, [{ queued }]] = await Promise.all([channelSpeed(channel),
        query<{ queued: number }>(`select coalesce(sum(cardinality(product_link_ids)), 0)::int queued from scrape_run_batches x where status in ('pending', 'running')
          and not exists (select 1 from scrape_runs r where r.run_id = x.scrape_run_id and r.status in ('Paused', 'Aborted'))`)]);
      return { sec_per_link: Math.round(sec * 100) / 100, page_sec: Math.round(pageSec * 10) / 10, concurrency: CONCURRENCY, measured, links_queued: queued };
    },
  },
  {
    // An open run page calls this while batches are waiting: restarts the worker when nothing is working on the queue
    // (an invocation was cut off, or the hand-over between invocations was lost). Does nothing while a batch is running.
    method: "POST", path: /^\/api\/scrape\/continue$/,
    handler: async () => { const stalled = await queueStalled(); if (stalled) await kick(); return { restarted: stalled }; },
  },
  { method: "GET", path: /^\/api\/cron\/scheduled-runs$/, access: "cron",
    handler: async () => { const out = await scheduledRuns(); await kick(); return out; } },
];
