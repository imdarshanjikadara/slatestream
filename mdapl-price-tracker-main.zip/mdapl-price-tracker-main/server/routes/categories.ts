import type { Route } from "../router.js";
import { query, tx } from "../db.js";
import { bad, notFound, q } from "../http.js";
import { like } from "../sql.js";

const statusOf = (v: string | null) => (v === "inactive" || v === "all" ? v : "active");

function cleanName(v: unknown) {
  const name = String(v ?? "").trim().replace(/\s+/g, " ");
  if (!name) throw bad("Enter a category name.");
  if (name.length > 120) throw bad("Keep the category name under 120 characters.");
  return name;
}

async function assertUnique(name: string, exceptId?: number) {
  const [dup] = await query("select category_id from product_categories where lower(name) = lower($1) and ($2::int is null or category_id <> $2) limit 1", [name, exceptId ?? null]);
  if (dup) throw bad(`A category called "${name}" already exists.`);
}

export const routes: Route[] = [
  {
    method: "GET", path: /^\/api\/categories$/,
    handler: async (r) => {
      const status = statusOf(r.query.get("status"));
      const search = like(q.str(r.query, "q"));
      const limit = q.limit(r.query), offset = q.offset(r.query);
      const where = `($1::text = 'all' or c.is_active = ($1 = 'active')) and ($2::text is null or c.name ilike $2)`;
      const [rows, [counts], [stats]] = await Promise.all([
        query(`select c.category_id, c.name, c.is_active, c.created_at, c.updated_at,
            coalesce(p.products, 0)::int products, coalesce(p.links, 0)::int links
          from product_categories c
          left join (select p.category_id, count(distinct p.product_id) products, count(pl.product_link_id) filter (where pl.is_active) links
                     from products p left join product_links pl on pl.product_id = p.product_id where p.is_active group by p.category_id) p on p.category_id = c.category_id
          where ${where} order by c.category_id desc limit ${limit} offset ${offset}`, [status, search]),
        query(`select count(*) filter (where is_active)::int active, count(*) filter (where not is_active)::int inactive, count(*)::int "all",
            count(*) filter (where ($1::text = 'all' or c.is_active = ($1 = 'active')) and ($2::text is null or c.name ilike $2))::int total
          from product_categories c`, [status, search]),
        query(`select (select count(*) from products where is_active)::int products,
            (select count(*) from product_links pl join products p on p.product_id = pl.product_id where pl.is_active and p.is_active)::int links`),
      ]);
      return { rows, total: counts.total, counts: { active: counts.active, inactive: counts.inactive, all: counts.all }, stats };
    },
  },
  {
    method: "GET", path: /^\/api\/categories\/(\d+)$/,
    handler: async (r) => {
      const id = Number(r.params[0]);
      const [[cat], products] = await Promise.all([
        query("select * from product_categories where category_id = $1", [id]),
        query(`select p.product_id, p.name, p.brand, p.hana_code, p.mrp, p.mop, p.is_active,
            count(pl.product_link_id) filter (where pl.is_active)::int links
          from products p left join product_links pl on pl.product_id = p.product_id
          where p.category_id = $1 group by p.product_id order by p.is_active desc, p.name`, [id]),
      ]);
      if (!cat) throw notFound();
      return { category: cat, products };
    },
  },
  {
    // saveCategories
    method: "POST", path: /^\/api\/categories$/,
    handler: async (r) => {
      const name = cleanName(r.body?.name);
      await assertUnique(name);
      const [row] = await tx(r.actor, (t) => t("insert into product_categories (name, is_active, created_at, updated_at) values ($1, true, now(), now()) returning *", [name]));
      return { status: 201, body: row };
    },
  },
  {
    // updateCategories (rename), plus deactivate / reactivate.
    method: "PATCH", path: /^\/api\/categories\/(\d+)$/,
    handler: async (r) => {
      const id = Number(r.params[0]);
      const name = r.body?.name !== undefined ? cleanName(r.body.name) : null;
      const active = typeof r.body?.is_active === "boolean" ? r.body.is_active : null;
      if (name) await assertUnique(name, id);
      const [row] = await tx(r.actor, (t) => t(`update product_categories set name = coalesce($2, name), is_active = coalesce($3, is_active), updated_at = now()
        where category_id = $1 returning *`, [id, name, active]));
      if (!row) throw notFound();
      return row;
    },
  },
  {
    // Delete a category for good. Its products stay, without a category (restorable from the Audit log for 30 days).
    method: "DELETE", path: /^\/api\/categories\/(\d+)$/,
    handler: async (r) => {
      const id = Number(r.params[0]);
      const out = await tx(r.actor, async (t) => {
        const moved = await t("update products set category_id = null, updated_at = now() where category_id = $1 returning product_id", [id]);
        const [row] = await t("delete from product_categories where category_id = $1 returning category_id, name", [id]);
        return row ? { ...row, products: moved.length } : null;
      });
      if (!out) throw notFound();
      return out;
    },
  },
];
