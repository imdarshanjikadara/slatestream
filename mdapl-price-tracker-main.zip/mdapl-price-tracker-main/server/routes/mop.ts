// MOP Breach Reports. A report records, for one channel and date range, every active product whose latest scraped
// price is below its MOP. The lines are stored, so the Excel can be rebuilt any time.
import type { Route } from "../router.js";
import { query, tx } from "../db.js";
import { CHANNEL_LABEL, bad, channelOf, istDay, notFound, q, validDate } from "../http.js";
import { like } from "../sql.js";
import { BASE } from "./results.js";

const WHERE = `($1::text is null or lower(r.channel_name) = $1)
  and ($2::date is null or r.report_date >= $2::date) and ($3::date is null or r.report_date <= $3::date)
  and ($4::text is null or r.remarks ilike $4 or r.generated_by ilike $4)`;

export const routes: Route[] = [
  {
    method: "GET", path: /^\/api\/mop-reports$/,
    handler: async (r) => {
      const args = [channelOf(r.query.get("channel")), q.date(r.query, "from"), q.date(r.query, "to"), like(q.str(r.query, "q"))];
      const limit = q.limit(r.query), offset = q.offset(r.query);
      const [rows, [s], perChannel] = await Promise.all([
        query(`select r.*, coalesce(i.n, 0)::int lines,
            coalesce((select u.name from app_users u where lower(u.email) = lower(r.generated_by)), r.generated_by) generated_by_name from mop_breach_reports r
          left join (select report_id, count(*) n from mop_breach_report_items group by 1) i on i.report_id = r.report_id
          where ${WHERE} order by r.report_date desc nulls last, r.report_id desc limit ${limit} offset ${offset}`, args),
        query(`select count(*)::int total, coalesce(sum(breached_products), 0)::int breached, coalesce(sum(total_products), 0)::int checked,
            max(report_date)::text last_date from mop_breach_reports r where ${WHERE}`, args),
        query(`select lower(channel_name) channel, count(*)::int n from mop_breach_reports r where ($1::date is null or r.report_date >= $1::date) and ($2::date is null or r.report_date <= $2::date) group by 1`, [args[1], args[2]]),
      ]);
      return { rows, total: s.total, stats: s, channels: Object.fromEntries(perChannel.map((x) => [x.channel, x.n])) };
    },
  },
  {
    method: "GET", path: /^\/api\/mop-reports\/(\d+)$/,
    handler: async (r) => {
      const id = Number(r.params[0]);
      const [[report], items] = await Promise.all([
        query("select * from mop_breach_reports where report_id = $1", [id]),
        query("select * from mop_breach_report_items where report_id = $1 order by gap desc, product_name", [id]),
      ]);
      if (!report) throw notFound();
      if (items.length || !report.breached_products) return { report, items, rebuilt: false };
      // Reports made in the old app kept their lines only in a file (file_url, which in the copied data points at placeholder storage).
      // Rebuild the lines from that day's latest prices for the channel, with the products' current trigger prices.
      const channel = channelOf(String(report.channel_name ?? "").toLowerCase());
      const day = report.report_date instanceof Date ? report.report_date.toISOString().slice(0, 10) : String(report.report_date).slice(0, 10);
      const rows = channel ? await query(`${BASE} select * from base where channel_name = $3 and below_mop order by (alert_price - price) desc, product_name`, [day, day, channel]) : [];
      return {
        report, rebuilt: true,
        items: rows.map((b, i) => ({ item_id: `r${i}`, product_link_id: b.product_link_id, product_id: b.product_id, product_name: b.product_name, brand: b.brand, category_name: b.category_name,
          seller: b.seller, url: b.url, price: b.price, mop: b.alert_price, gap: Number(b.alert_price) - Number(b.price), scraped_at: b.scrape_timestamp })),
      };
    },
  },
  {
    // "Generate MOP Breach Report" on Scrape Product Results.
    method: "POST", path: /^\/api\/mop-reports$/,
    handler: async (r) => {
      const channel = channelOf(r.body?.channel);
      if (!channel) throw bad("Choose a channel.");
      const from = validDate(r.body?.from) ? r.body.from : istDay(7);
      const to = validDate(r.body?.to) ? r.body.to : istDay(0);
      if (from > to) throw bad("The start date is after the end date.");
      const remarks = String(r.body?.remarks ?? "").trim().slice(0, 500) || null;
      const [all, breaches] = await Promise.all([
        query<{ n: number }>(`${BASE} select count(*)::int n from base where channel_name = $3 and price > 0`, [from, to, channel]),
        query(`${BASE} select * from base where channel_name = $3 and below_mop order by (alert_price - price) desc, product_name`, [from, to, channel]),
      ]);
      const report = await tx(r.actor, async (t) => {
        const [rep] = await t(`insert into mop_breach_reports (report_date, channel_name, total_products, breached_products, generated_by, generated_at, remarks)
          values ($1, $2, $3, $4, $5, now(), $6) returning *`, [to, CHANNEL_LABEL[channel], all[0]?.n ?? 0, breaches.length, r.user?.name ?? r.actor.actor, remarks]);
        for (let i = 0; i < breaches.length; i += 200) {
          const chunk = breaches.slice(i, i + 200);
          const vals: unknown[] = [];
          const rows = chunk.map((b, j) => {
            vals.push(rep.report_id, b.product_link_id, b.product_id, b.product_name, b.brand, b.category_name, b.seller, b.url, b.price, b.alert_price, Number(b.alert_price) - Number(b.price), b.scrape_timestamp);
            const o = j * 12;
            return `(${Array.from({ length: 12 }, (_, k) => `$${o + k + 1}`).join(",")})`;
          });
          await t(`insert into mop_breach_report_items (report_id, product_link_id, product_id, product_name, brand, category_name, seller, url, price, mop, gap, scraped_at) values ${rows.join(",")}`, vals);
        }
        return rep;
      });
      return { status: 201, body: { ...report, from, to } };
    },
  },
  {
    method: "PATCH", path: /^\/api\/mop-reports\/(\d+)$/,
    handler: async (r) => {
      const remarks = String(r.body?.remarks ?? "").trim().slice(0, 500) || null;
      const [row] = await tx(r.actor, (t) => t("update mop_breach_reports set remarks = $2 where report_id = $1 returning *", [Number(r.params[0]), remarks]));
      if (!row) throw notFound();
      return row;
    },
  },
];
