import type { Route } from "../router.js";
import { changeOwnPassword, clearCookie, issue, login, sessionCookie } from "../auth.js";
import { bad } from "../http.js";
import { isDemo } from "../db.js";

const secure = () => !!process.env.VERCEL || process.env.NODE_ENV === "production";

export const routes: Route[] = [
  {
    method: "POST", path: /^\/api\/auth\/login$/, access: "public",
    handler: async (r) => {
      const email = String(r.body?.email ?? ""), password = String(r.body?.password ?? "");
      if (!email || !password) throw bad("Enter your email and password.");
      const out = await login(email, password, r.ip);
      if (!out.user) return { status: 401, body: { error: out.error } };
      return { body: { user: out.user }, headers: { "Set-Cookie": sessionCookie(await issue(out.user), secure()) } };
    },
  },
  {
    method: "POST", path: /^\/api\/auth\/logout$/, access: "public",
    handler: async () => ({ body: { ok: true }, headers: { "Set-Cookie": clearCookie(secure()) } }),
  },
  {
    method: "GET", path: /^\/api\/auth\/me$/, access: "public",
    handler: async (r) => ({ user: r.user, demo: isDemo() && !process.env.APP_USERS }),
  },
  {
    // Change password (user menu); also how someone with a temporary password sets their own.
    method: "POST", path: /^\/api\/auth\/password$/,
    handler: async (r) => {
      const current = String(r.body?.current ?? ""), next = String(r.body?.next ?? "");
      if (!current || !next) throw bad("Enter your current password and a new one.");
      const out = await changeOwnPassword(r.user!, current, next, r.ip);
      if (out.error) throw bad(out.error);
      return { body: { ok: true }, headers: { "Set-Cookie": sessionCookie(out.token!, secure()) } };
    },
  },
];
