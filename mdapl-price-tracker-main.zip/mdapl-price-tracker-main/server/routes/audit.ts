// Audit log: every change recorded by the database trigger, with who, device, IP and field-by-field before/after.
import type { Route } from "../router.js";
import { query, tx } from "../db.js";
import { HttpError, bad, notFound, q } from "../http.js";
import { IST_FROM, IST_TO } from "../sql.js";

const UNDO_DAYS = 30;
const ACTIONS = ["insert", "update", "delete", "soft_delete", "restore"];

export const routes: Route[] = [
  {
    method: "GET", path: /^\/api\/audit$/, access: "admin",
    handler: async (r) => {
      const tab = r.query.get("tab") === "deleted" ? "deleted" : "all";
      const action = ACTIONS.includes(r.query.get("action") ?? "") ? r.query.get("action") : null;
      const args = [tab, q.str(r.query, "table", 64), action, q.str(r.query, "actor", 200), q.str(r.query, "record", 40), q.date(r.query, "from"), q.date(r.query, "to")];
      const where = `($1::text = 'all' or l.action in ('delete', 'soft_delete'))
        and ($2::text is null or l.table_name = $2) and ($3::text is null or l.action = $3) and ($4::text is null or l.actor = $4)
        and ($5::text is null or l.row_pk = $5) and ${IST_FROM("l.at", "$6")} and ${IST_TO("l.at", "$7")}`;
      const limit = q.limit(r.query), offset = q.offset(r.query);
      const [rows, [c], actors, tables, people] = await Promise.all([
        query(`select l.id, l.at, l.actor, l.ip, l.user_agent, l.table_name, l.row_pk, l.action, l.restored_at, l.restored_by,
            coalesce(l.new_data ->> 'name', l.old_data ->> 'name', l.new_data ->> 'product_name', l.old_data ->> 'url', l.new_data ->> 'url', l.new_data ->> 'channel_name', l.old_data ->> 'channel_name') title,
            case when l.action in ('update', 'restore') then (select array_agg(k) from jsonb_object_keys(coalesce(l.new_data, '{}'::jsonb)) k) end fields,
            case when l.action in ('update', 'restore') then (select jsonb_object_agg(k, jsonb_build_array(l.old_data -> k, l.new_data -> k)) from (select k from jsonb_object_keys(coalesce(l.new_data, '{}'::jsonb)) k limit 2) x) end preview,
            (l.action in ('delete', 'soft_delete') and l.restored_at is null and l.at > now() - interval '${UNDO_DAYS} days') restorable
          from audit_log l where ${where} order by l.at desc, l.id desc limit ${limit} offset ${offset}`, args),
        query(`select count(*)::int total from audit_log l where ${where}`, args),
        query<{ actor: string }>("select distinct actor from audit_log order by 1"),
        query<{ table_name: string }>("select distinct table_name from audit_log order by 1"),
        // People's names, so the log says "by Disha" instead of an email address.
        query<{ email: string; name: string }>("select lower(email) email, name from app_users"),
      ]);
      return { rows, total: c.total, actors: actors.map((a) => a.actor), tables: tables.map((t) => t.table_name),
        names: Object.fromEntries(people.map((p) => [p.email, p.name])) };
    },
  },
  {
    method: "GET", path: /^\/api\/audit\/(\d+)$/, access: "admin",
    handler: async (r) => {
      const [row] = await query(`select l.*, (l.action in ('delete', 'soft_delete') and l.restored_at is null and l.at > now() - interval '${UNDO_DAYS} days') restorable,
          (select count(*)::int from audit_log x where x.txid = l.txid and x.action in ('delete', 'soft_delete') and x.restored_at is null) together
        from audit_log l where l.id = $1`, [Number(r.params[0])]);
      if (!row) throw notFound("This audit entry no longer exists.");
      return row;
    },
  },
  {
    method: "POST", path: /^\/api\/audit\/(\d+)\/restore$/, access: "admin",
    handler: async (r) => {
      const id = Number(r.params[0]);
      if (!Number.isInteger(id) || id <= 0) throw bad("This entry no longer exists, so nothing was restored.");
      try {
        const [res] = await tx(r.actor, (t) => t<{ n: number }>("select restore_deleted($1, $2) n", [id, r.actor.actor]));
        if (!res.n) throw new HttpError(409, "This was already restored, so nothing changed. Reload the page.");
        return { restored: res.n, message: res.n === 1 ? "Restored. It is back in its list." : `Restored ${res.n} records that were deleted together.` };
      } catch (e) {
        const m = (e as Error).message;
        if (/expired/.test(m)) throw bad(`Deletes can be restored for ${UNDO_DAYS} days. This one is older, so nothing was restored.`);
        if (/not_found/.test(m)) throw notFound("This entry no longer exists, so nothing was restored.");
        throw e;
      }
    },
  },
];
