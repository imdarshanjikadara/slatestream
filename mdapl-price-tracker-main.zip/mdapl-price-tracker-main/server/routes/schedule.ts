// Your Schedule: every product the daily automatic run picks up (every day or on a schedule), with when it is next due,
// and what the next two weeks look like. Editing goes through POST /api/products/bulk.
import type { Route } from "../router.js";
import { query, tx } from "../db.js";
import { bad, q } from "../http.js";
import { like } from "../sql.js";
import { isDue, istDate, nextRun, type Schedule } from "../../shared/schedule.js";

const DAYS_AHEAD = 14;
const SCHED_COLS = "p.regular_scraping, p.scheduled_scraping, p.scraping_schedule_weekly, p.months_to_scrape, p.scraping_schedule_monthly, p.scrape_time, p.paused_mode";
// Paused: taken off the daily runs with Pause, remembering how it was scraped (paused_mode), or (paused before that was
// remembered) off with days, dates or months still saved.
const OFF = "not coalesce(p.regular_scraping, false) and not coalesce(p.scheduled_scraping, false)";
const PAUSED = `(${OFF} and (p.paused_mode is not null or coalesce(p.scraping_schedule_weekly, '') <> '' or coalesce(p.scraping_schedule_monthly, '') <> '' or coalesce(p.months_to_scrape, '') <> ''))`;
// $1 mode: active (every day or on a schedule) | regular | scheduled | paused | off | all; $2 search; $3 category; $4 brand.
const WHERE = `p.is_active
  and ($1::text = 'all' or ($1 = 'active' and (p.regular_scraping or p.scheduled_scraping)) or ($1 = 'regular' and p.regular_scraping)
    or ($1 = 'scheduled' and p.scheduled_scraping and not coalesce(p.regular_scraping, false)) or ($1 = 'paused' and ${PAUSED})
    or ($1 = 'off' and ${OFF} and not ${PAUSED}))
  and ($2::text is null or p.name ilike $2 or p.hana_code ilike $2)
  and ($3::int is null or p.category_id = $3)
  and ($4::text is null or lower(p.brand) = lower($4))`;
const idsOf = (v: unknown): number[] => [...new Set((Array.isArray(v) ? v : []).map(Number).filter((n: number) => Number.isInteger(n) && n > 0))] as number[];

const ymd = (d: { y: number; m: number; d: number }) => `${d.y}-${String(d.m).padStart(2, "0")}-${String(d.d).padStart(2, "0")}`;

export const routes: Route[] = [
  {
    // Pause: off the daily runs, remembering whether each product was scraped every day or on a schedule (and keeping
    // its days, dates, months and time), so Resume puts it back as it was.
    method: "POST", path: /^\/api\/schedule\/pause$/,
    handler: async (r) => {
      const ids = idsOf(r.body?.ids);
      if (!ids.length) throw bad("Select at least one product.");
      const rows = await tx(r.actor, (t) => t(`update products set paused_mode = case when regular_scraping then 'regular' else 'scheduled' end,
          regular_scraping = false, scheduled_scraping = false, updated_at = now()
        where product_id = any($1::int[]) and (regular_scraping or scheduled_scraping) returning product_id`, [ids]));
      return { paused: rows.length, skipped: ids.length - rows.length };
    },
  },
  {
    // Resume paused products: back to every day or their saved schedule. Products that are not paused are skipped.
    method: "POST", path: /^\/api\/schedule\/resume$/,
    handler: async (r) => {
      const ids = idsOf(r.body?.ids);
      if (!ids.length) throw bad("Select at least one product.");
      const rows = await tx(r.actor, (t) => t(`update products p set regular_scraping = coalesce(p.paused_mode, 'scheduled') = 'regular',
          scheduled_scraping = coalesce(p.paused_mode, 'scheduled') = 'scheduled', paused_mode = null, updated_at = now()
        where p.product_id = any($1::int[]) and p.is_active and ${PAUSED} returning p.product_id`, [ids]));
      return { resumed: rows.length, skipped: ids.length - rows.length };
    },
  },
  {
    method: "GET", path: /^\/api\/schedule$/,
    handler: async (r) => {
      const mode = ["regular", "scheduled", "paused", "off", "all"].includes(r.query.get("mode") ?? "") ? r.query.get("mode") : "active";
      const args = [mode, like(q.str(r.query, "q")), q.int(r.query, "category"), q.str(r.query, "brand")];
      const limit = q.limit(r.query), offset = q.offset(r.query);
      if (r.query.get("ids") === "1") return (await query<{ id: number }>(`select p.product_id id from products p where ${WHERE} order by p.product_id`, args)).map((x) => x.id);
      const [rows, [c], all] = await Promise.all([
        query(`select p.product_id, p.name, p.brand, p.hana_code, pc.name category_name, ${SCHED_COLS},
            (select count(*) from product_links pl where pl.product_id = p.product_id and pl.is_active)::int links
          from products p left join product_categories pc on pc.category_id = p.category_id
          where ${WHERE} order by p.regular_scraping desc nulls last, coalesce(p.scrape_time, '06:00'), p.name limit ${limit} offset ${offset}`, args),
        query(`select count(*) filter (where ${WHERE})::int total,
            count(*) filter (where p.is_active and (p.regular_scraping or p.scheduled_scraping))::int active,
            count(*) filter (where p.is_active and p.regular_scraping)::int regular,
            count(*) filter (where p.is_active and p.scheduled_scraping and not coalesce(p.regular_scraping, false))::int scheduled,
            count(*) filter (where p.is_active and ${PAUSED})::int paused,
            count(*) filter (where p.is_active and ${OFF} and not ${PAUSED})::int off,
            count(*) filter (where p.is_active)::int "all"
          from products p`, args),
        // The next two weeks: how many products each daily run picks up (active products with an active link).
        query<Schedule>(`select ${SCHED_COLS} from products p where p.is_active and (p.regular_scraping or p.scheduled_scraping)
          and ($1::text is null or p.name ilike $1 or p.hana_code ilike $1) and ($2::int is null or p.category_id = $2) and ($3::text is null or lower(p.brand) = lower($3))
          and exists (select 1 from product_links pl where pl.product_id = p.product_id and pl.is_active)`, args.slice(1)),
      ]);
      const now = Date.now();
      const days = Array.from({ length: DAYS_AHEAD }, (_, i) => {
        const day = istDate(new Date(now + i * 86_400_000));
        return { date: ymd(day), dow: day.dow, products: all.filter((p) => isDue(p, day)).length };
      });
      return {
        rows: rows.map((p) => { const n = nextRun(p as Schedule); return { ...p, next_due: n ? ymd(n) : null, next_time: n?.time ?? null }; }),
        total: c.total,
        counts: { active: c.active, regular: c.regular, scheduled: c.scheduled, paused: c.paused, off: c.off, all: c.all },
        days,
      };
    },
  },
];
