import type { Route } from "../router.js";
import { query } from "../db.js";
import { channelOf, istDay, q } from "../http.js";
import { BELOW, IST_DAY, IST_RANGE, latestCte } from "../sql.js";

// averagePriceDrop reads every result ever scraped (last 7 days against all before), so it is kept for 15 minutes:
// it only moves when a scrape lands, and a warm server answers the dashboard without that pass.
let avgDrop: { at: number; value: Promise<{ avg_price_change: string | null }[]> } | null = null;
function averagePriceChange() {
  if (!avgDrop || Date.now() - avgDrop.at > 15 * 60_000) {
    const value = query<{ avg_price_change: string | null }>(`select round(avg(t.cur - t.last)::numeric, 2) avg_price_change from (
        select pl.product_id,
          avg(sr.price) filter (where sr.created_at > now() - interval '7 days' and sr.price > 0) cur,
          avg(sr.price) filter (where sr.created_at <= now() - interval '7 days' and sr.price > 0) last
        from scrape_results sr join product_links pl on sr.product_link_id = pl.product_link_id group by pl.product_id) t
      where t.last > 0 and t.cur > 0`);
    avgDrop = { at: Date.now(), value };
    value.catch(() => { avgDrop = null; });
  }
  return avgDrop.value;
}

export const routes: Route[] = [
  {
    method: "GET", path: /^\/api\/dashboard$/,
    handler: async (r) => {
      // the old app default: the last 7 days up to today.
      const from = q.date(r.query, "from") ?? istDay(7), to = q.date(r.query, "to") ?? istDay(0);
      const channel = channelOf(r.query.get("channel")) ?? "amazon";
      // Default category for the trend (first active one) is resolved inside the queries, not in a round trip before them.
      const category = q.int(r.query, "category");
      const cat = "coalesce($3::int, (select category_id from product_categories where is_active order by category_id limit 1))";
      const inRange = IST_RANGE("sr.created_at", "$1", "$2");

      const [perChannel, breached, [drop], trend, channels, discount, categories, [firstCat]] = await Promise.all([
        // Links available (getAllProductLinks per channel) and unique links scraped in the range (totalProductsScraped).
        query(`select pl.channel_name, count(*)::int links, count(*) filter (where pl.is_active)::int active_links,
            count(s.product_link_id)::int scraped
          from product_links pl
          left join (select distinct sr.product_link_id from scrape_results sr where ${inRange}) s on s.product_link_id = pl.product_link_id
          group by pl.channel_name`, [from, to]),
        // Products whose latest price in the range is below their trigger price (MOP breach), per channel.
        query(`with ${latestCte("$1", "$2")}
          select pl.channel_name, count(*)::int checked,
            count(*) filter (where ${BELOW("l.price")})::int breached
          from latest l join product_links pl on pl.product_link_id = l.product_link_id join products p on p.product_id = pl.product_id
          where p.is_active and pl.is_active group by pl.channel_name`, [from, to]),
        // averagePriceDrop: average change of a product's price, last 7 days against before.
        averagePriceChange(),
        // linechartQuery: average price per day for one category.
        query(`select ${IST_DAY("sr.created_at")}::text date, round(avg(sr.price)::numeric, 2) avg_price
          from scrape_results sr join product_links pl on sr.product_link_id = pl.product_link_id join products p on pl.product_id = p.product_id
          where p.category_id = ${cat} and sr.price > 0 and ${inRange} group by 1 order by 1`, [from, to, category]),
        // barchartQuery: average price per channel.
        query(`select pl.channel_name, round(avg(sr.price)::numeric, 2) avg_price
          from scrape_results sr join product_links pl on sr.product_link_id = pl.product_link_id
          where sr.price > 0 and ${inRange} group by pl.channel_name order by avg_price`, [from, to]),
        // avgDiscountOverTime.
        query(`select ${IST_DAY("sr.created_at")}::text date, round(avg(sr.discount)::numeric, 2) avg_discount
          from scrape_results sr where ${inRange} group by 1 order by 1`, [from, to]),
        // pieChartQuery: products per category.
        query(`select c.name category_name, count(p.product_id)::int product_count
          from products p join product_categories c on p.category_id = c.category_id where p.is_active group by c.name order by 2 desc`),
        category ? Promise.resolve([{ id: category }]) : query<{ id: number }>("select category_id id from product_categories where is_active order by category_id limit 1"),
      ]);

      const ch = perChannel.find((x) => x.channel_name === channel) ?? { links: 0, active_links: 0, scraped: 0 };
      const b = breached.find((x) => x.channel_name === channel) ?? { checked: 0, breached: 0 };
      return {
        from, to, channel, category: category ?? firstCat?.id ?? null,
        stats: {
          breached: b.breached, checked: b.checked, scraped: ch.scraped, links: ch.links, activeLinks: ch.active_links,
          breachRate: b.checked ? Math.round((b.breached / b.checked) * 1000) / 10 : null,
          avgPriceChange: drop?.avg_price_change ?? null,
        },
        channelCounts: Object.fromEntries(perChannel.map((x) => [x.channel_name, x.links])),
        trend, channels, discount, categories,
      };
    },
  },
];
