// The scrape queue, ported from the old workflows:
// * createRun   = "Create Scrape Run + Batches"
// * processNextBatch = "Process Next Product Scrape Batch" (+ the per-channel "Scrape … Product Links" workflows)
// * scheduledRuns = "Batch Scraping of Products" (daily run per channel)
import { query, tx, type Actor } from "../db.js";
import { bad } from "../http.js";
import { DAILY_CHANNELS, PAGE_TIMEOUT_MS, SCRAPE_CHANNELS, browserlessPressure, overloaded, retryable, scrapeUrl, type Scraped } from "../scrape/browserless.js";
import { hhmm, isDue, istDate, istMinutes, timeOf, type Schedule } from "../../shared/schedule.js";
import { scrapeSeconds } from "../../shared/estimate.js";
import { report } from "../sentry.js";

const SYSTEM: Actor = { actor: "system:scraper" };
// A Vercel function is stopped after 300 s, so a batch still marked running after 6 minutes was cut off: take it over.
const STALE_LOCK_MIN = 6;
// A link try may use up to PAGE_TIMEOUT_MS (100 s). No new try starts with less than that left in the step: it carries
// on in the next step instead, so a step never ends with pages cut off half-way.
const LINK_MIN_MS = PAGE_TIMEOUT_MS + 5_000;
const MAX_ATTEMPTS = 5;
// One browser at a time on the Browserless server, for every run together: one link loads, is saved, then the next.
// With Amazon read without JavaScript a page takes about 5 s, so this is fast enough and never strains the droplet.
// SCRAPE_CONCURRENCY raises it only if the server is ever made bigger.
export const CONCURRENCY = Math.max(1, Number(process.env.SCRAPE_CONCURRENCY ?? 1) || 1);
// A link that times out or hits a proxy or Browserless error is tried again at the end of the batch on a fresh browser
// (a new proxy exit), up to 3 tries in all. Tries already made are remembered across steps (link_errors).
const LINK_TRIES = 3;
/** Batches of a paused run are left alone by the worker until the run is resumed. */
// Two lanes, each scraping one batch at a time: on-demand runs (someone is waiting) and full or scheduled runs. So a
// few links scraped on demand never wait behind a long background batch.
// One queue for all runs (one batch scraping at a time); on-demand batches are still taken first.
const LANE = (_r: string) => "true";
const NOT_PAUSED = (alias: string) => `not exists (select 1 from scrape_runs pr where pr.run_id = ${alias}.scrape_run_id and pr.status in ('Paused', 'Aborted'))`;

export type RunInput = { channel: string; batchSize?: number; mode?: string; runType?: string; linkIds?: number[]; /** Scheduled runs: only products whose time of day is one of these ("HH:MM"). */ times?: string[] };

/** validateCreateScrapeRunInput + createScrapeRun + getEligibleProductLinks + buildScrapeRunBatches + insertScrapeRunBatches. */
export async function createRun(input: RunInput, who: Actor) {
  const channel = String(input.channel || "").toLowerCase();
  const batchSize = Number(input.batchSize ?? 20);
  const runType = String(input.runType || "Manual");
  if (!(SCRAPE_CHANNELS as readonly string[]).includes(channel)) throw bad("Scraping runs are available for Amazon, Flipkart, Instamart and Zepto.");
  if (!Number.isInteger(batchSize) || batchSize < 1 || batchSize > 45) throw bad("Batch size must be a whole number from 1 to 45.");
  const only = input.linkIds?.length ? [...new Set(input.linkIds.map(Number).filter((n) => Number.isInteger(n) && n > 0))] : null;

  const scheduled = input.mode === "scheduled";
  const rows = await query<Schedule & { id: number }>(`select pl.product_link_id id, p.regular_scraping, p.scheduled_scraping, p.scraping_schedule_weekly, p.months_to_scrape,
      p.scraping_schedule_monthly, p.scrape_time from product_links pl join products p on p.product_id = pl.product_id
      where pl.channel_name = $1 and pl.is_active = true and p.is_active = true and ($2::int[] is null or pl.product_link_id = any($2::int[]))
      order by pl.product_link_id`, [channel, only]);
  // The daily run takes only the products due today; a manual full run and on-demand scraping take every active link, as in the old app.
  const ids = (scheduled ? rows.filter((r) => isDue(r) && (!input.times || input.times.includes(timeOf(r)))) : rows).map((r) => r.id);
  if (!ids.length && scheduled) return { status: "nothing_due", channel_name: channel, link_count: 0, active_links: rows.length };
  if (!ids.length) throw bad(only ? "None of the selected links can be scraped (the link or its product is switched off)." : "There are no active links to scrape on this channel.");

  const batches: number[][] = [];
  for (let i = 0; i < ids.length; i += batchSize) batches.push(ids.slice(i, i + batchSize));
  const run = await tx(who, async (t) => {
    const [r] = await t("insert into scrape_runs (created_at, run_date, status, type, channel_name) values (now(), now(), 'Started', $1, $2) returning run_id", [runType, channel]);
    await t(`insert into scrape_run_batches (scrape_run_id, channel_name, batch_number, batch_total_count, product_link_ids, status, created_at, updated_at)
      select $1, $2, b.n, $3, b.ids, 'pending', now(), now()
      from jsonb_to_recordset($4::jsonb) as b(n int, ids int[])`, [r.run_id, channel, batches.length, JSON.stringify(batches.map((ids, i) => ({ n: i + 1, ids })))]);
    return r;
  });
  const [{ pageSec }, [{ ahead }]] = await Promise.all([channelSpeed(channel),
    query<{ ahead: number }>(`select coalesce(sum(cardinality(product_link_ids)), 0)::int ahead from scrape_run_batches x where status in ('pending', 'running') and scrape_run_id <> $1 and ${NOT_PAUSED("x")}`, [run.run_id])]);
  // On-demand runs go first, so only full and scheduled runs wait behind the queue.
  const wait = runType === "On Demand" ? 0 : ahead;
  const est = batches.reduce((a, b) => a + scrapeSeconds(b.length, pageSec, CONCURRENCY), 0);
  return { status: "created", scrape_run_id: run.run_id, channel_name: channel, batch_count: batches.length, link_count: ids.length,
    est_seconds: Math.round(est), est_wait_seconds: Math.round(scrapeSeconds(wait, pageSec, CONCURRENCY)), links_ahead: wait, skipped: only ? only.length - ids.length : 0,
    ...(scheduled ? { not_due_today: rows.length - ids.length } : {}) };
}

/** The All tab on the Scraping page: one run per channel, since a run belongs to one channel.
 *  Channels with nothing to scrape are left out instead of failing the whole thing. */
export async function createRuns(input: RunInput, who: Actor) {
  if (String(input.channel || "").toLowerCase() !== "all") return createRun(input, who);
  // On-demand: the ticked links, grouped by their own channel.
  let byChannel: Map<string, number[]> | null = null;
  if (input.linkIds?.length) {
    const ids = [...new Set(input.linkIds.map(Number).filter((n) => Number.isInteger(n) && n > 0))];
    const rows = await query<{ id: number; channel_name: string }>("select product_link_id id, channel_name from product_links where product_link_id = any($1::int[])", [ids]);
    byChannel = new Map();
    for (const x of rows) byChannel.set(x.channel_name, [...(byChannel.get(x.channel_name) ?? []), x.id]);
  }
  type Created = Extract<Awaited<ReturnType<typeof createRun>>, { batch_count: number }>;
  const runs: Created[] = [];
  const empty: string[] = [];
  for (const channel of SCRAPE_CHANNELS) {
    const linkIds = byChannel ? byChannel.get(channel) ?? [] : undefined;
    if (byChannel && !linkIds!.length) continue;
    try {
      const out = await createRun({ ...input, channel, linkIds }, who);
      if (out.status === "nothing_due") empty.push(channel); else runs.push(out as Created);
    } catch (e) {
      // "No active links on this channel" only means this channel has nothing; a real problem still stops everything.
      if (/no active links|none of the selected links/i.test((e as Error).message)) { empty.push(channel); continue; }
      throw e;
    }
  }
  if (!runs.length) throw bad(input.mode === "scheduled" ? "No products are due today on any channel, so no run was created." : "There are no active links to scrape on any channel.");
  const sum = (k: "link_count" | "batch_count" | "est_seconds" | "skipped") => runs.reduce((a, x) => a + Number(x[k] ?? 0), 0);
  return {
    status: "created_many" as const, runs: runs.map((x) => ({ scrape_run_id: x.scrape_run_id as number, channel_name: x.channel_name, link_count: x.link_count })),
    scrape_run_id: runs[0].scrape_run_id as number, channel_name: "all", channels: runs.length, empty_channels: empty,
    link_count: sum("link_count"), batch_count: sum("batch_count"), est_seconds: sum("est_seconds"),
    est_wait_seconds: Math.max(...runs.map((x) => Number(x.est_wait_seconds ?? 0))), skipped: sum("skipped"),
  };
}

/** claimNextScrapeBatch: one batch at a time per lane (on demand / background); a lock older than 6 minutes is taken over.
 *  On-demand batches are taken first when their lane is free; otherwise oldest first.
 *  The advisory lock makes "is anything running? then take the next one" atomic when two workers start together. */
async function claim() {
  const [b] = await tx(SYSTEM, async (t) => { await t("select pg_advisory_xact_lock(724001)"); return t(`
    with busy_lanes as (
      select distinct ${LANE("ar")} od from scrape_run_batches ab left join scrape_runs ar on ar.run_id = ab.scrape_run_id
      where ab.status = 'running' and ab.locked_at >= now() - interval '${STALE_LOCK_MIN} minutes'
    ), next_batch as (
      select x.scrape_batch_id from scrape_run_batches x left join scrape_runs r on r.run_id = x.scrape_run_id
      where ${LANE("r")} not in (select od from busy_lanes) and coalesce(r.status, '') not in ('Paused', 'Aborted')
        and (x.status = 'pending' or (x.status = 'running' and x.locked_at < now() - interval '${STALE_LOCK_MIN} minutes'))
      order by (r.type = 'On Demand') desc nulls last, x.created_at, x.batch_number limit 1 for update of x skip locked
    )
    update scrape_run_batches b set status = 'running', attempt_count = attempt_count + 1, locked_at = now(),
      started_at = coalesce(started_at, now()), updated_at = now(), error_message = null
    from next_batch nb where b.scrape_batch_id = nb.scrape_batch_id returning b.*`); });
  return b ?? null;
}

/** insertScrapeResults / insertScrapeResultsNoData, per channel, as in the old subflows. */
async function saveResult(channel: string, linkId: number, runId: number, s: Scraped) {
  let v: [number, number, number, number, number, string, string];
  if (channel === "flipkart") {
    v = [s.price || 0, s.mrp || 0, s.discount || 0, s.rating || 0, s.reviewCount || 0, s.seller || "Flipkart", s.availability || "Unknown"];
  } else if (s.availability === "In Stock" || (s.availability === "Limited Stock" && s.price > 0)) {
    // "Only 3 left" is still on sale: keep its price (the old app kept only exact "In Stock").
    v = [s.price || 0, s.mrp || 0, s.discount || 0, s.rating || 0, s.reviewCount || 0, s.seller || (channel === "zepto" ? "Zepto" : channel === "instamart" ? "Instamart" : "Amazon"), s.availability || "Unknown"];
  } else {
    // Not in stock: no price is recorded, seller "No Data", availability "Currently Unavailable".
    v = [0, 0, 0, s.rating || 0, s.reviewCount || 0, "No Data", "Currently Unavailable"];
  }
  await tx(SYSTEM, (t) => t(`insert into scrape_results (price, mrp, discount, rating, reviews, seller, availability, product_link_id, scrape_run_id, created_at)
    values ($1, $2, $3, $4, $5, $6, $7, $8, $9, now())
    on conflict (scrape_run_id, product_link_id) do update set price = excluded.price, mrp = excluded.mrp, discount = excluded.discount, rating = excluded.rating,
      reviews = excluded.reviews, seller = excluded.seller, availability = excluded.availability, created_at = now()`, [...v, linkId, runId]));
}

async function finishRunIfComplete(runId: number) {
  // markScrapeRunDoneIfComplete
  // Done, or Failed when not a single link could be scraped.
  const done = await tx(SYSTEM, (t) => t(`update scrape_runs sr set status = case when exists (select 1 from scrape_results x where x.scrape_run_id = sr.run_id) then 'Done' else 'Failed' end
    where sr.run_id = $1 and sr.status not in ('Done', 'Failed', 'Paused', 'Aborted')
    and not exists (select 1 from scrape_run_batches b where b.scrape_run_id = sr.run_id and b.status in ('pending', 'running')) returning sr.run_id`, [runId]));
  return done.length > 0;
}

/** Processes one batch. Links that already have a result in this run are skipped, so a batch paused by the time
 *  limit carries on where it stopped. */
export async function processNextBatch(deadline: number) {
  const b = await claim();
  if (!b) return { status: "done", reason: "no_pending_batches" } as const;
  try {
    return await runBatch(b, deadline);
  } catch (e) {
    // Anything unexpected (database hiccup, a bug): the batch goes straight back to waiting instead of staying locked as
    // "running" for minutes, and the next step picks it up again. After MAX_ATTEMPTS such errors it stops as failed.
    console.error("[queue] batch", b.scrape_batch_id, e);
    report(e, { tags: { area: "queue", channel: b.channel_name, scrape_run_id: b.scrape_run_id } });
    const give = b.attempt_count >= MAX_ATTEMPTS;
    await tx(SYSTEM, (t) => t(`update scrape_run_batches set status = $3, locked_at = null, error_message = $2, updated_at = now() where scrape_batch_id = $1 and status = 'running'`,
      [b.scrape_batch_id, (give ? `Stopped after ${MAX_ATTEMPTS} attempts: ${(e as Error).message}` : `Interrupted by an error; it carries on in the next step. ${(e as Error).message}`).slice(0, 300), give ? "failed" : "pending"])).catch(() => {});
    if (give) await finishRunIfComplete(b.scrape_run_id).catch(() => false);
    return { status: "batch_paused", scrape_batch_id: b.scrape_batch_id, run_completed: false } as const;
  }
}

async function runBatch(b: any, deadline: number) {
  const runId = b.scrape_run_id as number;

  if (!(SCRAPE_CHANNELS as readonly string[]).includes(b.channel_name)) {
    // markScrapeBatchFailedInvalidChannel
    await tx(SYSTEM, (t) => t("update scrape_run_batches set status = 'failed', error_message = 'Invalid channel_name: ' || coalesce(channel_name, ''), updated_at = now() where scrape_batch_id = $1", [b.scrape_batch_id]));
    await finishRunIfComplete(runId);
    return { status: "batch_failed", scrape_batch_id: b.scrape_batch_id, reason: "invalid_channel" } as const;
  }
  await tx(SYSTEM, (t) => t("update scrape_runs set status = 'In Progress' where run_id = $1 and status in ('Started')", [runId]));

  const todo = await query<{ product_link_id: number; url: string; mrp: number; base: number }>(`
    select pl.product_link_id, pl.url, p.mrp, coalesce(nullif(p.mop_scheme, 0), nullif(p.mop, 0), p.mrp * 0.6) base
    from product_links pl join products p on p.product_id = pl.product_id
    where pl.product_link_id = any($1::int[])
      and not exists (select 1 from scrape_results sr where sr.scrape_run_id = $2 and sr.product_link_id = pl.product_link_id)
    order by pl.product_link_id`, [b.product_link_ids, runId]);

  const errors: string[] = [];
  const failed: Record<string, { error: string; tries: number; at: string }> = {};
  // Tries made in earlier steps of this batch count too, so a link is never tried more than LINK_TRIES times.
  const before = (b.link_errors ?? {}) as Record<string, { tries?: number }>;
  const tries = new Map<number, number>(Object.entries(before).map(([k, v]) => [Number(k), Number(v?.tries ?? 0)]));
  const queue = [...todo];
  let next = 0, outOfTime = false, paused = false, aborted = false, pageMs = 0, linksDone = 0, okMs = 0, okLinks = 0;
  // Pages at a time: CONCURRENCY, one fewer each time Browserless shows it is overloaded (408, 429, no answer), down to 1.
  let allowed = Math.min(CONCURRENCY, todo.length);
  const started = Date.now();
  // Pause is checked before each link (at most every 3 s): links already loading finish, no new one starts.
  let checkedAt = 0;
  // Browsers this batch may use: all of CONCURRENCY, or its share while a batch of the other lane is running too.
  let share = CONCURRENCY;
  const isPaused = async () => {
    if (paused) return true;
    if (Date.now() - checkedAt < 3000) return false;
    checkedAt = Date.now();
    const [r] = await query<{ status: string | null; others: number }>(`select (select status from scrape_runs where run_id = $1) status,
      (select count(*) from scrape_run_batches where status = 'running' and locked_at >= now() - interval '${STALE_LOCK_MIN} minutes' and scrape_batch_id <> $2)::int others`, [runId, b.scrape_batch_id]);
    aborted = r?.status === "Aborted";
    paused = r?.status === "Paused" || aborted;
    share = r?.others ? Math.max(1, Math.floor(CONCURRENCY / 2)) : CONCURRENCY;
    return paused;
  };
  // The droplet's own load, checked every 10 s: from 80% CPU or memory only one page loads at a time; from 88% (or when
  // Browserless says it is full) no new page starts until it has room, so pages already loading are not starved.
  let pressureAt = 0, hot = false, full = false;
  const checkPressure = async () => {
    if (Date.now() - pressureAt < 10_000) return;
    pressureAt = Date.now();
    const p = await browserlessPressure();
    const peak = Math.max(p?.cpu ?? 0, p?.memory ?? 0);
    hot = peak >= 80;
    // Browserless refuses new browsers at 90% (MAX_CPU_PERCENT / MAX_MEMORY_PERCENT on the droplet): stop just below.
    full = peak >= 88 || p?.available === false;
  };
  const worker = async (slot: number) => {
    for (;;) {
      if (slot >= Math.min(allowed, share)) return;
      if (next >= queue.length) return;
      if (deadline - Date.now() < LINK_MIN_MS) { outOfTime = true; return; }
      if (await isPaused()) return;
      await checkPressure();
      if (hot && slot > 0) return;
      if (full) { await new Promise((ok) => setTimeout(ok, 5000)); continue; }
      // Taken right after the check, with no await in between: another worker may have taken the last one meanwhile.
      const l = queue[next];
      if (!l) return;
      next++;
      const n = (tries.get(l.product_link_id) ?? 0) + 1;
      tries.set(l.product_link_id, n);
      const t0 = Date.now();
      // What is loading right now, for the run page ("Now loading: <product>, try 2 of 3").
      await query("update scrape_run_batches set current_link_id = $2, current_try = $3, current_at = now() where scrape_batch_id = $1", [b.scrape_batch_id, l.product_link_id, n]).catch(() => {});
      try {
        if (!l.url) throw new Error("no URL");
        const s = await scrapeUrl(b.channel_name, l.url, { mrp: Number(l.mrp), base: Number(l.base) }, Math.min(PAGE_TIMEOUT_MS, deadline - Date.now() - 5_000));
        await saveResult(b.channel_name, l.product_link_id, runId, s);
        linksDone++; okLinks++; okMs += Date.now() - t0;
      } catch (e) {
        const msg = (e as Error).message;
        if (overloaded(msg) && allowed > 1) allowed--;
        if (n < LINK_TRIES && l.url && retryable(msg)) queue.push(l);
        else {
          linksDone++;
          failed[l.product_link_id] = { error: msg.slice(0, 300), tries: n, at: new Date().toISOString() };
          // the old app's loop ignored errors per link; we do the same but keep the reason on the batch.
          errors.push(`link ${l.product_link_id}: ${msg}${n > 1 ? ` (after ${n} tries)` : ""}`.slice(0, 220));
        }
        // Remember the tries so far even if the step ends before the retry (it carries on in the next step).
        if (!failed[l.product_link_id]) failed[l.product_link_id] = { error: msg.slice(0, 300), tries: n, at: new Date().toISOString(), retrying: true } as never;
      } finally {
        pageMs += Date.now() - t0;
      }
    }
  };
  // Look before starting: paused or aborted meanwhile, and how many browsers this batch may use.
  await isPaused(); checkedAt = Date.now();
  await Promise.all(Array.from({ length: allowed }, (_, i) => worker(i)));
  // A link scraped after an earlier failed try is no longer failed.
  const scraped = new Set((await query<{ id: number }>("select product_link_id id from scrape_results where scrape_run_id = $1 and product_link_id = any($2::int[])", [runId, b.product_link_ids])).map((x) => x.id));
  const failedNow = Object.fromEntries(Object.entries(failed).filter(([k]) => !scraped.has(Number(k))));
  const cleared = Object.keys(before).filter((k) => scraped.has(Number(k)));
  // Pages loaded and links finished in this go, for time estimates (each concurrent page counts its own time).
  const timing = [Math.round(pageMs), linksDone, JSON.stringify(failedNow)];
  await tx(SYSTEM, (t) => t(`update scrape_run_batches set ok_ms = ok_ms + $2, ok_links = ok_links + $3, wall_ms = wall_ms + $4, current_link_id = null, current_at = null,
    link_errors = case when $5::text[] is null then link_errors else link_errors - $5::text[] end where scrape_batch_id = $1`,
    [b.scrape_batch_id, Math.round(okMs), okLinks, Date.now() - started, cleared.length ? cleared : null]));

  const note = errors.length ? `${errors.length} of ${todo.length} links failed. ${errors.slice(0, 3).join("; ")}` : null;
  // One Sentry issue per channel and kind of failure (proxy refused, timeout, Browserless error...), not one per link.
  if (errors.length) {
    const kind = errors[0].replace(/^link \d+: /, "").replace(/\d+/g, "N").slice(0, 60);
    report(`Scraping: ${errors.length} of ${todo.length} ${b.channel_name} links failed`, {
      level: errors.length === todo.length ? "error" : "warning", fingerprint: ["scrape-links", b.channel_name, kind],
      tags: { channel: b.channel_name, scrape_run_id: runId }, extra: { batch: b.scrape_batch_id, attempt: b.attempt_count, sample: errors.slice(0, 5) },
    });
  }
  if (aborted) {
    await tx(SYSTEM, (t) => t(`update scrape_run_batches set status = 'aborted', locked_at = null, page_ms = page_ms + $3, links_done = links_done + $4,
      link_errors = coalesce(link_errors, '{}'::jsonb) || $5::jsonb, error_message = $2, updated_at = now() where scrape_batch_id = $1`,
      [b.scrape_batch_id, `Aborted. ${note ?? ""}`.trim(), ...timing]));
    return { status: "batch_paused", scrape_batch_id: b.scrape_batch_id, run_paused: true, run_completed: false } as const;
  }
  if (paused) {
    // Paused: back to waiting, without counting this go as a failed attempt. Resuming carries on where it stopped.
    await tx(SYSTEM, (t) => t(`update scrape_run_batches set status = 'pending', locked_at = null, attempt_count = greatest(attempt_count - 1, 0),
      page_ms = page_ms + $3, links_done = links_done + $4, link_errors = coalesce(link_errors, '{}'::jsonb) || $5::jsonb, error_message = $2, updated_at = now() where scrape_batch_id = $1`,
      [b.scrape_batch_id, `Paused. ${note ?? ""}`.trim(), ...timing]));
    return { status: "batch_paused", scrape_batch_id: b.scrape_batch_id, run_paused: true, run_completed: false } as const;
  }
  if (outOfTime) {
    const status = b.attempt_count >= MAX_ATTEMPTS ? "failed" : "pending";
    await tx(SYSTEM, (t) => t("update scrape_run_batches set status = $2, locked_at = null, error_message = $3, page_ms = page_ms + $4, links_done = links_done + $5, link_errors = coalesce(link_errors, '{}'::jsonb) || $6::jsonb, updated_at = now() where scrape_batch_id = $1",
      [b.scrape_batch_id, status, status === "failed" ? `Stopped after ${MAX_ATTEMPTS} attempts. ${note ?? ""}`.trim() : `Continues in the next step (time limit of one step). ${note ?? ""}`.trim(), ...timing]));
    if (status === "failed") report(`Scraping: batch stopped after ${MAX_ATTEMPTS} attempts (${b.channel_name})`, {
      level: "error", fingerprint: ["scrape-batch-stopped", b.channel_name], tags: { channel: b.channel_name, scrape_run_id: runId }, extra: { batch: b.scrape_batch_id, note } });
    const completed = status === "failed" ? await finishRunIfComplete(runId) : false;
    return { status: "batch_paused", scrape_batch_id: b.scrape_batch_id, run_completed: completed } as const;
  }
  // markScrapeBatchDone
  await tx(SYSTEM, (t) => t("update scrape_run_batches set status = 'done', completed_at = now(), locked_at = null, error_message = $2, page_ms = page_ms + $3, links_done = links_done + $4, link_errors = coalesce(link_errors, '{}'::jsonb) || $5::jsonb, updated_at = now() where scrape_batch_id = $1", [b.scrape_batch_id, note, ...timing]));
  const completed = await finishRunIfComplete(runId);
  return { status: "batch_done", scrape_run_id: runId, scrape_batch_id: b.scrape_batch_id, channel_name: b.channel_name, batch_number: b.batch_number, batch_total_count: b.batch_total_count, run_completed: completed } as const;
}

/** Works through the queue until it is empty or the time budget is used. */
export async function processQueue(budgetMs: number) {
  const deadline = Date.now() + budgetMs;
  const out: unknown[] = [];
  while (deadline - Date.now() >= LINK_MIN_MS) {
    const r = await processNextBatch(deadline);
    out.push(r);
    if (r.status === "done" || (r.status === "batch_paused" && !("run_paused" in r && r.run_paused))) break;
  }
  return out;
}

/** "Batch Scraping of Products": a scheduled run per channel, 45 links per batch, with the products whose schedule is due today (IST). */
/** The 15-minute slots (India time, "HH:MM") the scheduler has not handled yet, up to now. `last` is the last slot handled.
 *  First call ever: only the current slot. A new day: every slot of today so far (a missed call is caught up). */
export function slotsDue(last: { day: string; min: number } | null, at = new Date()) {
  const d = istDate(at), day = `${d.y}-${String(d.m).padStart(2, "0")}-${String(d.d).padStart(2, "0")}`;
  const cur = Math.floor(istMinutes(at) / 15) * 15;
  const from = !last ? cur : last.day === day ? last.min + 15 : 0;
  const slots: string[] = [];
  for (let m = from; m <= cur; m += 15) slots.push(hhmm(m));
  return { day, cur, slots };
}

/** The scheduled-runs cron (every 15 minutes): for each channel, one run of the products due today whose time of day
 *  has come since the last call. Each slot is handled once, even if two calls overlap (compare-and-set on app_meta). */
export async function scheduledRuns(at = new Date()) {
  const [row] = await query<{ value: string }>("select value from app_meta where key = 'schedule_cursor'");
  let last: { day: string; min: number } | null = null;
  try { last = row ? JSON.parse(row.value) : null; } catch { last = null; }
  const { day, cur, slots } = slotsDue(last, at);
  if (!slots.length) return [{ status: "nothing_new", slot: hhmm(cur) }];
  const next = JSON.stringify({ day, min: cur });
  const claimed = row
    ? await query("update app_meta set value = $1 where key = 'schedule_cursor' and value = $2 returning key", [next, row.value])
    : await query("insert into app_meta (key, value) values ('schedule_cursor', $1) on conflict (key) do nothing returning key", [next]);
  if (!claimed.length) return [{ status: "taken", reason: "Another call is handling these slots." }];
  const daily = await dailyRuns();
  if (daily.paused) return [{ status: "paused", reason: "Daily automatic runs are paused (Channel Scraping).", since: daily.at, by: daily.by, slots }];
  const out = [];
  for (const channel of DAILY_CHANNELS) {
    try { out.push(await createRun({ channel, batchSize: 45, runType: "Scheduled", mode: "scheduled", times: slots }, { actor: "system:scheduler" })); }
    catch (e) { out.push({ channel, error: (e as Error).message }); }
  }
  return out;
}

// Seconds one link takes (clock time, CONCURRENCY pages at a time) when nothing has been measured yet.
// Measured on the droplet: an Amazon page without JavaScript loads in about 5 s through the proxy, Flipkart in about 7 s.
const DEFAULT_LINK_SEC = 8;

/** Measured speed of a channel (or of one run): clock seconds per finished link over the last 30 batches that recorded
 *  it, from wall_ms / links_done. That is what a run really takes: pages in parallel, slow pages, retries and links
 *  given up are all in it. `pageSec` is the same speed seen as one page at a time per slot (sec × CONCURRENCY). */
export async function channelSpeed(channel: string | null, runId?: number) {
  const [r] = await query<{ sec: number | null; n: number }>(`
    with b as (select wall_ms, links_done from scrape_run_batches
      where wall_ms > 0 and links_done > 0 and ($1::text is null or channel_name = $1) and ($2::int is null or scrape_run_id = $2)
      order by updated_at desc limit 30)
    select (sum(wall_ms) / 1000.0 / nullif(sum(links_done), 0))::float sec, count(*)::int n from b`, [channel, runId ?? null]);
  let sec = Number(r?.sec);
  const measured = !!r?.n && Number.isFinite(sec) && sec > 0;
  if (!measured) sec = DEFAULT_LINK_SEC;
  sec = Math.min(Math.max(sec, 0.2), 300);
  return { sec, pageSec: sec * CONCURRENCY, measured };
}

/** Where a run stands: the batches and links of other runs that go before it, whether a worker is busy, and timing
 *  (start, last result, finish) with the speed used for estimates (this run's own once it has a few results). */
export async function queuePosition(runId: number) {
  const [row] = await query<{ ahead: number; links_ahead: number; busy: boolean; open: number; channel: string | null; started_at: string | null;
    first_result_at: string | null; last_result_at: string | null; results: number; finished_at: string | null; links_left: number; open_batches: number[] | null; paused: boolean }>(`
    with me as (select (r.type = 'On Demand') od, r.created_at, r.channel_name from scrape_runs r where r.run_id = $1),
    open as (select x.scrape_run_id, x.created_at, cardinality(x.product_link_ids) links, coalesce(r.type = 'On Demand', false) od, coalesce(r.status = 'Paused', false) paused
      from scrape_run_batches x left join scrape_runs r on r.run_id = x.scrape_run_id where x.status in ('pending', 'running')),
    earlier as (select open.* from open, me where open.scrape_run_id <> $1 and not open.paused
        and ((open.od and not coalesce(me.od, false)) or (open.od = coalesce(me.od, false) and open.created_at < me.created_at)))
    select (select count(*) from earlier)::int ahead, (select coalesce(sum(links), 0) from earlier)::int links_ahead,
      exists (select 1 from scrape_run_batches y where y.status = 'running' and y.locked_at >= now() - interval '${STALE_LOCK_MIN} minutes') busy,
      (select count(*) from open where scrape_run_id = $1)::int open, (select channel_name from me) channel,
      (select min(started_at) from scrape_run_batches where scrape_run_id = $1) started_at,
      (select max(completed_at) from scrape_run_batches where scrape_run_id = $1 and not exists (select 1 from scrape_run_batches y where y.scrape_run_id = $1 and y.status in ('pending', 'running'))) finished_at,
      s.first first_result_at, s.last last_result_at, s.n::int results,
      -- Links still to try: those of waiting or running batches without a result yet (failed links of finished batches are not left).
      (select coalesce(sum((select count(*) from unnest(y.product_link_ids) u(id)
        where not exists (select 1 from scrape_results z where z.scrape_run_id = $1 and z.product_link_id = u.id))), 0)
        from scrape_run_batches y where y.scrape_run_id = $1 and y.status in ('pending', 'running'))::int links_left,
      (select array_agg(cardinality(y.product_link_ids) order by y.batch_number) from scrape_run_batches y where y.scrape_run_id = $1 and y.status in ('pending', 'running')) open_batches,
      coalesce((select status = 'Paused' from scrape_runs where run_id = $1), false) paused
    from (select min(created_at) first, max(created_at) last, count(*) n from scrape_results where scrape_run_id = $1) s`, [runId]);
  // This run's own finished batches once it has some, else the channel's recent batches.
  const own = await channelSpeed(row.channel, runId);
  const speed = own.measured ? { ...own, own: true } : { ...(await channelSpeed(row.channel)), own: false };
  // Time left: each waiting batch takes ceil(links / CONCURRENCY) rounds of one page time (a batch's links are spread
  // over the CONCURRENCY workers), the links left counted per batch.
  const left = row.links_left, total = (row.open_batches ?? []).reduce((a, n) => a + n, 0);
  const leftSec = (row.open_batches ?? []).reduce((a, n) => a + scrapeSeconds(total ? Math.round((n * left) / total) : 0, speed.pageSec, CONCURRENCY), 0);
  const { open_batches: _ob, ...rest } = row;
  return { ...rest, sec_per_link: Math.round(speed.sec * 100) / 100, page_sec: Math.round(speed.pageSec * 10) / 10, concurrency: CONCURRENCY,
    left_seconds: Math.round(leftSec), wait_seconds: Math.round(scrapeSeconds(row.links_ahead, speed.pageSec, CONCURRENCY)),
    speed_measured: speed.measured, speed_own: speed.own };
}

/** Whether a lane has batches waiting with no worker on it (the chain of invocations stopped). */
export async function queueStalled() {
  const [r] = await query<{ stalled: boolean }>(`with l as (
      select ${LANE("r")} od, bool_or(x.status = 'running' and x.locked_at >= now() - interval '${STALE_LOCK_MIN} minutes') live,
        bool_or((x.status = 'pending' or (x.status = 'running' and x.locked_at < now() - interval '${STALE_LOCK_MIN} minutes')) and coalesce(r.status, '') <> 'Paused') waiting
      from scrape_run_batches x left join scrape_runs r on r.run_id = x.scrape_run_id where x.status in ('pending', 'running') group by 1)
    select exists (select 1 from l where waiting and not live) stalled`);
  return r.stalled;
}

/** Puts a run's failed links back in the queue: failed batches, and finished batches with links that got no result.
 *  Links already scraped are skipped, so only the failed ones are tried again. Returns the links queued again. */
export async function retryFailed(runId: number, who: Actor) {
  const rows = await tx(who, async (t) => {
    const r = await t(`update scrape_run_batches b set status = 'pending', attempt_count = 0, error_message = null, locked_at = null, completed_at = null, updated_at = now()
      where b.scrape_run_id = $1 and b.status in ('failed', 'done', 'aborted') and exists (select 1 from unnest(b.product_link_ids) u(id)
        where not exists (select 1 from scrape_results x where x.scrape_run_id = $1 and x.product_link_id = u.id))
      returning (select count(*) from unnest(b.product_link_ids) u(id) where not exists (select 1 from scrape_results x where x.scrape_run_id = $1 and x.product_link_id = u.id))::int n`, [runId]);
    if (r.length) await t("update scrape_runs set status = case when exists (select 1 from scrape_results x where x.scrape_run_id = $1) then 'In Progress' else 'Started' end where run_id = $1", [runId]);
    return r as { n: number }[];
  });
  return rows.reduce((a, r) => a + Number(r.n), 0);
}

/** Pauses a run: no new link starts (links loading now finish), its batches wait until it is resumed. */
export async function pauseRun(runId: number, who: Actor) {
  return tx(who, async (t) => {
    const r = await t(`update scrape_runs set status = 'Paused' where run_id = $1 and coalesce(status, '') <> 'Paused'
      and exists (select 1 from scrape_run_batches where scrape_run_id = $1 and status in ('pending', 'running')) returning run_id`, [runId]);
    if (!r.length) throw bad("Only a run that is waiting or scraping can be paused.");
    // A batch left "running" by a cut-off step goes back to waiting now, so the run shows as paused right away.
    await t(`update scrape_run_batches set status = 'pending', locked_at = null, updated_at = now()
      where scrape_run_id = $1 and status = 'running' and locked_at < now() - interval '${STALE_LOCK_MIN} minutes'`, [runId]);
    return true;
  });
}

/** Aborts a run for good: its waiting batches are dropped, links loading now finish and are saved, nothing new starts.
 *  "Retry" on the run can still scrape the links that were left. */
export async function abortRun(runId: number, who: Actor) {
  return tx(who, async (t) => {
    const r = await t(`update scrape_runs set status = 'Aborted' where run_id = $1 and coalesce(status, '') not in ('Aborted', 'Done', 'Failed')
      and exists (select 1 from scrape_run_batches where scrape_run_id = $1 and status in ('pending', 'running')) returning run_id`, [runId]);
    if (!r.length) throw bad("Only a run that is waiting, scraping or paused can be aborted.");
    // Waiting batches stop now; a running one is stopped by its worker within seconds (or now, if its worker is gone).
    await t(`update scrape_run_batches set status = 'aborted', locked_at = null, error_message = 'Aborted.', updated_at = now()
      where scrape_run_id = $1 and (status = 'pending' or (status = 'running' and locked_at < now() - interval '${STALE_LOCK_MIN} minutes'))`, [runId]);
    return true;
  });
}

/** Resumes a paused run where it stopped (links already scraped are not scraped again). */
export async function resumeRun(runId: number, who: Actor) {
  const r = await tx(who, (t) => t(`update scrape_runs sr set status = case when exists (select 1 from scrape_results x where x.scrape_run_id = sr.run_id) then 'In Progress' else 'Started' end
    where sr.run_id = $1 and sr.status = 'Paused' returning run_id`, [runId]));
  if (!r.length) throw bad("This run is not paused.");
  return true;
}

/** The switch for the daily automatic runs (the scheduled-runs cron). */
export async function dailyRuns(): Promise<{ paused: boolean; by?: string; at?: string }> {
  const [r] = await query<{ value: string }>("select value from app_meta where key = 'daily_runs'");
  try { return r ? { paused: !!JSON.parse(r.value).paused, by: JSON.parse(r.value).by, at: JSON.parse(r.value).at } : { paused: false }; } catch { return { paused: false }; }
}
export async function setDailyRuns(paused: boolean, who: Actor) {
  const value = JSON.stringify({ paused, by: who.actor, at: new Date().toISOString() });
  await query("insert into app_meta (key, value) values ('daily_runs', $1) on conflict (key) do update set value = excluded.value", [value]);
  return dailyRuns();
}

// In-process background worker for local/demo mode (a long-lived server), so on-demand runs finish without cron.
// Up to two loops, like the two lanes on Vercel (a loop that finds both lanes busy ends at once).
let localLoops = 0;
export function kickLocal() {
  if (process.env.VERCEL || localLoops >= 2) return;
  localLoops++;
  void (async () => { try { for (let i = 0; i < 50; i++) { const r = await processQueue(240_000); if (r.some((x: any) => x.status === "done")) break; } } finally { localLoops--; } })();
}
