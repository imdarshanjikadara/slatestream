// Shared SQL pieces. Dates are India calendar days.
export const IST_DAY = (col: string) => `(${col} at time zone 'Asia/Kolkata')::date`;

// Date filters written against the bare column so the created_at / run_date / at indexes are used
// (wrapping the column in IST_DAY() forces a scan of every row). `p` is a parameter placeholder holding a date.
const IST_START = (p: string) => `((${p}::date)::timestamp at time zone 'Asia/Kolkata')`;
const IST_END = (p: string) => `(((${p}::date) + 1)::timestamp at time zone 'Asia/Kolkata')`;
/** col within the IST days from..to, both included. */
export const IST_RANGE = (col: string, from: string, to: string) => `(${col} >= ${IST_START(from)} and ${col} < ${IST_END(to)})`;
/** Optional bounds: no filter when the parameter is null. */
export const IST_FROM = (col: string, p: string) => `(${p}::date is null or ${col} >= ${IST_START(p)})`;
export const IST_TO = (col: string, p: string) => `(${p}::date is null or ${col} < ${IST_END(p)})`;

/** MOP breach threshold of a product (alias p): trigger price, else MOP scheme, else MOP. Same rule as alertPrice in shared/pricing.ts. */
export const ALERT_PRICE = (p = "p") => `coalesce(nullif(${p}.trigger_price, 0), nullif(${p}.mop_scheme, 0), nullif(${p}.mop, 0), 0)`;
export const BELOW = (price: string, p = "p") => `(${ALERT_PRICE(p)} > 0 and coalesce(${price}, 0) > 0 and ${price} < ${ALERT_PRICE(p)})`;

/** Latest scrape of every link inside a date range (the old getScrapeResults rule), as a CTE named `latest`.
 *  $from / $to are parameter placeholders, e.g. "$1", "$2". */
export const latestCte = (from: string, to: string) => `latest as (
  select distinct on (sr.product_link_id) sr.*
  from scrape_results sr
  where ${IST_RANGE("sr.created_at", from, to)}
  order by sr.product_link_id, sr.created_at desc, sr.scrape_result_id desc)`;

/** Columns of a result row as the Scrape Product Results page shows them. */
export const RESULT_COLS = `
  sr.scrape_result_id, sr.price, sr.mrp scraped_mrp, sr.discount, sr.availability, sr.seller, sr.created_at scrape_timestamp, sr.reviews, sr.rating, sr.scrape_run_id,
  pl.product_link_id, pl.channel_name, pl.url, pl.is_active link_is_active,
  p.product_id, p.name product_name, p.brand, p.dealer_landing, p.mrp base_mrp, p.hana_code, p.ph, p.category_id, p.direct_discount, p.gst_percent, p.mop, p.mop_scheme, p.trigger_price,
  ${ALERT_PRICE()} alert_price, pc.name category_name,
  ${BELOW("sr.price")} below_mop`;

/** ILIKE pattern from a search box, with the wildcard characters escaped. */
export const like = (s: string | null) => (s ? `%${s.replace(/[\\%_]/g, (c) => "\\" + c)}%` : null);
