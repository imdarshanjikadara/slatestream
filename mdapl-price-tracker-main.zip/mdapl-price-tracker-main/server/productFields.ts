// Product fields shared by the product form, bulk edit and the Excel import: validation, calculated pricing, links.
import { generatedColumns, type Q } from "./db.js";
import { CHANNELS, bad } from "./http.js";
import { DERIVED, PRICING_INPUTS, computePricing } from "../shared/pricing.js";

/** Fields a person can set. The pricing results (MOP, net landing, ...) are calculated, never accepted as input. */
export const FIELDS: Record<string, "text" | "num" | "int" | "bool" | "list" | "time"> = {
  name: "text", description: "text", category_id: "int", brand: "text", hana_code: "text", ph: "text",
  mrp: "num", gst_percent: "num", direct_discount: "num", dealer_landing: "num",
  regular_scraping: "bool", scheduled_scraping: "bool", scraping_schedule_weekly: "list", months_to_scrape: "list", scraping_schedule_monthly: "list", scrape_time: "time",
  scheme_1: "num", scheme_2: "num", scheme_3: "num", dp_margin_percent: "num", retail_margin_percent: "num", trigger_price_percent: "num",
};
export const LABEL: Record<string, string> = {
  name: "Name", description: "Description", category_id: "Category", brand: "Brand", hana_code: "Hana code", ph: "PH", mrp: "MRP", gst_percent: "GST %",
  direct_discount: "Direct discount %", dealer_landing: "Dealer landing", regular_scraping: "Regular scraping", scheduled_scraping: "Scheduled scraping",
  scraping_schedule_weekly: "Weekly days", months_to_scrape: "Months to scrape", scraping_schedule_monthly: "Monthly dates", scrape_time: "Time of day", scheme_1: "Scheme 1",
  scheme_2: "Scheme 2", scheme_3: "Scheme 3", dp_margin_percent: "DP margin %", retail_margin_percent: "Retail margin %", trigger_price_percent: "Trigger price %",
  mop: "MOP", total_scheme: "Total scheme", net_landing: "Net landing", retail_margin: "Retail margin", mop_scheme: "MOP scheme", trigger_price: "Trigger price",
  is_active: "Active",
};

const BOOL_TRUE = new Set(["true", "yes", "y", "1"]);
const BOOL_FALSE = new Set(["false", "no", "n", "0", ""]);

/** One value as stored; throws a plain sentence when it cannot be. */
export function cleanValue(k: string, v: unknown): unknown {
  const kind = FIELDS[k];
  const label = LABEL[k] ?? k;
  if (kind === "text") { const s = String(v ?? "").trim().replace(/\.0$/, (m) => (k === "hana_code" ? "" : m)); if (s.length > 2000) throw bad(`${label} is too long.`); return s || null; }
  if (kind === "bool") {
    if (typeof v === "boolean") return v;
    const s = String(v ?? "").trim().toLowerCase();
    if (BOOL_TRUE.has(s)) return true;
    if (BOOL_FALSE.has(s)) return false;
    throw bad(`${label} must be yes or no (got "${String(v).slice(0, 20)}").`);
  }
  if (kind === "time") {
    // "15:30" / "3:30 PM" -> "15:30", India time, in 15-minute steps (the scheduler looks every 15 minutes). Blank = 6:00 AM.
    const s = String(v ?? "").trim().toUpperCase();
    if (!s) return null;
    const m = /^(\d{1,2})[:.](\d{2})\s*(AM|PM)?$/.exec(s);
    let h = m ? Number(m[1]) : NaN; const mi = m ? Number(m[2]) : NaN;
    if (m?.[3]) { if (h < 1 || h > 12) h = NaN; else h = (h % 12) + (m[3] === "PM" ? 12 : 0); }
    if (!(h >= 0 && h <= 23 && [0, 15, 30, 45].includes(mi))) throw bad(`${label} must be a time like 15:30 or 3:30 PM, on the hour or at :15, :30 or :45.`);
    return `${String(h).padStart(2, "0")}:${String(mi).padStart(2, "0")}`;
  }
  if (kind === "list") {
    // "1,3,5" / [1,3] / 7 / 7.0 -> "1,3,5"; days 1-7, months 1-12, dates 1-31.
    const max = k === "scraping_schedule_weekly" ? 7 : k === "months_to_scrape" ? 12 : 31;
    const parts = (Array.isArray(v) ? v : String(v ?? "").split(/[,;\s]+/)).map((x) => String(x).trim().replace(/\.0+$/, "")).filter(Boolean);
    for (const p of parts) if (!/^\d{1,2}$/.test(p) || Number(p) < 1 || Number(p) > max) throw bad(`${label}: "${p}" is not a number from 1 to ${max}.`);
    return parts.length ? [...new Set(parts.map(Number))].sort((a, b) => a - b).join(",") : null;
  }
  if (v === null || v === "" || v === undefined) return kind === "int" ? null : 0;
  const n = Number(String(v).replace(/[₹,\s]/g, "").replace(/%$/, ""));
  if (!Number.isFinite(n)) throw bad(`${label} must be a number (got "${String(v).slice(0, 20)}").`);
  if (n < 0) throw bad(`${label} cannot be negative.`);
  if (/percent|discount/.test(k) && n > 100) throw bad(`${label} is a percentage, so it must be 100 or less.`);
  return kind === "int" ? Math.trunc(n) : n;
}

export function clean(body: Record<string, unknown>, creating: boolean) {
  const out: Record<string, unknown> = {};
  for (const k of Object.keys(FIELDS)) if (k in body) out[k] = cleanValue(k, body[k]);
  if (creating || "name" in out) { if (!out.name) throw bad("Enter the product name."); }
  if (creating || "category_id" in out) { if (!out.category_id) throw bad("Choose a category."); }
  return out;
}

export function cleanUrl(v: unknown): string | null {
  let s = String(v ?? "").trim();
  if (!s) return null;
  if (!/^https?:\/\//i.test(s)) s = "https://" + s;
  try { const u = new URL(s); if (!/\./.test(u.hostname)) throw 0; return u.toString(); } catch { throw bad(`"${String(v).slice(0, 60)}" is not a web address.`); }
}

/** One link per channel, created or updated; a cleared box turns the link off (only when `clearMeansOff`). */
export async function saveLinks(t: Q, productId: number, links: Record<string, unknown> | undefined, clearMeansOff = true) {
  if (!links) return;
  for (const ch of CHANNELS) {
    if (!(ch in links)) continue;
    const url = cleanUrl(links[ch]);
    if (url) await t(`insert into product_links (product_id, channel_name, url, is_active, created_at, updated_at) values ($1, $2, $3, true, now(), now())
        on conflict (product_id, channel_name) do update set url = excluded.url, is_active = true, updated_at = now()`, [productId, ch, url]);
    else if (clearMeansOff) await t("update product_links set is_active = false, updated_at = now() where product_id = $1 and channel_name = $2 and is_active", [productId, ch]);
  }
}

/** Adds the calculated pricing to a write, from the product as it will be after the write. Generated columns are left to the database. */
export async function withPricing(data: Record<string, unknown>, current?: Record<string, unknown>, q?: Q) {
  const gen = await generatedColumns("products", q);
  const out = Object.fromEntries(Object.entries(data).filter(([k]) => !gen.has(k)));
  // Scraping is every day (regular) or on a schedule, never both: turning one on turns the other off.
  if (data.regular_scraping === true && data.scheduled_scraping === true) throw bad("Choose one: scraped every day (regular) or on a schedule, not both.");
  if (data.regular_scraping === true) out.scheduled_scraping = false;
  if (data.scheduled_scraping === true) out.regular_scraping = false;
  if (!current || PRICING_INPUTS.some((k) => k in data)) {
    const priced = computePricing({ ...(current ?? {}), ...data });
    for (const k of DERIVED) if (!gen.has(k)) out[k] = priced[k];
  }
  return out;
}
