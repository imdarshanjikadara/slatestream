// Demo data for local development (PGlite only, and only into a database that had no tables).
// Shaped like the live data: Pigeon / Stovekraft catalogue, Amazon and Flipkart links on most products,
// a few Instamart and Zepto links, one scheduled run per channel per day for the last 30 days.
import type { Q } from "./db.js";
import { computePricing } from "../shared/pricing.js";

const CATS: [string, [string, number, string][]][] = [
  ["Airfryer", [["Healthifry+ Orbitron 6.5L Airfryer", 10995, "B0DNJJ2VMJ"], ["Healthifry Digital 4.2L Airfryer", 7495, "B09XYZAF42"], ["Healthifry Glass 5L Airfryer", 8995, "B0C1GLASS5"], ["Healthifry Compact 2.5L Airfryer", 4995, "B0COMP25L"]]],
  ["Pressure Cooker", [["Stainless Steel Outer Lid Pressure Cooker 3L", 2195, "B07SS3LPC"], ["Aluminium Inner Lid Cooker 5L", 1895, "B08AL5LPC"], ["Hard Anodised Cooker 3L", 2495, "B09HA3LPC"], ["Favourite Outer Lid Cooker 2L", 1295, "B06FAV2LC"], ["Triply Pressure Cooker 4L", 3295, "B0TRI4LPC"]]],
  ["Induction Cooktop", [["Rapido Cute Induction Cooktop 1800W", 3195, "B00RAPIDO1"], ["Acer Plus Induction 1800W", 2995, "B01ACERPLS"], ["Rapido Touch Induction 2100W", 3995, "B0RAPTOUCH"]]],
  ["Mixer Grinder", [["Amaze Plus 750W Mixer Grinder", 4295, "B07AMAZE75"], ["Glory 500W Mixer Grinder 3 Jars", 2895, "B08GLORY50"], ["Ultra Mixer Grinder 1000W", 5495, "B0ULTRA100"], ["Duo 550W Mixer Grinder", 3195, "B0DUO550W"]]],
  ["Kettle", [["Kessel Multipurpose Kettle 1.2L", 1595, "B0KESSEL12"], ["Amaze Electric Kettle 1.5L", 1195, "B01AMAZEKT"], ["Polo Electric Kettle 1.8L", 1395, "B0POLO18L"], ["Glass Kettle 1.7L", 1795, "B0GLASSKT"]]],
  ["Ceiling Fan", [["Aura 1200mm Ceiling Fan", 2899, "FANAURA120"], ["Nova 1200mm BLDC Fan", 4499, "FANNOVA120"], ["Zest 900mm Ceiling Fan", 2399, "FANZEST900"]]],
  ["Iron", [["Clothes Nonstick Dry Iron 1000W", 1195, "B01MDPQ6UM"], ["Steam Iron Ezee 1200W", 1795, "B0STEAMEZ"], ["Glide Dry Iron 750W", 895, "B0GLIDE750"]]],
  ["Gas Stove", [["Favourite 2 Burner Glass Top Stove", 4995, "B0FAV2BRN"], ["Blaze 3 Burner Glass Top Stove", 6995, "B0BLAZE3B"], ["Smart 4 Burner Stove", 8995, "B0SMART4B"]]],
  ["Cookware", [["Hard Anodised Kadai 24cm", 1495, "B0HAKAD24"], ["Nonstick Tawa 28cm", 995, "B0NSTAW28"], ["Triply Fry Pan 24cm", 1895, "B0TRIFRY24"], ["Cookware Set 3 Piece", 2995, "B0CKSET3P"]]],
  ["Water Bottle", [["Steel Water Bottle 1L Set of 3", 999, "B0STBOT1L"], ["Thermo Flask 750ml", 1195, "B0THERM75"]]],
  ["Room Heater", [["Oil Filled Room Heater 11 Fin", 9995, "B0OFR11FN"], ["Fan Heater 2000W", 2495, "B0FANHT20"]]],
  ["Sandwich Maker", [["Sandwich Toaster 750W", 1695, "B0SANDT75"], ["Grill Sandwich Maker 1000W", 2295, "B0GRILL10"]]],
];
const BRANDS = ["Pigeon", "Pigeon", "Pigeon", "Stovekraft", "Gilma"];
const PH = ["Puneeth", "Ravi Kumar", "Anitha", "Suresh"];
const SIZES = ["", " Black", " Silver", " Red", " (Pack of 2)"];

export async function seedDemo(d: { tx: <T>(fn: (q: Q) => Promise<T>) => Promise<T> }) {
  await d.tx(async (q) => {
    await q("select set_config('app.skip_audit', 'on', true)");
    let pid = 0;
    const products: unknown[][] = [];
    const links: unknown[][] = [];
    let ci = 0;
    for (const [cat, items] of CATS) {
      ci++;
      await q("insert into product_categories (category_id, name, is_active, created_at, updated_at) values ($1, $2, true, now() - interval '200 days', now() - interval '20 days')", [ci, cat.toUpperCase()]);
      for (const [name, mrp, asin] of items) {
        for (let v = 0; v < SIZES.length; v++) {
          if (v > 0 && (pid + v) % 3 === 0) continue;
          pid++;
          const brand = BRANDS[(pid + ci) % BRANDS.length];
          const m = Math.round(mrp * (1 + v * 0.06) / 5) * 5 - 5;
          const disc = [50, 45, 40, 55][pid % 4];
          const dl = Math.round(m * (1 - disc / 100));
          const s1 = pid % 5 === 0 ? 100 : 0, s2 = pid % 7 === 0 ? 50 : 0;
          const dpm = pid % 6 === 0 ? 0 : 10;
          // Pricing exactly as the app calculates it (shared/pricing.ts).
          const c = computePricing({ dealer_landing: dl, dp_margin_percent: dpm, scheme_1: s1, scheme_2: s2, retail_margin_percent: 20, trigger_price_percent: 5 });
          const [net, rm, mop, mopScheme, trig] = [c.net_landing, c.retail_margin, c.mop, c.mop_scheme, c.trigger_price];
          const active = pid % 41 !== 0;
          products.push([pid, `${brand.toUpperCase()} ${name.toUpperCase()}${SIZES[v].toUpperCase()}`, ci, brand, String(19004000 + pid * 7), PH[pid % PH.length], m, 18, disc, dl,
            active, pid % 3 === 0, pid % 4 === 0 ? "1,3,5" : null, pid % 4 === 0 ? "1,2,3,4,5,6,7,8,9,10,11,12" : null, s1, s2, s1 + s2, net, 20, rm, mop, mopScheme, 5, trig, dpm, pid % 4 === 0]);
          const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, "-");
          if (pid % 13 !== 0) links.push([pid, "amazon", `https://www.amazon.in/Pigeon-${slug}/dp/${asin}${v}`, pid % 29 !== 0]);
          if (pid % 11 !== 0) links.push([pid, "flipkart", `https://www.flipkart.com/pigeon-${slug}/p/itm${(pid * 7919).toString(16)}?pid=${asin}${v}`, true]);
          if (pid % 4 === 0) links.push([pid, "instamart", `https://www.swiggy.com/instamart/item/${pid * 101}`, true]);
          if (pid % 5 === 0) links.push([pid, "zepto", `https://www.zeptonow.com/pn/pigeon-${slug}/pvid/${(pid * 104729).toString(16)}`, true]);
        }
      }
    }
    for (const p of products)
      await q(`insert into products (product_id, name, category_id, brand, hana_code, ph, mrp, gst_percent, direct_discount, dealer_landing, is_active, regular_scraping,
          scraping_schedule_weekly, months_to_scrape, scheme_1, scheme_2, total_scheme, net_landing, retail_margin_percent, retail_margin, mop, mop_scheme, trigger_price_percent, trigger_price, dp_margin_percent,
          scheduled_scraping, created_at, updated_at) values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26, now() - interval '150 days', now() - interval '3 days')`, p);
    for (const l of links)
      await q("insert into product_links (product_id, channel_name, url, is_active, created_at, updated_at) values ($1,$2,$3,$4, now() - interval '150 days', now() - interval '10 days')", l);
    await q("select setval(pg_get_serial_sequence('product_categories','category_id'), (select max(category_id) from product_categories))");
    await q("select setval(pg_get_serial_sequence('products','product_id'), (select max(product_id) from products))");

    // One scheduled run per channel per day (06:00 IST) for 30 days, results for every active link.
    await q("select setseed(0.42)");
    await q(`insert into scrape_runs (created_at, run_date, status, type, channel_name)
      select d + interval '30 minutes', d + interval '30 minutes', 'Done', 'Scheduled', ch
      from generate_series(date_trunc('day', now()) - interval '29 days', date_trunc('day', now()), interval '1 day') d
      cross join (values ('amazon'), ('flipkart')) c(ch) order by d, ch`);
    await q(`insert into scrape_run_batches (scrape_run_id, channel_name, batch_number, batch_total_count, product_link_ids, status, attempt_count, locked_at, started_at, completed_at, created_at, updated_at)
      select r.run_id, r.channel_name, b.n, b.total, b.ids, 'done', 1, r.run_date, r.run_date, r.run_date + interval '9 minutes', r.run_date, r.run_date + interval '9 minutes'
      from scrape_runs r
      join (
        select channel_name, n, array_agg(id order by id) ids, count(*) over (partition by channel_name) total from (
          select pl.channel_name, pl.product_link_id id, ((row_number() over (partition by pl.channel_name order by pl.product_link_id) - 1) / 20)::int + 1 n
          from product_links pl join products p on p.product_id = pl.product_id where pl.is_active and p.is_active) x
        group by channel_name, n) b on b.channel_name = r.channel_name`);
    await q(`insert into scrape_results (price, mrp, discount, rating, reviews, seller, availability, product_link_id, scrape_run_id, created_at)
      select case when av = 'In Stock' then price else 0 end,
             case when av = 'In Stock' then p_mrp else 0 end,
             case when av = 'In Stock' and p_mrp > price then round((p_mrp - price) / p_mrp * 100) else 0 end,
             rating, reviews,
             case when av = 'In Stock' then seller else 'No Data' end,
             case when av = 'In Stock' then av else 'Currently Unavailable' end,
             link_id, run_id, created_at
      from (
        select pl.product_link_id link_id, r.run_id, r.run_date + (random() * interval '8 minutes') created_at, p.mrp p_mrp,
          round((p.mrp_scheme_base * (0.93 + random() * 0.16 + case when pl.product_link_id % 9 = 0 then -0.12 else 0 end))::numeric, 0) price,
          round((3.6 + (pl.product_link_id % 13) / 10.0)::numeric, 1) rating,
          (pl.product_link_id * 37 % 4200 + 12)::int reviews,
          case when pl.channel_name = 'amazon' then (array['Appario Retail', 'Cloudtail India', 'Stovekraft Ltd', 'RetailEZ'])[1 + pl.product_link_id % 4]
               else (array['RetailNet', 'SuperComNet', 'Stovekraft Official', 'OmniTechRetail'])[1 + pl.product_link_id % 4] end seller,
          case when random() < 0.06 then 'Out of Stock' when random() < 0.02 then 'Currently Unavailable' else 'In Stock' end av
        from scrape_runs r
        join product_links pl on pl.channel_name = r.channel_name and pl.is_active
        join (select product_id, mrp, coalesce(nullif(mop_scheme, 0), mrp * 0.6) mrp_scheme_base, is_active from products) p on p.product_id = pl.product_id and p.is_active
      ) s`);
    // Today's Amazon run is still going: two batches done, the rest pending, so the queue has work.
    await q(`update scrape_runs set status = 'In Progress', type = 'Manual' where run_id = (select max(run_id) from scrape_runs where channel_name = 'amazon')`);
    await q(`update scrape_run_batches set status = 'pending', completed_at = null, locked_at = null, started_at = null, attempt_count = 0
      where scrape_run_id = (select max(run_id) from scrape_runs where channel_name = 'amazon') and batch_number > 2`);
    await q(`delete from scrape_results where scrape_run_id = (select max(run_id) from scrape_runs where channel_name = 'amazon')
      and product_link_id in (select unnest(product_link_ids) from scrape_run_batches where status = 'pending')`);

    // Earlier MOP breach reports, one a week per channel.
    await q(`insert into mop_breach_reports (report_date, channel_name, total_products, breached_products, generated_by, generated_at, remarks)
      select (date_trunc('day', now()) - (w * 7 || ' days')::interval)::date, ch, 140 + w * 3, 9 + (w * 5) % 7, 'Puneeth',
        date_trunc('day', now()) - (w * 7 || ' days')::interval + interval '11 hours', case when w = 1 then 'Shared with channel team' else null end
      from generate_series(1, 4) w cross join (values ('Amazon'), ('Flipkart')) c(ch)`);
    // Like the copied the old app data: an Instamart report whose file_url points at placeholder storage.
    await q(`insert into mop_breach_reports (report_date, channel_name, total_products, breached_products, generated_by, generated_at, file_url)
      values ((now() - interval '10 days')::date, 'Instamart', 28, 4, 'import', now() - interval '10 days',
        'https://storage.example.com/reports/mop_breach_' || to_char(now() - interval '10 days', 'YYYY-MM-DD') || '_instamart.pdf')`);
  });
  console.log("[seed] demo data loaded");
}
