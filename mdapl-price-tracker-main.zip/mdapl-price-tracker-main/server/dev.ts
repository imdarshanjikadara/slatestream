// Local API server for `npm run dev` (Vite proxies /api here). Same handler as the Vercel function.
import { createServer } from "node:http";
import { readFileSync, existsSync } from "node:fs";

// Minimal .env loader (no dependency): KEY=value lines, existing env wins.
if (existsSync(".env")) {
  for (const line of readFileSync(".env", "utf8").split(/\r?\n/)) {
    const m = /^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/.exec(line);
    if (m && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^(['"])(.*)\1$/, "$2");
  }
}

const { handle } = await import("./router.js");
const { getDb } = await import("./db.js");
const port = Number(process.env.API_PORT ?? 3001);
createServer((req, res) => void handle(req, res)).listen(port, () => console.log(`[api] http://localhost:${port}`));
// Locally there is no Vercel Cron: work through any queued batches once the database is ready.
void getDb().then(async () => (await import("./jobs/queue.js")).kickLocal());
