// Calls Browserless (the "Browserless v3" the old app resource): POST {BROWSERLESS_URL}/function?token=…&launch=…
// with { code, context }, through the residential proxy. All credentials come from env vars.
import { isDemo } from "../db.js";
import { AMAZON, AMAZON_ELEMENTS, FLIPKART, MYNTRA, MYNTRA_ELEMENTS, ZEPTO, INSTAMART } from "./scripts.js";

export type Scraped = { price: number; mrp: number; discount: number; rating: number; reviewCount: number; seller: string | null; availability: string | null };

/** Channels the queue can scrape (on demand and full runs). */
export const SCRAPE_CHANNELS = ["amazon", "flipkart", "instamart", "zepto"] as const;
/** Channels in the daily automatic run. Zepto joins once it has been checked on real pages. */
export const DAILY_CHANNELS = ["amazon", "flipkart"] as const;

const SCRIPTS: Record<string, { code: string; context?: Record<string, unknown> }> = {
  amazon: { code: AMAZON, context: { elements: AMAZON_ELEMENTS } },
  flipkart: { code: FLIPKART },
  myntra: { code: MYNTRA, context: { elements: MYNTRA_ELEMENTS } },
  zepto: { code: ZEPTO },
  instamart: { code: INSTAMART },
};

const env = () => ({
  url: (process.env.BROWSERLESS_URL || "https://production-sfo.browserless.io").replace(/\/+$/, ""),
  token: process.env.BROWSERLESS_TOKEN || "",
  proxy: process.env.SCRAPE_PROXY_SERVER || "",
  user: process.env.SCRAPE_PROXY_USERNAME || "",
  pass: process.env.SCRAPE_PROXY_PASSWORD || "",
  direct: process.env.SCRAPE_DIRECT_CHANNELS || "",
});

/** Channels read from the scraping server's own address instead of the residential proxy (SCRAPE_DIRECT_CHANNELS,
 *  e.g. "instamart,zepto"). Instamart and Zepto sit behind a bot check that hands the browser a small test to pass and
 *  reload; the proxy answers the reload from a different address, so the test never clears and the page stays empty.
 *  Amazon and Flipkart have no such check and keep the proxy, which is what gives their prices the right location. */
export const directChannels = () => new Set(env().direct.split(",").map((c) => c.trim().toLowerCase()).filter(Boolean));
const usesProxy = (channel: string) => !!env().proxy && !directChannels().has(channel.toLowerCase());

/** Demo mode without a Browserless token: plausible prices so the whole flow can be tried locally. */
export const simulated = () => isDemo() && !env().token;

export function scraperStatus() {
  const e = env();
  return { browserless: !!e.token || simulated(), proxy: (!!e.proxy && !!e.user && !!e.pass) || simulated(), simulated: simulated() };
}

// Time limits for one page. Only the product page's HTML is loaded (scripts, images and styles are blocked), which
// through the residential proxy takes seconds; a page that has not loaded in 75 s will not load at all on that proxy
// exit (production showed 2-minute waits ending in Browserless 408). So a try gets 100 s in all: the page load stops
// at 75 s, the Browserless session at 90 s (so Browserless answers with what it has), and the call is cut at 100 s.
// A slow page is then tried again on a fresh browser and a new proxy exit, instead of waiting minutes on a dead one.
export const PAGE_TIMEOUT_MS = 100_000;
export const NAV_TIMEOUT_MS = 75_000;

// The Browserless droplet is small: Chrome is started with as little as it needs to read one product page (no GPU,
// images, extensions, audio or background work), which keeps its memory and CPU low.
const LIGHT_CHROME = ["--disable-gpu", "--disable-dev-shm-usage", "--disable-extensions", "--disable-background-networking", "--disable-component-update",
  "--disable-default-apps", "--disable-sync", "--mute-audio", "--no-first-run", "--blink-settings=imagesEnabled=false", "--js-flags=--max-old-space-size=256"];

let lightChrome = true;

export type Pressure = { cpu: number | null; memory: number | null; running: number | null; queued: number | null; available: boolean | null };
/** How busy the Browserless server is (its /pressure endpoint: CPU and memory in %, browsers running and queued). Null
 *  when it cannot tell (older Browserless, simulated, or no answer within 5 s): the queue then goes by its own limit. */
export async function browserlessPressure(): Promise<Pressure | null> {
  if (simulated()) return null;
  const e = env();
  if (!e.token) return null;
  try {
    const res = await fetch(`${e.url}/pressure?token=${encodeURIComponent(e.token)}`, { signal: AbortSignal.timeout(5000) });
    if (!res.ok) return null;
    const body = (await res.json()) as any;
    const p = body?.pressure ?? body;
    const n = (v: unknown) => (typeof v === "number" && Number.isFinite(v) ? v : null);
    return { cpu: n(p?.cpu), memory: n(p?.memory), running: n(p?.running), queued: n(p?.queued), available: typeof p?.isAvailable === "boolean" ? p.isAvailable : null };
  } catch { return null; }
}

/** Failures worth one more try with a fresh browser (and a new proxy exit): timeouts, aborts, proxy and network errors. */
export const retryable = (msg: string) => /timeout|timed out|no answer|aborted|ERR_|proxy|socket|ECONNRESET|fetch failed|captcha|robot check|ProtocolError|408|429|50[234]/i.test(msg);
/** Browserless itself is overloaded (queue full, session cut, no answer): fewer pages at a time helps. */
export const overloaded = (msg: string) => /Browserless (408|429|503)|no answer from browserless|too many|callFunctionOn timed out/i.test(msg);

/** Scrapes one page. `timeoutMs` (at most PAGE_TIMEOUT_MS) is how long it may take in all; the queue passes what is left
 *  of the function's time, so a page started late in a step still finishes before the step ends. */
export async function scrapeUrl(channel: string, url: string, hint?: { mrp?: number; base?: number }, timeoutMs = PAGE_TIMEOUT_MS): Promise<Scraped> {
  if (simulated()) return simulate(url, hint);
  const t0 = Date.now();
  const first = await scrapeOnce(channel, url, timeoutMs, false);
  // Amazon is read without JavaScript (fast, light). A page that came back with no title, price or stock was not a
  // normal product page that way: load it once more the old way, with the page's own scripts on.
  const empty = channel === "amazon" && !first.hasTitle && !first.price && (!first.availability || first.availability === "Unknown");
  const left = timeoutMs - (Date.now() - t0);
  if (empty && left > 45_000) return strip(await scrapeOnce(channel, url, left, true));
  return strip(first);
}
const strip = ({ hasTitle: _h, ...s }: Scraped & { hasTitle?: boolean }): Scraped => s;

async function scrapeOnce(channel: string, url: string, timeoutMs: number, javascript: boolean): Promise<Scraped & { hasTitle?: boolean }> {
  const e = env();
  if (!e.token) throw new Error("Browserless is not configured (BROWSERLESS_TOKEN).");
  const script = SCRIPTS[channel];
  if (!script) throw new Error(`No scraper for channel ${channel}.`);
  const total = Math.min(PAGE_TIMEOUT_MS, Math.max(45_000, timeoutMs));
  const nav = Math.min(NAV_TIMEOUT_MS, total - 25_000);
  const proxied = usesProxy(channel);
  const launchOf = (light: boolean) => {
    const args = [...(light ? LIGHT_CHROME : []), ...(proxied ? [`--proxy-server=${e.proxy}`] : [])];
    return args.length ? `&launch=${encodeURIComponent(JSON.stringify({ args }))}` : "";
  };
  const context = {
    ...(script.context ?? {}),
    url, javascript,
    gotoOptions: { waitUntil: "domcontentloaded", timeout: nav },
    ...(proxied && e.user ? { authenticate: { username: e.user, password: e.pass } } : {}),
  };
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), total);
  try {
    const call = (light: boolean) => fetch(`${e.url}/function?token=${encodeURIComponent(e.token)}&timeout=${total - 10_000}${launchOf(light)}`, {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ code: script.code, context }), signal: ctl.signal,
    });
    let res = await call(lightChrome);
    let text = await res.text();
    // A Browserless that does not accept the extra Chrome flags: drop them from now on and try once more without.
    if (lightChrome && res.status === 400 && /launch|arg|flag/i.test(text)) {
      lightChrome = false;
      res = await call(false);
      text = await res.text();
    }
    if (!res.ok) {
      // Browserless sends { error: "message\nstack..." }: keep the message only.
      let msg = text;
      try { msg = String(JSON.parse(text)?.error ?? text); } catch { /* not JSON */ }
      throw new Error(`Browserless ${res.status}: ${msg.split("\n")[0].slice(0, 160)}`);
    }
    const body = JSON.parse(text);
    // Browserless answers with the function's `data` (or the whole { data, type } object, depending on version).
    const d = body?.data && typeof body.data === "object" && "price" in body.data ? body.data : body;
    return {
      price: num(d.price), mrp: num(d.mrp), discount: num(d.discount), rating: num(d.rating), reviewCount: Math.round(num(d.reviewCount)),
      seller: d.seller ? String(d.seller).trim() : null, availability: d.availability ? String(d.availability).trim() : null, hasTitle: d.hasTitle !== false,
    };
  } catch (err) {
    const msg = (err as Error).message ?? "";
    if ((err as Error).name === "AbortError") throw new Error(`No answer from Browserless within ${Math.round(total / 1000)} s (page load too slow through the proxy)`);
    // The bot check never clears while each request comes from a different proxy address.
    if (proxied && /bot check|did not let the page load|HTTP 202/i.test(msg)) {
      throw new Error(`${msg} The proxy answers from a different address each time, which this check refuses; add ${channel} to SCRAPE_DIRECT_CHANNELS to read it without the proxy.`);
    }
    throw err;
  } finally {
    clearTimeout(timer);
  }
}

const num = (v: unknown) => { const n = Number(String(v ?? "").trim()); return Number.isFinite(n) ? n : 0; };

function simulate(url: string, hint?: { mrp?: number; base?: number }): Promise<Scraped> {
  const mrp = hint?.mrp || 2000;
  const base = hint?.base || mrp * 0.6;
  const price = Math.round(base * (0.9 + Math.random() * 0.2));
  const inStock = Math.random() > 0.07;
  const seller = /flipkart/.test(url) ? "RetailNet" : "Appario Retail";
  // SIMULATE_FAIL_RATE (0 to 1, local demo only) makes some pages time out, to try failures, retries and the run page.
  const failRate = Number(process.env.SIMULATE_FAIL_RATE ?? 0);
  if (failRate > 0 && Math.random() < failRate) return new Promise((_, no) => setTimeout(() => no(new Error(`Browserless 400: Navigation timeout of ${NAV_TIMEOUT_MS} ms exceeded`)), 300));
  return new Promise((ok) => setTimeout(() => ok({
    price: inStock ? price : 0, mrp, discount: inStock && mrp > price ? Math.round(((mrp - price) / mrp) * 100) : 0,
    rating: Math.round((3.5 + Math.random() * 1.4) * 10) / 10, reviewCount: Math.round(Math.random() * 3000),
    seller, availability: inStock ? "In Stock" : "Out of Stock",
  }), 150 + Math.random() * 250));
}

/** What is configured, without any secret: hosts only (a SCRAPE_PROXY_SERVER with a login in it is shown without it). */
export function scraperSettings() {
  const e = env();
  const host = (u: string) => { try { const x = new URL(u.includes("://") ? u : `http://${u}`); return x.port ? `${x.hostname}:${x.port}` : x.hostname; } catch { return null; } };
  return {
    simulated: simulated(),
    browserless: { configured: !!e.token, host: host(e.url) },
    proxy: { configured: !!e.proxy && !!e.user && !!e.pass, host: e.proxy ? host(e.proxy) : null, login: !!e.user && !!e.pass },
    directChannels: [...directChannels()],
  };
}

/** Opens Decodo's IP check page in Browserless through the proxy: proves the token, the proxy login and the Indian exit in one call. */
export async function testConnection(): Promise<{ ok: boolean; ms: number; exit?: { ip?: string; country?: string; city?: string; isp?: string }; error?: string; simulated?: boolean }> {
  const t0 = Date.now();
  if (simulated()) return { ok: true, ms: 0, simulated: true, exit: { ip: "(demo)", country: "India", city: "Demo", isp: "Simulated" } };
  const e = env();
  if (!e.token) return { ok: false, ms: 0, error: "BROWSERLESS_TOKEN is not set in Vercel." };
  if (!e.proxy || !e.user || !e.pass) return { ok: false, ms: 0, error: "SCRAPE_PROXY_SERVER, SCRAPE_PROXY_USERNAME and SCRAPE_PROXY_PASSWORD must all be set in Vercel." };
  const code = `export default async function ({ page, context }) {
  await page.authenticate(context.authenticate);
  await page.goto("https://ip.decodo.com/json", { waitUntil: "domcontentloaded", timeout: 45000 });
  return { data: { body: await page.evaluate(() => document.body.innerText) }, type: "application/json" };
}`;
  const launch = `&launch=${encodeURIComponent(JSON.stringify({ args: [`--proxy-server=${e.proxy}`] }))}`;
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 60_000);
  try {
    const res = await fetch(`${e.url}/function?token=${encodeURIComponent(e.token)}${launch}`, {
      method: "POST", headers: { "Content-Type": "application/json" }, signal: ctl.signal,
      body: JSON.stringify({ code, context: { authenticate: { username: e.user, password: e.pass } } }),
    });
    const text = await res.text();
    const ms = Date.now() - t0;
    if (res.status === 401 || res.status === 403) return { ok: false, ms, error: "Browserless refused the token. Check BROWSERLESS_TOKEN (and BROWSERLESS_URL for your region)." };
    if (!res.ok) {
      if (/407|ERR_TUNNEL|ERR_PROXY|proxy/i.test(text)) return { ok: false, ms, error: "The proxy refused the connection. Check the Decodo username, password and the host:port in SCRAPE_PROXY_SERVER." };
      return { ok: false, ms, error: `Browserless answered ${res.status}. ${text.replace(/\s+/g, " ").slice(0, 160)}` };
    }
    const body = JSON.parse(text);
    const raw = body?.data?.body ?? body?.body ?? "";
    const j = JSON.parse(raw);
    return { ok: true, ms, exit: { ip: j?.proxy?.ip, country: j?.country?.name, city: j?.city?.name, isp: j?.isp?.isp } };
  } catch (err) {
    const ms = Date.now() - t0;
    if ((err as Error).name === "AbortError") return { ok: false, ms, error: "No answer within 60 seconds. Browserless or the proxy is not reachable." };
    return { ok: false, ms, error: "The check page did not load through the proxy. Check the Decodo login and host:port." };
  } finally {
    clearTimeout(timer);
  }
}
