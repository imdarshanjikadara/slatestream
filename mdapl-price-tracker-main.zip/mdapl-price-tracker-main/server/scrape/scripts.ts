// Browserless /function scripts, ported from the old workflow subflows ("Scrape … Product Links for Product Data").
// The scripts are unchanged except that the proxy login now arrives in `context.authenticate` from env vars
// (the old copies had it written into the script).

export const AMAZON_ELEMENTS = [
  "span.a-price.a-text-price.a-size-medium.apexPriceToPay span.a-offscreen",
  "span.a-price:not(.a-text-price) .a-offscreen",
  '.a-price.a-text-price[data-a-color="secondary"] .a-offscreen',
  ".a-text-strike .a-offscreen",
  ".savingsPercentage",
  ".a-size-large.a-color-price.savingsPercentage",
  "span.a-icon-alt",
  "#acrCustomerReviewText",
  "#sellerProfileTriggerId",
  "#availability span",
  "span.a-size-medium.a-color-success",
  "#availability",
  "#outOfStock",
  "#add-to-cart-button",
  "#buy-now-button",
].map((selector) => ({ selector }));

export const AMAZON = String.raw`
export default async function ({ page, context }) {
  // Every step has its own time limit, so a page that hangs fails in seconds instead of holding the browser.
  const limit = (p, ms, what) => Promise.race([p, new Promise((_, no) => setTimeout(() => no(new Error(what + " timed out after " + Math.round(ms / 1000) + " s")), ms))]);
  if (context.authenticate) await page.authenticate(context.authenticate);
  // Prices, seller and stock are in the page's HTML: no JavaScript runs at all (Amazon's inline scripts kept the
  // small Browserless server's CPU busy for minutes), and only the product page itself is fetched.
  // context.javascript: the fallback for a page that came back empty without JavaScript (the old way: scripts on the
  // page run, external scripts, images, styles and trackers are blocked).
  if (!context.javascript) await page.setJavaScriptEnabled(false);
  await page.setRequestInterception(true);
  const blocked = ["image", "stylesheet", "font", "media", "xhr", "script"];
  page.on("request", req => {
    if (req.isInterceptResolutionHandled && req.isInterceptResolutionHandled()) return;
    const ok = context.javascript ? !blocked.includes(req.resourceType()) : req.resourceType() === "document" && req.frame() === page.mainFrame();
    if (ok) req.continue(); else req.abort();
  });

  try {
    await page.goto(context.url, context.gotoOptions || { waitUntil: "domcontentloaded" });
  } catch (err) {
    // Navigation timed out: use what has arrived if the product page is already there, else fail as before.
    const ready = await limit(page.evaluate(() => !!document.querySelector("#productTitle, #corePrice_feature_div")), 5000, "Page check").catch(() => false);
    if (!ready) throw err;
  }
  const robot = await limit(page.evaluate(() => !!document.querySelector("form[action*='validateCaptcha'], #captchacharacters")), 5000, "Page check").catch(() => false);
  if (robot) throw new Error("Amazon showed a robot check (captcha) on this proxy exit");

  // All selectors read in one call.
  const results = await limit(page.evaluate((selectors) => {
    const out = {};
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      out[sel] = el ? { text: (el.textContent || "").trim() } : null;
    }
    return out;
  }, context.elements.map(e => e.selector).concat(["#productTitle"])), 15000, "Reading the page");
  const hasTitle = !!results["#productTitle"]?.text;

  const extractNumber = (text) => {
    if (!text) return 0;
    const n = parseFloat(text.replace(/[^\d.,]/g, "").replace(/,/g, ""));
    return isNaN(n) ? 0 : n;
  };
  const extractRating = (text) => {
    if (!text) return 0.0;
    const m = text.match(/(\d+\.?\d*)\s*out\s*of\s*5/i);
    return m ? parseFloat(m[1]) : 0.0;
  };
  const extractReviewCount = (text) => {
    if (!text) return 0;
    const m = text.match(/([\d,]+)\s*(ratings?|reviews?)/i);
    if (!m) return 0;
    const n = parseInt(m[1].replace(/,/g, ""));
    return isNaN(n) ? 0 : n;
  };
  const extractDiscount = (text) => {
    if (!text) return 0;
    const m = text.match(/(\d+)%/);
    return m ? Math.abs(parseInt(m[1])) : 0;
  };
  const cleanSeller = (seller) => {
    if (!seller) return "Amazon";
    return seller.replace(/^(Sold by|Ships from|Fulfilled by)\s*/i, "").trim() || "Amazon";
  };
  const cleanAvailability = (a) => {
    if (!a) return "Unknown";
    const c = a.toLowerCase().trim();
    if (c.includes("in stock")) return "In Stock";
    if (c.includes("out of stock")) return "Out of Stock";
    if (c.includes("temporarily unavailable")) return "Temporarily Unavailable";
    if (c.includes("currently unavailable")) return "Currently Unavailable";
    if (c.includes("limited") || (c.includes("only") && c.includes("left"))) return "Limited Stock";
    return "Unknown";
  };

  const currentPriceText = results["span.a-price:not(.a-text-price) .a-offscreen"]?.text
    || results["span.a-price.a-text-price.a-size-medium.apexPriceToPay span.a-offscreen"]?.text;
  const mrpText = results['.a-price.a-text-price[data-a-color="secondary"] .a-offscreen']?.text
    || results[".a-text-strike .a-offscreen"]?.text;
  const discountText = results[".savingsPercentage"]?.text
    || results[".a-size-large.a-color-price.savingsPercentage"]?.text;
  const ratingText = results["span.a-icon-alt"]?.text;
  const reviewText = results["#acrCustomerReviewText"]?.text;
  const sellerText = results["#sellerProfileTriggerId"]?.text;
  const availabilityText = results["#availability span"]?.text
    || results["span.a-size-medium.a-color-success"]?.text
    || results["#availability"]?.text
    || results["#outOfStock"]?.text;
  // The buy box decides when the stock line is missing or unclear: a price with "Add to cart" or "Buy now" is buyable.
  const canBuy = !!(results["#add-to-cart-button"] || results["#buy-now-button"]);

  const price = extractNumber(currentPriceText);
  const mrp = extractNumber(mrpText) || price;
  const discount = extractDiscount(discountText) || (price && mrp > price ? Math.round(((mrp - price) / mrp) * 100) : 0);

  return {
    data: {
      price,
      mrp,
      discount,
      rating: extractRating(ratingText),
      reviewCount: extractReviewCount(reviewText),
      seller: cleanSeller(sellerText),
      availability: (() => { const a = cleanAvailability(availabilityText); return a === "Unknown" && price > 0 && canBuy ? "In Stock" : a; })(),
      hasTitle
    },
    type: "application/json"
  };
}`;

export const FLIPKART = String.raw`
export default async function ({ page, context }) {
  const limit = (p, ms, what) => Promise.race([p, new Promise((_, no) => setTimeout(() => no(new Error(what + " timed out after " + Math.round(ms / 1000) + " s")), ms))]);
  if (context.authenticate) await page.authenticate(context.authenticate);
  await page.setRequestInterception(true);

  const blockedTypes = ["image", "stylesheet", "font", "media", "xhr", "script"];
  page.on("request", req => {
    if (blockedTypes.includes(req.resourceType()) || !req.url().includes("flipkart.com")) req.abort();
    else req.continue();
  });

  try {
    await page.goto(context.url, context.gotoOptions || { waitUntil: "domcontentloaded" });
  } catch (err) {
    // Navigation timed out: use what has arrived if the product page is already there, else fail as before.
    const ready = await limit(page.evaluate(() => !!document.querySelector("script[type='application/ld+json']")), 5000, "Page check").catch(() => false);
    if (!ready) throw err;
  }

  const raw = await limit(page.evaluate(() => {
    const flat = (x) => Array.isArray(x) ? x.flatMap(flat) : (x && x["@graph"] ? flat(x["@graph"]) : [x]);
    let product = null;
    for (const s of document.querySelectorAll('script[type="application/ld+json"]')) {
      try {
        const found = flat(JSON.parse(s.textContent)).find(o => o && o["@type"] === "Product");
        if (found) { product = found; break; }
      } catch (e) {}
    }
    const sellerEl = [...document.querySelectorAll("body *")]
      .find(el => el.children.length === 0 && /^Seller:/i.test((el.textContent || "").trim()));
    return { product, sellerText: sellerEl ? sellerEl.textContent.trim() : null };
  }), 15000, "Reading the page");

  const p = raw.product || {};
  const offer = Array.isArray(p.offers) ? (p.offers[0] || {}) : (p.offers || {});
  const agg = p.aggregateRating || {};
  const toNum = (v) => { const n = parseFloat(String(v ?? "").replace(/[^\d.]/g, "")); return isNaN(n) ? 0 : n; };

  const price = toNum(offer.price ?? offer.lowPrice);
  const mrpMatch = (p.description || "").match(/Rs\.?\s*([\d,]+(?:\.\d+)?)/i);
  const mrpRaw = mrpMatch ? toNum(mrpMatch[1]) : 0;
  const mrp = mrpRaw > price ? mrpRaw : price;
  const discount = price && mrp > price ? Math.round(((mrp - price) / mrp) * 100) : 0;

  const stockKey = String(offer.availability || "").split("/").pop().toLowerCase();
  const availability = {
    instock: "In Stock",
    outofstock: "Out of Stock",
    soldout: "Out of Stock",
    limitedavailability: "Limited Stock",
    discontinued: "Currently Unavailable",
    preorder: "Pre Order",
    backorder: "Pre Order"
  }[stockKey] || "Unknown";

  const seller = raw.sellerText ? (raw.sellerText.replace(/^Seller:\s*/i, "").trim() || "Flipkart") : "Flipkart";

  return {
    data: {
      found: !!raw.product,
      price,
      mrp,
      discount,
      rating: toNum(agg.ratingValue),
      reviewCount: toNum(agg.reviewCount),
      ratingCount: toNum(agg.ratingCount),
      seller,
      availability
    },
    type: "application/json"
  };
}`;

// Myntra and Zepto: scripts existed in the old app but their workflows were disabled and the screens showed "Coming soon".
// Myntra is kept here so it can be switched on later; the queue routes Amazon, Flipkart and Zepto.
export const MYNTRA_ELEMENTS = { price: ".pdp-price strong", mrp: ".pdp-mrp s", rating: ".index-overallRating div:first-child", reviewCount: ".index-ratingsCount", seller: ".SelectedSizeSellerInfo-sellerButton" };
export const MYNTRA = String.raw`
export default async function ({ page, context }) {
  if (context.authenticate) await page.authenticate(context.authenticate);
  await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36');
  await page.goto(context.url, { waitUntil: 'networkidle2', timeout: 60000 });
  for (const key of Object.keys(context.elements)) {
    await page.waitForSelector(context.elements[key], { timeout: 20000 });
  }
  const grabText = async (selector) => { try { return await page.$eval(selector, el => el.textContent.trim()); } catch { return null; } };
  const rawPrice = await grabText(context.elements.price);
  const rawMrp = await grabText(context.elements.mrp);
  const rawRating = await grabText(context.elements.rating);
  const rawReviews = await grabText(context.elements.reviewCount);
  const seller = await grabText(context.elements.seller);
  const extractNumber = (text) => { if (!text) return 0; const cleaned = text.replace(/[^\d.]/g, ''); return parseFloat(cleaned) || 0; };
  const price = extractNumber(rawPrice);
  const mrp = extractNumber(rawMrp);
  const rating = parseFloat(rawRating) || 0;
  const reviewCount = rawReviews ? parseInt(rawReviews.replace(/[^\d]/g, '')) : 0;
  const discount = price && mrp && mrp > price ? Math.round(((mrp - price) / mrp) * 100) : 0;
  return { data: { price, mrp, discount, rating, reviewCount, seller, availability: 'In Stock' }, type: 'application/json' };
}`;

export const ZEPTO = String.raw`
export default async function ({ page, context }) {
  // Every step has its own time limit, so a page that hangs fails in seconds instead of holding the browser.
  const limit = (p, ms, what) => Promise.race([p, new Promise((_, no) => setTimeout(() => no(new Error(what + " timed out after " + Math.round(ms / 1000) + " s")), ms))]);
  if (context.authenticate) await page.authenticate(context.authenticate);
  await page.setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36");
  await page.setExtraHTTPHeaders({ "Accept-Language": "en-IN,en;q=0.9" });
  await page.setRequestInterception(true);
  // Zepto answers a headless browser with a blank 202 page and a bot check that has to run its JavaScript, set a
  // cookie and reload. So scripts and data calls are allowed here; images, fonts, video and styles stay blocked.
  const blockedTypes = ["image", "stylesheet", "font", "media"];
  page.on("request", req => {
    if (req.isInterceptResolutionHandled && req.isInterceptResolutionHandled()) return;
    if (blockedTypes.includes(req.resourceType())) req.abort(); else req.continue();
  });
  let status = 0;
  try {
    const res = await page.goto(context.url, context.gotoOptions || { waitUntil: "domcontentloaded", timeout: 60000 });
    status = res ? res.status() : 0;
  } catch (err) {
    const ready = await limit(page.evaluate(() => !!document.querySelector("[data-testid='product-price'], #productSchema")), 5000, "Page check").catch(() => false);
    if (!ready) throw err;
  }
  // Wait for the product (after the bot check reloads the page). The page may navigate while we wait, so retry.
  const ready = "[data-testid='product-price'], #productSchema";
  const until = Date.now() + 25000;
  while (Date.now() < until) {
    const found = await limit(page.evaluate((sel) => !!document.querySelector(sel), ready), 5000, "Page check").catch(() => false);
    if (found) break;
    await new Promise(r => setTimeout(r, 750));
  }
  const challenged = status === 202;
  // Zepto renders the product on the server: price and MRP carry data-testid, the name is an h2 (no h1),
  // and a JSON-LD Product block (#productSchema) backs up name, price, stock and rating.
  const d = await limit(page.evaluate(() => {
    const text = (sel) => document.querySelector(sel)?.textContent?.trim() || null;
    let ld = null;
    for (const s of document.querySelectorAll("script[type='application/ld+json']")) {
      try { const j = JSON.parse(s.textContent || ""); const list = Array.isArray(j) ? j : [j]; ld = list.find(x => x && x["@type"] === "Product") || ld; } catch {}
      if (ld) break;
    }
    const offer = ld && (Array.isArray(ld.offers) ? ld.offers[0] : ld.offers);
    const meta = (n) => document.querySelector("meta[property='" + n + "']")?.getAttribute("content")?.trim() || null;
    const h2 = [...document.querySelectorAll("h1, h2")].map(h => (h.textContent || "").trim()).find(t => t.length > 3) || null;
    // "Seller Name" label, value in the next element.
    const label = [...document.querySelectorAll("#vendorDetail p, #vendorDetail span, p, span")].find(el => /^Seller Name$/i.test((el.textContent || "").trim()));
    const seller = label ? ((label.nextElementSibling?.textContent || "").trim() || (label.parentElement?.innerText || "").replace(/^Seller Name\s*/i, "").trim() || null) : null;
    const discount = [...document.querySelectorAll("span, p, div")].map(el => el.children.length ? "" : (el.textContent || "").trim()).find(t => /^\d{1,2}%\s*Off$/i.test(t)) || null;
    const buttons = [...document.querySelectorAll("button, [role='button'], [aria-label]")].map(el => ((el.getAttribute("aria-label") || "") + " " + (el.textContent || "")).toLowerCase());
    const addToCart = !!document.querySelector("[aria-label='Add to Cart']") || buttons.some(t => t.includes("add to cart"));
    const notifyMe = buttons.some(t => t.includes("notify me"));
    const body = (document.body?.innerText || "").toLowerCase();
    return {
      title: ld?.name || meta("og:title") || h2 || null, // the first h2 can be a banner ("Verify at your Doorstep")
      price: text("[data-testid='product-price']") || (offer?.price != null ? String(offer.price) : null),
      mrp: text("[data-testid='product-mrp']"),
      discount,
      rating: ld?.aggregateRating?.ratingValue != null ? String(ld.aggregateRating.ratingValue) : null,
      reviews: ld?.aggregateRating?.reviewCount != null ? String(ld.aggregateRating.reviewCount) : (ld?.aggregateRating?.ratingCount != null ? String(ld.aggregateRating.ratingCount) : null),
      seller, addToCart, notifyMe,
      ldStock: String(offer?.availability || "").toLowerCase(),
      soldOut: /out of stock|sold out|currently unavailable/.test(body),
    };
  }), 15000, "Reading the page");
  // A blocked or failed request shows Chrome's own error page ("This page isn't working"), not Zepto's.
  if (!d.price && (status >= 400 || /isn.t working|can.t be reached|access denied|too many requests/i.test(d.title || "")))
    throw new Error("Zepto refused the page" + (status ? " (HTTP " + status + ")" : "") + ", try again later");
  if (!d.price && !d.title && challenged) throw new Error("Zepto's bot check did not let the page load (HTTP 202), try again later");
  if (!d.title && !d.price) throw new Error("The Zepto product page did not load (no title or price on the page)");
  const num = (t) => { if (!t) return 0; const c = String(t).replace(/[^\d.,kK]/g, "").toLowerCase(); if (c.includes("k")) return parseFloat(c.replace(/k/, "")) * 1000; const n = parseFloat(c.replace(/,/g, "")); return isNaN(n) ? 0 : n; };
  const price = num(d.price);
  const mrp = Math.max(num(d.mrp), price);
  const discount = num(d.discount) || (price && mrp > price ? Math.floor(((mrp - price) / mrp) * 100) : 0);
  const out = d.notifyMe || d.ldStock.includes("outofstock") || (!d.addToCart && d.soldOut);
  const availability = out ? "Out of Stock" : d.ldStock.includes("limited") ? "Limited Stock" : price ? "In Stock" : "Unknown";
  return { data: { price, mrp, discount, rating: parseFloat(d.rating) || 0, reviewCount: Math.round(num(d.reviews)), seller: d.seller || "Zepto", availability }, type: "application/json" };
}`;

export const INSTAMART = String.raw`
export default async function ({ page, context }) {
  // Every step has its own time limit, so a page that hangs fails in seconds instead of holding the browser.
  const limit = (p, ms, what) => Promise.race([p, new Promise((_, no) => setTimeout(() => no(new Error(what + " timed out after " + Math.round(ms / 1000) + " s")), ms))]);
  if (context.authenticate) await page.authenticate(context.authenticate);
  await page.setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36");
  await page.setExtraHTTPHeaders({ "Accept-Language": "en-IN,en;q=0.9" });
  await page.setRequestInterception(true);
  // Like Zepto, Instamart sits behind an AWS bot check that must run its script and reload, and the product block is
  // drawn by the page's own scripts. So scripts and data calls are allowed; images, fonts, video and styles are blocked.
  const blockedTypes = ["image", "stylesheet", "font", "media"];
  page.on("request", req => {
    if (req.isInterceptResolutionHandled && req.isInterceptResolutionHandled()) return;
    if (blockedTypes.includes(req.resourceType())) req.abort(); else req.continue();
  });
  let status = 0;
  try {
    const res = await page.goto(context.url, context.gotoOptions || { waitUntil: "domcontentloaded", timeout: 60000 });
    status = res ? res.status() : 0;
  } catch (err) {
    const ok = await limit(page.evaluate(() => !!document.querySelector("[data-testid='item-collection-pdp-price-section']")), 5000, "Page check").catch(() => false);
    if (!ok) throw err;
  }
  // Wait for the product's price block (after the bot check reloads the page). The page may navigate while we wait.
  const until = Date.now() + 25000;
  while (Date.now() < until) {
    const found = await limit(page.evaluate(() => !!document.querySelector("[data-testid='item-collection-pdp-price-section'] [data-testid='item-offer-price']")), 5000, "Page check").catch(() => false);
    if (found) break;
    await new Promise(r => setTimeout(r, 750));
  }
  // The seller box is near the bottom and is drawn only when scrolled to. The page scrolls inside a div, not the
  // window, so scroll every scrollable box down, then wait up to 4 s for "Seller Name".
  const sellerUntil = Date.now() + 4000;
  while (Date.now() < sellerUntil) {
    const has = await limit(page.evaluate(() => {
      window.scrollTo(0, document.body.scrollHeight);
      for (const el of document.querySelectorAll("div")) if (el.scrollHeight > el.clientHeight + 50) el.scrollTop = el.scrollHeight;
      return /Seller Name/i.test(document.body?.innerText || "");
    }), 5000, "Scrolling").catch(() => false);
    if (has) break;
    await new Promise(r => setTimeout(r, 500));
  }
  const d = await limit(page.evaluate(() => {
    // Only the product's own block: "Frequently bought together" cards further down have prices too.
    const box = document.querySelector("[data-testid='item-collection-pdp-container']") || document;
    const text = (sel, root) => (root || box).querySelector(sel)?.textContent?.trim() || null;
    let ld = null;
    for (const s of document.querySelectorAll("script[type='application/ld+json']")) {
      try { const j = JSON.parse(s.textContent || ""); const list = Array.isArray(j) ? j : [j]; ld = list.find(x => x && x["@type"] === "Product") || ld; } catch {}
      if (ld) break;
    }
    const offer = ld && (Array.isArray(ld.offers) ? ld.offers[0] : ld.offers);
    // "Seller Name: Greenmania Modern Retail Pvt Ltd - CarmelaramCustomer Care: ..."
    const all = (document.body?.textContent || "").replace(/\s+/g, " ");
    const m = all.match(/Seller Name\s*:\s*(.+?)(?=Customer Care|FSSAI|Address|Seller Address|$)/i);
    const seller = m ? m[1].trim().slice(0, 120) || null : null;
    const priceBox = box.querySelector("[data-testid='item-collection-pdp-price-section']") || box;
    const buttons = [...priceBox.querySelectorAll("button, [role='button']")].map(el => ((el.getAttribute("aria-label") || "") + " " + (el.textContent || "")).toLowerCase());
    const canAdd = !!priceBox.querySelector("[data-testid='add_buttons_center']") || buttons.some(t => /\badd\b/.test(t));
    const soldText = (priceBox.textContent || "").toLowerCase();
    return {
      title: text("h1", document) || ld?.name || null,
      price: text("[data-testid='item-offer-price']") || (offer?.price != null ? String(offer.price) : null),
      mrp: text("[data-testid='item-mrp-price']"),
      discount: text("[data-testid='item-offer-label-discount-text']"),
      rating: ld?.aggregateRating?.ratingValue != null ? String(ld.aggregateRating.ratingValue) : null,
      reviews: ld?.aggregateRating?.reviewCount != null ? String(ld.aggregateRating.reviewCount) : (ld?.aggregateRating?.ratingCount != null ? String(ld.aggregateRating.ratingCount) : null),
      seller, canAdd,
      soldOut: /sold out|out of stock|notify me|currently unavailable/.test(soldText),
      ldStock: String(offer?.availability || "").toLowerCase(),
      unserviceable: /not serviceable|doesn.t deliver|no store|unserviceable/i.test(document.body?.innerText || ""),
    };
  }), 15000, "Reading the page");
  if (!d.price && (status >= 400 || /isn.t working|can.t be reached|access denied|too many requests/i.test(d.title || "")))
    throw new Error("Instamart refused the page" + (status ? " (HTTP " + status + ")" : "") + ", try again later");
  if (!d.price && !d.title && status === 202) throw new Error("Instamart's bot check did not let the page load (HTTP 202), try again later");
  if (!d.title && !d.price) throw new Error("The Instamart product page did not load (no title or price on the page)");
  const num = (t) => { if (!t) return 0; const c = String(t).replace(/[^\d.,kK]/g, "").toLowerCase(); if (c.includes("k")) return parseFloat(c.replace(/k/, "")) * 1000; const n = parseFloat(c.replace(/,/g, "")); return isNaN(n) ? 0 : n; };
  const price = num(d.price);
  const mrp = Math.max(num(d.mrp), price);
  const discount = num(d.discount) || (price && mrp > price ? Math.floor(((mrp - price) / mrp) * 100) : 0);
  const out = d.soldOut || d.ldStock.includes("outofstock") || (price && !d.canAdd);
  const availability = out ? "Out of Stock" : price ? "In Stock" : "Unknown";
  return { data: { price, mrp, discount, rating: parseFloat(d.rating) || 0, reviewCount: Math.round(num(d.reviews)), seller: d.seller || "Instamart", availability }, type: "application/json" };
}`;
