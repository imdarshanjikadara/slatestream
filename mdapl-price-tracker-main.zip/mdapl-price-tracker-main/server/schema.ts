// Schema setup that is safe on a live database:
// * one cheap version check on every cold start; nothing else runs when the schema is current,
// * tables and columns are only created when missing (checked first, never a blind ALTER),
// * every lock-taking statement runs under `lock_timeout`, so startup can never queue behind traffic,
// * demo data is only seeded into a database that had no tables at all.
import type { Q } from "./db.js";

const SCHEMA_VERSION = "2026-11-16.2";

type D = { query: Q; tx: <T>(fn: (q: Q) => Promise<T>) => Promise<T>; kind: "postgres" | "pglite" };

const TABLES: Record<string, string> = {
  // People who can sign in. APP_USERS (env) only creates the first accounts; after that admins manage them in Team & access.
  // session_version goes up when a password changes or access is taken away, which ends that person's other sessions.
  app_users: `create table app_users (
    user_id serial primary key,
    email text not null unique,
    name text not null,
    role text not null default 'staff' check (role in ('admin', 'staff')),
    password_hash text not null,
    must_change_password boolean not null default false,
    is_active boolean not null default true,
    session_version int not null default 1,
    session_grace_until timestamptz,
    last_sign_in_at timestamptz,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now())`,
  product_categories: `create table product_categories (
    category_id serial primary key,
    name text not null,
    is_active boolean not null default true,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now())`,
  products: `create table products (
    product_id serial primary key,
    name text,
    description text,
    category_id int references product_categories(category_id),
    brand text,
    hana_code text,
    ph text,
    mrp numeric default 0,
    gst_percent numeric default 0,
    direct_discount numeric default 0,
    dealer_landing numeric default 0,
    is_active boolean not null default true,
    regular_scraping boolean default false,
    scheduled_scraping boolean default false,
    scraping_schedule_weekly text,
    months_to_scrape text,
    scraping_schedule_monthly text,
    scrape_time text,
    paused_mode text,
    scheme_1 numeric default 0,
    scheme_2 numeric default 0,
    scheme_3 numeric default 0,
    total_scheme numeric default 0,
    net_landing numeric default 0,
    dp_margin_percent numeric default 0,
    retail_margin_percent numeric default 0,
    retail_margin numeric default 0,
    mop numeric default 0,
    mop_scheme numeric default 0,
    trigger_price_percent numeric default 0,
    trigger_price numeric default 0,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now())`,
  product_links: `create table product_links (
    product_link_id serial primary key,
    product_id int references products(product_id),
    channel_name text not null,
    url text,
    is_active boolean not null default true,
    created_at timestamptz not null default now(),
    updated_at timestamptz default now())`,
  scrape_runs: `create table scrape_runs (
    run_id serial primary key,
    created_at timestamptz not null default now(),
    run_date timestamptz not null default now(),
    status text,
    type text,
    channel_name text)`,
  scrape_run_batches: `create table scrape_run_batches (
    scrape_batch_id serial primary key,
    scrape_run_id int references scrape_runs(run_id),
    channel_name text,
    batch_number int,
    batch_total_count int,
    product_link_ids int[],
    status text not null default 'pending',
    attempt_count int not null default 0,
    locked_at timestamptz,
    started_at timestamptz,
    completed_at timestamptz,
    error_message text,
    page_ms bigint not null default 0,
    links_done int not null default 0,
    link_errors jsonb,
    ok_ms bigint not null default 0,
    ok_links int not null default 0,
    wall_ms bigint not null default 0,
    current_link_id int,
    current_try int,
    current_at timestamptz,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now())`,
  scrape_results: `create table scrape_results (
    scrape_result_id serial primary key,
    price numeric default 0,
    mrp numeric default 0,
    discount numeric default 0,
    rating numeric default 0,
    reviews int default 0,
    seller text,
    availability text,
    product_link_id int references product_links(product_link_id),
    scrape_run_id int references scrape_runs(run_id),
    created_at timestamptz not null default now())`,
  mop_breach_reports: `create table mop_breach_reports (
    report_id serial primary key,
    report_date date,
    channel_name text,
    total_products int default 0,
    breached_products int default 0,
    generated_by text,
    generated_at timestamptz default now(),
    remarks text,
    file_url text)`,
  mop_breach_report_items: `create table mop_breach_report_items (
    item_id serial primary key,
    report_id int not null references mop_breach_reports(report_id) on delete cascade,
    product_link_id int,
    product_id int,
    product_name text,
    brand text,
    category_name text,
    seller text,
    url text,
    price numeric,
    mop numeric,
    gap numeric,
    scraped_at timestamptz)`,
  audit_log: `create table audit_log (
    id bigserial primary key,
    at timestamptz not null default now(),
    txid bigint not null default txid_current(),
    actor text not null,
    ip text,
    user_agent text,
    table_name text not null,
    row_pk text not null,
    action text not null check (action in ('insert','update','delete','soft_delete','restore')),
    old_data jsonb,
    new_data jsonb,
    restored_at timestamptz,
    restored_by text)`,
  app_meta: `create table app_meta (key text primary key, value text)`,
};

/** Columns the app relies on, added (after checking) to tables that came over from the old app without them. */
const COLUMNS: Record<string, [string, string][]> = {
  app_users: [["session_grace_until", "timestamptz"]],
  product_categories: [["is_active", "boolean not null default true"], ["created_at", "timestamptz default now()"], ["updated_at", "timestamptz default now()"]],
  products: [["description", "text"], ["regular_scraping", "boolean default false"], ["scheduled_scraping", "boolean default false"],
    ["scraping_schedule_weekly", "text"], ["months_to_scrape", "text"], ["scraping_schedule_monthly", "text"], ["scrape_time", "text"], ["paused_mode", "text"], ["scheme_1", "numeric default 0"],
    ["scheme_2", "numeric default 0"], ["scheme_3", "numeric default 0"], ["total_scheme", "numeric default 0"], ["net_landing", "numeric default 0"],
    ["dp_margin_percent", "numeric default 0"], ["retail_margin_percent", "numeric default 0"], ["retail_margin", "numeric default 0"], ["mop", "numeric default 0"],
    ["mop_scheme", "numeric default 0"], ["trigger_price_percent", "numeric default 0"], ["trigger_price", "numeric default 0"],
    ["is_active", "boolean not null default true"], ["created_at", "timestamptz default now()"], ["updated_at", "timestamptz default now()"]],
  product_links: [["is_active", "boolean not null default true"], ["created_at", "timestamptz default now()"], ["updated_at", "timestamptz default now()"]],
  scrape_runs: [["type", "text"], ["channel_name", "text"], ["run_date", "timestamptz default now()"]],
  scrape_run_batches: [["attempt_count", "int not null default 0"], ["locked_at", "timestamptz"], ["started_at", "timestamptz"], ["completed_at", "timestamptz"], ["error_message", "text"],
    // Time spent loading pages and links finished (scraped or given up), for time estimates that match real runs.
    ["page_ms", "bigint not null default 0"], ["links_done", "int not null default 0"],
    // Why each link that could not be scraped failed: { "<link id>": { error, tries, at } }.
    ["link_errors", "jsonb"],
    // Time of the pages that loaded and how many: the speed used for estimates (timeouts would make it look minutes per page).
    ["ok_ms", "bigint not null default 0"], ["ok_links", "int not null default 0"],
    // Clock time the worker spent on the batch (all its steps): links_done / wall_ms is the real speed, retries and
    // failures included, which is what time estimates use.
    ["wall_ms", "bigint not null default 0"],
    // The link loading right now (one at a time) and since when, for the run page.
    ["current_link_id", "int"], ["current_try", "int"], ["current_at", "timestamptz"]],
  scrape_results: [["discount", "numeric default 0"], ["rating", "numeric default 0"], ["reviews", "int default 0"], ["seller", "text"], ["availability", "text"], ["scrape_run_id", "int"]],
  mop_breach_reports: [["remarks", "text"], ["file_url", "text"], ["generated_by", "text"], ["generated_at", "timestamptz default now()"]],
  audit_log: [["ip", "text"], ["user_agent", "text"], ["restored_at", "timestamptz"], ["restored_by", "text"]],
};

/** Every foreign key and lookup column is indexed. [name, table, definition]. */
const INDEXES: [string, string, string][] = [
  ["products_category_id_idx", "products", "(category_id)"],
  ["products_active_idx", "products", "(is_active)"],
  ["products_brand_idx", "products", "(lower(brand))"],
  ["products_name_idx", "products", "(lower(name))"],
  ["product_links_product_id_idx", "product_links", "(product_id)"],
  ["product_links_channel_idx", "product_links", "(channel_name, is_active)"],
  ["scrape_results_link_created_idx", "scrape_results", "(product_link_id, created_at desc)"],
  // Per-run counts (total, in stock) come from this index alone, without reading the rows.
  ["scrape_results_run_avail_idx", "scrape_results", "(scrape_run_id, availability)"],
  ["scrape_results_created_idx", "scrape_results", "(created_at)"],
  ["scrape_runs_run_date_idx", "scrape_runs", "(run_date desc)"],
  ["scrape_runs_status_idx", "scrape_runs", "(status)"],
  ["scrape_run_batches_run_idx", "scrape_run_batches", "(scrape_run_id)"],
  ["scrape_run_batches_queue_idx", "scrape_run_batches", "(status, created_at, batch_number)"],
  ["mop_breach_reports_channel_idx", "mop_breach_reports", "(channel_name, report_date desc)"],
  ["mop_breach_report_items_report_idx", "mop_breach_report_items", "(report_id)"],
  ["audit_log_at_idx", "audit_log", "(at desc)"],
  ["audit_log_table_pk_idx", "audit_log", "(table_name, row_pk, at desc)"],
  ["audit_log_txid_idx", "audit_log", "(txid)"],
  ["audit_log_actor_idx", "audit_log", "(actor)"],
];
/** Indexes replaced by better ones above (scrape_run_id lookups are served by scrape_results_run_avail_idx). */
const DROPPED_INDEXES = ["scrape_results_run_idx"];
/** Unique keys the upserts depend on (ON CONFLICT). Only created when no duplicate rows exist. */
const UNIQUES: [string, string, string][] = [
  ["product_links_product_channel_key", "product_links", "(product_id, channel_name)"],
  ["scrape_results_run_link_key", "scrape_results", "(scrape_run_id, product_link_id)"],
];

const AUDIT_FN = `
create or replace function audit_row() returns trigger language plpgsql as $$
declare
  pk_col text := tg_argv[0];
  flag text := nullif(tg_argv[1], '');
  actor text := coalesce(nullif(current_setting('app.actor', true), ''), 'database');
  ip text := nullif(current_setting('app.ip', true), '');
  ua text := nullif(current_setting('app.ua', true), '');
  o jsonb; n jsonb; old_diff jsonb; new_diff jsonb; act text;
begin
  if current_setting('app.skip_audit', true) = 'on' then return null; end if;
  if tg_op = 'INSERT' then
    n := to_jsonb(new) - 'password_hash';
    insert into audit_log (actor, ip, user_agent, table_name, row_pk, action, new_data) values (actor, ip, ua, tg_table_name, n ->> pk_col, 'insert', n);
  elsif tg_op = 'DELETE' then
    o := to_jsonb(old) - 'password_hash';
    insert into audit_log (actor, ip, user_agent, table_name, row_pk, action, old_data) values (actor, ip, ua, tg_table_name, o ->> pk_col, 'delete', o);
  else
    o := to_jsonb(old); n := to_jsonb(new);
    -- Password hashes never reach the log; a change is recorded as "password: changed".
    if (o ->> 'password_hash') is distinct from (n ->> 'password_hash') then
      o := o || '{"password": "previous"}'; n := n || '{"password": "changed"}';
    end if;
    o := o - 'password_hash'; n := n - 'password_hash';
    select jsonb_object_agg(k, o -> k), jsonb_object_agg(k, n -> k) into old_diff, new_diff
      from jsonb_object_keys(n) k where (o -> k) is distinct from (n -> k) and k not in ('updated_at', 'last_sign_in_at', 'session_version', 'session_grace_until');
    if old_diff is null then return null; end if;
    act := case
      when flag is not null and coalesce((o ->> flag)::boolean, true) and not coalesce((n ->> flag)::boolean, true) then 'soft_delete'
      when flag is not null and not coalesce((o ->> flag)::boolean, true) and coalesce((n ->> flag)::boolean, true) then 'restore'
      else 'update' end;
    insert into audit_log (actor, ip, user_agent, table_name, row_pk, action, old_data, new_data)
      values (actor, ip, ua, tg_table_name, n ->> pk_col, act, case when act = 'soft_delete' then o else old_diff end, new_diff);
  end if;
  return null;
end $$`;

const RESTORE_FN = `
create or replace function restore_deleted(p_audit_id bigint, p_actor text) returns int language plpgsql as $$
declare e audit_log; x audit_log; pk text; n int := 0; c int;
begin
  select * into e from audit_log where id = p_audit_id and action in ('delete', 'soft_delete') for update;
  if not found then raise exception 'not_found'; end if;
  if e.restored_at is not null then return 0; end if;
  if e.at < now() - interval '30 days' then raise exception 'expired'; end if;
  perform set_config('app.actor', p_actor, true);
  for x in select * from audit_log where txid = e.txid and action in ('delete', 'soft_delete') and restored_at is null order by id desc loop
    select a.attname into pk from pg_index i join pg_attribute a on a.attrelid = i.indrelid and a.attnum = i.indkey[0]
      where i.indrelid = format('public.%I', x.table_name)::regclass and i.indisprimary;
    if x.action = 'soft_delete' then
      execute format('update %I set is_active = true where %I::text = $1 and not coalesce(is_active, true)', x.table_name, pk) using x.row_pk;
    else
      execute format('insert into %I select * from jsonb_populate_record(null::%I, $1) on conflict do nothing', x.table_name, x.table_name) using x.old_data;
    end if;
    get diagnostics c = row_count; n := n + c;
    update audit_log set restored_at = now(), restored_by = p_actor where id = x.id;
  end loop;
  return n;
end $$`;

// Written by the scraper and the report generator, not by people: auditing them doubled every scrape's writes and buried
// people's changes in the log. Runs and reports themselves stay audited.
const NOT_AUDITED = new Set(["audit_log", "app_meta", "scrape_results", "scrape_run_batches", "mop_breach_report_items"]);

export async function ensureSchema(d: D) {
  const t0 = Date.now();
  // Usual case: schema already current, answered by one small query (a cold start pays nothing more).
  const [cur] = await d.query<{ value: string }>("select value from app_meta where key = 'schema_version'").catch(() => [] as { value: string }[]);
  if (cur?.value === SCHEMA_VERSION) return;
  const existing = new Set((await d.query<{ t: string }>("select table_name t from information_schema.tables where table_schema = 'public' and table_type = 'BASE TABLE'")).map((r) => r.t));
  const fresh = existing.size === 0;

  await d.tx(async (q) => {
    if (d.kind === "postgres") {
      // Two cold starts migrating at once deadlocked; the second now waits for the first, then finds the schema current.
      await q("select pg_advisory_xact_lock(724002)");
      const [again] = await q<{ value: string }>("select value from app_meta where key = 'schema_version'").catch(() => [] as { value: string }[]);
      if (again?.value === SCHEMA_VERSION) return;
      await q("set local lock_timeout = '10s'; set local statement_timeout = '60s'");
    }
    for (const [name, ddl] of Object.entries(TABLES)) if (!existing.has(name)) await q(ddl);

    const cols = await q<{ table_name: string; column_name: string }>("select table_name, column_name from information_schema.columns where table_schema = 'public'");
    const have = new Set(cols.map((c) => `${c.table_name}.${c.column_name}`));
    for (const [t, list] of Object.entries(COLUMNS))
      for (const [c, def] of list) if (!have.has(`${t}.${c}`)) await q(`alter table ${t} add column ${c} ${def}`);

    const idx = new Set((await q<{ indexname: string }>("select indexname from pg_indexes where schemaname = 'public'")).map((r) => r.indexname));
    for (const [name, table, def] of INDEXES) if (!idx.has(name)) await q(`create index if not exists ${name} on ${table} ${def}`);
    for (const name of DROPPED_INDEXES) if (idx.has(name)) await q(`drop index if exists ${name}`);
    // Unique keys: skip when an equivalent unique index already exists (the old app DB had them under other names).
    const uniques = await q<{ tablename: string; indexdef: string }>("select tablename, indexdef from pg_indexes where schemaname = 'public' and indexdef ilike 'create unique%'");
    for (const [name, table, def] of UNIQUES) {
      const colsWanted = def.replace(/[()\s]/g, "");
      if (uniques.some((u) => u.tablename === table && u.indexdef.replace(/\s/g, "").includes(`(${colsWanted})`))) continue;
      const cl = colsWanted.split(",");
      const [{ dup }] = await q<{ dup: boolean }>(`select exists (select 1 from ${table} group by ${cl.join(",")} having count(*) > 1) dup`);
      if (!dup) await q(`create unique index if not exists ${name} on ${table} ${def}`);
      else console.warn(`[schema] ${table} has duplicate ${def}; unique key not created`);
    }

    await q(AUDIT_FN);
    await q(RESTORE_FN);

    // Data rules. A product is scraped every day (regular) or on a schedule, never both: regular wins, as it always did.
    if (!fresh) await q("update products set scheduled_scraping = false where regular_scraping and scheduled_scraping");
    // The daily automatic runs start paused (switched back on from Channel Scraping); a choice already made is kept.
    await q(`insert into app_meta (key, value) values ('daily_runs', $1) on conflict (key) do nothing`, [JSON.stringify({ paused: true, by: "system", at: new Date().toISOString() })]);

    // Audit trigger on every table (only where missing), RLS on every table.
    const tables = await q<{ t: string; pk: string | null; flag: string | null; trig: boolean; rls: boolean }>(`
      select c.relname t,
        (select a.attname from pg_index i join pg_attribute a on a.attrelid = i.indrelid and a.attnum = i.indkey[0] where i.indrelid = c.oid and i.indisprimary) pk,
        (select 'is_active' from information_schema.columns ic where ic.table_schema = 'public' and ic.table_name = c.relname and ic.column_name = 'is_active') flag,
        exists (select 1 from pg_trigger g where g.tgrelid = c.oid and g.tgname = 'audit') trig,
        c.relrowsecurity rls
      from pg_class c join pg_namespace s on s.oid = c.relnamespace
      where s.nspname = 'public' and c.relkind = 'r'`);
    for (const t of tables) {
      if (!(t.t in TABLES)) continue;   // only this app's tables; other tables in the same database are left alone
      if (!t.rls) await q(`alter table ${quoteIdent(t.t)} enable row level security`);
      if (NOT_AUDITED.has(t.t)) { if (t.trig) await q(`drop trigger if exists audit on ${quoteIdent(t.t)}`); continue; }
      if (!t.pk || t.trig) continue;
      await q(`create trigger audit after insert or update or delete on ${quoteIdent(t.t)} for each row execute function audit_row('${t.pk}', '${t.flag ?? ""}')`);
    }
    await q("insert into app_meta (key, value) values ('schema_version', $1) on conflict (key) do update set value = excluded.value", [SCHEMA_VERSION]);
  });

  if (fresh && d.kind === "pglite") {
    const { seedDemo } = await import("./seed.js");
    await seedDemo(d);
  }
  console.log(`[schema] ready in ${Date.now() - t0} ms (${d.kind}${fresh ? ", new database" : ""})`);
}

const quoteIdent = (s: string) => `"${s.replace(/"/g, '""')}"`;
