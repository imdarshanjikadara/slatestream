// One entry for every API call (Vercel: api/main.ts; local: server/dev.ts).
import type { IncomingMessage, ServerResponse } from "node:http";
import { cookieName, read } from "./auth.js";
import { report, routeTag } from "./sentry.js";
import { HttpError, clientIp, readBody, send, type Req, type Res } from "./http.js";
import { routes as authRoutes } from "./routes/auth.js";
import { routes as metaRoutes } from "./routes/meta.js";
import { routes as dashboardRoutes } from "./routes/dashboard.js";
import { routes as categoryRoutes } from "./routes/categories.js";
import { routes as productRoutes } from "./routes/products.js";
import { routes as linkRoutes } from "./routes/links.js";
import { routes as resultRoutes } from "./routes/results.js";
import { routes as mopRoutes } from "./routes/mop.js";
import { routes as runRoutes } from "./routes/runs.js";
import { routes as auditRoutes } from "./routes/audit.js";
import { routes as jobRoutes } from "./routes/jobs.js";
import { routes as teamRoutes } from "./routes/team.js";
import { routes as supportRoutes } from "./routes/support.js";
import { routes as scheduleRoutes } from "./routes/schedule.js";

export type Route = {
  method: "GET" | "POST" | "PATCH" | "PUT" | "DELETE";
  path: RegExp;
  /** public: no sign-in; cron: CRON_SECRET bearer; admin: admin role only. Default: any signed-in user. */
  access?: "public" | "cron" | "admin";
  handler: (r: Req) => Promise<Res | unknown>;
};

const ROUTES: Route[] = [...authRoutes, ...metaRoutes, ...dashboardRoutes, ...categoryRoutes, ...productRoutes, ...linkRoutes,
  ...resultRoutes, ...mopRoutes, ...runRoutes, ...auditRoutes, ...jobRoutes, ...teamRoutes, ...supportRoutes, ...scheduleRoutes];
// Support attachments come as base64 JSON (a 3 MB file is about 4 MB): this path may send up to 5 MB.
const BIG_BODY = /^\/api\/support\/tickets\/[^/]+\/attachments$/;

const cookie = (req: IncomingMessage, name: string) =>
  String(req.headers.cookie ?? "").split(/;\s*/).find((c) => c.startsWith(name + "="))?.slice(name.length + 1);

export async function handle(req: IncomingMessage & { body?: unknown }, res: ServerResponse) {
  const url = new URL(req.url ?? "/", "http://local");
  const path = url.pathname.replace(/\/+$/, "") || "/";
  const method = (req.method ?? "GET").toUpperCase();
  let reqUser: { id: number; email: string; role: string } | null = null;
  try {
    let match: { route: Route; params: string[] } | null = null;
    let pathKnown = false;
    for (const route of ROUTES) {
      const m = route.path.exec(path);
      if (!m) continue;
      pathKnown = true;
      if (route.method === method) { match = { route, params: m.slice(1) }; break; }
    }
    if (!match) throw new HttpError(pathKnown ? 405 : 404, pathKnown ? "Method not allowed." : "Not found.");
    // Writes must come from this site (cookie auth + same-origin check instead of CSRF tokens).
    if (method !== "GET" && match.route.access !== "cron") {
      const origin = req.headers.origin;
      const hosts = [req.headers.host, req.headers["x-forwarded-host"]].flatMap((h) => String(h ?? "").split(",")).map((h) => h.trim()).filter(Boolean);
      if (origin && !hosts.includes(new URL(origin).host)) throw new HttpError(403, "Requests from other sites are not allowed.");
    }
    const user = await read(cookie(req, cookieName));
    reqUser = user ? { id: user.id, email: user.email, role: user.role } : null;
    const access = match.route.access;
    if (access === "cron") {
      const secret = process.env.CRON_SECRET;
      const ok = secret ? req.headers.authorization === `Bearer ${secret}` : !process.env.VERCEL;
      if (!ok && !user) throw new HttpError(401, "Not authorised.");
    } else if (access !== "public") {
      if (!user) throw new HttpError(401, "Your session has ended. Sign in again.");
      if (access === "admin" && user.role !== "admin") throw new HttpError(403, "Only admins can do this.");
      // Someone signed in with a temporary password can only set their own password until they do.
      if (user.mustChangePassword && !path.startsWith("/api/auth/")) throw new HttpError(403, "Set your own password first.");
    }
    const ip = clientIp(req);
    const ua = String(req.headers["user-agent"] ?? "");
    const r: Req = {
      method, path, params: match.params, query: url.searchParams, headers: req.headers, ip, user,
      body: await readBody(req, BIG_BODY.test(path) ? 5_000_000 : undefined),
      actor: { actor: user?.email ?? (access === "cron" ? "system:scheduler" : "anonymous"), ip, ua },
    };
    const out = await match.route.handler(r);
    const isRes = out && typeof out === "object" && ("body" in (out as object) || "raw" in (out as object) || "status" in (out as object));
    send(req, res, isRes ? (out as Res) : { body: out });
  } catch (e) {
    if (e instanceof HttpError) return send(req, res, { status: e.status, body: { error: e.message } });
    const err = e as { message?: string; code?: string };
    // Postgres constraint errors become plain sentences; everything else is logged, not shown.
    if (err.code === "23505") return send(req, res, { status: 409, body: { error: "A record with these details already exists." } });
    if (err.code === "23503") return send(req, res, { status: 409, body: { error: "This record is still used elsewhere, so it cannot be changed this way." } });
    if (err.code === "55P03" || err.code === "57014") return send(req, res, { status: 503, body: { error: "The database is busy. Try again in a moment." } });
    console.error(`[api] ${method} ${path}`, e);
    const host = String(req.headers["x-forwarded-host"] ?? req.headers.host ?? "").split(",")[0].trim() || undefined;
    report(e, { tags: { route: routeTag(method, path), pg_code: err.code }, user: reqUser, host });
    send(req, res, { status: 500, body: { error: "Something went wrong on our side. Try again; if it keeps happening, tell the admin." } });
  }
}
