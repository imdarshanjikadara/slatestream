// One database interface for both modes:
// * DATABASE_URL set: Postgres through `pg` (Supabase transaction pooler, port 6543).
// * no DATABASE_URL: PGlite in-process with demo data (local development and previews).
import type { Pool, PoolClient } from "pg";
import { ensureSchema } from "./schema.js";

export type Row = Record<string, any>;
export type Q = <T extends Row = Row>(text: string, params?: unknown[]) => Promise<T[]>;
/** Who is making the change; written into the transaction so the audit trigger can record it. */
export type Actor = { actor: string; ip?: string | null; ua?: string | null };

type Driver = {
  query: Q;
  tx: <T>(fn: (q: Q) => Promise<T>) => Promise<T>;
  kind: "postgres" | "pglite";
};

let driver: Promise<Driver> | null = null;
export const isDemo = () => !process.env.DATABASE_URL;

async function makePg(): Promise<Driver> {
  const pg = (await import("pg")).default;
  // Numbers as numbers; plain dates stay 'YYYY-MM-DD' (no time-zone shift).
  pg.types.setTypeParser(1700, (v) => (v === null ? null : parseFloat(v)));
  pg.types.setTypeParser(20, (v) => (v === null ? null : Number(v)));
  pg.types.setTypeParser(1082, (v) => v);
  const pool: Pool = new pg.Pool({
    connectionString: process.env.DATABASE_URL,
    // Pages send up to 8 queries at once (the dashboard 7): with fewer connections they queue and each wave costs another
    // round trip to the database. The Supabase pooler (port 6543) is built for many short client connections.
    max: Number(process.env.PG_POOL_MAX ?? 8),
    // Keep connections open between clicks: a new one costs a TLS handshake and a login, several round trips.
    idleTimeoutMillis: 60_000,
    connectionTimeoutMillis: 10_000,
    ssl: /localhost|127\.0\.0\.1/.test(process.env.DATABASE_URL ?? "") ? undefined : { rejectUnauthorized: false },
  });
  const run = (c: Pool | PoolClient): Q => async (text, params) => (await c.query(text, params as unknown[])).rows;
  return {
    kind: "postgres",
    query: run(pool),
    tx: async (fn) => {
      const c = await pool.connect();
      try {
        await c.query("begin");
        const out = await fn(run(c));
        await c.query("commit");
        return out;
      } catch (e) {
        await c.query("rollback").catch(() => {});
        throw e;
      } finally {
        c.release();
      }
    },
  };
}

async function makePglite(): Promise<Driver> {
  const { PGlite } = await import("@electric-sql/pglite");
  // Persist between dev restarts; serverless previews use memory.
  const dir = process.env.VERCEL ? undefined : process.env.PGLITE_DIR ?? ".pglite";
  const db = await PGlite.create(dir, { parsers: { 1700: (v: string) => parseFloat(v), 20: (v: string) => Number(v), 1082: (v: string) => v } });
  // PGlite is single-connection: serialise transactions so two requests never interleave.
  let chain: Promise<unknown> = Promise.resolve();
  const lock = <T>(fn: () => Promise<T>): Promise<T> => { const p = chain.then(fn, fn); chain = p.catch(() => {}); return p; };
  const direct: Q = async (text, params) => (await db.query(text, params as unknown[])).rows as any[];
  return {
    kind: "pglite",
    query: (text, params) => lock(() => direct(text, params)) as any,
    tx: (fn) => lock(() => db.transaction(async (t) => fn(async (text, params) => (await t.query(text, params as unknown[])).rows as any[]))),
  };
}

export function getDb(): Promise<Driver> {
  if (!driver) {
    driver = (async () => {
      const d = isDemo() ? await makePglite() : await makePg();
      await ensureSchema(d);
      return d;
    })();
    driver.catch(() => { driver = null; });
  }
  return driver;
}

export const query: Q = async (text, params) => (await getDb()).query(text, params);

/** A transaction tagged with the signed-in user, device and IP (read by the audit trigger). */
export async function tx<T>(who: Actor, fn: (q: Q) => Promise<T>): Promise<T> {
  const d = await getDb();
  return d.tx(async (q) => {
    await q("select set_config('app.actor', $1, true), set_config('app.ip', $2, true), set_config('app.ua', $3, true)", [who.actor, who.ip ?? "", (who.ua ?? "").slice(0, 400)]);
    return fn(q);
  });
}

/** Columns Postgres computes itself (generated columns are never written). Cached per table. */
const generated = new Map<string, Set<string>>();
/** Pass the transaction client when inside tx(): in demo mode the shared client waits for the transaction to finish. */
export async function generatedColumns(table: string, q: Q = query): Promise<Set<string>> {
  if (!generated.has(table)) {
    const rows = await q<{ column_name: string }>(
      "select column_name from information_schema.columns where table_schema = 'public' and table_name = $1 and (is_generated = 'ALWAYS' or column_default like 'generated%')", [table]);
    generated.set(table, new Set(rows.map((r) => r.column_name)));
  }
  return generated.get(table)!;
}
