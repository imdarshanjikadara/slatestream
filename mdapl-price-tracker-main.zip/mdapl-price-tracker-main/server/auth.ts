// Accounts live in app_users (Team & access). APP_USERS (env, scrypt hashes from `npm run hash-password`) only creates
// the first accounts and never overwrites one that exists. AUTH_SECRET signs the session cookie. Demo mode has one demo account.
import { createHash, createHmac, randomBytes, randomInt, scryptSync, timingSafeEqual } from "node:crypto";
import { isDemo, query, tx } from "./db.js";

export type Role = "admin" | "staff";
export type User = { id: number; email: string; name: string; role: Role; mustChangePassword: boolean };
type Row = { user_id: number; email: string; name: string; role: Role; password_hash: string; must_change_password: boolean; is_active: boolean; session_version: number; session_grace_until: string | Date | null };
const ROW = "user_id, email, name, role, password_hash, must_change_password, is_active, session_version, session_grace_until";

const COOKIE = "mdapl_session";
const TTL_S = 7 * 24 * 3600;
const DEMO_HASH = hashPassword("demo1234", Buffer.from("mdapl-demo-salt!"));

export function hashPassword(password: string, salt = randomBytes(16)): string {
  const N = 16384, r = 8, p = 1;
  const key = scryptSync(password.normalize("NFKC"), salt, 32, { N, r, p });
  return `scrypt$${N}$${r}$${p}$${salt.toString("base64url")}$${key.toString("base64url")}`;
}

function verify(password: string, stored: string): boolean {
  const [alg, N, r, p, salt, hash] = stored.split("$");
  if (alg !== "scrypt" || !salt || !hash) return false;
  const want = Buffer.from(hash, "base64url");
  const got = scryptSync(password.normalize("NFKC"), Buffer.from(salt, "base64url"), want.length, { N: Number(N), r: Number(r), p: Number(p) });
  return got.length === want.length && timingSafeEqual(got, want);
}

/** A sentence when the password is not acceptable, else null. */
export function passwordProblem(password: string, email: string): string | null {
  if (password.length < 10) return "Use at least 10 characters.";
  if (password.length > 200) return "Use at most 200 characters.";
  if (password.trim().toLowerCase() === email.toLowerCase()) return "Do not use your email as the password.";
  return null;
}

/** A temporary password to read out or paste: 14 characters, no look-alikes (0/O, 1/l/I). */
export function temporaryPassword() {
  const A = "ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789";
  return Array.from({ length: 14 }, () => A[randomInt(A.length)]).join("");
}

/** Accounts from APP_USERS (or the demo account), to create in app_users when missing. */
function envAccounts(): { email: string; name: string; role: Role; hash: string }[] {
  const raw = process.env.APP_USERS;
  if (!raw) return isDemo() ? [{ email: "demo@mdapl.local", name: "Demo User", role: "admin", hash: DEMO_HASH }] : [];
  try {
    // An array of accounts; a single account object without the [ ] is accepted too.
    const parsed = JSON.parse(raw) as Partial<{ email: string; name: string; role: string; hash: string }> | Partial<{ email: string; name: string; role: string; hash: string }>[];
    const list = Array.isArray(parsed) ? parsed : [parsed];
    return list.filter((a) => a.email && a.hash).map((a) => ({ email: a.email!.trim().toLowerCase(), name: a.name || a.email!, role: a.role === "staff" ? "staff" : "admin", hash: a.hash! }));
  } catch {
    console.error("[auth] APP_USERS is not valid JSON");
    return [];
  }
}

let seeded: Promise<void> | null = null;
/** Once per server: create the APP_USERS accounts that do not exist yet (existing ones, and anyone switched off, stay as they are). */
function ensureAccounts() {
  seeded ??= (async () => {
    const list = envAccounts();
    if (!list.length) return;
    await tx({ actor: "system:setup" }, async (t) => {
      for (const a of list)
        await t("insert into app_users (email, name, role, password_hash) values ($1, $2, $3, $4) on conflict (email) do nothing", [a.email, a.name, a.role, a.hash]);
    });
  })().catch((e) => { seeded = null; throw e; });
  return seeded;
}

// Accounts are read on every request; a 30-second copy per server keeps that off the database. Changes made here clear it,
// so a switched-off account or a reset password ends other sessions within 30 seconds on other servers, at once on this one.
const cache = new Map<string, { row: Row | null; at: number }>();
/** After an admin changes someone: load the account fresh, so this server applies the change at once. */
export const refreshAccount = (email: string) => account(email, true).then(() => undefined);
async function account(email: string, fresh = false): Promise<Row | null> {
  const e = email.toLowerCase();
  const hit = cache.get(e);
  if (!fresh && hit && Date.now() - hit.at < 30_000) return hit.row;
  await ensureAccounts();
  const [row] = await query<Row>(`select ${ROW} from app_users where email = $1`, [e]);
  remember(e, row ?? null);
  return row ?? null;
}
/** Never let a read that started before a password change put the older session version back into the cache. */
function remember(e: string, row: Row | null) {
  const prev = cache.get(e)?.row;
  if (prev && row && row.user_id === prev.user_id && row.session_version < prev.session_version) return;
  cache.set(e, { row, at: Date.now() });
}
const toUser = (a: Row): User => ({ id: a.user_id, email: a.email, name: a.name, role: a.role, mustChangePassword: a.must_change_password });

function secret(): string {
  if (process.env.AUTH_SECRET) return process.env.AUTH_SECRET;
  if (!isDemo()) throw new Error("AUTH_SECRET is not set");
  // Demo mode only: stable across dev restarts so sessions survive a reload of the API.
  return createHash("sha256").update(`mdapl-demo:${process.cwd()}`).digest("hex");
}

const sign = (body: string) => createHmac("sha256", secret()).update(body).digest("base64url");

export async function issue(u: User, version?: number): Promise<string> {
  const v = version ?? (await account(u.email))?.session_version ?? 1;
  const body = Buffer.from(JSON.stringify({ e: u.email, v, x: Math.floor(Date.now() / 1000) + TTL_S })).toString("base64url");
  return `${body}.${sign(body)}`;
}

/** The signed-in person, or null when the cookie is missing, forged, expired, switched off or from before a password change. */
export async function read(token: string | undefined): Promise<User | null> {
  if (!token) return null;
  const [body, mac] = token.split(".");
  if (!body || !mac) return null;
  const want = Buffer.from(sign(body)), got = Buffer.from(mac);
  if (want.length !== got.length || !timingSafeEqual(want, got)) return null;
  let s: { e: string; v?: number; x: number };
  try { s = JSON.parse(Buffer.from(body, "base64url").toString()); } catch { return null; }
  if (!s.e || s.x < Date.now() / 1000) return null;
  let a = await account(s.e);
  // A cookie newer than this server's copy (a password just changed on another server): read the account again.
  if (a && a.session_version < (s.v ?? 1)) a = await account(s.e, true);
  const v = s.v ?? 1;
  // Right after someone changes their own password, requests their browser sent just before still carry the previous cookie:
  // it is accepted for 10 seconds so the page does not bounce to sign-in. Resets and switch-offs get no such grace.
  const grace = !!a?.session_grace_until && new Date(a.session_grace_until).getTime() > Date.now();
  const current = a?.session_version === v || (a?.session_version === v + 1 && grace);
  if (!a || !a.is_active || !current) return null;
  return toUser(a);
}

// Best-effort brute-force brake per IP and per email (per function instance).
const fails = new Map<string, { n: number; until: number }>();
export function loginBlocked(key: string): number {
  const f = fails.get(key);
  return f && f.until > Date.now() ? Math.ceil((f.until - Date.now()) / 1000) : 0;
}
function noteFail(key: string) {
  const f = fails.get(key) ?? { n: 0, until: 0 };
  f.n++;
  if (f.n >= 5) { f.until = Date.now() + Math.min(15 * 60_000, 30_000 * 2 ** (f.n - 5)); }
  fails.set(key, f);
}

export async function login(email: string, password: string, ip: string): Promise<{ user?: User; error?: string }> {
  const e = email.trim().toLowerCase();
  for (const k of [`ip:${ip}`, `e:${e}`]) {
    const wait = loginBlocked(k);
    if (wait) return { error: `Too many attempts. Try again in ${wait > 60 ? `${Math.ceil(wait / 60)} minutes` : `${wait} seconds`}.` };
  }
  const a = await account(e);
  const usable = !!a && a.is_active;
  const ok = usable ? verify(password, a!.password_hash) : (verify(password, DEMO_HASH), false);
  if (!ok || !a) {
    noteFail(`ip:${ip}`); noteFail(`e:${e}`);
    return { error: "That email and password do not match. Check both and try again." };
  }
  fails.delete(`ip:${ip}`); fails.delete(`e:${e}`);
  await query("update app_users set last_sign_in_at = now() where user_id = $1", [a.user_id]);
  return { user: toUser(a) };
}

/** Changes the signed-in person's own password; their other sessions end, this one gets a new cookie. */
export async function changeOwnPassword(u: User, current: string, next: string, ip: string): Promise<{ error?: string; token?: string }> {
  const wait = loginBlocked(`pw:${u.email}`);
  if (wait) return { error: `Too many attempts. Try again in ${Math.ceil(wait / 60)} minutes.` };
  const a = await account(u.email);
  if (!a || !verify(current, a.password_hash)) { noteFail(`pw:${u.email}`); return { error: "Your current password is not right." }; }
  const problem = passwordProblem(next, u.email);
  if (problem) return { error: problem };
  if (verify(next, a.password_hash)) return { error: "Choose a password different from the current one." };
  const [row] = await tx({ actor: u.email, ip }, (t) => t<Row>(`update app_users set password_hash = $2, must_change_password = false, session_version = session_version + 1,
      session_grace_until = now() + interval '10 seconds', updated_at = now()
    where user_id = $1 returning ${ROW}`, [a.user_id, hashPassword(next)]));
  remember(u.email.toLowerCase(), row);
  return { token: await issue(u, row.session_version) };
}

export const cookieName = COOKIE;
export const sessionCookie = (token: string, secure: boolean) =>
  `${COOKIE}=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${TTL_S}${secure ? "; Secure" : ""}`;
export const clearCookie = (secure: boolean) => `${COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${secure ? "; Secure" : ""}`;
