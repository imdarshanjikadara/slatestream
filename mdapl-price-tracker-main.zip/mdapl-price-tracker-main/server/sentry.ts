// Error reporting to Sentry, project smallbay-digital/mdapl-web: the browser and the server report to the same project,
// told apart by the tag side=browser / side=server. Only unexpected failures are sent from here: 500s from the API, scraper
// batches with failing links and background queue failures; validation errors and other 4xx answers are not.
// Started when this module loads (the Vercel function imports it first), when SENTRY_DSN is set or on Vercel.
// The DSN only lets events be sent, it is not a secret; SENTRY_DSN overrides it and an empty SENTRY_DSN switches reporting off.
import * as Sentry from "@sentry/node";

const DEFAULT_DSN = "https://f82bdbac15c66932d6a5425a982f3856@o4512328579874816.ingest.us.sentry.io/4512328698101760";
const dsn = process.env.SENTRY_DSN ?? (process.env.VERCEL ? DEFAULT_DSN : "");
export const sentryOn = !!dsn;
// The browser uses its hostname as the environment; the server uses the host of the request, else the production domain.
const defaultHost = process.env.VERCEL_PROJECT_PRODUCTION_URL || process.env.VERCEL_URL || process.env.VERCEL_ENV || "development";
let pending = false;

if (sentryOn) {
  Sentry.init({
    dsn,
    environment: defaultHost,
    release: process.env.VERCEL_GIT_COMMIT_SHA,
    // sendDefaultPii is gone in SDK 11; this is its equivalent: no automatic user info, cookies, headers, bodies, query
    // strings, SQL parameters (they include password hashes) or local variables. The user's email is added explicitly.
    dataCollection: { userInfo: false, cookies: false, httpHeaders: false, httpBodies: [], urlQueryParams: false, databaseQueryData: false, queues: false, stackFrameVariables: false },
    tracesSampleRate: 0,
    initialScope: { tags: { side: "server" } },
    beforeSend(event) {
      if (event.request) { delete event.request.cookies; delete event.request.data; delete event.request.headers; }
      return event;
    },
  });
}

type Ctx = { tags?: Record<string, string | number | undefined>; extra?: Record<string, unknown>; user?: { id: number; email: string; role: string } | null;
  host?: string; level?: Sentry.SeverityLevel; fingerprint?: string[] };

/** "GET /api/products/12" -> "GET /api/products/:id". */
export const routeTag = (method: string, path: string) => `${method} ${path.replace(/\/\d+(?=\/|$)/g, "/:id")}`;

export function report(err: unknown, ctx: Ctx = {}) {
  if (!sentryOn) return;
  Sentry.withScope((scope) => {
    for (const [k, v] of Object.entries(ctx.tags ?? {})) if (v !== undefined) scope.setTag(k, String(v));
    if (ctx.extra) scope.setExtras(ctx.extra);
    if (ctx.user) { scope.setUser({ id: String(ctx.user.id), email: ctx.user.email }); scope.setTag("role", ctx.user.role); }
    if (ctx.host) scope.setTag("host", ctx.host);
    if (ctx.level) scope.setLevel(ctx.level);
    if (ctx.fingerprint) scope.setFingerprint(ctx.fingerprint);
    scope.addEventProcessor((event) => ({ ...event, environment: ctx.host || defaultHost }));
    if (typeof err === "string") Sentry.captureMessage(err); else Sentry.captureException(err);
  });
  pending = true;
}

/** Serverless: called at the end of every invocation. Waits (up to 2 s) only when something was reported. */
export async function flushSentry() {
  if (!pending) return;
  pending = false;
  await Sentry.flush(2000).catch(() => false);
}
