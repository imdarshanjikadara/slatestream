import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { api } from "./api";
import { istDay } from "./format";

/** Filters live in the URL (shareable, survive reload). Setting a value replaces history, so Back leaves the page. */
export function useUrlState<K extends string>(defaults: Record<K, string>) {
  const [sp, setSp] = useSearchParams();
  const values = useMemo(() => {
    const out = {} as Record<K, string>;
    for (const k of Object.keys(defaults) as K[]) out[k] = sp.get(k) ?? defaults[k];
    return out;
  }, [sp]); // eslint-disable-line react-hooks/exhaustive-deps
  const set = useCallback((patch: Partial<Record<K, string | null>>) => {
    setSp((prev) => {
      const next = new URLSearchParams(prev);
      next.delete("page");   // new filters: back to the first page of the list
      for (const [k, v] of Object.entries(patch) as [K, string | null][]) {
        if (v === null || v === undefined || v === "" || v === defaults[k]) next.delete(k);
        else next.set(k, v);
      }
      return next;
    }, { replace: true });
  }, [setSp]); // eslint-disable-line react-hooks/exhaustive-deps
  const active = (Object.keys(defaults) as K[]).filter((k) => sp.has(k));
  return [values, set, active] as const;
}

/** The query string with `patch` applied: for a tab that both changes a filter and closes the open record, so the
 *  change and the navigation happen in one go (two of them would fight, and the navigation would win with stale values). */
export function urlWith(search: string, patch: Record<string, string | null>, defaults: Record<string, string> = {}) {
  const next = new URLSearchParams(search);
  next.delete("page");
  for (const [k, v] of Object.entries(patch)) {
    if (v === null || v === undefined || v === "" || v === defaults[k]) next.delete(k); else next.set(k, v);
  }
  const out = next.toString();
  return out ? `?${out}` : "";
}

/** A search box that writes to the URL 300 ms after typing stops. */
export function useDebouncedUrlValue(value: string, write: (v: string) => void, ms = 300) {
  const [text, setText] = useState(value);
  const last = useRef(value);
  useEffect(() => { if (value !== last.current) { setText(value); last.current = value; } }, [value]);
  useEffect(() => {
    if (text === last.current) return;
    const t = setTimeout(() => { last.current = text; write(text); }, ms);
    return () => clearTimeout(t);
  }, [text]); // eslint-disable-line react-hooks/exhaustive-deps
  return [text, setText] as const;
}

/** Fixed browser tab title on every page. */
export const APP_TITLE = "MDAPL Price Tracker";
export function useFixedTitle() { useEffect(() => { document.title = APP_TITLE; }); }

export function useMediaQuery(q: string) {
  const [m, setM] = useState(() => typeof window !== "undefined" && window.matchMedia(q).matches);
  useEffect(() => { const mq = window.matchMedia(q); const h = () => setM(mq.matches); mq.addEventListener("change", h); return () => mq.removeEventListener("change", h); }, [q]);
  return m;
}

/** The default date range of the price pages: the 7 days up to today, or up to the last day anything was scraped when
 *  scraping has stopped (so the pages never open empty). `stale` is that last day when it is before yesterday. */
export const LATEST_SCRAPE = { queryKey: ["latest-scrape"], queryFn: () => api<{ day: string | null }>("meta/latest-scrape"), staleTime: 300_000 };
export function scrapeWindow(latest: string | null) {
  const today = istDay(0);
  const to = latest && latest < today ? latest : today;
  const from = new Date(new Date(`${to}T00:00:00Z`).getTime() - 7 * 86400000).toISOString().slice(0, 10);
  return { from, to, latest, stale: latest && latest < istDay(1) ? latest : null };
}
export function useScrapeWindow() {
  const q = useQuery(LATEST_SCRAPE);
  return { ...scrapeWindow(q.data?.day ?? null), ready: !q.isLoading };
}
