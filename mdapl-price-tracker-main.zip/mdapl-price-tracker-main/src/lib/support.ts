// Help and support: what the SBD support hub's keys mean on screen, and file handling for attachments.
// The same wording is used in every SmallBay Digital client app.
import { useQuery } from "@tanstack/react-query";
import { api } from "./api";
import type { Tone } from "@/components/Pill";

export const STATUS: Record<string, { label: string; tone: Tone; dot: boolean; hint: string }> = {
  open: { label: "Received", tone: "neutral", dot: true, hint: "Submitted, nobody has replied yet" },
  in_progress: { label: "In progress", tone: "info", dot: true, hint: "The team is working on it" },
  waiting_client: { label: "Waiting on you", tone: "warning", dot: true, hint: "The team needs something from you" },
  resolved: { label: "Resolved", tone: "success", dot: true, hint: "The team believes it's fixed" },
  closed: { label: "Closed", tone: "neutral", dot: false, hint: "Finished and read-only" },
};
export const OPEN_STATUSES = ["open", "in_progress", "waiting_client"];

export const CATEGORIES = [
  { value: "problem", label: "Something isn't working", short: "Problem" },
  { value: "question", label: "A question", short: "Question" },
  { value: "change", label: "Change how something works", short: "Change" },
  { value: "feature", label: "Something new", short: "New feature" },
  { value: "data", label: "Fix wrong data", short: "Data fix" },
];
export const categoryLabel = (v: string) => CATEGORIES.find((c) => c.value === v)?.short ?? v;

export const PRIORITIES = [
  { value: "critical", label: "Critical", when: "Nothing works, or data is at risk", reply: "1 hour" },
  { value: "high", label: "Urgent", when: "Work is blocked until it's fixed", reply: "3 hours" },
  { value: "medium", label: "Normal", when: "It can wait a few hours", reply: "12 hours" },
  { value: "low", label: "Low", when: "A question or a small annoyance", reply: "24 hours" },
];
/** The two a user picks from: Normal (preselected) and Urgent. */
export const USER_PRIORITIES = [PRIORITIES[2], PRIORITIES[1]];
export const priorityOf = (v: string) => PRIORITIES.find((p) => p.value === v) ?? PRIORITIES[2];

/** The parts of this app a request can be about (its main pages), plus sign-in and anything else. */
export const AREAS = ["Dashboard", "Product Categories", "Products", "Import products", "Scraping", "Scrape Product Results", "MOP Breach Reports",
  "Scrape Run Results", "Team & access", "Audit log", "Sign-in", "Something else"];

export const ref = (id: number) => `#SUP-${String(id).padStart(4, "0")}`;
export const newKey = () => (crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`);

const TZ = "Asia/Kolkata";
/** "Just now", "5 min ago", "3 h ago", "Yesterday", then "12 Oct". */
export function ago(v: string) {
  const s = (Date.now() - new Date(v).getTime()) / 1000;
  if (s < 60) return "Just now";
  if (s < 3600) return `${Math.floor(s / 60)} min ago`;
  if (s < 86400) return `${Math.floor(s / 3600)} h ago`;
  if (s < 172800) return "Yesterday";
  return new Date(v).toLocaleDateString("en-GB", { day: "2-digit", month: "short", timeZone: TZ });
}
/** "02 Nov, 1:44 PM" in India time. */
export function when(v: string | null | undefined) {
  if (!v) return "";
  const d = new Date(v);
  const day = d.toLocaleDateString("en-GB", { day: "2-digit", month: "short", timeZone: TZ });
  const time = d.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit", hour12: true, timeZone: TZ });
  return `${day}, ${time}`;
}
export const fileSize = (n: number) => (n < 1024 ? `${n} B` : n < 1048576 ? `${Math.round(n / 1024)} KB` : `${(n / 1048576).toFixed(1)} MB`);
export const fileUrl = (id: number) => `/api/support/attachments/${id}`;

// Files go up one by one as base64, under the hub's 3 MB limit; big photos are shrunk in the browser first.
export const MAX_FILE = 3 * 1024 * 1024;
export const MAX_FILES = 5;
export const ACCEPT = "image/*,application/pdf,video/mp4,video/quicktime,text/*,.csv,.xlsx,.xls,.docx,.doc";
async function shrink(file: File): Promise<Blob> {
  if (!file.type.startsWith("image/") || file.type === "image/gif" || file.size <= MAX_FILE) return file;
  const img = await createImageBitmap(file);
  for (const [side, quality] of [[2400, 0.85], [1800, 0.8], [1400, 0.75]] as const) {
    const k = Math.min(1, side / Math.max(img.width, img.height));
    const c = document.createElement("canvas");
    c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
    c.getContext("2d")!.drawImage(img, 0, 0, c.width, c.height);
    const out = await new Promise<Blob | null>((r) => c.toBlob(r, "image/jpeg", quality));
    if (out && out.size <= MAX_FILE) return out;
  }
  return file;
}
export async function filePayload(file: File) {
  const blob = await shrink(file);
  if (blob.size > MAX_FILE) throw new Error(`${file.name} is over 3 MB`);
  const buf = new Uint8Array(await blob.arrayBuffer());
  let bin = "";
  for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode(...buf.subarray(i, i + 0x8000));
  const name = blob !== file && !/\.jpe?g$/i.test(file.name) ? file.name.replace(/\.\w+$/, "") + ".jpg" : file.name;
  return { name, type: blob.type || file.type || "application/octet-stream", data: btoa(bin) };
}

export type Summary = { team: boolean; unread: number; me: string };
/** The menu badge: unread replies, checked every minute. */
export const useSupportSummary = (refetchInterval = 60_000) =>
  useQuery({ queryKey: ["support", "summary"], queryFn: () => api<Summary>("support/summary"), refetchInterval, retry: false, staleTime: 20_000 });

/** The page the user was on before Help and support, sent with a new request. */
export const LAST_PAGE = "last-page";
