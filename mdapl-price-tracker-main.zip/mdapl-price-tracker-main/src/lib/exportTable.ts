// Excel (.xlsx, formatted, with totals), CSV and Print of a list, exactly as filtered. ExcelJS loads on first use.
// PDF is in exportPdf.ts (loaded on first use too).
import { dateLong, dateTime, inr } from "./format";

export type Kind = "text" | "int" | "num" | "money" | "pct" | "date" | "datetime" | "bool" | "status" | "link" | "mono";
export type ExportCol = { key: string; label: string; kind?: Kind; total?: boolean; value?: (r: any) => unknown;
  /** PDF only: false leaves the column out (a PDF page is one A4 landscape wide); pdfValue / pdfLabel replace the value / heading. */
  pdf?: boolean; pdfValue?: (r: any) => unknown; pdfLabel?: string };
type Row = Record<string, any>;

export const NUMERIC = new Set<Kind | undefined>(["int", "num", "money", "pct"]);
const IST = 5.5 * 3600 * 1000;
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

export const get = (c: ExportCol, r: Row) => (c.value ? c.value(r) : r[c.key]);
export const toNumber = (v: unknown) => { if (v === null || v === undefined || v === "") return null; const n = Number(String(v).replace(/,/g, "")); return Number.isFinite(n) ? n : null; };
function toDate(v: unknown, withTime: boolean): Date | null {
  const s = String(v);
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s);
  if (m) return new Date(Date.UTC(+m[1], +m[2] - 1, +m[3]));
  const t = new Date(s).getTime();
  if (Number.isNaN(t)) return null;
  const d = new Date(t + IST);
  return withTime ? d : new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));
}
function cell(c: ExportCol, r: Row): string | number | Date | null {
  const v = get(c, r);
  if (v === null || v === undefined || v === "") return null;
  if (NUMERIC.has(c.kind)) return toNumber(v);
  if (c.kind === "date" || c.kind === "datetime") return toDate(v, c.kind === "datetime") ?? String(v);
  if (c.kind === "bool") return v ? "Yes" : "No";
  return String(v);
}
export const totalsOf = (cols: ExportCol[], rows: Row[]) =>
  new Map(cols.filter((c) => c.total && NUMERIC.has(c.kind)).map((c) => [c.key, Math.round(rows.reduce((s, r) => s + (toNumber(get(c, r)) ?? 0), 0) * 100) / 100]));

export const stampNow = () => { const d = new Date(Date.now() + IST); const p = (n: number) => String(n).padStart(2, "0"); return `${p(d.getUTCDate())} ${MONTHS[d.getUTCMonth()]} ${d.getUTCFullYear()}, ${d.getUTCHours() % 12 || 12}:${p(d.getUTCMinutes())} ${d.getUTCHours() < 12 ? "AM" : "PM"}`; };
export const fileName = (title: string, ext: string) => `${title.replace(/[^\w\s-]+/g, "").trim().replace(/\s+/g, "_").toLowerCase() || "export"}_${new Date(Date.now() + IST).toISOString().slice(0, 10)}.${ext}`;

export function save(blob: Blob, name: string) {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
}

export type ExportInput = { title: string; cols: ExportCol[]; rows: Row[]; note?: string; sheet?: string; file?: string };

export function downloadCsv({ title, cols, rows, file }: ExportInput) {
  const totals = totalsOf(cols, rows);
  const esc = (v: unknown) => `"${String(v ?? "").replace(/"/g, '""')}"`;
  const fmt = (c: ExportCol, r: Row) => {
    const x = cell(c, r);
    if (x === null) return "";
    if (x instanceof Date) return c.kind === "datetime" ? dateTime(get(c, r)) : dateLong(get(c, r));
    return String(x);
  };
  const lines = [cols.map((c) => esc(c.label)).join(",")].concat(rows.map((r) => cols.map((c) => esc(fmt(c, r))).join(",")));
  if (totals.size) lines.push(cols.map((c, i) => esc(totals.has(c.key) ? totals.get(c.key) : i === 0 ? "TOTAL" : "")).join(","));
  save(new Blob(["﻿" + lines.join("\r\n")], { type: "text/csv;charset=utf-8" }), fileName(file ?? title, "csv"));
}

/** Title and generated line, bold dark header with filters and a frozen top, light borders and banding, number
 *  formats per column, and a bold Total row. */
export async function downloadXlsx({ title, cols, rows, note, sheet, file }: ExportInput) {
  const totals = totalsOf(cols, rows);
  const ExcelJS = (await import("exceljs")).default;
  const wb = new ExcelJS.Workbook();
  wb.creator = "MDAPL Price Tracker"; wb.created = new Date();
  const ws = wb.addWorksheet((sheet ?? title).replace(/[\\/?*[\]:]/g, " ").slice(0, 31) || "Sheet1", { views: [{ state: "frozen", ySplit: 4 }] });
  const n = Math.max(1, cols.length);
  const grey = { argb: "FFBFBFBF" }, dark = { argb: "FF1F2937" };
  const thin = { style: "thin" as const, color: grey };
  const border = { top: thin, left: thin, bottom: thin, right: thin };
  ws.mergeCells(1, 1, 1, n);
  Object.assign(ws.getCell(1, 1), { value: title, font: { size: 14, bold: true, color: dark } });
  ws.mergeCells(2, 1, 2, n);
  Object.assign(ws.getCell(2, 1), { value: `MDAPL · Generated ${stampNow()} IST · ${rows.length} ${rows.length === 1 ? "row" : "rows"}${note ? ` · ${note}` : ""}`, font: { size: 9, color: { argb: "FF595959" } } });
  const head = ws.getRow(4);
  cols.forEach((c, i) => {
    const h = head.getCell(i + 1);
    h.value = c.label;
    h.font = { bold: true, color: { argb: "FF1E1A14" } };
    h.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FFF9CF1F" } };
    h.alignment = { vertical: "middle", horizontal: NUMERIC.has(c.kind) ? "right" : "left", wrapText: true };
    h.border = border;
  });
  head.height = 22;
  const numFmt = (c: ExportCol) => c.kind === "money" ? '"₹ "#,##0.00' : c.kind === "int" ? "#,##0" : c.kind === "num" ? "#,##0.##" : c.kind === "pct" ? '0.0"%"' : c.kind === "date" ? "dd mmm yyyy" : c.kind === "datetime" ? "dd mmm yyyy h:mm AM/PM" : undefined;
  rows.forEach((r, ri) => {
    const row = ws.getRow(5 + ri);
    cols.forEach((c, i) => {
      const x = row.getCell(i + 1);
      const v = cell(c, r);
      x.value = (c.kind === "link" && typeof v === "string" ? { text: v, hyperlink: v } : v) as never;
      const f = numFmt(c); if (f) x.numFmt = f;
      x.font = { color: c.kind === "link" ? { argb: "FF1D4ED8" } : dark };
      x.border = border;
      if (ri % 2 === 1) x.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FFF4F5F7" } };
      if (NUMERIC.has(c.kind)) x.alignment = { horizontal: "right" };
    });
  });
  if (totals.size) {
    const row = ws.getRow(5 + rows.length);
    cols.forEach((c, i) => {
      const x = row.getCell(i + 1);
      x.value = totals.has(c.key) ? totals.get(c.key)! : i === 0 ? "TOTAL" : null;
      const f = numFmt(c); if (f && totals.has(c.key)) x.numFmt = f;
      x.font = { bold: true, color: dark };
      x.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FFE5E7EB" } };
      x.border = { ...border, top: { style: "medium", color: dark } };
      if (NUMERIC.has(c.kind)) x.alignment = { horizontal: "right" };
    });
  }
  if (rows.length) ws.autoFilter = { from: { row: 4, column: 1 }, to: { row: 4 + rows.length, column: n } };
  cols.forEach((c, i) => {
    const len = (r: Row) => { const x = cell(c, r); return x === null ? 0 : x instanceof Date ? 14 : typeof x === "number" ? inr(x, 2).length + 2 : String(x).length; };
    const widest = Math.max(c.label.length, ...rows.slice(0, 2000).map(len));
    ws.getColumn(i + 1).width = Math.min(c.kind === "link" ? 60 : 48, Math.max(9, widest + 2));
  });
  ws.pageSetup = { orientation: n > 7 ? "landscape" : "portrait", fitToPage: true, fitToWidth: 1, fitToHeight: 0, printTitlesRow: "4:4" };
  const buf = await wb.xlsx.writeBuffer();
  save(new Blob([buf], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" }), fileName(file ?? title, "xlsx"));
}

/** A clean printable page of the rows (A4, header row repeats), opened in a new window and sent to print. */
export function printRows({ title, cols, rows, note }: ExportInput) {
  const totals = totalsOf(cols, rows);
  const esc = (s: unknown) => String(s ?? "").replace(/[&<>"]/g, (ch) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[ch]!);
  const show = (c: ExportCol, r: Row) => {
    const v = get(c, r);
    if (v === null || v === undefined || v === "") return "";
    if (c.kind === "money") return `₹ ${inr(v, 2)}`;
    if (c.kind === "int") return inr(v);
    if (c.kind === "num") return inr(v, 2);
    if (c.kind === "pct") return `${inr(v, 1)}%`;
    if (c.kind === "date") return dateLong(v);
    if (c.kind === "datetime") return dateTime(v);
    if (c.kind === "bool") return v ? "Yes" : "No";
    return String(v);
  };
  const right = (c: ExportCol) => (NUMERIC.has(c.kind) ? ' class="r"' : "");
  const html = `<!doctype html><html><head><meta charset="utf-8"><title>${esc(title)}</title><style>
    @page { size: A4 ${cols.length > 7 ? "landscape" : "portrait"}; margin: 12mm; }
    body { font: 10.5px/1.4 Inter, system-ui, sans-serif; color: #111827; margin: 0; }
    h1 { font-size: 16px; margin: 0 0 2px; } .meta { color: #6b7280; margin-bottom: 10px; }
    table { width: 100%; border-collapse: collapse; } thead { display: table-header-group; }
    th { background: #f9cf1f; color: #1e1a14; text-align: left; font-weight: 600; padding: 5px 6px; }
    td { border-bottom: 1px solid #e5e7eb; padding: 4px 6px; vertical-align: top; word-break: break-word; }
    tr:nth-child(even) td { background: #f7f8fa; } .r { text-align: right; } tfoot td { font-weight: 700; border-top: 2px solid #111827; background: #eef0f3; }
  </style></head><body><h1>${esc(title)}</h1><div class="meta">MDAPL · ${esc(stampNow())} IST · ${rows.length} rows${note ? ` · ${esc(note)}` : ""}</div>
  <table><thead><tr>${cols.map((c) => `<th${right(c)}>${esc(c.label)}</th>`).join("")}</tr></thead>
  <tbody>${rows.map((r) => `<tr>${cols.map((c) => `<td${right(c)}>${esc(show(c, r))}</td>`).join("")}</tr>`).join("")}</tbody>
  ${totals.size ? `<tfoot><tr>${cols.map((c, i) => `<td${right(c)}>${totals.has(c.key) ? esc(show(c, { [c.key]: totals.get(c.key) })) : i === 0 ? "Total" : ""}</td>`).join("")}</tr></tfoot>` : ""}
  </table><script>window.onload = () => { window.print(); }</script></body></html>`;
  const w = window.open("", "_blank");
  if (!w) { alert("Allow pop-ups for this site to print."); return; }
  w.document.open(); w.document.write(html); w.document.close();
}

/** Excel or PDF of the same list (the PDF module loads only when asked for). */
export async function downloadAs(format: "xlsx" | "pdf", input: ExportInput) {
  if (format === "pdf") return (await import("./exportPdf")).downloadPdf(input);
  return downloadXlsx(input);
}
