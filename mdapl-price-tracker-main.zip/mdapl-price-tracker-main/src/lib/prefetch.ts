// Prefetch a page's first data on sidebar hover. Parameters match what each page sends with an empty URL
// (the price pages' dates come from the latest scrape, see useScrapeWindow).
const win = async () => { const { from, to } = scrapeWindow((await queryClient.fetchQuery(LATEST_SCRAPE)).day); return { from, to }; };
import { api, prefetchList, queryClient, qs } from "./api";
import { LATEST_SCRAPE, scrapeWindow } from "./hooks";

export const PAGE_DEFAULTS = {
  dashboard: async () => ({ ...(await win()), channel: "amazon", category: null }),
  categories: () => ({ status: "active" }),
  products: () => ({ status: "active" }),
  scraping: () => ({ channel: "amazon", status: "active" }),
  results: async () => ({ channel: "amazon", ...(await win()), q: "", brand: "", category: "", product: "", stock: "", mop: "" }),
  schedule: () => ({ mode: "active", q: "", brand: "", category: "" }),
  mop: () => ({}),
  runs: () => ({}),
  audit: () => ({ tab: "all" }),
};

export const PREFETCH: Record<string, () => void> = {
  "/": () => void PAGE_DEFAULTS.dashboard().then((p) => queryClient.prefetchQuery({ queryKey: ["dashboard", qs(p)], queryFn: () => api(`dashboard${qs(p)}`), staleTime: 30_000 })),
  "/categories": () => void prefetchList("categories", PAGE_DEFAULTS.categories()),
  "/products": () => void prefetchList("products", PAGE_DEFAULTS.products()),
  "/scraping": () => void prefetchList("links", PAGE_DEFAULTS.scraping()),
  "/results": () => void PAGE_DEFAULTS.results().then((p) => prefetchList("results", p)),
  "/schedule": () => void prefetchList("schedule", PAGE_DEFAULTS.schedule()),
  "/mop-reports": () => void prefetchList("mop-reports", PAGE_DEFAULTS.mop()),
  "/runs": () => void prefetchList("runs", PAGE_DEFAULTS.runs()),
  "/audit": () => void prefetchList("audit", PAGE_DEFAULTS.audit()),
};
