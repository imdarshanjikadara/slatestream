import { createContext, useContext } from "react";
import { useQuery } from "@tanstack/react-query";
import { api, queryClient } from "./api";

export type User = { id: number; email: string; name: string; role: "admin" | "staff"; mustChangePassword: boolean };
type Ctx = { user: User | null; demo: boolean; loading: boolean; signOut: () => Promise<void>; refresh: () => Promise<unknown> };
const AuthCtx = createContext<Ctx>({ user: null, demo: false, loading: true, signOut: async () => {}, refresh: async () => {} });

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const q = useQuery({ queryKey: ["me"], queryFn: () => api<{ user: User | null; demo: boolean }>("auth/me"), staleTime: 5 * 60_000, retry: 1 });
  const signOut = async () => {
    await api("auth/logout", { method: "POST", body: {} }).catch(() => {});
    // Go to the sign-in page first (the router picks up the hash change asynchronously), then mark the session
    // as ended and drop every cached record of it; the other order would bounce through /login?next=...
    window.location.hash = "#/login?signed_out=1";
    await new Promise<void>((ok) => { window.addEventListener("hashchange", () => ok(), { once: true }); setTimeout(ok, 300); });
    queryClient.setQueryData(["me"], { user: null, demo: !!q.data?.demo });
    queryClient.removeQueries({ predicate: (x) => x.queryKey[0] !== "me" });
  };
  return <AuthCtx.Provider value={{ user: q.data?.user ?? null, demo: !!q.data?.demo, loading: q.isLoading, signOut, refresh: q.refetch }}>{children}</AuthCtx.Provider>;
}
export const useAuth = () => useContext(AuthCtx);
