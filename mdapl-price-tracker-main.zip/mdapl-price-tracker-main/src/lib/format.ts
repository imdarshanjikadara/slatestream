// Deterministic formatting. Dates in India time, shown as "09 Oct 2026". Numbers with Indian digit grouping.
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const IST = 330 * 60000;
const p2 = (n: number) => String(n).padStart(2, "0");

export function inr(v: unknown, digits = 0): string {
  const n = Number(v);
  if (v === null || v === undefined || v === "" || !Number.isFinite(n)) return "-";
  const [int, frac] = Math.abs(n).toFixed(digits).split(".");
  const last3 = int.slice(-3), rest = int.slice(0, -3);
  const grouped = rest ? rest.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + "," + last3 : last3;
  return (n < 0 && Number(int + "." + (frac ?? "0")) !== 0 ? "-" : "") + grouped + (frac ? "." + frac : "");
}
/** ₹ 1,23,456 (no paise unless there are any). */
export const money = (v: unknown) => { const n = Number(v); if (v === null || v === undefined || v === "" || !Number.isFinite(n)) return "-"; return `₹ ${inr(n, Number.isInteger(n) ? 0 : 2)}`; };
export const pct = (v: unknown, digits = 0) => (v === null || v === undefined || v === "" ? "-" : `${inr(v, digits)}%`);

const parts = (v: unknown) => {
  if (v === null || v === undefined || v === "") return null;
  const s = String(v);
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) { const [y, m, d] = s.split("-").map(Number); return { y, m: m - 1, d, h: 0, mi: 0, s: 0 }; }
  const t = new Date(s).getTime();
  if (Number.isNaN(t)) return null;
  const x = new Date(t + IST);
  return { y: x.getUTCFullYear(), m: x.getUTCMonth(), d: x.getUTCDate(), h: x.getUTCHours(), mi: x.getUTCMinutes(), s: x.getUTCSeconds() };
};
/** 09 Oct 2026 */
export const dateLong = (v: unknown) => { const q = parts(v); return q ? `${p2(q.d)} ${MONTHS[q.m]} ${q.y}` : "-"; };
/** 2:05 PM: every time in the app is on the 12-hour clock with AM / PM (India time). */
export const ampm = (h: number, mi: number, s?: number) => `${h % 12 || 12}:${p2(mi)}${s !== undefined ? `:${p2(s)}` : ""} ${h < 12 ? "AM" : "PM"}`;
/** 09 Oct 2026, 2:05 PM */
export const dateTime = (v: unknown) => { const q = parts(v); return q ? `${p2(q.d)} ${MONTHS[q.m]} ${q.y}, ${ampm(q.h, q.mi)}` : "-"; };
/** 09 Oct 2026, 2:05:09 PM IST */
export const dateTimeFull = (v: unknown) => { const q = parts(v); return q ? `${p2(q.d)} ${MONTHS[q.m]} ${q.y}, ${ampm(q.h, q.mi, q.s)} IST` : "-"; };
/** 09 Oct */
export const dayShort = (v: unknown) => { const q = parts(v); return q ? `${p2(q.d)} ${MONTHS[q.m]}` : "-"; };
/** "5 min ago", "3 h ago", else the date. */
export function ago(v: unknown) {
  const t = new Date(String(v)).getTime();
  if (!v || Number.isNaN(t)) return "-";
  const s = (Date.now() - t) / 1000;
  if (s < 60) return "just now";
  if (s < 3600) return `${Math.floor(s / 60)} min ago`;
  if (s < 86400) return `${Math.floor(s / 3600)} h ago`;
  return dateLong(v);
}

/** Today in India, 'YYYY-MM-DD', and n days back. */
export const istDay = (back = 0) => new Date(Date.now() + IST - back * 86400000).toISOString().slice(0, 10);
/** The India-time date of a timestamp, as YYYY-MM-DD (for the date filters in a page address). */
export const istDayOf = (v: unknown) => { const t = new Date(String(v ?? "")).getTime(); return Number.isFinite(t) ? new Date(t + IST).toISOString().slice(0, 10) : istDay(0); };

export const plural = (n: number, one: string, many = `${one}s`) => `${inr(n)} ${n === 1 ? one : many}`;
export const titleCase = (s: unknown) => String(s ?? "").toLowerCase().replace(/(^|[\s(/-])(\p{L})/gu, (_, a, b) => a + b.toUpperCase());
export const CHANNEL_LABEL: Record<string, string> = { amazon: "Amazon", flipkart: "Flipkart", instamart: "Instamart", zepto: "Zepto", myntra: "Myntra" };
export const channelLabel = (c: unknown) => CHANNEL_LABEL[String(c ?? "").toLowerCase()] ?? titleCase(c);

/** A length of time in words: "40 s", "12 min", "1 h 25 min", "2 days 3 h". */
export function duration(seconds: unknown) {
  const s = Math.max(0, Math.round(Number(seconds)));
  if (!Number.isFinite(s)) return "-";
  if (s < 60) return `${s} s`;
  const m = Math.round(s / 60);
  if (m < 60) return `${m} min`;
  const h = Math.floor(m / 60), rm = m % 60;
  if (h < 24) return rm ? `${h} h ${rm} min` : `${h} h`;
  const d = Math.floor(h / 24), rh = h % 24;
  return `${d} ${d === 1 ? "day" : "days"}${rh ? ` ${rh} h` : ""}`;
}
/** Clock time in India: "2:05 PM" today, else "09 Oct, 2:05 PM". */
export const clock = (v: unknown) => { const q = parts(v), t = parts(new Date()); return !q ? "-" : q.y === t!.y && q.m === t!.m && q.d === t!.d ? ampm(q.h, q.mi) : `${p2(q.d)} ${MONTHS[q.m]}, ${ampm(q.h, q.mi)}`; };
