// PDF of a list or report: A4 landscape, Madhukar header (logo, title, filters, when and how many rows), yellow table header
// repeated on every page, banded rows, numbers right-aligned in ₹, a bold total row, clickable links, and "Page x of y".
// jsPDF, its table plugin and the Inter font (with the ₹ sign) load only when a PDF is made.
import { dateLong, dateTime, inr } from "./format";
import { NUMERIC, fileName, get, save, stampNow, toNumber, totalsOf, type ExportCol, type ExportInput } from "./exportTable";

type Row = Record<string, any>;
const INK: [number, number, number] = [30, 26, 20];
const MUTED: [number, number, number] = [107, 114, 128];
const GOLD: [number, number, number] = [249, 207, 31];
const BAND: [number, number, number] = [250, 249, 245];
const LINE: [number, number, number] = [214, 217, 224];
const LINK: [number, number, number] = [29, 78, 216];

/** "amazon.in/..." -> "Amazon": links read as the shop's name, and stay clickable. */
const SHOPS: [RegExp, string][] = [[/amazon\./, "Amazon"], [/flipkart\./, "Flipkart"], [/swiggy\.|instamart\./, "Instamart"], [/zepto/, "Zepto"], [/myntra\./, "Myntra"]];
export function shopName(url: string) {
  try { const h = new URL(url).hostname.replace(/^www\./, ""); return SHOPS.find(([re]) => re.test(h))?.[1] ?? h; } catch { return url; }
}

let fonts: Promise<[string, string]> | null = null;
const b64 = async (url: string) => {
  const buf = new Uint8Array(await (await fetch(url)).arrayBuffer());
  let s = ""; for (let i = 0; i < buf.length; i += 0x8000) s += String.fromCharCode(...buf.subarray(i, i + 0x8000));
  return btoa(s);
};
const loadFonts = () => (fonts ??= Promise.all([b64("/fonts/Inter-400Regular.ttf"), b64("/fonts/Inter-600SemiBold.ttf")]));
const loadLogo = () => fetch("/brand/apple-touch-icon.png").then((r) => r.blob()).then((b) => new Promise<string>((ok) => { const f = new FileReader(); f.onload = () => ok(String(f.result)); f.readAsDataURL(b); })).catch(() => null);

function text(c: ExportCol, r: Row): string {
  const v = c.pdfValue ? c.pdfValue(r) : get(c, r);
  if (v === null || v === undefined || v === "") return "";
  if (c.pdfValue) return String(v);
  switch (c.kind) {
    // Non-breaking space: an amount never splits across two lines.
    case "money": { const n = toNumber(v); return n === null ? "" : `₹\u00a0${inr(n, Number.isInteger(n) ? 0 : 2)}`; }
    case "pct": { const n = toNumber(v); return n === null ? "" : `${inr(n, 1)}%`; }
    case "int": case "num": { const n = toNumber(v); return n === null ? String(v) : inr(n, Number.isInteger(n) ? 0 : 2); }
    case "date": return dateLong(v);
    case "datetime": return dateTime(v);
    case "bool": return v ? "Yes" : "No";
    case "link": return shopName(String(v));
    default: return String(v);
  }
}

export async function downloadPdf({ title, cols: all, rows, note, file }: ExportInput) {
  const [{ jsPDF }, { default: autoTable }, [regular, semibold], logo] = await Promise.all([import("jspdf"), import("jspdf-autotable"), loadFonts(), loadLogo()]);
  const cols = all.filter((c) => c.pdf !== false);
  const doc = new jsPDF({ orientation: "landscape", unit: "pt", format: "a4", compress: true });
  doc.addFileToVFS("Inter-Regular.ttf", regular); doc.addFont("Inter-Regular.ttf", "Inter", "normal");
  doc.addFileToVFS("Inter-SemiBold.ttf", semibold); doc.addFont("Inter-SemiBold.ttf", "Inter", "bold");
  doc.setProperties({ title, creator: "MDAPL Price Tracker", author: "Madhukar Domestic Appliances" });
  const W = doc.internal.pageSize.getWidth(), H = doc.internal.pageSize.getHeight(), M = 32;

  // Header (first page): logo, title, what the list is, when it was made.
  let y = M;
  if (logo) doc.addImage(logo, "PNG", M, y, 30, 30);
  const x0 = logo ? M + 40 : M;
  doc.setFont("Inter", "bold"); doc.setFontSize(15); doc.setTextColor(...INK); doc.text(title, x0, y + 12);
  doc.setFont("Inter", "normal"); doc.setFontSize(8.5); doc.setTextColor(...MUTED);
  doc.text(`Madhukar Domestic Appliances · Price Tracker · Generated ${stampNow()} IST · ${inr(rows.length)} ${rows.length === 1 ? "row" : "rows"}`, x0, y + 26);
  y += 38;
  if (note) { const lines = doc.splitTextToSize(note, W - 2 * M); doc.text(lines, M, y + 6); y += 6 + lines.length * 10; }

  const totals = totalsOf(cols, rows);
  const right = (c: ExportCol) => NUMERIC.has(c.kind);
  const linkCols = new Set(cols.map((c, i) => (c.kind === "link" && !c.pdfValue ? i : -1)).filter((i) => i >= 0));
  const body = rows.map((r) => cols.map((c) => text(c, r)));
  const fontSize = cols.length > 14 ? 6.5 : cols.length > 10 ? 7 : 8;
  // Numbers, dates, codes and shop names never wrap: each such column is at least as wide as its widest value (header
  // words may wrap). Text columns (names) share the rest and wrap. Nothing is cut off at the page edge.
  doc.setFont("Inter", "normal"); doc.setFontSize(fontSize);
  const keep = (c: ExportCol) => right(c) || ["mono", "date", "datetime", "link", "bool", "int"].includes(c.kind ?? "");
  const widest = (i: number) => Math.min(110, Math.max(...body.slice(0, 2000).map((r) => doc.getTextWidth(r[i] ?? "")), 0) + 11);
  const minW = cols.map((c, i) => (keep(c) ? widest(i) : 0));
  autoTable(doc, {
    startY: y + 4,
    margin: { left: M, right: M, top: M, bottom: M + 6 },
    head: [cols.map((c) => c.pdfLabel ?? c.label)],
    body,
    foot: totals.size ? [cols.map((c, i) => (totals.has(c.key) ? text({ ...c, value: undefined, pdfValue: undefined }, { [c.key]: totals.get(c.key) }) : i === 0 ? "Total" : ""))] : undefined,
    showFoot: "lastPage",
    theme: "plain",
    tableWidth: "auto",
    // Too many columns for one page width even at their narrowest: the extra columns continue on the next page
    // (first column repeated) instead of being cut off.
    ...(minW.reduce((a, b) => a + b, 0) + cols.filter((c, i) => !minW[i]).length * 70 > W - 2 * M ? { horizontalPageBreak: true, horizontalPageBreakRepeat: 0 } : {}),
    // A full grid: every cell has a thin border.
    styles: { font: "Inter", fontSize, textColor: INK, cellPadding: { top: 4, bottom: 4, left: 5, right: 5 }, lineColor: LINE, lineWidth: 0.5, overflow: "linebreak", valign: "middle" },
    headStyles: { font: "Inter", fontStyle: "bold", fillColor: GOLD, textColor: INK, fontSize, lineColor: [214, 174, 18], lineWidth: 0.5, valign: "middle" },
    footStyles: { font: "Inter", fontStyle: "bold", fillColor: [244, 241, 232], textColor: INK, lineColor: LINE, lineWidth: 0.5 },
    alternateRowStyles: { fillColor: BAND },
    // Numbers, codes and dates keep their natural width; text columns (names) take what is left and wrap.
    columnStyles: Object.fromEntries(cols.map((c, i) => [i, { halign: right(c) ? "right" : "left", ...(minW[i] ? { minCellWidth: minW[i] } : {}) }])),
    didParseCell: (d) => {
      if ((d.section === "head" || d.section === "foot") && right(cols[d.column.index])) d.cell.styles.halign = "right";
      if (d.section === "body" && linkCols.has(d.column.index) && d.cell.raw) { d.cell.styles.textColor = LINK; d.cell.styles.fontStyle = "bold"; }
    },
    // Links stay clickable in the PDF.
    didDrawCell: (d) => {
      if (d.section !== "body" || !linkCols.has(d.column.index)) return;
      const row = rows[d.row.index];   // a row split by a page break has no source row of its own
      if (!row) return;
      const url = get(cols[d.column.index], row);
      if (url) doc.link(d.cell.x, d.cell.y, d.cell.width, d.cell.height, { url: String(url) });
    },
  });

  // Footer on every page.
  const pages = doc.getNumberOfPages();
  for (let p = 1; p <= pages; p++) {
    doc.setPage(p);
    doc.setDrawColor(...LINE); doc.setLineWidth(0.5); doc.line(M, H - M + 2, W - M, H - M + 2);
    doc.setFont("Inter", "normal"); doc.setFontSize(7.5); doc.setTextColor(...MUTED);
    doc.text(`${title} · MDAPL Price Tracker · Internal`, M, H - M + 14);
    doc.text(`Page ${p} of ${pages}`, W - M, H - M + 14, { align: "right" });
  }
  save(doc.output("blob"), fileName(file ?? title, "pdf"));
}
