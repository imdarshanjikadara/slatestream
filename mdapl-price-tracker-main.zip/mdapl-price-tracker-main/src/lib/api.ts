import { useCallback, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { QueryClient, keepPreviousData, useQuery, type QueryKey } from "@tanstack/react-query";

export class ApiError extends Error {
  constructor(public status: number, message: string) { super(message); }
}

let onUnauthorised: (() => void) | null = null;
export const setUnauthorisedHandler = (fn: () => void) => { onUnauthorised = fn; };

export async function api<T = any>(path: string, init?: { method?: string; body?: unknown; signal?: AbortSignal }): Promise<T> {
  let res: Response;
  try {
    res = await fetch(`/api/${path.replace(/^\//, "")}`, {
      method: init?.method ?? (init?.body !== undefined ? "POST" : "GET"),
      headers: init?.body !== undefined ? { "Content-Type": "application/json" } : undefined,
      body: init?.body !== undefined ? JSON.stringify(init.body) : undefined,
      credentials: "same-origin",
      signal: init?.signal,
    });
  } catch (e) {
    if ((e as Error).name === "AbortError") throw e;
    throw new ApiError(0, "Could not reach the server. Check the connection and try again.");
  }
  const data = await res.json().catch(() => null);
  if (!res.ok) {
    if (res.status === 401 && !path.startsWith("auth/")) onUnauthorised?.();
    throw new ApiError(res.status, data?.error ?? `Request failed (${res.status}).`);
  }
  return data as T;
}

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: { staleTime: 30_000, refetchOnWindowFocus: true, retry: (n, e) => !(e instanceof ApiError && e.status >= 400 && e.status < 500) && n < 2 },
  },
});

/** Query string from an object, dropping empty values, sorted so cache keys are stable. */
export function qs(params: Record<string, string | number | null | undefined | boolean>) {
  const p = new URLSearchParams();
  for (const k of Object.keys(params).sort()) {
    const v = params[k];
    if (v === null || v === undefined || v === "" || v === false) continue;
    p.set(k, String(v));
  }
  const s = p.toString();
  return s ? `?${s}` : "";
}

export type Page<R> = { rows: R[]; total: number; [k: string]: any };

export const PER_PAGE = [25, 50, 100, 200] as const;
const perKey = (endpoint: string) => `mdapl.per.${endpoint}`;
/** The page size last chosen for this list (25 when none, or when storage is blocked). */
export function storedPer(endpoint: string) {
  try { const v = Number(localStorage.getItem(perKey(endpoint))); return (PER_PAGE as readonly number[]).includes(v) ? v : 25; } catch { return 25; }
}

export const listKey = (endpoint: string, params: Record<string, any>, page = 1, per = 25): QueryKey => ["list", endpoint, qs(params), page, per];
const listFn = (endpoint: string, params: Record<string, any>, page: number, per: number) => ({ signal }: { signal: AbortSignal }) =>
  api<Page<any>>(`${endpoint}${qs({ ...params, offset: (page - 1) * per || null, limit: per })}`, { signal });

/** A list paged by the server. The page and page size live in the URL (?page=, ?per=); the size is also remembered per list.
 *  Changing a filter goes back to page 1 (useUrlState drops ?page). The previous page stays on screen while the next loads. */
export function useList<R = any>(endpoint: string, params: Record<string, any>, enabled = true) {
  const [sp, setSp] = useSearchParams();
  const perUrl = Number(sp.get("per"));
  const per = (PER_PAGE as readonly number[]).includes(perUrl) ? perUrl : storedPer(endpoint);
  const pageUrl = Number(sp.get("page"));
  const page = Number.isInteger(pageUrl) && pageUrl > 1 ? pageUrl : 1;
  const q = useQuery({ queryKey: listKey(endpoint, params, page, per), queryFn: listFn(endpoint, params, page, per), placeholderData: keepPreviousData, enabled });
  const total: number = q.data?.total ?? 0;
  const pageCount = Math.max(1, Math.ceil(total / per));
  const setUrl = useCallback((patch: { page?: number; per?: number }) => setSp((prev) => {
    const next = new URLSearchParams(prev);
    if (patch.page !== undefined) { if (patch.page > 1) next.set("page", String(patch.page)); else next.delete("page"); }
    if (patch.per !== undefined) next.set("per", String(patch.per));
    return next;
  }, { replace: true }), [setSp]);
  const setPage = useCallback((p: number) => setUrl({ page: p }), [setUrl]);
  const setPer = useCallback((n: number) => { try { localStorage.setItem(perKey(endpoint), String(n)); } catch { /* storage blocked */ } setUrl({ per: n, page: 1 }); }, [endpoint, setUrl]);
  // A page past the end (rows deleted, or an old link): go to the last page.
  useEffect(() => { if (q.data && !q.isPlaceholderData && page > pageCount) setPage(pageCount); }, [q.data, q.isPlaceholderData, page, pageCount, setPage]);
  return {
    ...q,
    rows: (q.data?.rows ?? []) as R[],
    total,
    meta: q.data as Page<R> | undefined,
    pager: { page, per, total, pageCount, setPage, setPer, loading: q.isFetching } as Pager,
  };
}
export type Pager = { page: number; per: number; total: number; pageCount: number; setPage: (p: number) => void; setPer: (n: number) => void; loading?: boolean };

export function prefetchList(endpoint: string, params: Record<string, any>) {
  const per = storedPer(endpoint);
  return queryClient.prefetchQuery({ queryKey: listKey(endpoint, params, 1, per), queryFn: listFn(endpoint, params, 1, per) as any, staleTime: 30_000 });
}

/** Every row matching the current filters (exports). */
export const fetchAll = (endpoint: string, params: Record<string, any>) => api<Page<any>>(`${endpoint}${qs({ ...params, all: 1 })}`);
