// Error reporting to Sentry, project smallbay-digital/mdapl-web (shared with the server, which tags side=server).
// Imported first in main.tsx so it starts before the app; production builds only.
// API failures are not reported here: the server reports its own 500s with the cause.
// The DSN only lets events be sent, it is not a secret; VITE_SENTRY_DSN overrides it and an empty value switches reporting off.
import * as Sentry from "@sentry/react";
import { ApiError } from "./api";

declare const __SENTRY_RELEASE__: string;

const DEFAULT_DSN = "https://f82bdbac15c66932d6a5425a982f3856@o4512328579874816.ingest.us.sentry.io/4512328698101760";
const DSN: string = import.meta.env.VITE_SENTRY_DSN ?? DEFAULT_DSN;
const ON = import.meta.env.PROD && !!DSN;

// Filters and searches live in the hash ("#/products?q=..."), which Sentry's query-string setting does not cover: cut them off.
const cleanUrl = (u?: string) => u?.replace(/(#[^?]*)\?.*$/, "$1");

if (ON) {
  Sentry.init({
    dsn: DSN,
    release: __SENTRY_RELEASE__ || undefined,
    environment: window.location.hostname,
    integrations: [Sentry.browserTracingIntegration()],
    tracesSampleRate: 0.1,
    // No trace headers on API calls (the API does not trace).
    tracePropagationTargets: [],
    // sendDefaultPii is gone in SDK 11; this is its equivalent: no automatic user info, cookies, headers, bodies or query strings.
    // The signed-in person's id and email are set explicitly (setSentryUser).
    dataCollection: { userInfo: false, cookies: false, httpHeaders: false, httpBodies: [], urlQueryParams: false },
    initialScope: { tags: { side: "browser" } },
    ignoreErrors: ["ResizeObserver loop limit exceeded", "ResizeObserver loop completed with undelivered notifications"],
    beforeSend(event, hint) {
      if (hint.originalException instanceof ApiError) return null;
      if (event.request) event.request.url = cleanUrl(event.request.url);
      return event;
    },
    // Page-load timings are sent as spans with the address in their attributes and name.
    beforeSendSpan(span) {
      span.name = cleanUrl(span.name) ?? span.name;
      for (const [k, v] of Object.entries(span.attributes ?? {})) {
        if (typeof v === "string") span.attributes[k] = cleanUrl(v);
        else if (v && typeof v === "object" && typeof (v as { value?: unknown }).value === "string") (v as { value: string }).value = cleanUrl((v as { value: string }).value)!;
      }
      return span;
    },
    beforeBreadcrumb(crumb) {
      if (crumb.data) for (const k of ["url", "from", "to"]) if (typeof crumb.data[k] === "string") crumb.data[k] = cleanUrl(crumb.data[k]);
      return crumb;
    },
  });
}

/** Whether this page reports to Sentry (production builds). */
export const sentryEnabled = ON;

/** The signed-in person (id, email and role), or null after sign-out. */
export function setSentryUser(u: { id: number; email: string; role: string } | null) {
  if (!ON) return;
  Sentry.setUser(u ? { id: String(u.id), email: u.email } : null);
  Sentry.setTag("role", u?.role);
}

/** Error boundaries: report a render crash with the React component stack. */
export function reportError(error: unknown, extra?: Record<string, unknown>) {
  if (!ON) return;
  Sentry.captureException(error, extra ? { extra } : undefined);
}
