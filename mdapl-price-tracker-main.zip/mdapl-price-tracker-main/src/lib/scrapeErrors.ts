// Scraper errors in plain words: what went wrong with a link, and what usually helps.
export type Reason = { key: string; title: string; hint: string };

const REASONS: (Reason & { re: RegExp })[] = [
  { key: "nav-timeout", re: /navigation timeout|timeout of \d+ ?ms|timed out|browserless 408/i, title: "Page took too long to load",
    hint: "The product page did not finish loading in time through the proxy. Usually the proxy exit was slow or the site held the request back; trying again normally works." },
  { key: "no-answer", re: /no answer from browserless|operation was aborted|aborted/i, title: "No answer from the browser in time",
    hint: "The page did not come back within 100 seconds on any of its tries (each try uses a fresh browser and proxy exit). Usually the proxy exit was very slow or Amazon held the page back. \"Retry failed links\" a little later normally gets them; if many links fail this way, the Browserless server may be short of memory." },
  { key: "limit", re: /browserless 429|too many requests|concurren/i, title: "Browserless limit reached",
    hint: "Too many browsers were open at once for the Browserless plan. Lower SCRAPE_CONCURRENCY or wait for other runs to finish." },
  { key: "token", re: /browserless 40[13]|not configured/i, title: "Browserless refused the request",
    hint: "The Browserless token is missing or not accepted. Check BROWSERLESS_TOKEN and BROWSERLESS_URL." },
  { key: "proxy", re: /407|ERR_TUNNEL|ERR_PROXY|proxy/i, title: "Proxy refused the connection",
    hint: "The residential proxy did not let the browser through. Check the proxy login and balance on the Decodo dashboard." },
  { key: "network", re: /ERR_NAME|ERR_CONNECTION|ERR_INTERNET|ECONN|socket|ENOTFOUND/i, title: "Network error",
    hint: "The page could not be reached (connection dropped or the site did not answer). Trying again normally works." },
  { key: "no-url", re: /no url/i, title: "The link has no URL",
    hint: "Add the product page address to this link on the Channel Scraping page." },
  { key: "server", re: /browserless 5\d\d/i, title: "Browserless had an error",
    hint: "Browserless failed on its side. Trying again normally works." },
];

export function reasonOf(error: unknown): Reason {
  const msg = String(error ?? "");
  const r = REASONS.find((x) => x.re.test(msg));
  return r ? { key: r.key, title: r.title, hint: r.hint } : { key: "other", title: "Other error", hint: "See the details next to the link." };
}

/** Failures grouped by reason, most frequent first. */
export function groupReasons(errors: unknown[]) {
  const m = new Map<string, Reason & { n: number }>();
  for (const e of errors) { const r = reasonOf(e); const x = m.get(r.key); if (x) x.n++; else m.set(r.key, { ...r, n: 1 }); }
  return [...m.values()].sort((a, b) => b.n - a.n);
}
