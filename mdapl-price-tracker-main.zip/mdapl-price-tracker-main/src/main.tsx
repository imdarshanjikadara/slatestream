// Sentry first, so errors anywhere in the app (including while it starts) are reported.
import "./lib/sentry";
import { StrictMode, Suspense, lazy } from "react";
import { createRoot } from "react-dom/client";
import { HashRouter, Navigate, Route, Routes, useLocation } from "react-router-dom";
import { QueryClientProvider } from "@tanstack/react-query";
import "./styles.css";
import { queryClient, setUnauthorisedHandler } from "./lib/api";
import { AuthProvider, useAuth } from "./lib/auth";
import { Layout } from "./components/Layout";
import { ConfirmHost, Toaster } from "./components/overlays";
import { Loading } from "./components/common";
import Login from "./pages/Login";
import { ErrorBoundary } from "./components/ErrorBoundary";
import { SetOwnPassword } from "./pages/SetOwnPassword";
import { UpdatePrompt } from "./components/UpdatePrompt";

const Dashboard = lazy(() => import("./pages/Dashboard"));
const Categories = lazy(() => import("./pages/Categories"));
const CategoryDetail = lazy(() => import("./pages/CategoryDetail"));
const Products = lazy(() => import("./pages/Products"));
const ProductDetail = lazy(() => import("./pages/ProductDetail"));
const ProductImport = lazy(() => import("./pages/ProductImport"));
const Scraping = lazy(() => import("./pages/Scraping"));
const Schedule = lazy(() => import("./pages/Schedule"));
const Results = lazy(() => import("./pages/Results"));
const MopReports = lazy(() => import("./pages/MopReports"));
const Runs = lazy(() => import("./pages/Runs"));
const Audit = lazy(() => import("./pages/Audit"));
const Team = lazy(() => import("./pages/Team"));
const NotFound = lazy(() => import("./pages/NotFound"));
const Support = lazy(() => import("./pages/Support"));
const SupportNew = lazy(() => import("./pages/SupportNew"));
const SupportTicket = lazy(() => import("./pages/SupportTicket"));
const Guide = lazy(() => import("./pages/Guide"));

setUnauthorisedHandler(() => {
  queryClient.setQueryData(["me"], { user: null, demo: false });
  const here = window.location.hash.replace(/^#/, "");
  if (!here.startsWith("/login")) window.location.hash = `#/login?next=${encodeURIComponent(here)}`;
});

function Gate({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  const loc = useLocation();
  if (loading) return <div className="grid min-h-screen place-items-center"><Loading /></div>;
  if (!user) return <Navigate to={`/login?next=${encodeURIComponent(loc.pathname + loc.search)}`} replace />;
  if (user.mustChangePassword) return <SetOwnPassword />;
  return <>{children}</>;
}

function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route element={<Gate><Layout /></Gate>}>
        <Route path="/" element={<Page><Dashboard /></Page>} />
        <Route path="/categories" element={<Page><Categories /></Page>} />
        <Route path="/categories/:id" element={<Page><CategoryDetail /></Page>} />
        <Route path="/products" element={<Page><Products /></Page>} />
        <Route path="/products/new" element={<Page><ProductDetail /></Page>} />
        <Route path="/products/import" element={<Page><ProductImport /></Page>} />
        <Route path="/products/:id" element={<Page><ProductDetail /></Page>} />
        <Route path="/scraping" element={<Page><Scraping /></Page>} />
        <Route path="/schedule" element={<Page><Schedule /></Page>} />
        <Route path="/results" element={<Page><Results /></Page>} />
        <Route path="/results/:id" element={<Page><Results /></Page>} />
        <Route path="/mop-reports" element={<Page><MopReports /></Page>} />
        <Route path="/mop-reports/:id" element={<Page><MopReports /></Page>} />
        <Route path="/runs" element={<Page><Runs /></Page>} />
        <Route path="/runs/:id" element={<Page><Runs /></Page>} />
        <Route path="/audit" element={<Page><Audit /></Page>} />
        <Route path="/team" element={<Page><Team /></Page>} />
        <Route path="/support" element={<Page><Support /></Page>} />
        <Route path="/support/new" element={<Page><SupportNew /></Page>} />
        <Route path="/support/:id" element={<Page><SupportTicket /></Page>} />
        <Route path="/guide/:id?" element={<Page><Guide /></Page>} />
        <Route path="*" element={<Page><NotFound /></Page>} />
      </Route>
    </Routes>
  );
}
const Page = ({ children }: { children: React.ReactNode }) => <Suspense fallback={<Loading />}>{children}</Suspense>;

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <ErrorBoundary full>
      <QueryClientProvider client={queryClient}>
        <AuthProvider>
          <HashRouter>
            <App />
            <ConfirmHost />
            <Toaster />
            <UpdatePrompt />
          </HashRouter>
        </AuthProvider>
      </QueryClientProvider>
    </ErrorBoundary>
  </StrictMode>,
);
