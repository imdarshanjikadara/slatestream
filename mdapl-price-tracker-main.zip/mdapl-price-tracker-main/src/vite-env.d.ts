/// <reference types="vite/client" />

interface ImportMetaEnv {
  /** Optional override of the browser Sentry DSN; an empty value switches browser reporting off. */
  readonly VITE_SENTRY_DSN?: string;
}
