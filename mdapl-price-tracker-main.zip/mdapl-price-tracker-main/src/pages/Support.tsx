// Help and support home: start a request, follow every request with its status, and jump to the ones with new
// replies. Requests live in the SBD support hub; this page reads them through /api/support/*.
import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { HelpCircle, LifeBuoy, MessageSquare, Paperclip, Plus, Wrench } from "lucide-react";
import { api } from "@/lib/api";
import { useUrlState } from "@/lib/hooks";
import { inr } from "@/lib/format";
import { ago, categoryLabel, OPEN_STATUSES, priorityOf, ref, STATUS } from "@/lib/support";
import { EmptyState, ErrorState, Notice, PageHeader, StatStrip, Tabs } from "@/components/common";
import { SearchBox } from "@/components/FilterBar";
import { Pagination } from "@/components/DataTable";
import { Pill } from "@/components/Pill";

export type Ticket = {
  ticket_id: number; title: string; category: string; priority: string; status: string; area: string | null; created_by: string; created_by_name: string;
  created_at: string; updated_at: string; replies: number; files: number; last_message: string | null; unread: boolean;
};

/** The hub is not set up for this app (503): the pages say so instead of an error. */
export const notConnected = (e: unknown) => (e as { status?: number })?.status === 503;
export function NotConnected() {
  return <Notice tone="warning" title="Support isn't connected yet">Requests go to the SmallBay Digital support team once this app is connected to the support hub (SUPPORT_HUB_URL and SUPPORT_HUB_KEY).</Notice>;
}

const PER = 25;

export default function Support() {
  const q = useQuery({ queryKey: ["support", "tickets"], queryFn: () => api<Ticket[]>("support/tickets"), refetchInterval: 30_000, retry: false });
  const [f, set] = useUrlState({ tab: "open", q: "" });
  const [page, setPage] = useState(1);
  const [per, setPer] = useState(PER);
  const all = q.data ?? [];
  const counts = { open: all.filter((t) => OPEN_STATUSES.includes(t.status)).length, done: all.filter((t) => !OPEN_STATUSES.includes(t.status)).length };
  const rows = useMemo(() => {
    const term = f.q.trim().toLowerCase().replace(/^#?sup-0*/, "");
    return all.filter((r) => (f.tab === "all" || (f.tab === "open" ? OPEN_STATUSES.includes(r.status) : !OPEN_STATUSES.includes(r.status)))
      && (!term || r.title.toLowerCase().includes(term) || String(r.ticket_id) === term));
  }, [all, f.tab, f.q]);
  const pageCount = Math.max(1, Math.ceil(rows.length / per));
  const at = Math.min(page, pageCount);
  const shown = rows.slice((at - 1) * per, at * per);
  const waiting = all.filter((t) => t.status === "waiting_client").length;
  const unread = all.filter((t) => t.unread).length;

  return (
    <div className="page">
      <PageHeader title="Support" subtitle="Report a problem, ask a question or ask for a change. Our team replies here, in the same thread.">
        <Link to="/support/new" className="btn-primary"><Plus className="h-4 w-4" />New request</Link>
      </PageHeader>

      <div className="grid gap-3 sm:grid-cols-3">
        {[
          { to: "/support/new?category=problem", icon: Wrench, title: "Report a problem", hint: "Something isn't working or shows the wrong thing" },
          { to: "/support/new?category=question", icon: HelpCircle, title: "Ask a question", hint: "How to do something in the app" },
          { to: "/support/new?category=change", icon: LifeBuoy, title: "Request a change", hint: "Change how something works, or add something new" },
        ].map((s) => (
          <Link key={s.to} to={s.to} className="card group flex items-start gap-3 p-4 transition-colors hover:border-line-hover hover:bg-surface-alt">
            <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-accent-soft text-bronze"><s.icon className="h-[18px] w-[18px]" /></span>
            <span className="min-w-0"><span className="block text-[14px] font-medium text-ink">{s.title}</span><span className="block text-[12.5px] text-faint">{s.hint}</span></span>
          </Link>))}
      </div>

      {notConnected(q.error) ? <NotConnected /> : <>
        <StatStrip loading={q.isFetching && !q.data} items={[
          { label: "Open requests", value: inr(counts.open), hint: "Received, in progress or waiting on you" },
          { label: "Waiting on you", value: inr(waiting), tone: waiting ? "warning" : undefined, sub: waiting ? "The team needs your reply" : "Nothing needed from you" },
          { label: "New replies", value: inr(unread), sub: unread ? "Marked with a dot below" : "All read" },
          { label: "Resolved or closed", value: inr(counts.done) },
        ]} />

        <div className="flex flex-wrap items-center gap-3">
          <Tabs ariaLabel="Requests" active={f.tab} onChange={(k) => { set({ tab: k }); setPage(1); }} items={[
            { key: "open", label: "Open", count: counts.open }, { key: "done", label: "Resolved and closed", count: counts.done }, { key: "all", label: "All", count: all.length }]} />
          <SearchBox className="w-full sm:ml-auto sm:w-72" value={f.q} onChange={(v) => { set({ q: v }); setPage(1); }} placeholder="Search title or #SUP-…" />
        </div>

        <section className="card overflow-hidden">
          {q.error ? <ErrorState error={q.error} retry={() => q.refetch()} /> : <>
            {q.isLoading && Array.from({ length: 4 }, (_, i) => (
              <div key={i} className="space-y-2 border-b border-line px-4 py-3.5"><div className="h-3 w-1/2 animate-pulse rounded bg-track" /><div className="h-3 w-1/4 animate-pulse rounded bg-track" /></div>))}
            {!q.isLoading && !rows.length && (all.length
              ? <EmptyState title={f.q ? `No requests match "${f.q}"` : f.tab === "open" ? "No open requests" : "Nothing here yet"} hint={f.q ? "Try another word or the reference number." : undefined}
                  action={f.q ? <button className="btn btn-sm" onClick={() => set({ q: null })}>Clear search</button> : undefined} />
              : <EmptyState title="No requests yet" hint="When something isn't right, or you need something changed, start a request and follow it here."
                  action={<Link to="/support/new" className="btn-primary btn-sm"><Plus className="h-4 w-4" />Start a request</Link>} />)}
            <ul className="divide-y divide-line">
              {shown.map((t) => {
                const s = STATUS[t.status] ?? STATUS.open;
                const p = priorityOf(t.priority);
                return (
                  <li key={t.ticket_id}>
                    <Link to={`/support/${t.ticket_id}`} className="flex gap-3 px-4 py-3 transition-colors hover:bg-hover-row">
                      <span className={`mt-1.5 h-2 w-2 shrink-0 rounded-full ${t.unread ? "bg-gold-line" : "bg-transparent"}`} title={t.unread ? "New reply" : undefined} />
                      <span className="min-w-0 flex-1">
                        <span className="flex flex-wrap items-baseline justify-between gap-x-3 gap-y-1">
                          <span className={`min-w-0 truncate text-[14px] text-ink ${t.unread ? "font-semibold" : "font-medium"}`}>{t.title}</span>
                          <Pill tone={s.tone} dot={s.dot} title={s.hint}>{s.label}</Pill>
                        </span>
                        <span className="mt-0.5 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[12.5px] text-faint">
                          <span className="tabular-nums">{ref(t.ticket_id)}</span><span aria-hidden>·</span><span>{categoryLabel(t.category)}</span>
                          {t.area && <><span aria-hidden>·</span><span>{t.area}</span></>}
                          <span aria-hidden>·</span><span className={t.priority === "critical" || t.priority === "high" ? "font-medium text-warning" : undefined}>{p.label}</span>
                          <span className="ml-auto flex items-center gap-3">
                            {t.replies > 0 && <span className="inline-flex items-center gap-1" title={`${t.replies} ${t.replies === 1 ? "reply" : "replies"}`}><MessageSquare className="h-3.5 w-3.5" />{t.replies}</span>}
                            {t.files > 0 && <span className="inline-flex items-center gap-1" title={`${t.files} ${t.files === 1 ? "file" : "files"}`}><Paperclip className="h-3.5 w-3.5" />{t.files}</span>}
                            <span>{ago(t.updated_at)}</span>
                          </span>
                        </span>
                        {t.last_message && <span className="mt-1 block truncate text-[12.5px] text-muted">{t.last_message}</span>}
                      </span>
                    </Link>
                  </li>);
              })}
            </ul>
            {rows.length > PER && <Pagination pager={{ page: at, per, total: rows.length, pageCount, setPage, setPer: (n) => { setPer(n); setPage(1); } }} />}
          </>}
        </section>
      </>}
    </div>
  );
}
