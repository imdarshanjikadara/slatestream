// Bulk edit of selected products, and the product master download (the old sheet's columns, ready to edit and import back).
import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { api, qs, queryClient } from "@/lib/api";
import { inr, titleCase } from "@/lib/format";
import { downloadXlsx, type ExportCol } from "@/lib/exportTable";
import { Select } from "@/components/ui/Select";
import { Dialog, toast } from "@/components/overlays";
import { ScheduleParts, ScrapingModePicker, TimePicker, modeFields } from "@/components/ScrapingMode";
import { useLookups } from "./Products";

const NUM = new Set(["product_id", "category_id", "mrp", "direct_discount", "dealer_landing", "dp_margin_percent", "mop", "scheme_1", "scheme_2", "scheme_3", "total_scheme",
  "net_landing", "retail_margin_percent", "retail_margin", "mop_scheme", "trigger_price_percent", "trigger_price", "gst_percent", "amazon_product_link_id",
  "flipkart_product_link_id", "instamart_product_link_id", "zepto_product_link_id"]);

/** Every product in the sheet's column layout. Edit it in Excel and bring it back with Import. */
/** The product master in the sheet's layout, for the products matching the Products page filters (`filters` says which, for the file). */
export async function downloadMaster(params: Record<string, any> = {}, filters = "") {
  try {
    const { columns, rows } = await api<{ columns: string[]; rows: any[] }>(`products/master${qs(params)}`);
    if (!rows.length) { toast.error("No products match these filters."); return; }
    const cols: ExportCol[] = columns.map((k) => ({ key: k, label: k, kind: NUM.has(k) ? "num" : k.endsWith("_url") ? "link" : undefined, value: k === "product_is_active" || k.endsWith("scraping") ? (r: any) => (r[k] === null ? "" : r[k] ? "TRUE" : "FALSE") : undefined }));
    await downloadXlsx({ title: "Product master", sheet: "Products", cols, rows, file: "product_master", note: `${filters ? `${inr(rows.length)} products: ${filters}. ` : ""}Edit and bring back with Products > Import (only the products in the file change). MOP, total scheme, net landing, retail margin, MOP scheme and trigger price are calculated by the app.` });
  } catch (e) { toast.error((e as Error).message); }
}

type Key = "category_id" | "brand" | "ph" | "is_active" | "mode"
  | "gst_percent" | "direct_discount" | "dp_margin_percent" | "retail_margin_percent" | "trigger_price_percent";

/** Edit selected products; `scheduleOnly` shows just the scraping schedule (Scraping > Update Scraping Schedule). */
export function BulkEditDialog({ ids, open, onClose, onDone, scheduleOnly, title }: { ids: number[]; open: boolean; onClose: () => void; onDone: () => void; scheduleOnly?: boolean; title?: string }) {
  const lk = useLookups();
  const [on, setOn] = useState<Partial<Record<Key, boolean>>>({});
  const [v, setV] = useState<Record<string, any>>({ is_active: "true", mode: "", weekly: [], monthly: [], months: [], time: "06:00" });
  const set = (k: Key, val: unknown) => { setV((o) => ({ ...o, [k]: val })); setOn((o) => ({ ...o, [k]: true })); };
  // The schedule dialog always sets the scraping mode; the general one only when ticked.
  const modeOn = scheduleOnly ? !!v.mode : !!on.mode && !!v.mode;
  const m = useMutation({
    mutationFn: () => {
      const payload: Record<string, unknown> = {};
      for (const [k, yes] of Object.entries(on)) if (yes && k !== "mode") payload[k] = k === "is_active" ? v[k] === "true" : v[k] ?? "";
      if (modeOn) {
        Object.assign(payload, modeFields(v.mode));
        // Week-wise, month-wise and year-wise parts belong to "On a schedule"; the other modes leave them as they are.
        if (v.mode === "scheduled") Object.assign(payload, { scraping_schedule_weekly: v.weekly, scraping_schedule_monthly: v.monthly, months_to_scrape: v.months });
        if (v.mode !== "off") payload.scrape_time = v.time;
      }
      return api("products/bulk", { body: { ids, set: payload } });
    },
    onSuccess: (r) => { toast.success(`${inr(r.updated)} products updated.`); void queryClient.invalidateQueries(); onDone(); onClose(); setOn({}); },
  });
  const count = Object.entries(on).filter(([k, x]) => x && k !== "mode").length + (modeOn ? 1 : 0);
  const row = (k: Key, label: string, children: React.ReactNode) => (scheduleOnly ? null :
    <div key={k} className="grid grid-cols-[1.5rem_9rem_minmax(0,1fr)] items-center gap-3 border-b border-line py-2.5 last:border-0">
      <input type="checkbox" checked={!!on[k]} onChange={(e) => setOn((o) => ({ ...o, [k]: e.target.checked }))} aria-label={`Change ${label}`} />
      <span className={`text-[13px] ${on[k] ? "font-medium text-ink" : "text-muted"}`}>{label}</span>
      <div className="min-w-0">{children}</div>
    </div>
  );
  const schedule = <ScheduleParts weekly={v.weekly} monthly={v.monthly} months={v.months}
    onWeekly={(x) => setV((o) => ({ ...o, weekly: x }))} onMonthly={(x) => setV((o) => ({ ...o, monthly: x }))} onMonths={(x) => setV((o) => ({ ...o, months: x }))} />;
  const pct = (k: Key, label: string) => (
    row(k, label, <><input className="input w-32 text-right" inputMode="decimal" value={v[k] ?? ""} onChange={(e) => set(k, e.target.value.replace(/[^\d.]/g, ""))} placeholder="0" aria-label={label} /></>)
  );
  return (
    <Dialog open={open} onClose={() => { m.reset(); onClose(); }} wide title={title ?? `Edit ${inr(ids.length)} selected ${ids.length === 1 ? "product" : "products"}`}
      footer={<><button className="btn-ghost" onClick={onClose}>Cancel</button><button className="btn-primary" disabled={!count || m.isPending} onClick={() => m.mutate()}>{m.isPending ? "Saving..." : scheduleOnly ? (modeOn ? `Apply to ${inr(ids.length)} ${ids.length === 1 ? "product" : "products"}` : "Choose how to scrape") : count ? `Apply ${count} ${count === 1 ? "change" : "changes"}` : "Choose what to change"}</button></>}>
      {m.error && <div className="notice notice-danger mb-3">{(m.error as Error).message}</div>}
      {!scheduleOnly && <p className="mb-2 text-[13px] text-muted">Tick what to change; everything else stays as it is on each product. Every change is in the Audit log.</p>}
      {row("category_id", "Category", <><Select ariaLabel="Category" placeholder="Choose a category" value={v.category_id ?? ""} onChange={(x) => set("category_id", x)} options={(lk.categories.data ?? []).map((c) => ({ value: String(c.id), label: titleCase(c.name) }))} /></>)}
      {row("brand", "Brand", <><input className="input" value={v.brand ?? ""} onChange={(e) => set("brand", e.target.value)} aria-label="Brand" /></>)}
      {row("ph", "Product head (PH)", <><input className="input" value={v.ph ?? ""} onChange={(e) => set("ph", e.target.value)} aria-label="Product head" /></>)}
      {row("is_active", "Status", <><Select required ariaLabel="Status" value={v.is_active} onChange={(x) => set("is_active", x)} options={[{ value: "true", label: "Active" }, { value: "false", label: "Inactive (switched off)" }]} /></>)}
      {scheduleOnly ? <div className="space-y-3">
          <ScrapingModePicker value={v.mode} onChange={(x) => setV((o) => ({ ...o, mode: x }))} />
          {v.mode && v.mode !== "off" && <TimePicker value={v.time} onChange={(x) => setV((o) => ({ ...o, time: x }))} />}
          {v.mode === "scheduled" && schedule}
        </div>
        : row("mode", "Scraping", <div className="space-y-3"><ScrapingModePicker value={v.mode} onChange={(x) => set("mode", x)} />{v.mode && v.mode !== "off" && <TimePicker value={v.time} onChange={(x) => setV((o) => ({ ...o, time: x }))} />}{v.mode === "scheduled" && schedule}</div>)}
      {pct("gst_percent", "GST %")}
      {pct("direct_discount", "Direct discount %")}
      {pct("dp_margin_percent", "DP margin %")}
      {pct("retail_margin_percent", "Retail margin %")}
      {pct("trigger_price_percent", "Trigger price %")}
      {scheduleOnly ? <p className="mt-3 text-[12px] text-faint">A product is scraped every day or on a schedule, never both. The new setting replaces what each product had.</p>
        : <p className="mt-3 text-[12px] text-faint">MOP, net landing, retail margin, MOP scheme and trigger price are recalculated for each product.</p>}
    </Dialog>
  );
}
