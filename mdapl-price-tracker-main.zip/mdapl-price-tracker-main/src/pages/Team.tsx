// Team & access: who can sign in and with which role. Everyone sees the list; only admins add or remove people, change
// roles, switch access off, give a temporary password or set a new one. Staff change only their own password (menu
// under their name). Every change is in the Audit log (passwords never are).
import { useEffect, useRef, useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { ChevronDown, Copy, KeyRound, Lock, Pencil, Power, Trash2, UserPlus } from "lucide-react";
import { useFloating } from "@/components/ui/useFloating";
import { ChangePasswordDialog } from "@/components/UserMenu";
import { api, queryClient } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { ago, dateTime, inr } from "@/lib/format";
import { ErrorState, Field, PageHeader, StatStrip } from "@/components/common";
import { DataTable, type Col } from "@/components/DataTable";
import { Select } from "@/components/ui/Select";
import { Pill } from "@/components/Pill";
import { Dialog, confirmAction, toast } from "@/components/overlays";

type Member = { user_id: number; email: string; name: string; role: "admin" | "staff"; is_active: boolean; must_change_password: boolean; last_sign_in_at: string | null; created_at: string };
const ROLES = [{ value: "staff", label: "Staff" }, { value: "admin", label: "Admin" }];
const ROLE_HELP = "Staff work with products, scraping and reports. Admins also manage Team & access, the scraper connection and the Audit log.";
const refresh = () => queryClient.invalidateQueries({ queryKey: ["team"] });

/** The one moment a temporary password is visible: copy it, send it to the person, close. */
function TemporaryPassword({ who, password, onClose }: { who: Member | null; password: string | null; onClose: () => void }) {
  const message = who && password ? `Hi ${who.name.split(" ")[0]}, you can now sign in to the MDAPL Price Tracker at ${window.location.origin} with ${who.email} and the temporary password ${password}. You will be asked to choose your own password.` : "";
  const copy = async (text: string, what: string) => { try { await navigator.clipboard.writeText(text); toast.success(`${what} copied.`); } catch { toast.error("Copy did not work. Select the text and copy it."); } };
  return (
    <Dialog open={!!password} onClose={onClose} title={`Temporary password for ${who?.name ?? ""}`}
      footer={<><button className="btn" onClick={() => void copy(message, "Message")}><Copy className="h-4 w-4" />Copy message</button><button className="btn-primary" onClick={onClose}>Done</button></>}>
      <p className="text-[13.5px] text-muted">Send this to {who?.email} through a private channel. It is shown only now; if it is lost, reset it again.</p>
      <div className="mt-3 flex items-center gap-2 rounded-lg border border-line bg-surface-alt px-3 py-2.5">
        <code className="flex-1 select-all break-all font-mono text-[16px] tracking-wide text-ink" data-testid="temp-password">{password}</code>
        <button className="btn btn-sm" onClick={() => void copy(password ?? "", "Password")}><Copy className="h-3.5 w-3.5" />Copy</button>
      </div>
      <p className="mt-3 text-[12.5px] text-faint">At their next sign-in they must replace it with their own password before they can do anything else.</p>
    </Dialog>
  );
}

/** An admin sets someone's password directly; by default they choose their own at their next sign-in. */
function SetPassword({ who, onClose }: { who: Member | null; onClose: () => void }) {
  const [pw, setPw] = useState("");
  const [mustChange, setMustChange] = useState(true);
  const m = useMutation({
    mutationFn: () => api(`team/${who!.user_id}/password`, { body: { password: pw, must_change: mustChange } }),
    onSuccess: () => { toast.success(`New password set for ${who!.name}. They are signed out everywhere.`); setPw(""); void refresh(); onClose(); },
  });
  return (
    <Dialog open={!!who} onClose={() => { m.reset(); setPw(""); onClose(); }} title={`Set a password for ${who?.name ?? ""}`}
      footer={<><button className="btn-ghost" onClick={onClose}>Cancel</button><button className="btn-primary" form="set-password" disabled={m.isPending || pw.length < 10}>{m.isPending ? "Saving..." : "Set password"}</button></>}>
      <form id="set-password" className="space-y-3" onSubmit={(e) => { e.preventDefault(); if (!m.isPending) m.mutate(); }}>
        {m.error && <div className="notice notice-danger">{(m.error as Error).message}</div>}
        <Field label="New password" htmlFor="set-pw" hint="At least 10 characters. Their current password stops working and they are signed out everywhere.">
          <input id="set-pw" type="text" className="input font-mono" value={pw} onChange={(e) => setPw(e.target.value)} autoComplete="new-password" spellCheck={false} />
        </Field>
        <label className="inline-flex items-center gap-2 text-[13.5px]"><input type="checkbox" checked={mustChange} onChange={(e) => setMustChange(e.target.checked)} />Ask them to choose their own password at their next sign-in</label>
      </form>
    </Dialog>
  );
}

/** Rename someone (the name shown in the app and in the Audit log). */
function Rename({ who, onClose }: { who: Member | null; onClose: () => void }) {
  const [name, setName] = useState("");
  useEffect(() => { if (who) setName(who.name); }, [who]);
  const m = useMutation({
    mutationFn: () => api(`team/${who!.user_id}`, { method: "PATCH", body: { name: name.trim() } }),
    onSuccess: () => { toast.success("Name saved."); void refresh(); onClose(); },
  });
  return (
    <Dialog open={!!who} onClose={() => { m.reset(); onClose(); }} title="Rename"
      footer={<><button className="btn-ghost" onClick={onClose}>Cancel</button><button className="btn-primary" form="rename" disabled={m.isPending || !name.trim()}>{m.isPending ? "Saving..." : "Save"}</button></>}>
      <form id="rename" onSubmit={(e) => { e.preventDefault(); if (!m.isPending && name.trim()) m.mutate(); }}>
        {m.error && <div className="notice notice-danger mb-3">{(m.error as Error).message}</div>}
        <Field label="Name" htmlFor="rename-name"><input id="rename-name" className="input" value={name} onChange={(e) => setName(e.target.value)} maxLength={120} autoFocus /></Field>
      </form>
    </Dialog>
  );
}

type Action = { label: string; icon: React.ComponentType<{ className?: string }>; onClick: () => void; danger?: boolean; disabled?: string };
/** One "Actions" menu per person, so every row looks the same and nothing is spread across the table. */
function RowActions({ name, actions }: { name: string; actions: Action[] }) {
  const [open, setOpen] = useState(false);
  const btn = useRef<HTMLButtonElement>(null);
  const box = useRef<HTMLDivElement>(null);
  const style = useFloating(open, btn, 320, 230);
  useEffect(() => {
    if (!open) return;
    const away = (e: MouseEvent | KeyboardEvent) => { if (e instanceof KeyboardEvent ? e.key === "Escape" : !box.current?.contains(e.target as Node) && !btn.current?.contains(e.target as Node)) setOpen(false); };
    document.addEventListener("mousedown", away); document.addEventListener("keydown", away);
    return () => { document.removeEventListener("mousedown", away); document.removeEventListener("keydown", away); };
  }, [open]);
  return (
    <>
      <button ref={btn} type="button" className="btn btn-sm" aria-haspopup="menu" aria-expanded={open} aria-label={`Actions for ${name}`} onClick={() => setOpen((o) => !o)}>
        Actions<ChevronDown className="h-3.5 w-3.5 text-faint" />
      </button>
      {open && (
        <div ref={box} role="menu" style={{ ...style, left: Math.max(8, Number(style.left ?? 0) - (230 - (btn.current?.offsetWidth ?? 0))) }} className="pop z-[70] overflow-hidden py-1">
          {actions.map((a) => (
            <button key={a.label} type="button" role="menuitem" disabled={!!a.disabled} title={a.disabled}
              onClick={() => { setOpen(false); a.onClick(); }}
              className={`flex w-full items-center gap-2.5 px-3 py-2 text-left text-[13.5px] transition-colors hover:bg-hover disabled:cursor-not-allowed disabled:opacity-45 ${a.danger ? "text-danger" : "text-ink"}`}>
              <a.icon className={`h-4 w-4 shrink-0 ${a.danger ? "text-danger" : "text-faint"}`} />
              <span className="min-w-0 flex-1">{a.label}{a.disabled && <span className="block text-[11.5px] text-faint">{a.disabled}</span>}</span>
            </button>))}
        </div>)}
    </>
  );
}

function AddPerson({ open, onClose, onAdded }: { open: boolean; onClose: () => void; onAdded: (m: Member, password: string) => void }) {
  const [f, setF] = useState({ name: "", email: "", role: "staff" });
  const m = useMutation({
    mutationFn: () => api<{ user: Member; temporaryPassword: string }>("team", { body: f }),
    onSuccess: (r) => { void refresh(); setF({ name: "", email: "", role: "staff" }); onClose(); onAdded(r.user, r.temporaryPassword); },
  });
  return (
    <Dialog open={open} onClose={() => { m.reset(); onClose(); }} title="Add a person"
      footer={<><button className="btn-ghost" onClick={onClose}>Cancel</button><button className="btn-primary" form="add-person" disabled={m.isPending}>{m.isPending ? "Adding..." : "Add and create password"}</button></>}>
      <form id="add-person" className="space-y-3" onSubmit={(e) => { e.preventDefault(); if (!m.isPending) m.mutate(); }}>
        {m.error && <div className="notice notice-danger">{(m.error as Error).message}</div>}
        <Field label="Name" htmlFor="p-name"><input id="p-name" className="input" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} required autoComplete="off" /></Field>
        <Field label="Work email" htmlFor="p-email"><input id="p-email" type="email" className="input" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} required autoComplete="off" /></Field>
        <Field label="Role" hint={ROLE_HELP}><Select ariaLabel="Role" required value={f.role} onChange={(v) => setF({ ...f, role: v })} options={ROLES} /></Field>
      </form>
    </Dialog>
  );
}

export default function Team() {
  const { user } = useAuth();
  const q = useQuery({ queryKey: ["team"], queryFn: () => api<Member[]>("team") });
  const [adding, setAdding] = useState(false);
  const [shown, setShown] = useState<{ who: Member; password: string } | null>(null);
  const [setting, setSetting] = useState<Member | null>(null);
  const [renaming, setRenaming] = useState<Member | null>(null);
  const [ownPassword, setOwnPassword] = useState(false);
  const isAdmin = user?.role === "admin";
  const remove = useMutation({
    mutationFn: (m: Member) => api(`team/${m.user_id}`, { method: "DELETE" }),
    onSuccess: (_r, m) => { void refresh(); toast.success(`${m.name} was removed.`); },
    onError: (e) => toast.error((e as Error).message),
  });
  const removeFor = async (m: Member) => {
    if (await confirmAction({ title: `Remove ${m.name}?`, tone: "danger", confirmLabel: "Remove",
      body: `${m.email} can no longer sign in, and is taken off this list. Their past changes stay in the Audit log. To give access again later, add them as a new person.` })) remove.mutate(m);
  };
  const patch = useMutation({
    mutationFn: ({ id, body }: { id: number; body: Partial<Member> }) => api<Member>(`team/${id}`, { method: "PATCH", body }),
    onSuccess: (m) => { void refresh(); toast.success(`${m.name} updated.`); },
    onError: (e) => toast.error((e as Error).message),
  });
  const reset = useMutation({
    mutationFn: (m: Member) => api<{ user: Member; temporaryPassword: string }>(`team/${m.user_id}/reset-password`, { body: {} }),
    onSuccess: (r) => { void refresh(); setShown({ who: r.user, password: r.temporaryPassword }); },
    onError: (e) => toast.error((e as Error).message),
  });
  const rows = q.data ?? [];
  const active = rows.filter((r) => r.is_active);

  const toggle = async (m: Member) => {
    if (m.is_active && !(await confirmAction({ title: `Switch off access for ${m.name}?`, body: "They are signed out at once and cannot sign in until access is switched back on. Their past changes stay in the Audit log.", confirmLabel: "Switch off", tone: "danger" }))) return;
    patch.mutate({ id: m.user_id, body: { is_active: !m.is_active } });
  };
  const resetFor = async (m: Member) => {
    if (await confirmAction({ title: `New temporary password for ${m.name}?`, body: "Their current password stops working and they are signed out everywhere.", confirmLabel: "Create temporary password" })) reset.mutate(m);
  };

  const COLS: Col<Member>[] = [
    { key: "name", label: "Name", grow: true, render: (m) => <span className="font-medium">{m.name}{m.user_id === user?.id && <span className="ml-1.5 text-[12px] font-normal text-faint">(you)</span>}</span> },
    { key: "email", label: "Email" },
    { key: "role", label: "Role", render: (m) => !isAdmin || m.user_id === user?.id || !m.is_active ? <Pill tone={m.role === "admin" ? "success" : "neutral"}>{m.role === "admin" ? "Admin" : "Staff"}</Pill>
      : <Select size="sm" className="w-28" ariaLabel={`Role of ${m.name}`} required value={m.role} onChange={(v) => v !== m.role && patch.mutate({ id: m.user_id, body: { role: v as Member["role"] } })} options={ROLES} /> },
    { key: "is_active", label: "Access", render: (m) => !m.is_active ? <Pill tone="warning">Switched off</Pill> : m.must_change_password ? <Pill tone="info">Temporary password</Pill> : <Pill tone="success">Active</Pill> },
    { key: "last_sign_in_at", label: "Last sign-in", kind: "datetime", render: (m) => m.last_sign_in_at ? <span title={dateTime(m.last_sign_in_at)}>{ago(m.last_sign_in_at)}</span> : <span className="text-faint">Never</span> },
    ...(isAdmin ? [{ key: "user_id", label: "", align: "right" as const, render: (m: Member) => {
      const self = m.user_id === user?.id;
      const off = !m.is_active;
      const acts: Action[] = [
        { label: "Rename", icon: Pencil, onClick: () => setRenaming(m) },
        ...(self ? [{ label: "Change my password", icon: Lock, onClick: () => setOwnPassword(true) }] : [
          { label: "Temporary password", icon: KeyRound, onClick: () => void resetFor(m), disabled: off ? "Switch access on first" : undefined },
          { label: "Set password", icon: Lock, onClick: () => setSetting(m), disabled: off ? "Switch access on first" : undefined },
        ]),
        { label: m.is_active ? "Switch off access" : "Switch access on", icon: Power, onClick: () => void toggle(m), danger: m.is_active, disabled: self ? "You cannot switch off yourself" : undefined },
        { label: "Remove", icon: Trash2, onClick: () => void removeFor(m), danger: true, disabled: self ? "Another admin can remove you" : undefined },
      ];
      return <RowActions name={m.name} actions={acts} />;
    } }] : []),
  ];

  return (
    <div className="page">
      <PageHeader title="Team & access" subtitle={isAdmin ? "Who can sign in, and what they can do." : "Who can sign in. Only admins can add people or change access; change your own password from the menu under your name."}>
        {isAdmin && <button className="btn-primary" onClick={() => setAdding(true)}><UserPlus className="h-4 w-4" />Add a person</button>}
      </PageHeader>
      <StatStrip loading={q.isFetching} items={[
        { label: "People with access", value: q.data ? inr(active.length) : "-" },
        { label: "Admins", value: q.data ? inr(active.filter((r) => r.role === "admin").length) : "-" },
        { label: "Waiting to set a password", value: q.data ? inr(active.filter((r) => r.must_change_password).length) : "-" },
        { label: "Switched off", value: q.data ? inr(rows.length - active.length) : "-" },
      ]} />
      {q.error ? <div className="card"><ErrorState error={q.error} retry={() => q.refetch()} /></div> :
        <DataTable cols={COLS} rows={rows} total={rows.length} rowKey="user_id" loading={q.isLoading} maxHeight="calc(100dvh - 20rem)" empty={{ title: "Nobody yet", hint: "Add the first person." }} />}
      <p className="text-[12.5px] text-faint">{ROLE_HELP}</p>
      <AddPerson open={adding} onClose={() => setAdding(false)} onAdded={(who, password) => setShown({ who, password })} />
      <TemporaryPassword who={shown?.who ?? null} password={shown?.password ?? null} onClose={() => setShown(null)} />
      <SetPassword who={setting} onClose={() => setSetting(null)} />
      <Rename who={renaming} onClose={() => setRenaming(null)} />
      <ChangePasswordDialog open={ownPassword} onClose={() => setOwnPassword(false)} />
    </div>
  );
}
