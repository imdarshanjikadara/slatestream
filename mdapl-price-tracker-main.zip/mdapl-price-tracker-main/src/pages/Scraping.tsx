// Scraping (the old app screen "Scraping"): channel links with on-demand scraping of the selected links, and a full run
// ("Create Scrape Run + Batches").
import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { useMutation, useQuery } from "@tanstack/react-query";
import { CalendarClock, CirclePause, Play, ScanSearch } from "lucide-react";
import { scrapeSeconds } from "../../shared/estimate";
import { api, qs, queryClient, useList } from "@/lib/api";
import { useUrlState } from "@/lib/hooks";
import { ago, channelLabel, dateTime, duration, inr, titleCase } from "@/lib/format";
import { Field, Notice, PageHeader, StatStrip, Tabs, ErrorState } from "@/components/common";
import { DataTable, ExportMenu, type Col } from "@/components/DataTable";
import { FilterBar, SearchBox } from "@/components/FilterBar";
import { Select } from "@/components/ui/Select";
import { ActiveStatus } from "@/components/Pill";
import { Dialog, toast } from "@/components/overlays";
import { useLookups } from "./Products";
import { BulkEditDialog } from "./ProductBulk";

// "all" is every channel at once: the list shows each link's channel, and a run is created per channel.
const CHANNELS = ["all", "amazon", "flipkart", "instamart", "zepto"];
const SCRAPEABLE = new Set(["all", "amazon", "flipkart", "instamart", "zepto"]);
const chLabel = (c: string) => (c === "all" ? "All channels" : channelLabel(c));

const COLS: Col[] = [
  { key: "product_link_id", label: "Link", kind: "int", align: "left", className: "text-faint" },
  { key: "product_name", label: "Product name", grow: true, render: (r) => <span className="font-medium">{r.product_name ?? <span className="text-faint">No product</span>}</span> },
  { key: "channel_name", label: "Channel", value: (r) => channelLabel(r.channel_name) },
  { key: "brand", label: "Brand", value: (r) => titleCase(r.brand) },
  { key: "category_name", label: "Category", value: (r) => titleCase(r.category_name) },
  { key: "url", label: "URL", kind: "link", edit: { type: "text", required: true } },
  { key: "is_active", label: "Status", value: (r) => (r.is_active && r.product_is_active ? "Active" : "Inactive"), render: (r) => <ActiveStatus active={r.is_active && r.product_is_active} on="Active" off={r.is_active ? "Product off" : "Link off"} />,
    edit: { type: "select", options: [{ value: "true", label: "Link on" }, { value: "false", label: "Link off" }] } },
  { key: "last_scraped_at", label: "Last scraped", kind: "datetime", render: (r) => <span title={dateTime(r.last_scraped_at)}>{r.last_scraped_at ? ago(r.last_scraped_at) : <span className="text-faint">Never</span>}</span> },
  { key: "created_at", label: "Created at", kind: "datetime", exportOnly: true },
  { key: "updated_at", label: "Updated at", kind: "datetime", exportOnly: true },
];

/** The channel's scraping speed and what is already queued, for time estimates before a run starts. */
function useEstimate(channel: string, enabled = true) {
  return useQuery({ queryKey: ["scrape-estimate", channel], queryFn: () => api<{ sec_per_link: number; page_sec: number; concurrency: number; measured: boolean; links_queued: number }>(`scrape/estimate?channel=${channel}`), enabled, staleTime: 30_000 });
}
/** Links are scraped in batches, `concurrency` pages at a time inside a batch. */
const runSeconds = (links: number, batch: number, e: { page_sec: number; concurrency: number }) => {
  let s = 0;
  for (let left = links; left > 0; left -= batch) s += scrapeSeconds(Math.min(batch, left), e.page_sec, e.concurrency);
  return s;
};

/** The daily automatic runs (at each product's time of day, 6:00 AM India time unless set): paused or on, with a switch. */
export function DailyRuns() {
  const q = useQuery({ queryKey: ["scrape-daily"], queryFn: () => api<{ paused: boolean; by?: string; at?: string }>("scrape/daily") });
  const m = useMutation({
    mutationFn: (paused: boolean) => api("scrape/daily", { body: { paused } }),
    onSuccess: (r) => { queryClient.setQueryData(["scrape-daily"], r); toast.success(r.paused ? "Daily automatic runs are paused. Nothing is scraped on its own until you switch them back on." : "Daily automatic runs are back on: products are scraped at their set time again."); },
    onError: (e) => toast.error((e as Error).message),
  });
  if (!q.data) return null;
  const by = q.data.by && q.data.by !== "system" ? ` by ${q.data.by}` : "";
  return q.data.paused ? (
    <div className="card flex flex-wrap items-center gap-3 border-warning-line bg-warning-soft px-4 py-3 text-[13px]" data-testid="daily-runs">
      <CirclePause className="h-5 w-5 shrink-0 text-warning" />
      <div className="min-w-0 flex-1"><div className="font-semibold text-ink">Daily automatic runs are paused</div>
        <div className="text-muted">Automatic runs for products on regular or scheduled scraping are skipped{q.data.at ? ` (paused${by} ${ago(q.data.at)})` : ""}. On-demand and full runs started here still work.</div></div>
      <button className="btn btn-sm" disabled={m.isPending} onClick={() => m.mutate(false)}><Play className="h-4 w-4" />Switch daily runs back on</button>
    </div>
  ) : (
    <div className="flex flex-wrap items-center gap-2 text-[12.5px] text-muted" data-testid="daily-runs">
      <span>Daily automatic runs: products are scraped at their set time of day, 6:00 AM India time unless changed{q.data.at ? ` (on${by} ${ago(q.data.at)})` : ""}.</span>
      <button className="btn-ghost btn-sm" disabled={m.isPending} onClick={() => m.mutate(true)}><CirclePause className="h-4 w-4" />Pause daily runs</button>
    </div>
  );
}
const etaText = (r: { est_seconds?: number; est_wait_seconds?: number }) =>
  r.est_seconds ? ` Estimated time: about ${duration(r.est_seconds)}${r.est_wait_seconds ? `, after about ${duration(r.est_wait_seconds)} waiting for runs ahead of it` : ""}.` : "";

function FullRunDialog({ channel, due, active, open, onClose }: { channel: string; due?: number; active?: number; open: boolean; onClose: () => void }) {
  const est = useEstimate(channel, open);
  const [size, setSize] = useState("20");
  const [mode, setMode] = useState("all");
  const m = useMutation({
    mutationFn: () => api("scrape/runs", { body: { channel, batch_size: Number(size), mode, run_type: "Manual" } }),
    onSuccess: (r) => { onClose();
      if (r.status === "nothing_due") { toast.success(`No ${channelLabel(channel)} products are due today, so no run was created.`); return; }
      toast.success(r.status === "created_many"
        ? <>{inr(r.channels)} runs created, one per channel: {inr(r.link_count)} links in {inr(r.batch_count)} batches.{etaText(r)} <Link className="underline" to="/runs">Follow them in Scrape Run Results</Link></>
        : <>Scrape run #{r.scrape_run_id} created: {inr(r.link_count)} {channelLabel(channel)} links in {inr(r.batch_count)} batches.{etaText(r)} <Link className="underline" to={`/runs/${r.scrape_run_id}`}>Open the run</Link></>);
      void queryClient.invalidateQueries({ queryKey: ["list", "runs"] }); },
  });
  const n = Number(size), valid = Number.isInteger(n) && n >= 1 && n <= 45;
  return (
    <Dialog open={open} onClose={() => { m.reset(); onClose(); }} title={channel === "all" ? "Scrape every channel" : `Scrape all ${channelLabel(channel)} links`}
      footer={<><button className="btn-ghost" onClick={onClose}>Cancel</button><button className="btn-primary" form="full-run" disabled={!valid || m.isPending}>{m.isPending ? "Creating..." : "Start run"}</button></>}>
      <form id="full-run" className="space-y-3" onSubmit={(e) => { e.preventDefault(); if (valid) m.mutate(); }}>
        {m.error && <div className="notice notice-danger">{(m.error as Error).message}</div>}
        <Field label="Links" htmlFor="run-mode">
          <Select ariaLabel="Links" required value={mode} onChange={setMode} options={[{ value: "all", label: "Every active link" }, { value: "scheduled", label: `Only products due today${due !== undefined ? ` (${inr(due)})` : ""}` }]} />
        </Field>
        <p className="text-[13.5px] text-muted">{mode === "all" ? (channel === "all" ? "Every active link of an active product, on every channel, is queued in batches." : `Every active link of an active product on ${channelLabel(channel)} is queued in batches.`) : "Only products with regular scraping, or with a schedule that falls on today, are queued; this is what the daily scheduled run does."}{channel === "all" ? " One run is created per channel, since a run belongs to one channel." : ""} One batch is scraped at a time; progress shows under Scrape Run Results.</p>
        <Field label="Links per batch" hint="1 to 45. Smaller batches finish sooner and are retried more cheaply." htmlFor="batch-size">
          <input id="batch-size" className="input w-28 text-right" inputMode="numeric" value={size} onChange={(e) => setSize(e.target.value.replace(/\D/g, ""))} />
        </Field>
        {(() => {
          const links = mode === "all" ? active : due;
          if (!est.data || links === undefined) return null;
          const run = runSeconds(links, n || 20, est.data), wait = scrapeSeconds(est.data.links_queued, est.data.page_sec, est.data.concurrency);
          return (
            <div className="rounded-lg border border-info-line bg-info-soft px-3 py-2.5 text-[13px] text-ink" data-testid="run-estimate">
              <div className="font-semibold">Estimated time: about {duration(run)}</div>
              <div className="text-muted">{inr(links)} links at about {inr(60 / est.data.sec_per_link, 60 / est.data.sec_per_link < 10 ? 1 : 0)} links a minute, one link at a time{est.data.measured ? ", measured on recent runs with slow pages and retries included" : "; a first estimate that improves as runs finish"}.
                {est.data.links_queued > 0 ? ` ${inr(est.data.links_queued)} links of other runs are queued first: about ${duration(wait)} before this run starts.` : " Nothing else is queued, so it starts right away."}</div>
            </div>);
        })()}
      </form>
    </Dialog>
  );
}

export default function Scraping() {
  const lk = useLookups();
  const [f, set, active] = useUrlState({ channel: "amazon", status: "active", q: "", brand: "", category: "", scraped: "" });
  const params = { channel: f.channel, status: f.status, q: f.q, brand: f.brand, category: f.category, scraped: f.scraped };
  const list = useList("links", params);
  const [sel, setSel] = useState<Set<number>>(new Set());
  const [fullRun, setFullRun] = useState(false);
  useEffect(() => setSel(new Set()), [f.channel]);
  const stats = list.meta?.stats, channels = list.meta?.channels;
  const canScrape = SCRAPEABLE.has(f.channel);
  // The channel of each link matters only when every channel is listed together.
  const cols = useMemo(() => (f.channel === "all" ? COLS : COLS.filter((c) => c.key !== "channel_name")), [f.channel]);
  const filtered = active.some((k) => !["channel", "status"].includes(k));
  const clear = () => set({ q: null, brand: null, category: null, scraped: null });

  const selEst = useEstimate(f.channel, sel.size > 0 && canScrape);
  const scrape = useMutation({
    mutationFn: () => api("scrape/on-demand", { body: { channel: f.channel, link_ids: [...sel] } }),
    onSuccess: (r) => {
      toast.success(r.status === "created_many"
        ? <>Scraping {inr(r.link_count)} links started in {inr(r.channels)} runs, one per channel.{etaText(r)}{r.skipped ? ` ${inr(r.skipped)} switched-off links were left out.` : ""} <Link className="underline" to="/runs">Follow them in Scrape Run Results</Link></>
        : <>Scraping {inr(r.link_count)} {channelLabel(f.channel)} links started (run #{r.scrape_run_id}).{etaText(r)}{r.skipped ? ` ${inr(r.skipped)} switched-off links were left out.` : ""} <Link className="underline" to={`/runs/${r.scrape_run_id}`}>Follow it in Scrape Run Results</Link></>);
      setSel(new Set());
      void queryClient.invalidateQueries({ queryKey: ["list", "runs"] });
    },
    onError: (e) => toast.error((e as Error).message),
  });
  // Update Scraping Schedule: the products behind the ticked links, else behind every link matching the filters.
  const [schedule, setSchedule] = useState<{ ids: number[]; open: boolean; loading: boolean; scope: string }>({ ids: [], open: false, loading: false, scope: "" });
  const openSchedule = async () => {
    setSchedule((s) => ({ ...s, loading: true }));
    try {
      const ids = await api<number[]>(`links${qs(sel.size ? { channel: f.channel, ids: "products", links: [...sel].join(",") } : { ...params, ids: "products" })}`);
      if (!ids.length) { toast.error("No products match these links."); setSchedule((s) => ({ ...s, loading: false })); return; }
      setSchedule({ ids, open: true, loading: false, scope: sel.size ? `the ${inr(sel.size)} ticked ${f.channel === "all" ? "" : `${channelLabel(f.channel)} `}links` : `every ${f.channel === "all" ? "" : `${channelLabel(f.channel)} `}link in this list` });
    } catch (e) { toast.error((e as Error).message); setSchedule((s) => ({ ...s, loading: false })); }
  };
  const selectAllMatching = async () => {
    try { const ids = await api<number[]>(`links${qs({ ...params, ids: 1 })}`); setSel(new Set(ids)); }
    catch (e) { toast.error((e as Error).message); }
  };

  return (
    <div className="page">
      <PageHeader title="Channel Scraping" subtitle="Scrape selected links now, or queue a full run of a channel.">
        <button className="btn" onClick={() => void openSchedule()} disabled={schedule.loading} title={sel.size ? "Change the schedule of the products behind the ticked links" : "Change the schedule of every product in this list"}>
          <CalendarClock className="h-4 w-4" />{schedule.loading ? "Loading..." : "Update Scraping Schedule"}</button>
        <ExportMenu endpoint="links" params={params} cols={cols} title={`${chLabel(f.channel)} links`} selected={sel} rowKey="product_link_id" />
        <button className="btn-primary" disabled={!canScrape} onClick={() => setFullRun(true)}><Play className="h-4 w-4" />Start full run</button>
      </PageHeader>
      <DailyRuns />
      <Tabs ariaLabel="Channel" active={f.channel} onChange={(k) => set({ channel: k })} items={CHANNELS.map((c) => ({ key: c, label: chLabel(c), count: c === "all" ? (channels ? Object.values(channels as Record<string, number>).reduce((a, b) => a + b, 0) : null) : channels?.[c] ?? (channels ? 0 : null) }))} />
      <StatStrip loading={list.isFetching} items={[
        { label: "Total links available", value: stats ? inr(stats.all) : "-" },
        { label: "Active links", value: stats ? inr(stats.active) : "-" },
        { label: "Due in today's scheduled run", value: stats ? inr(stats.due) : "-" },
        { label: "Scraped today", value: stats ? inr(stats.today) : "-" },
        { label: "Never scraped", value: stats ? inr(stats.never) : "-", tone: stats?.never ? "warning" : undefined },
      ]} />
      {!canScrape && <Notice tone="neutral">Scraping is available for Amazon, Flipkart, Instamart and Zepto; there is no {channelLabel(f.channel)} scraper yet. You can still tick {channelLabel(f.channel)} links to export them or update their products' scraping schedule.</Notice>}
      <FilterBar active={filtered} onClear={clear}>
        <SearchBox value={f.q} onChange={(v) => set({ q: v })} placeholder="Search product name, URL" />
        <Select className="w-full sm:w-40" ariaLabel="Brand" placeholder="All brands" value={f.brand} onChange={(v) => set({ brand: v || null })} options={(lk.brands.data ?? []).map((b) => ({ value: b, label: titleCase(b) }))} />
        <Select className="w-full sm:w-48" ariaLabel="Category" placeholder="All categories" value={f.category} onChange={(v) => set({ category: v || null })} options={(lk.categories.data ?? []).map((c) => ({ value: String(c.id), label: titleCase(c.name) }))} />
        <Select className="w-full sm:w-40" ariaLabel="Status" required value={f.status} onChange={(v) => set({ status: v })} options={[{ value: "active", label: "Active links" }, { value: "inactive", label: "Switched off" }, { value: "all", label: "All links" }]} />
        <Select className="w-full sm:w-44" ariaLabel="Last scraped" placeholder="Any scrape date" value={f.scraped} onChange={(v) => set({ scraped: v || null })} options={[{ value: "today", label: "Scraped today" }, { value: "stale", label: "Not scraped today" }, { value: "never", label: "Never scraped" }]} />
      </FilterBar>
      {sel.size > 0 && (
        <div className="card flex flex-wrap items-center gap-2 border-accent-line bg-accent-soft px-4 py-2.5 text-[13px]">
          <span className="font-medium">{inr(sel.size)} {sel.size === 1 ? "link" : "links"} selected</span>
          {canScrape && selEst.data && <span className="text-muted" title="On-demand runs go before full and scheduled runs">· scraping them takes about {duration(runSeconds(sel.size, 20, selEst.data))}</span>}
          {list.total > sel.size && <button className="btn-ghost btn-sm" onClick={selectAllMatching}>Select all {inr(list.total)} matching</button>}
          <button className="btn-ghost btn-sm" onClick={() => setSel(new Set())}>Clear selection</button>
          <button className="btn-primary btn-sm ml-auto" disabled={!canScrape || scrape.isPending} onClick={() => scrape.mutate()} title={canScrape ? undefined : `No ${channelLabel(f.channel)} scraper yet`}>
            <ScanSearch className="h-4 w-4" />{scrape.isPending ? "Starting..." : f.channel === "all" ? "Scrape selected links" : `Scrape ${channelLabel(f.channel)} Links`}
          </button>
        </div>)}
      {list.error ? <div className="card"><ErrorState error={list.error} retry={() => list.refetch()} /></div> :
        <DataTable cols={cols} rows={list.rows} rowKey="product_link_id" loading={list.isLoading} fetching={list.isFetching} pager={list.pager}
          selected={sel} onSelect={setSel}
          onSave={async (r, ch) => {
            await api(`links/${r.product_link_id}`, { method: "PATCH", body: { ...("url" in ch ? { url: ch.url } : {}), ...("is_active" in ch ? { is_active: ch.is_active === "true" } : {}) } });
            await queryClient.invalidateQueries({ queryKey: ["list", "links"] });
          }}
          filtersActive={filtered || f.status !== "active"} onClearFilters={() => { clear(); set({ status: null }); }}
          empty={{ title: f.channel === "all" ? "No links yet" : `No ${channelLabel(f.channel)} links yet`, hint: "Links are added on the product page, or in bulk with Products > Import." }} />}
      <BulkEditDialog scheduleOnly ids={schedule.ids} open={schedule.open} onClose={() => setSchedule((s) => ({ ...s, open: false }))}
        onDone={() => void queryClient.invalidateQueries({ queryKey: ["list", "links"] })}
        title={`Scraping schedule of ${inr(schedule.ids.length)} ${schedule.ids.length === 1 ? "product" : "products"} (${schedule.scope})`} />
      <FullRunDialog channel={f.channel} due={stats?.due} active={stats?.active} open={fullRun} onClose={() => setFullRun(false)} />
    </div>
  );
}
