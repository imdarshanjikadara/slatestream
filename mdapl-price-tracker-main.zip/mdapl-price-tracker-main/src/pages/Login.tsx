// Sign-in (reference: AuthShell + SignInForm + PasswordField): brand panel, show/hide password, Caps Lock warning.
import { useState } from "react";
import { Navigate, useNavigate, useSearchParams } from "react-router-dom";
import { api, ApiError } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { useFixedTitle } from "@/lib/hooks";

const safeNext = (v: string | null) => (v && /^\/(?!\/|\\)[^\s]*$/.test(v) && !v.startsWith("/login") ? v : "/");

function PasswordField({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const [show, setShow] = useState(false);
  const [caps, setCaps] = useState(false);
  const check = (e: React.KeyboardEvent<HTMLInputElement>) => setCaps(e.getModifierState?.("CapsLock") ?? false);
  return (
    <div>
      <label className="label" htmlFor="password">Password</label>
      <div className="relative">
        <input id="password" name="password" type={show ? "text" : "password"} required autoComplete="current-password" value={value} onChange={(e) => onChange(e.target.value)}
          onKeyUp={check} onKeyDown={check} className="input h-11 pr-16 text-[15px]" aria-describedby={caps ? "password-caps" : undefined} />
        <button type="button" onClick={() => setShow((s) => !s)} aria-pressed={show} aria-controls="password"
          className="absolute inset-y-0 right-1.5 my-1.5 rounded-md px-2.5 text-[12px] font-medium text-muted hover:bg-hover hover:text-ink">{show ? "Hide" : "Show"}</button>
      </div>
      {caps && <p id="password-caps" className="mt-1.5 text-[12px] text-warning">Caps Lock is on.</p>}
    </div>
  );
}

export default function Login() {
  useFixedTitle();
  const { user, demo, refresh } = useAuth();
  const [sp] = useSearchParams();
  const nav = useNavigate();
  const next = safeNext(sp.get("next"));
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);
  if (user && !sp.get("signed_out")) return <Navigate to={next} replace />;

  const notice = sp.get("signed_out") ? { tone: "success", text: "You are signed out." } : sp.get("next") ? { tone: "info", text: "Sign in to continue. Your session may have ended." } : null;
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password) { setError("Enter your email and password."); return; }
    setPending(true); setError(null);
    try {
      await api("auth/login", { body: { email, password } });
      await refresh();
      nav(next, { replace: true });
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not sign in. Try again.");
    } finally { setPending(false); }
  };

  return (
    <main className="grid min-h-dvh bg-surface lg:grid-cols-[minmax(0,1fr)_minmax(0,1.1fr)]">
      <aside className="relative hidden overflow-hidden bg-brand text-white lg:flex lg:flex-col lg:justify-between lg:p-12">
        <svg aria-hidden className="pointer-events-none absolute -bottom-40 -right-40 h-[38rem] w-[38rem] text-white/[0.06]" viewBox="0 0 200 200" fill="none" stroke="currentColor" strokeWidth="0.6">
          <path d="M20 160 L60 110 L95 130 L140 60 L180 85" /><path d="M20 175 L60 135 L95 150 L140 90 L180 110" /><circle cx="140" cy="60" r="4" /><circle cx="60" cy="110" r="4" />
          <rect x="30" y="30" width="140" height="140" rx="6" />
        </svg>
        <div className="relative flex items-center gap-3.5">
          <img src="/brand/mark.svg" alt="" className="h-14 w-14" />
          <div className="leading-tight"><div className="text-[19px] font-bold tracking-[0.08em] text-[#F2C94C]">MADHUKAR</div><div className="text-[12px] font-medium uppercase tracking-[0.12em] text-white/75">Domestic Appliances Pvt. Ltd.</div></div>
        </div>
        <div className="relative max-w-md">
          <h2 className="text-[40px] font-semibold leading-[1.08] tracking-tight">Price Tracker</h2>
          <p className="mt-4 text-[15px] leading-relaxed text-white/80">Product prices, availability and MOP breaches on Amazon, Flipkart, Instamart and Zepto, scraped and checked every day.</p>
        </div>
        <div className="relative text-[12px] text-white/70">Private system for Madhukar Domestic Appliances staff. Activity is recorded.</div>
      </aside>
      <section className="flex min-h-dvh flex-col bg-canvas lg:bg-surface">
        <div className="flex items-center gap-3 bg-brand px-5 py-4 lg:hidden"><img src="/brand/mark.svg" alt="" className="h-9 w-9" />
          <div className="leading-tight"><div className="text-[15px] font-bold tracking-[0.08em] text-[#F2C94C]">MADHUKAR</div><div className="text-[11px] text-white/70">Price Tracker</div></div></div>
        <div className="flex flex-1 items-center justify-center px-5 py-10">
          <div className="w-full max-w-[400px]">
            <h1 className="text-[28px] font-semibold leading-tight tracking-tight text-ink">Sign in</h1>
            <p className="mt-1.5 text-[14px] text-muted">Use your MDAPL work email.</p>
            <form onSubmit={submit} className="mt-7 space-y-4" noValidate>
              {error ? <div role="alert" className="notice notice-danger text-[13.5px]">{error}</div>
                : notice ? <div role="status" className={`notice ${notice.tone === "success" ? "notice-success" : "notice-neutral"} text-[13.5px]`}>{notice.text}</div> : null}
              <div>
                <label className="label" htmlFor="email">Email</label>
                <input id="email" name="email" type="email" required autoComplete="username" autoFocus inputMode="email" autoCapitalize="none" spellCheck={false}
                  value={email} onChange={(e) => setEmail(e.target.value)} className="input h-11 text-[15px]" />
              </div>
              <PasswordField value={password} onChange={setPassword} />
              <button disabled={pending} className="btn-primary h-11 w-full text-[15px]">{pending ? "Signing in..." : "Sign in"}</button>
              <p className="text-center text-[13px] text-faint">No account or forgot the password? Ask an admin.</p>
              {demo && <div className="notice notice-neutral text-[12.5px]">Demo mode: sign in with <span className="font-mono">demo@mdapl.local</span> / <span className="font-mono">demo1234</span>.</div>}
            </form>
          </div>
        </div>
        <p className="px-5 pb-6 text-center text-[12px] text-faint">© {new Date().getFullYear()} MDAPL</p>
      </section>
    </main>
  );
}
