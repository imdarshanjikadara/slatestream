// Scrape Product Results (the old app screen "scrapeProductResults"): the latest scrape of every link in the date range,
// per channel. Split view: results on the left, the selected link's full record and price history on the right.
import { useMemo, useState } from "react";
import { Link, useLocation, useNavigate, useParams } from "react-router-dom";
import { useMutation, useQuery } from "@tanstack/react-query";
import { ExternalLink, ShieldAlert } from "lucide-react";
import { api, queryClient, useList } from "@/lib/api";
import { urlWith, useScrapeWindow, useUrlState } from "@/lib/hooks";
import { channelLabel, dateLong, dateTime, inr, money, pct, titleCase, plural } from "@/lib/format";
import { downloadAs } from "@/lib/exportTable";
import { Card, EmptyState, ErrorState, Field, Loading, Notice, PageHeader, StatStrip, Tabs } from "@/components/common";
import { DataTable, ExportMenu, type Col } from "@/components/DataTable";
import { FilterBar, SearchBox } from "@/components/FilterBar";
import { Select } from "@/components/ui/Select";
import { DateRange } from "@/components/ui/DateRange";
import { Availability, Pill } from "@/components/Pill";
import { NothingSelected, SplitItem, SplitList, SplitView } from "@/components/SplitView";
import { LineChart } from "@/components/Charts";
import { Dialog, toast } from "@/components/overlays";
import { useLookups } from "./Products";
import { MOP_ITEM_COLS } from "./MopReports";
import { alertPrice, isBreach } from "../../shared/pricing";

// "all" lists every channel together, so one export holds the whole scrape.
const CHANNELS = ["all", "amazon", "flipkart", "zepto", "instamart"];
const chLabel = (c: string) => (c === "all" ? "All channels" : channelLabel(c));

// Every column of the old results tables, in the same order, for the Excel / CSV / Print export.
// PDF keeps the columns that fit an A4 landscape page; Excel and CSV carry all of them.
export const RESULT_COLS: Col[] = [
  { key: "product_name", label: "Product Name" },
  { key: "channel_name", label: "Channel", value: (r) => channelLabel(r.channel_name) },
  { key: "brand", label: "Brand", value: (r) => titleCase(r.brand) },
  { key: "category_name", label: "Category name", value: (r) => titleCase(r.category_name), pdf: false },
  { key: "seller", label: "Seller" },
  { key: "price", label: "Price", kind: "money" },
  { key: "availability", label: "Availability" },
  { key: "scraped_mrp", label: "Scraped MRP", kind: "money" },
  { key: "scrape_timestamp", label: "Scrape Timestamp", kind: "datetime" },
  { key: "url", label: "URL", kind: "link" },
  { key: "dealer_landing", label: "Dealer Landing", kind: "money", pdf: false },
  { key: "base_mrp", label: "Base MRP", kind: "money", pdf: false },
  { key: "hana_code", label: "Hana Code", pdf: false },
  { key: "ph", label: "PH", pdf: false },
  { key: "direct_discount", label: "Direct Discount", kind: "pct", pdf: false },
  { key: "rating", label: "Rating", kind: "num", pdf: false },
  { key: "reviews", label: "Reviews", kind: "int", pdf: false },
  { key: "gst_percent", label: "GST", kind: "pct", pdf: false },
  { key: "alert_price", label: "Trigger price", kind: "money" },
  { key: "below_mop", label: "Below MOP", kind: "bool" },
  { key: "discount", label: "Discount", kind: "pct" },
];

function Detail({ id, from, to }: { id: string; from: string; to: string }) {
  const q = useQuery({ queryKey: ["result", id, from, to], queryFn: () => api(`results/${id}?from=${from}&to=${to}`) });
  if (q.isLoading) return <div className="card"><Loading /></div>;
  if (q.error) return <div className="card"><ErrorState error={q.error} retry={() => q.refetch()} /></div>;
  const { link: l, latest: r, history } = q.data;
  const below = !!r && isBreach(r.price, l);
  const priced = (history as any[]).filter((h) => h.price > 0).reverse();
  const HCOLS: Col[] = [
    { key: "created_at", label: "Scraped", kind: "datetime" },
    { key: "price", label: "Price", kind: "money", render: (h) => <span className={isBreach(h.price, l) ? "font-medium text-danger" : ""}>{h.price > 0 ? money(h.price) : "-"}</span> },
    { key: "mrp", label: "Scraped MRP", kind: "money" },
    { key: "discount", label: "Discount", kind: "pct" },
    { key: "availability", label: "Availability", render: (h) => <span className="inline-flex gap-1.5"><Availability v={h.availability} />{isBreach(h.price, l) && <Pill tone="danger">Below MOP</Pill>}</span> },
    { key: "seller", label: "Seller", grow: true },
    { key: "scrape_run_id", label: "Run", render: (h) => <Link to={`/runs/${h.scrape_run_id}`} className="text-ink underline decoration-line-strong underline-offset-2 hover:decoration-ink" onClick={(e) => e.stopPropagation()}>#{h.scrape_run_id}</Link> },
  ];
  return (
    <div className="space-y-4">
      <section className="card p-5">
        <div className="flex flex-wrap items-start gap-3">
          <div className="min-w-0 flex-1 basis-64">
            <div className="text-[12px] text-faint">{channelLabel(l.channel_name)} · link #{l.product_link_id}</div>
            <h2 className="mt-0.5 text-[17px] font-semibold leading-snug text-ink">{l.product_name}</h2>
            <div className="mt-1.5 flex flex-wrap items-center gap-1.5">{r ? <Availability v={r.availability} /> : <Pill>Not scraped in this period</Pill>}{below && <Pill tone="danger">Below MOP</Pill>}{!l.link_is_active && <Pill tone="warning">Link switched off</Pill>}</div>
          </div>
          <div className="flex flex-wrap gap-2">
            <Link to={`/products/${l.product_id}`} className="btn btn-sm">Open product</Link>
            {l.url && <a href={l.url} target="_blank" rel="noopener noreferrer" className="btn btn-sm"><ExternalLink className="h-4 w-4" />Open on {channelLabel(l.channel_name)}</a>}
          </div>
        </div>
        <div className="mt-4 grid grid-cols-2 gap-x-6 gap-y-3 border-t border-line pt-4 sm:grid-cols-4">
          {[["Price", r && r.price > 0 ? money(r.price) : "-"], ["Trigger price", alertPrice(l) > 0 ? money(alertPrice(l)) : "Not set"], ["Scraped MRP", r && r.mrp > 0 ? money(r.mrp) : "-"], ["Discount", r ? pct(r.discount) : "-"]].map(([k, v]) => (
            <div key={k}><div className="text-[12px] text-faint">{k}</div><div className={`mt-0.5 text-[18px] font-medium tabular-nums ${k === "Price" && below ? "text-danger" : "text-ink"}`}>{v}</div></div>))}
        </div>
      </section>
      <div className="grid gap-4 xl:grid-cols-2">
        <Card title="Scrape details">
          <dl className="dl">
            <dt>Seller</dt><dd>{r?.seller ?? "-"}</dd>
            <dt>Scrape timestamp</dt><dd>{r ? dateTime(r.created_at) : "-"}</dd>
            <dt>Rating</dt><dd>{r ? inr(r.rating, 1) : "-"}</dd>
            <dt>Reviews</dt><dd>{r ? inr(r.reviews) : "-"}</dd>
            <dt>URL</dt><dd>{l.url ? <a href={l.url} target="_blank" rel="noopener noreferrer" title={l.url} className="inline-flex items-center gap-1 font-medium text-info hover:underline">URL<ExternalLink className="h-3 w-3" /></a> : "-"}</dd>
          </dl>
        </Card>
        <Card title="Product">
          <dl className="dl">
            <dt>Brand</dt><dd>{titleCase(l.brand) || "-"}</dd>
            <dt>Category</dt><dd>{titleCase(l.category_name) || "-"}</dd>
            <dt>Hana code</dt><dd className="font-mono text-[12.5px]">{l.hana_code ?? "-"}</dd>
            <dt>PH</dt><dd>{l.ph ?? "-"}</dd>
            <dt>Base MRP</dt><dd>{money(l.base_mrp)}</dd>
            <dt>Dealer landing</dt><dd>{money(l.dealer_landing)}</dd>
            <dt>Direct discount</dt><dd>{pct(l.direct_discount)}</dd>
            <dt>GST</dt><dd>{pct(l.gst_percent)}</dd>
            <dt>Trigger price</dt><dd>{money(l.trigger_price)}</dd>
          </dl>
        </Card>
      </div>
      <Card title="Price in this period" count={`${dateLong(from)} to ${dateLong(to)}`}>
        <LineChart data={priced.map((h: any) => ({ x: h.created_at, y: Number(h.price) }))} prefix="₹" height={180} />
      </Card>
      <Card title="Every scrape in this period" count={plural(history.length, "scrape")} bodyClass="">
        <DataTable embedded cols={HCOLS} rows={history} total={history.length} rowKey="scrape_result_id" maxHeight="26rem" empty={{ title: "No scrapes in this period", hint: "Widen the dates to see older scrapes." }} />
      </Card>
    </div>
  );
}

function GenerateDialog({ open, onClose, channel, from, to }: { open: boolean; onClose: () => void; channel: string; from: string; to: string }) {
  const [remarks, setRemarks] = useState("");
  const [format, setFormat] = useState<"xlsx" | "pdf">("xlsx");
  const nav = useNavigate();
  const m = useMutation({
    mutationFn: async () => {
      const rep = await api("mop-reports", { body: { channel, from, to, remarks } });
      const full = await api(`mop-reports/${rep.report_id}`);
      await downloadAs(format, { title: `MOP Breach Report ${channelLabel(channel)} ${dateLong(rep.report_date)}`, sheet: channel.toUpperCase(), cols: MOP_ITEM_COLS, rows: full.items,
        note: `${dateLong(from)} to ${dateLong(to)} · ${rep.breached_products} of ${rep.total_products} below MOP` });
      return rep;
    },
    onSuccess: (rep) => {
      onClose(); setRemarks("");
      void queryClient.invalidateQueries({ queryKey: ["list", "mop-reports"] });
      toast.success(<>MOP breach report saved: {inr(rep.breached_products)} of {inr(rep.total_products)} products below MOP. <button className="underline" onClick={() => nav(`/mop-reports/${rep.report_id}`)}>Open the report</button></>);
    },
  });
  return (
    <Dialog open={open} onClose={() => { m.reset(); onClose(); }} title="Generate MOP Breach Report"
      footer={<><button className="btn-ghost" onClick={onClose}>Cancel</button><button className="btn-primary" form="gen-mop" disabled={m.isPending}>{m.isPending ? "Generating..." : "Generate and download"}</button></>}>
      <form id="gen-mop" className="space-y-3" onSubmit={(e) => { e.preventDefault(); m.mutate(); }}>
        {m.error && <div className="notice notice-danger">{(m.error as Error).message}</div>}
        <p className="text-[13.5px] text-muted">Checks the latest {channelLabel(channel)} price of every active product from {dateLong(from)} to {dateLong(to)} against its MOP. The report is saved under MOP Breach Reports and downloaded as Excel.</p>
        <Field label="Remarks (optional)" htmlFor="remarks"><textarea id="remarks" rows={2} className="input" value={remarks} onChange={(e) => setRemarks(e.target.value)} maxLength={500} /></Field>
        <Field label="Download as">
          <div className="flex gap-2" role="radiogroup" aria-label="Download as">
            {([["xlsx", "Excel"], ["pdf", "PDF"]] as const).map(([v, l]) => (
              <button key={v} type="button" role="radio" aria-checked={format === v} onClick={() => setFormat(v)}
                className={`h-8 rounded-lg border px-3 text-[13px] font-medium ${format === v ? "border-gold-line bg-gold text-on-gold" : "border-line-strong bg-surface text-muted hover:text-ink"}`}>{l}</button>))}
          </div>
        </Field>
      </form>
    </Dialog>
  );
}

export default function Results() {
  const { id } = useParams();
  const nav = useNavigate();
  const loc = useLocation();
  const lk = useLookups();
  const [f, set, active] = useUrlState({ channel: "amazon", from: "", to: "", q: "", brand: "", category: "", product: "", stock: "", mop: "" });
  const w = useScrapeWindow();
  const from = f.from || w.from, to = f.to || w.to;
  const params = { channel: f.channel, from, to, q: f.q, brand: f.brand, category: f.category, product: f.product, stock: f.stock, mop: f.mop };
  const list = useList("results", params, w.ready);
  const products = useQuery({ queryKey: ["lookup", "products", f.category, f.channel], queryFn: () => api<{ id: number; name: string }[]>(`lookups/products?channel=${f.channel}${f.category ? `&category=${f.category}` : ""}`), staleTime: 300_000 });
  const [gen, setGen] = useState(false);
  const s = list.meta?.stats, ch = list.meta?.channels;
  const filtered = active.some((k) => !["channel", "from", "to"].includes(k));
  const clear = () => set({ q: null, brand: null, category: null, product: null, stock: null, mop: null });
  const open = (linkId: number) => nav(`/results/${linkId}${loc.search}`);
  const cols = useMemo(() => (f.channel === "all" ? RESULT_COLS : RESULT_COLS.filter((c) => c.key !== "channel_name")), [f.channel]);

  return (
    <div className="page">
      <PageHeader title="Scrape Product Results" subtitle="The latest scrape of every link in the period, per channel.">
        <ExportMenu endpoint="results" params={params} cols={cols} title={`Scrape results ${chLabel(f.channel)}`} sheet={f.channel === "all" ? "ALL" : f.channel.toUpperCase()} file={`scrape_results_${f.channel}_${to}`} note={`${dateLong(from)} to ${dateLong(to)}`} />
        <button className="btn-primary" onClick={() => setGen(true)} disabled={!list.total || f.channel === "all"}
          title={f.channel === "all" ? "A report covers one channel. Pick a channel tab first." : undefined}><ShieldAlert className="h-4 w-4" />Generate MOP Breach Report</button>
      </PageHeader>
      {w.stale && !f.from && !f.to && <Notice tone="warning">Nothing has been scraped since {dateLong(w.stale)}, so this shows the 7 days up to then.</Notice>}
      <Tabs ariaLabel="Channel" active={f.channel} onChange={(k) => nav(`/results${urlWith(loc.search, { channel: k, product: null }, { channel: "amazon" })}`)} items={CHANNELS.map((c) => ({ key: c, label: chLabel(c), count: ch ? (c === "all" ? Object.values(ch as Record<string, number>).reduce((a, b) => a + b, 0) : ch[c] ?? 0) : null }))} />
      <FilterBar active={filtered} onClear={clear}>
        <DateRange label="Scraped" from={from} to={to} onFrom={(v) => set({ from: v || null })} onTo={(v) => set({ to: v || null })} className="w-full sm:w-auto" />
        <SearchBox value={f.q} onChange={(v) => set({ q: v })} placeholder="Search product, seller" className="w-full sm:w-56" />
        <Select className="w-full sm:w-36" ariaLabel="Brand" placeholder="All brands" value={f.brand} onChange={(v) => set({ brand: v || null })} options={(lk.brands.data ?? []).map((b) => ({ value: b, label: titleCase(b) }))} />
        <Select className="w-full sm:w-44" ariaLabel="Category" placeholder="All categories" value={f.category} onChange={(v) => set({ category: v || null, product: null })} options={(lk.categories.data ?? []).map((c) => ({ value: String(c.id), label: titleCase(c.name) }))} />
        <Select className="w-full sm:w-56" ariaLabel="Product" placeholder="All products" value={f.product} onChange={(v) => set({ product: v || null })} options={(products.data ?? []).map((p) => ({ value: String(p.id), label: p.name }))} />
        <Select className="w-full sm:w-40" ariaLabel="Availability" placeholder="Any availability" value={f.stock} onChange={(v) => set({ stock: v || null })} options={[{ value: "in", label: "In stock" }, { value: "out", label: "Not in stock" }]} />
        <Select className="w-full sm:w-36" ariaLabel="MOP" placeholder="Any price" value={f.mop} onChange={(v) => set({ mop: v || null })} options={[{ value: "below", label: "Below MOP" }]} />
      </FilterBar>
      <StatStrip loading={list.isFetching} items={[
        { label: f.channel === "all" ? "Links scraped" : `${channelLabel(f.channel)} links`, value: s ? inr(s.total) : "-" },
        { label: "In stock", value: s ? inr(s.in_stock) : "-" },
        { label: "Not in stock", value: s ? inr(s.not_in_stock) : "-", tone: s?.not_in_stock ? "warning" : undefined },
        { label: "Below MOP", value: s ? inr(s.below_mop) : "-", tone: s?.below_mop ? "danger" : undefined },
        { label: "Average discount", value: s?.avg_discount !== null && s?.avg_discount !== undefined ? `${inr(s.avg_discount, 1)}%` : "-" },
      ]} />
      {list.error ? <div className="card"><ErrorState error={list.error} retry={() => list.refetch()} /></div> : (
        <SplitView selected={!!id} onBack={() => nav(`/results${loc.search}`)}
          list={<SplitList title="Results" count={plural(list.total, "link")} rows={list.rows} rowKey={(r: any) => r.product_link_id} activeId={id ?? null} onPick={(r: any) => open(r.product_link_id)}
            loading={list.isLoading} fetching={list.isFetching} pager={list.pager}
            empty={filtered ? <EmptyState title="Nothing matches these filters" hint="Results exist, but the filters hide them." action={<button className="btn btn-sm" onClick={clear}>Clear filters</button>} />
              : <EmptyState title={f.channel === "all" ? "No scrapes in this period" : `No ${channelLabel(f.channel)} scrapes in this period`} hint="Pick other dates, or start a run on the Scraping page." />}
            render={(r: any) => (
              <SplitItem title={r.product_name} right={<span className={`text-[13.5px] font-medium tabular-nums ${r.below_mop ? "text-danger" : "text-ink"}`}>{r.price > 0 ? money(r.price) : "-"}</span>}
                meta={<><span className="shrink-0"><Availability v={r.availability} /></span>{r.below_mop && <span className="shrink-0"><Pill tone="danger">Below MOP</Pill></span>}
                  {f.channel === "all" && <span className="shrink-0"><Pill>{channelLabel(r.channel_name)}</Pill></span>}<span className="truncate">{r.seller}</span></>}
                metaRight={dateTime(r.scrape_timestamp)} />)} />}
          detail={id ? <Detail id={id} from={from} to={to} /> : <NothingSelected what="a product link" />} />)}
      <GenerateDialog open={gen} onClose={() => setGen(false)} channel={f.channel} from={from} to={to} />
    </div>
  );
}
