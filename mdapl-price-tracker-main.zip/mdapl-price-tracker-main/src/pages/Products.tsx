// Products (the old app screen "products"): the product master as an editable sheet, every column of the old Google Sheet.
import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { Download, ExternalLink, Pencil, Plus, Trash2, Upload } from "lucide-react";
import { api, qs, queryClient, useList } from "@/lib/api";
import { useUrlState } from "@/lib/hooks";
import { channelLabel, inr, titleCase } from "@/lib/format";
import { EmptyState, PageHeader, StatStrip, Tabs, ErrorState } from "@/components/common";
import { ExportMenu, Pagination, type Col } from "@/components/DataTable";
import { FilterBar, SearchBox } from "@/components/FilterBar";
import { MultiSelect, Select } from "@/components/ui/Select";
import { confirmAction, toast } from "@/components/overlays";
import { BulkEditDialog, downloadMaster } from "./ProductBulk";
import { modeLabel, modeOf } from "@/components/ScrapingMode";
import { GridLegend, ProductGrid, gridColumns } from "./ProductGrid";

export function LinkChip({ channel, url }: { channel: string; url?: string | null }) {
  if (!url) return <span className="pill border-dashed border-line-strong bg-surface text-faint" title={`No ${channelLabel(channel)} link`}>{channelLabel(channel)}</span>;
  return <a href={url} target="_blank" rel="noopener noreferrer" onClick={(e) => e.stopPropagation()} className="pill pill-neutral hover:border-line-hover hover:text-ink" title={url}>{channelLabel(channel)}<ExternalLink className="h-3 w-3" /></a>;
}

export const useLookups = () => ({
  brands: useQuery({ queryKey: ["lookup", "brands"], queryFn: () => api<string[]>("lookups/brands"), staleTime: 300_000 }),
  categories: useQuery({ queryKey: ["lookup", "categories"], queryFn: () => api<{ id: number; name: string }[]>("lookups/categories"), staleTime: 300_000 }),
  phs: useQuery({ queryKey: ["lookup", "phs"], queryFn: () => api<string[]>("lookups/phs"), staleTime: 300_000 }),
});

// Exports carry every column of the sheet; the PDF (landscape, one page wide) keeps the ones marked pdf.
const COLS: Col[] = [
  { key: "product_id", label: "ID", kind: "int", align: "left" },
  { key: "name", label: "Name", grow: true },
  { key: "brand", label: "Brand", value: (r) => titleCase(r.brand) },
  { key: "category_name", label: "Category", value: (r) => titleCase(r.category_name) },
  { key: "hana_code", label: "Hana code", kind: "mono" },
  { key: "ph", label: "PH", pdf: false },
  { key: "is_active", label: "Status", value: (r) => (r.is_active ? "Active" : "Inactive"), pdf: false },
  { key: "scraping_mode", label: "Scraping", value: (r) => modeLabel(modeOf(r)), pdf: false },
  { key: "scraping_schedule_weekly", label: "Weekly days", pdf: false },
  { key: "months_to_scrape", label: "Months", pdf: false },
  { key: "scraping_schedule_monthly", label: "Monthly dates", pdf: false },
  { key: "mrp", label: "MRP", kind: "money" },
  { key: "direct_discount", label: "Direct discount %", kind: "num", pdf: false },
  { key: "dealer_landing", label: "Dealer landing", kind: "money" },
  { key: "dp_margin_percent", label: "DP margin %", kind: "num", pdf: false },
  { key: "mop", label: "MOP", kind: "money" },
  { key: "scheme_1", label: "Scheme 1", kind: "money", pdf: false },
  { key: "scheme_2", label: "Scheme 2", kind: "money", pdf: false },
  { key: "scheme_3", label: "Scheme 3", kind: "money", pdf: false },
  { key: "total_scheme", label: "Total scheme", kind: "money", pdf: false },
  { key: "net_landing", label: "Net landing", kind: "money" },
  { key: "retail_margin_percent", label: "Retail margin %", kind: "num", pdf: false },
  { key: "retail_margin", label: "Retail margin", kind: "money", pdf: false },
  { key: "mop_scheme", label: "MOP scheme", kind: "money" },
  { key: "trigger_price_percent", label: "Trigger %", kind: "num", pdf: false },
  { key: "trigger_price", label: "Trigger price", kind: "money" },
  { key: "gst_percent", label: "GST %", kind: "num", pdf: false },
  { key: "amazon_url", label: "Amazon link", kind: "link", value: (r) => r.amazon_url ?? "", pdfValue: (r) => (r.amazon_url ? "Yes" : "-"), pdfLabel: "Amazon" },
  { key: "flipkart_url", label: "Flipkart link", kind: "link", value: (r) => r.flipkart_url ?? "", pdfValue: (r) => (r.flipkart_url ? "Yes" : "-"), pdfLabel: "Flipkart" },
  { key: "instamart_url", label: "Instamart link", kind: "link", pdf: false },
  { key: "zepto_url", label: "Zepto link", kind: "link", pdf: false },
];

// Tick as many as you like: a product matching any ticked filter is shown.
const LINK_OPTIONS = [
  { value: "any", label: "Has any link" },
  ...["amazon", "flipkart", "instamart", "zepto"].flatMap((c) => [
    { value: `has_${c}`, label: `Has ${channelLabel(c)} link` },
    { value: `no_${c}`, label: `No ${channelLabel(c)} link` }]),
  { value: "missing", label: "No links at all" }];

export default function Products() {
  const nav = useNavigate();
  const lk = useLookups();
  const [f, set, active] = useUrlState({ status: "active", q: "", brand: "", category: "", link: "" });
  const params = { status: f.status, q: f.q, brand: f.brand, category: f.category, link: f.link };
  const list = useList("products", params);
  const counts = list.meta?.counts, stats = list.meta?.stats;
  const filtered = active.some((k) => k !== "status");
  const cols = COLS;
  // The filters in words, for the downloaded file.
  const links = f.link ? f.link.split(",").filter(Boolean) : [];
  const filterNote = [{ active: "Active", inactive: "Inactive", all: "Active and inactive" }[f.status] ?? f.status, f.q && `search "${f.q}"`, f.brand && `brand ${titleCase(f.brand)}`,
    f.category && `category ${titleCase(lk.categories.data?.find((c) => String(c.id) === f.category)?.name ?? f.category)}`,
    links.length && LINK_OPTIONS.filter((o) => links.includes(o.value)).map((o) => o.label.toLowerCase()).join(" or ")].filter(Boolean).join(", ");
  const gridCols = useMemo(() => gridColumns({ brands: lk.brands.data ?? [], categories: lk.categories.data ?? [], phs: lk.phs.data ?? [] }), [lk.brands.data, lk.categories.data, lk.phs.data]);
  const [sel, setSel] = useState<Set<number>>(new Set());
  const [bulk, setBulk] = useState(false);
  const clear = () => set({ q: null, brand: null, category: null, link: null });
  const selectAllMatching = async () => {
    try { setSel(new Set(await api<number[]>(`products${qs({ ...params, ids: 1 })}`))); }
    catch (e) { toast.error((e as Error).message); }
  };

  const deleteSelected = async () => {
    const n = sel.size, what = `${inr(n)} ${n === 1 ? "product" : "products"}`;
    if (!(await confirmAction({ title: `Delete ${what}?`, tone: "danger", confirmLabel: `Delete ${what}`,
      body: `${n === 1 ? "It is" : "They are"} removed with ${n === 1 ? "its" : "their"} channel links and the price history scraped for those links. An admin can restore the products and links from the Audit log within 30 days, but not the price history. To only hide a product, make it inactive instead.` }))) return;
    try {
      const r = await api<{ deleted: number; links: number; results: number }>("products/delete", { body: { ids: [...sel] } });
      toast.success(`${inr(r.deleted)} ${r.deleted === 1 ? "product" : "products"} deleted, with ${inr(r.links)} links and ${inr(r.results)} scraped prices.`);
      setSel(new Set());
      void queryClient.invalidateQueries();
    } catch (e) { toast.error((e as Error).message); }
  };

  return (
    <div className="page">
      <PageHeader title="Products" subtitle="The product master. Click any cell to edit it; prices are recalculated as you save.">
        <button className="btn" onClick={() => void (sel.size ? downloadMaster({ only: [...sel].slice(0, 1500).join(",") }, `${inr(sel.size)} selected products`) : downloadMaster(params, filterNote))} title="The products shown with these filters (or the ticked ones), in the product sheet's layout, ready to edit and import"><Download className="h-4 w-4" />{sel.size ? `Product master (${inr(sel.size)})` : "Product master"}</button>
        <button className="btn" onClick={() => nav(`/products/import${qs(params)}`)}><Upload className="h-4 w-4" />Import</button>
        <ExportMenu endpoint="products" params={params} cols={cols} title="Products" selected={sel} rowKey="product_id" />
        <button className="btn-primary" onClick={() => nav("/products/new")}><Plus className="h-4 w-4" />New product</button>
      </PageHeader>
      <Tabs ariaLabel="Status" active={f.status} onChange={(k) => set({ status: k })} items={[
        { key: "active", label: "Active", count: counts?.active }, { key: "inactive", label: "Inactive", count: counts?.inactive }, { key: "all", label: "All", count: counts?.all }]} />
      <StatStrip loading={list.isFetching} items={[
        { label: "Total Products", value: stats ? inr(stats.total) : "-" },
        { label: "With Amazon link", value: stats ? inr(stats.withAmazon) : "-" },
        { label: "With Flipkart link", value: stats ? inr(stats.withFlipkart) : "-" },
        { label: "Without any link", value: stats ? inr(stats.noLinks) : "-", tone: stats?.noLinks ? "warning" : undefined },
      ]} />
      <FilterBar active={filtered} onClear={clear}>
        <SearchBox value={f.q} onChange={(v) => set({ q: v })} placeholder="Search name, hana code" />
        <Select className="w-full sm:w-44" ariaLabel="Brand" placeholder="All brands" value={f.brand} onChange={(v) => set({ brand: v || null })} options={(lk.brands.data ?? []).map((b) => ({ value: b, label: titleCase(b) }))} />
        <Select className="w-full sm:w-52" ariaLabel="Category" placeholder="All categories" value={f.category} onChange={(v) => set({ category: v || null })} options={(lk.categories.data ?? []).map((c) => ({ value: String(c.id), label: titleCase(c.name) }))} />
        <MultiSelect className="w-full sm:w-52" ariaLabel="Links" placeholder="Any links" hint="A product matching any ticked filter is shown."
          value={links} onChange={(v) => set({ link: v.join(",") || null })} options={LINK_OPTIONS} />
      </FilterBar>
      {sel.size > 0 && (
        <div className="card flex flex-wrap items-center gap-2 border-accent-line bg-accent-soft px-4 py-2.5 text-[13px]">
          <span className="font-medium">{inr(sel.size)} {sel.size === 1 ? "product" : "products"} selected</span>
          {list.total > sel.size && <button className="btn-ghost btn-sm" onClick={selectAllMatching}>Select all {inr(list.total)} matching</button>}
          <button className="btn-ghost btn-sm" onClick={() => setSel(new Set())}>Clear selection</button>
          <button className="btn-danger btn-sm ml-auto" onClick={() => void deleteSelected()}><Trash2 className="h-4 w-4" />Delete selected</button>
          <button className="btn-primary btn-sm" onClick={() => setBulk(true)}><Pencil className="h-4 w-4" />Edit selected</button>
        </div>)}
      {list.error ? <div className="card"><ErrorState error={list.error} retry={() => list.refetch()} /></div>
        : !list.isLoading && !list.rows.length
          ? <div className="card"><EmptyState title={filtered ? "No product matches these filters" : "No products yet"} hint={filtered ? "Change or clear the filters." : "Add a product, or import the product master from Excel."}
              action={filtered ? <button className="btn btn-sm" onClick={clear}>Clear filters</button> : <button className="btn btn-sm" onClick={() => nav("/products/import")}>Import from Excel</button>} /></div>
          : <ProductGrid rows={list.rows} loading={list.isLoading} selected={sel} onSelect={setSel} cols={gridCols}
              footer={<Pagination pager={list.pager} />} />}
      <GridLegend />
      <BulkEditDialog ids={[...sel]} open={bulk} onClose={() => setBulk(false)} onDone={() => setSel(new Set())} />
    </div>
  );
}
