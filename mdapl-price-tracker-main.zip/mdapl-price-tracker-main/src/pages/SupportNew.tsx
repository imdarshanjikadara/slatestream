// A new support request in three short steps: what it's about, the details and files, then a review with how
// urgent it is. What the user types stays on this device until it's sent; the page they came from, the browser and
// the app version go with it, unseen.
import { useEffect, useMemo, useRef, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { ArrowLeft, Check, CheckCircle2 } from "lucide-react";
import { api, queryClient } from "@/lib/api";
import { AREAS, CATEGORIES, filePayload, LAST_PAGE, newKey, priorityOf, ref, USER_PRIORITIES } from "@/lib/support";
import { acceptFiles, DropZone, FileChips, pastedFiles } from "@/components/FilePicker";
import { Field, Notice, PageHeader, Spinner } from "@/components/common";
import { Select } from "@/components/ui/Select";
import { toast } from "@/components/overlays";

declare const __APP_VERSION__: string;
const DRAFT = "support-draft";
// The footer buttons are one size, whatever they say.
const FOOT = "w-28 justify-center sm:w-36";
type Draft = { category: string; title: string; area: string; description: string; priority: string; key: string };
const empty = (category = ""): Draft => ({ category: CATEGORIES.some((c) => c.value === category) ? category : "", title: "", area: "", description: "", priority: "medium", key: newKey() });
const readDraft = (): Draft | null => {
  try { const d = JSON.parse(localStorage.getItem(DRAFT) ?? "null"); return d?.key ? { ...d, priority: d.priority === "high" ? "high" : "medium" } : null; } catch { return null; }
};

function device() {
  const ua = navigator.userAgent;
  const browser = /Edg\//.test(ua) ? "Edge" : /Firefox\//.test(ua) ? "Firefox" : /Chrome\//.test(ua) ? "Chrome" : /Safari\//.test(ua) ? "Safari" : "Browser";
  const os = /iPhone|iPad/.test(ua) ? "iOS" : /Android/.test(ua) ? "Android" : /Windows/.test(ua) ? "Windows" : /Mac OS X/.test(ua) ? "Mac" : "Linux";
  return { browser: `${browser} ${(ua.match(/(?:Edg|Firefox|Chrome|Version)\/(\d+)/) ?? [])[1] ?? ""}`.trim(), os, screen: `${window.innerWidth}×${window.innerHeight}` };
}

function Radio({ on }: { on: boolean }) {
  return <span className={`grid h-4 w-4 shrink-0 place-items-center rounded-full border ${on ? "border-bronze" : "border-line-hover"}`}>{on && <span className="h-2 w-2 rounded-full bg-bronze" />}</span>;
}
const choice = (on: boolean) => `flex cursor-pointer items-center gap-2.5 rounded-lg border px-3 py-2.5 text-[13.5px] transition-colors ${on ? "border-gold-line bg-accent-soft text-ink shadow-[inset_0_0_0_1px_var(--color-gold-line)]" : "border-line-strong text-muted hover:border-line-hover hover:text-ink"}`;

export default function SupportNew() {
  const nav = useNavigate();
  const [params] = useSearchParams();
  const saved = useMemo(readDraft, []);
  const [d, setD] = useState<Draft>(() => saved ?? empty(params.get("category") ?? ""));
  const [restored, setRestored] = useState(!!saved && !!(saved.title || saved.description));
  const [files, setFiles] = useState<File[]>([]);
  const [step, setStep] = useState(1);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [sending, setSending] = useState<string | null>(null);
  const [done, setDone] = useState<{ id: number; failed: string[] } | null>(null);
  const from = useMemo(() => { try { return sessionStorage.getItem(LAST_PAGE) ?? ""; } catch { return ""; } }, []);
  const ctx = useMemo(() => ({ ...device(), page: from || null, version: __APP_VERSION__.slice(0, 7) }), [from]);
  const top = useRef<HTMLDivElement>(null);
  const set = (x: Partial<Draft>) => { setD((v) => ({ ...v, ...x })); setErrors((e) => Object.fromEntries(Object.entries(e).filter(([k]) => !(k in x)))); };
  useEffect(() => { if (!done) try { localStorage.setItem(DRAFT, JSON.stringify(d)); } catch { /* private mode */ } }, [d, done]);

  const check = (s: number) => {
    const e: Record<string, string> = {};
    if (s >= 1 && !d.category) e.category = "Pick what this is about";
    if (s >= 1 && (d.title.trim().length < 5 || d.title.trim().length > 120)) e.title = "Write a short title, 5 to 120 characters";
    if (s >= 2 && (d.description.trim().length < 10 || d.description.trim().length > 4000)) e.description = "Describe it in at least 10 characters";
    setErrors(e);
    if (Object.keys(e).length) {
      const first = ["category", "title", "description"].find((k) => e[k])!;
      setStep(first === "description" ? 2 : 1);
      requestAnimationFrame(() => document.getElementById(`sup-${first}`)?.focus());
      return false;
    }
    return true;
  };
  const next = () => { if (check(step)) { setStep(step + 1); top.current?.scrollIntoView({ block: "start" }); } };

  const submit = async () => {
    if (!check(3) || sending) return;
    setSending("Sending your request…");
    try {
      const r = await api<{ ticket_id: number }>("support/tickets", { body: { title: d.title.trim(), description: d.description.trim(), category: d.category, priority: d.priority, area: d.area || null, context: ctx, client_key: d.key } });
      const failed: string[] = [];
      for (const [i, f] of files.entries()) {
        setSending(`Uploading ${i + 1} of ${files.length}: ${f.name}`);
        try { await api(`support/tickets/${r.ticket_id}/attachments`, { body: await filePayload(f) }); }
        catch (e) { failed.push(`${f.name}: ${(e as Error).message}`); }
      }
      try { localStorage.removeItem(DRAFT); } catch { /* private mode */ }
      void queryClient.invalidateQueries({ queryKey: ["support"] });
      setDone({ id: r.ticket_id, failed });
    } catch (e) {
      toast.error(`Couldn't send your request: ${(e as Error).message} Your answers are still here.`);
    }
    setSending(null);
  };

  if (done) {
    const p = priorityOf(d.priority);
    return (
      <div className="page page-fill items-center justify-center">
        <div className="card flex w-full max-w-lg flex-col items-center gap-3 px-6 py-10 text-center">
          <CheckCircle2 className="h-10 w-10 text-success" />
          <h1 className="page-title">Request received · {ref(done.id)}</h1>
          <p className="max-w-sm text-[13.5px] text-muted">Our team will reply within <b className="font-semibold text-ink">{p.reply}</b>. You'll get a badge on Help and support in the menu when they do.</p>
          {done.failed.length > 0 && <Notice tone="warning" title="Some files didn't upload" className="w-full text-left">{done.failed.join("; ")}. Attach them again in the conversation.</Notice>}
          <div className="mt-2 flex flex-wrap justify-center gap-2">
            <button className="btn-primary w-48" onClick={() => nav(`/support/${done.id}`)}>Open the conversation</button>
            <button className="btn w-48" onClick={() => nav("/support")}>Back to Support</button>
          </div>
        </div>
      </div>
    );
  }

  const steps = ["What's this about?", "Details", "Review and send"];
  const err = (k: string) => errors[k] && <span className="mt-1 block text-[12px] text-danger">{errors[k]}</span>;
  return (
    <div className="page page-fill mx-auto w-full max-w-4xl" ref={top}>
      <PageHeader title="New request" breadcrumb={[{ to: "/support", label: "Support" }]} subtitle="Tell us what's wrong or what you need. Three short steps." />
      {restored && <Notice tone="info" title="Picking up where you left off" action={<button className="btn btn-sm" onClick={() => { setD(empty()); setFiles([]); setStep(1); setRestored(false); setErrors({}); }}>Start over</button>}>Your earlier draft was kept on this device.</Notice>}

      <div className="card flex min-h-0 flex-1 flex-col">
        <ol className="flex shrink-0 border-b border-line">
          {steps.map((s, i) => {
            const n = i + 1, on = n === step, past = n < step;
            return (
              <li key={s} className="min-w-0 flex-1">
                <button type="button" disabled={n > step} onClick={() => n < step && setStep(n)} aria-current={on ? "step" : undefined}
                  className={`flex w-full items-center gap-2 px-4 py-3 text-left text-[13px] transition-colors disabled:cursor-default ${on ? "text-ink" : past ? "text-muted hover:text-ink" : "text-faint"}`}>
                  <span className={`grid h-6 w-6 shrink-0 place-items-center rounded-full text-[12px] font-semibold ${on ? "bg-gold text-on-gold" : past ? "bg-success-soft text-success" : "bg-surface-alt text-faint"}`}>{past ? <Check className="h-3.5 w-3.5" /> : n}</span>
                  <span className="hidden truncate font-medium sm:block">{s}</span>
                </button>
                <div className={`h-0.5 ${n <= step ? "bg-gold-line" : "bg-line"}`} />
              </li>);
          })}
        </ol>

        <div className="flex min-h-0 flex-1 flex-col gap-5 overflow-y-auto p-5">
          {step === 1 && <>
            <fieldset>
              <legend className="label">What is this about?</legend>
              <div id="sup-category" tabIndex={-1} className="grid gap-2 outline-none sm:grid-cols-2">
                {CATEGORIES.map((c) => (
                  <label key={c.value} className={choice(d.category === c.value)}>
                    <input type="radio" name="category" className="sr-only" checked={d.category === c.value} onChange={() => set({ category: c.value })} />
                    <Radio on={d.category === c.value} />{c.label}
                  </label>))}
              </div>
              {err("category")}
            </fieldset>
            <Field label="Title" htmlFor="sup-title" hint={`${d.title.trim().length}/120. One line, like "MOP report PDF shows no products".`}>
              <input id="sup-title" className="input" value={d.title} maxLength={120} onChange={(e) => set({ title: e.target.value })} placeholder="What's wrong, or what you need" aria-invalid={!!errors.title} />
              {err("title")}
            </Field>
            <Field label="Which part of the app?" hint="Optional, but it helps us look in the right place.">
              <Select ariaLabel="Which part of the app?" value={d.area} onChange={(v) => set({ area: v })} placeholder="Pick a page" options={AREAS.map((a) => ({ value: a, label: a }))} />
            </Field>
          </>}

          {step === 2 && <>
            <div className="flex min-h-[180px] flex-1 flex-col">
              <label className="label" htmlFor="sup-description">Describe it</label>
              <textarea id="sup-description" rows={5} className="input min-h-0 flex-1 resize-none" value={d.description} maxLength={4000} aria-invalid={!!errors.description}
                onChange={(e) => set({ description: e.target.value })} onPaste={(e) => { const p = pastedFiles(e); if (p.length) { e.preventDefault(); setFiles((f) => acceptFiles(p, f)); } }}
                placeholder={d.category === "problem" || d.category === "data"
                  ? "What did you do, what did you expect, and what happened instead? Order numbers help."
                  : "What do you need, and why? An example helps."} />
              <p className="hint">{d.description.trim().length}/4000</p>
              {err("description")}
            </div>
            <div><span className="label">Screenshots and files</span><DropZone files={files} onChange={setFiles} /></div>
          </>}

          {step === 3 && <>
            <div className="rounded-lg border border-line">
              <div className="border-b border-line px-4 py-2.5 text-[12px] font-semibold uppercase tracking-wider text-faint">Review</div>
              <dl className="divide-y divide-line text-[13.5px]">
                {[
                  { k: "About", v: CATEGORIES.find((c) => c.value === d.category)?.label, s: 1 },
                  { k: "Title", v: d.title, s: 1 },
                  { k: "Part of the app", v: d.area || "Not given", s: 1 },
                  { k: "Description", v: <span className="whitespace-pre-wrap">{d.description}</span>, s: 2 },
                  { k: "Files", v: files.length ? <FileChips files={files} /> : "None", s: 2 },
                ].map((r) => (
                  <div key={r.k} className="grid grid-cols-[110px_minmax(0,1fr)_auto] gap-3 px-4 py-2.5 sm:grid-cols-[140px_minmax(0,1fr)_auto]">
                    <dt className="text-faint">{r.k}</dt><dd className="min-w-0 break-words text-ink">{r.v}</dd>
                    <button type="button" className="text-[12.5px] text-muted underline decoration-line-strong underline-offset-2 hover:text-ink" onClick={() => setStep(r.s)}>Edit</button>
                  </div>))}
              </dl>
            </div>
            <fieldset>
              <legend className="label">How urgent is it?</legend>
              <div className="grid gap-2 sm:grid-cols-2">
                {USER_PRIORITIES.map((p) => (
                  <label key={p.value} className={choice(d.priority === p.value)}>
                    <input type="radio" name="priority" className="sr-only" checked={d.priority === p.value} onChange={() => set({ priority: p.value })} />
                    <Radio on={d.priority === p.value} />
                    <span className="min-w-0"><span className="font-medium text-ink">{p.label}</span><span className="text-[12.5px] text-muted"> · {p.when}, reply within {p.reply}</span></span>
                  </label>))}
              </div>
            </fieldset>
          </>}
        </div>

        <div className="flex shrink-0 items-center gap-3 border-t border-line px-5 py-3">
          {step > 1 ? <button className={`btn ${FOOT}`} onClick={() => setStep(step - 1)} disabled={!!sending}><ArrowLeft className="h-4 w-4" />Back</button>
            : <Link to="/support" className={`btn ${FOOT}`}>Cancel</Link>}
          <span className="min-w-0 flex-1 truncate text-center text-[12.5px] text-faint">{sending ?? `Step ${step} of 3`}</span>
          {step < 3 ? <button className={`btn-primary ${FOOT}`} onClick={next}>Next</button>
            : <button className={`btn-primary ${FOOT}`} disabled={!!sending} onClick={() => void submit()}>{sending ? <><Spinner className="h-4 w-4" />Sending…</> : "Send request"}</button>}
        </div>
      </div>
    </div>
  );
}
