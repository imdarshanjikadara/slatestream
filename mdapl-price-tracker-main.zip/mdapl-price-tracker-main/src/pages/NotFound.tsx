import { Link } from "react-router-dom";
import { EmptyState } from "@/components/common";

export default function NotFound() {
  return <div className="card"><EmptyState title="This page does not exist" hint="The link may be old, or the record was removed." action={<Link to="/" className="btn btn-sm">Go to the dashboard</Link>} /></div>;
}
