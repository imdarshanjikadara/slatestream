// Your Schedule: what the daily automatic runs scrape, and at what time of day (6:00 AM India time unless set), at a glance.
// Each product is scraped every day, on a schedule (days of the week, dates of the month, months of the year), or not at all.
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { CalendarClock, CirclePause, Play, Trash2 } from "lucide-react";
import { api, qs, queryClient, useList } from "@/lib/api";
import { useUrlState } from "@/lib/hooks";
import { dateLong, inr, titleCase } from "@/lib/format";
import { Card, ErrorState, PageHeader, Tabs } from "@/components/common";
import { DataTable, ExportMenu, type Col } from "@/components/DataTable";
import { FilterBar, SearchBox } from "@/components/FilterBar";
import { Select } from "@/components/ui/Select";
import { confirmAction, toast } from "@/components/overlays";
import { DAYS, MONTHS, listOf, modeLabel, modeOf, timeLabel } from "@/components/ScrapingMode";
import { BulkEditDialog } from "./ProductBulk";
import { useLookups } from "./Products";
import { DailyRuns } from "./Scraping";

const WEEKDAY = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
const names = (v: unknown, labels: string[]) => listOf(v).map((x) => labels[Number(x) - 1] ?? x).join(", ");

/** The schedule of one product in words. */
/** Taken off the daily run with Stop automatic scraping, but with its days, dates or months kept: Resume puts it back. */
export const isPaused = (r: any) => modeOf(r) === "off" && (!!r.paused_mode || [r.scraping_schedule_weekly, r.scraping_schedule_monthly, r.months_to_scrape].some((v) => listOf(v).length > 0));

export function scheduleText(r: any): string {
  const m = modeOf(r);
  if (isPaused(r)) return `Paused (was: ${scheduleText(r.paused_mode === "regular" ? { ...r, regular_scraping: true } : { ...r, scheduled_scraping: true })})`;
  if (m !== "scheduled") return modeLabel(m);
  const days = names(r.scraping_schedule_weekly, DAYS.map(titleCase)), dates = listOf(r.scraping_schedule_monthly).join(", "), months = names(r.months_to_scrape, MONTHS.map(titleCase));
  const when = [days && `every ${days}`, dates && `on date${listOf(r.scraping_schedule_monthly).length > 1 ? "s" : ""} ${dates}`].filter(Boolean).join(" and ") || "every day";
  return `${when[0].toUpperCase()}${when.slice(1)}${months ? `, in ${months}` : ""}`;
}

const today = () => new Date(Date.now() + 330 * 60_000).toISOString().slice(0, 10);

const COLS: Col[] = [
  { key: "product_id", label: "ID", kind: "int", align: "left", className: "text-faint" },
  { key: "name", label: "Product", grow: true, render: (r) => <span className="font-medium">{r.name}</span> },
  { key: "brand", label: "Brand", value: (r) => titleCase(r.brand) },
  { key: "category_name", label: "Category", value: (r) => titleCase(r.category_name) },
  { key: "mode", label: "Scraping", value: (r) => (isPaused(r) ? "Paused" : modeLabel(modeOf(r))),
    render: (r) => { const m = modeOf(r); if (isPaused(r)) return <span className="pill pill-warning">Paused</span>; return <span className={`pill ${m === "regular" ? "pill-success" : m === "scheduled" ? "pill-info" : "pill-neutral"}`}>{modeLabel(m)}</span>; } },
  { key: "schedule", label: "Schedule", value: (r) => scheduleText(r) },
  { key: "scrape_time", label: "Time", value: (r) => (modeOf(r) === "off" && !isPaused(r) ? "-" : timeLabel(r.scrape_time)) },
  { key: "next_due", label: "Next run", value: (r) => (r.next_due ? `${r.next_due === today() ? "Today" : dateLong(r.next_due)}, ${timeLabel(r.next_time)}` : "-") },
  { key: "links", label: "Active links", kind: "int" },
];

export default function Schedule() {
  const nav = useNavigate();
  const lk = useLookups();
  const [f, set, active] = useUrlState({ mode: "active", q: "", brand: "", category: "" });
  const params = { mode: f.mode, q: f.q, brand: f.brand, category: f.category };
  const list = useList("schedule", params);
  const counts = list.meta?.counts, days = (list.meta as any)?.days as { date: string; dow: number; products: number }[] | undefined;
  const [sel, setSel] = useState<Set<number>>(new Set());
  const [editing, setEditing] = useState<number[] | null>(null);
  const filtered = active.some((k) => k !== "mode");
  const clear = () => set({ q: null, brand: null, category: null });
  const ids = [...sel];
  const what = `${inr(ids.length)} ${ids.length === 1 ? "product" : "products"}`;

  const bulk = async (body: Record<string, unknown>, msg: string) => {
    try { await api("products/bulk", { body: { ids, set: body } }); toast.success(msg); setSel(new Set()); void queryClient.invalidateQueries(); }
    catch (e) { toast.error((e as Error).message); }
  };
  const turnOff = async () => {
    if (!(await confirmAction({ title: `Pause ${what}?`, body: "They leave the daily runs but keep how and when they are scraped. They wait on the Paused tab; tick them there and click Resume to put them back as they were. They can still be scraped on demand meanwhile.", confirmLabel: "Pause" }))) return;
    try {
      const r = await api<{ paused: number; skipped: number }>("schedule/pause", { body: { ids } });
      toast.success(`${inr(r.paused)} ${r.paused === 1 ? "product" : "products"} paused. Find ${r.paused === 1 ? "it" : "them"} on the Paused tab.`);
      if (r.skipped) toast.error(`${inr(r.skipped)} ${r.skipped === 1 ? "product was" : "products were"} not in the daily runs, so not paused.`);
      setSel(new Set()); void queryClient.invalidateQueries();
    } catch (e) { toast.error((e as Error).message); }
  };
  const resume = async () => {
    try {
      const r = await api<{ resumed: number; skipped: number }>("schedule/resume", { body: { ids } });
      if (r.resumed) toast.success(`${inr(r.resumed)} ${r.resumed === 1 ? "product is" : "products are"} back on ${r.resumed === 1 ? "its" : "their"} schedule.`);
      if (r.skipped) toast.error(`${inr(r.skipped)} ${r.skipped === 1 ? "product was" : "products were"} not paused (already scheduled, or no saved schedule). Use Edit schedule for ${r.skipped === 1 ? "it" : "them"}.`);
      setSel(new Set()); void queryClient.invalidateQueries();
    } catch (e) { toast.error((e as Error).message); }
  };
  const remove = async () => {
    if (!(await confirmAction({ title: `Delete the schedule of ${what}?`, body: "They leave the daily run and their days, dates and months are cleared. The products themselves are not deleted.", confirmLabel: "Delete schedule", tone: "danger" }))) return;
    await bulk({ regular_scraping: false, scheduled_scraping: false, scraping_schedule_weekly: [], scraping_schedule_monthly: [], months_to_scrape: [] }, `Schedule of ${what} deleted.`);
  };
  const selectAllMatching = async () => {
    try { setSel(new Set(await api<number[]>(`schedule${qs({ ...params, ids: 1 })}`))); } catch (e) { toast.error((e as Error).message); }
  };

  return (
    <div className="page">
      <PageHeader title="Your Schedule" subtitle="What the daily automatic run scrapes, and when. Tick products to change their schedule.">
        <ExportMenu endpoint="schedule" params={params} cols={COLS} title="Scraping schedule" selected={sel} rowKey="product_id" />
      </PageHeader>
      <DailyRuns />
      <Card title="Next two weeks" count={`products picked up by each daily run${filtered ? ", with these filters" : ""}`}>
        <div className="grid grid-cols-7 gap-1.5 sm:gap-2" data-testid="schedule-days">
          {(days ?? Array.from({ length: 14 }, () => null)).map((d, i) => (
            <div key={i} className={`rounded-lg border px-1.5 py-2 text-center ${i === 0 ? "border-gold-line bg-accent-soft" : "border-line bg-surface"}`}>
              <div className="text-[11px] text-faint">{d ? (i === 0 ? "Today" : WEEKDAY[d.dow - 1]) : " "}</div>
              <div className="text-[12px] text-muted">{d ? dateLong(d.date).slice(0, 6) : "-"}</div>
              <div className="mt-0.5 text-[17px] font-semibold tabular-nums text-ink">{d ? inr(d.products) : "-"}</div>
            </div>))}
        </div>
      </Card>
      <Tabs ariaLabel="Scraping" active={f.mode} onChange={(k) => { setSel(new Set()); set({ mode: k }); }} items={[
        { key: "active", label: "In the daily run", count: counts?.active }, { key: "regular", label: "Every day", count: counts?.regular },
        { key: "scheduled", label: "On a schedule", count: counts?.scheduled }, { key: "paused", label: "Paused", count: counts?.paused }, { key: "off", label: "Not scheduled", count: counts?.off }, { key: "all", label: "All", count: counts?.all }]} />
      <FilterBar active={filtered} onClear={clear}>
        <SearchBox value={f.q} onChange={(v) => set({ q: v })} placeholder="Search name, hana code" />
        <Select className="w-full sm:w-44" ariaLabel="Brand" placeholder="All brands" value={f.brand} onChange={(v) => set({ brand: v || null })} options={(lk.brands.data ?? []).map((b) => ({ value: b, label: titleCase(b) }))} />
        <Select className="w-full sm:w-52" ariaLabel="Category" placeholder="All categories" value={f.category} onChange={(v) => set({ category: v || null })} options={(lk.categories.data ?? []).map((c) => ({ value: String(c.id), label: titleCase(c.name) }))} />
      </FilterBar>
      {sel.size > 0 && (
        <div className="card flex flex-wrap items-center gap-2 border-accent-line bg-accent-soft px-4 py-2.5 text-[13px]">
          <span className="font-medium">{what} selected</span>
          {list.total > sel.size && <button className="btn-ghost btn-sm" onClick={selectAllMatching}>Select all {inr(list.total)} matching</button>}
          <button className="btn-ghost btn-sm" onClick={() => setSel(new Set())}>Clear selection</button>
          <span className="ml-auto flex flex-wrap gap-2">
            {(f.mode === "paused" || f.mode === "all") && <button className="btn btn-sm" onClick={() => void resume()} title="Put paused products back as they were"><Play className="h-4 w-4" />Resume</button>}
            {["active", "regular", "scheduled", "all"].includes(f.mode) && <button className="btn btn-sm" onClick={() => void turnOff()} title="Take them off the daily runs, keeping how and when they are scraped"><CirclePause className="h-4 w-4" />Pause (stop automatic scraping)</button>}
            <button className="btn-danger btn-sm" onClick={() => void remove()}><Trash2 className="h-4 w-4" />Delete schedule</button>
            <button className="btn-primary btn-sm" onClick={() => setEditing(ids)}><CalendarClock className="h-4 w-4" />Edit schedule</button>
          </span>
        </div>)}
      {list.error ? <div className="card"><ErrorState error={list.error} retry={() => list.refetch()} /></div> :
        <DataTable cols={COLS} rows={list.rows} rowKey="product_id" loading={list.isLoading} fetching={list.isFetching} pager={list.pager}
          selected={sel} onSelect={setSel} onRowClick={(r) => nav(`/products/${r.product_id}`)} onEdit={(r) => setEditing([r.product_id])} editLabel="Edit this product's schedule"
          filtersActive={filtered} onClearFilters={clear}
          empty={{ title: f.mode === "off" ? "Every active product is scheduled" : f.mode === "paused" ? "Nothing is paused" : "Nothing scheduled here", hint: "Tick links on the Scraping page, or products here, and use Edit schedule." }} />}
      <BulkEditDialog scheduleOnly ids={editing ?? []} open={!!editing} onClose={() => setEditing(null)} onDone={() => setSel(new Set())}
        title={editing ? `Scraping schedule of ${inr(editing.length)} ${editing.length === 1 ? "product" : "products"}` : undefined} />
    </div>
  );
}
