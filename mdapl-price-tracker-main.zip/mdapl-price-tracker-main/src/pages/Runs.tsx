// Scrape Run Results (the old app screen "scrapeRunResults"). Split view: runs on the left, the run with its batches and results on the right.
import { useEffect, useState } from "react";
import { Link, useLocation, useNavigate, useParams } from "react-router-dom";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Ban, CircleCheck, CirclePause, CircleX, Clock, Download, FileText, Hourglass, Pause, Play, RotateCcw, Table2, TriangleAlert } from "lucide-react";
import { groupReasons, reasonOf } from "@/lib/scrapeErrors";
import { api, queryClient, useList } from "@/lib/api";
import { urlWith, useUrlState } from "@/lib/hooks";
import { channelLabel, clock, dateTime, duration, inr, istDayOf, money, titleCase, plural } from "@/lib/format";
import { downloadAs } from "@/lib/exportTable";
import { Card, EmptyState, ErrorState, Loading, PageHeader, Spinner, StatStrip, Tabs } from "@/components/common";
import { DataTable, ExportMenu, type Col } from "@/components/DataTable";
import { FilterBar } from "@/components/FilterBar";
import { DateRange } from "@/components/ui/DateRange";
import { Select } from "@/components/ui/Select";
import { Availability, Pill, RunStatus, runStatus } from "@/components/Pill";
import { NothingSelected, SplitItem, SplitList, SplitView } from "@/components/SplitView";
import { confirmAction, toast } from "@/components/overlays";

const LIST_COLS: Col[] = [
  { key: "run_id", label: "Run ID", kind: "int" },
  { key: "run_date", label: "Run date", kind: "datetime" },
  { key: "status", label: "Status" },
  { key: "created_at", label: "Created at", kind: "datetime" },
  { key: "type", label: "Type" },
  { key: "channel_name", label: "Channel name", value: (r) => channelLabel(r.channel_name) },
  { key: "batches", label: "Batches", kind: "int", total: true },
  { key: "links", label: "Links", kind: "int", total: true },
  { key: "results", label: "Results", kind: "int", total: true },
  { key: "in_stock", label: "In stock", kind: "int", total: true },
];
const RESULT_COLS: Col[] = [
  { key: "product_name", label: "Product", grow: true, render: (r) => <Link to={`/results/${r.product_link_id}`} className="font-medium text-ink hover:underline" onClick={(e) => e.stopPropagation()}>{r.product_name}</Link> },
  { key: "brand", label: "Brand", value: (r) => titleCase(r.brand) },
  { key: "category_name", label: "Category", value: (r) => titleCase(r.category_name), exportOnly: true },
  { key: "price", label: "Price", kind: "money", render: (r) => <span className={r.below_mop ? "font-medium text-danger" : ""}>{r.price > 0 ? money(r.price) : "-"}</span> },
  { key: "mrp", label: "Scraped MRP", kind: "money" },
  { key: "alert_price", label: "Trigger price", kind: "money", exportOnly: true },
  { key: "discount", label: "Discount", kind: "pct" },
  { key: "availability", label: "Availability", render: (r) => <span className="inline-flex gap-1.5"><Availability v={r.availability} />{r.below_mop && <Pill tone="danger">Below MOP</Pill>}</span> },
  { key: "seller", label: "Seller" },
  { key: "rating", label: "Rating", kind: "num", exportOnly: true },
  { key: "reviews", label: "Reviews", kind: "int", exportOnly: true },
  { key: "created_at", label: "Scraped", kind: "datetime" },
  { key: "url", label: "URL", kind: "link", exportOnly: true },
];
const BATCH_COLS: Col[] = [
  { key: "batch_number", label: "Batch", render: (b) => <span className="tabular-nums">{b.batch_number} of {b.batch_total_count}</span> },
  { key: "links", label: "Links", kind: "int" },
  { key: "status", label: "Status", render: (b) => <RunStatus v={b.status} /> },
  { key: "attempt_count", label: "Attempts", kind: "int" },
  { key: "started_at", label: "Started", kind: "datetime" },
  { key: "completed_at", label: "Completed", kind: "datetime" },
  { key: "took", label: "Took", value: (b) => (b.started_at && b.completed_at ? duration((new Date(b.completed_at).getTime() - new Date(b.started_at).getTime()) / 1000) : null) },
  { key: "error_message", label: "Note", grow: true, render: (b) => b.error_message ? <span className={b.status === "failed" ? "text-danger" : "text-muted"}>{b.error_message}</span> : <span className="text-faint">-</span> },
];

type Queue = { ahead: number; links_ahead: number; busy: boolean; open: number; started_at: string | null; first_result_at: string | null; last_result_at: string | null;
  finished_at: string | null; links_left: number; paused: boolean; sec_per_link: number; page_sec: number; concurrency: number; left_seconds: number; wait_seconds: number;
  speed_measured: boolean; speed_own: boolean };
type Failure = { product_link_id: number; error: string; tries: number; failed_at: string | null; batch_number: number; retrying: boolean; url: string | null; channel_name: string | null; product_id: number | null; product_name: string | null; brand: string | null; hana_code: string | null; category_name: string | null };

const n = (v: number, one: string, many = `${one}s`) => `${inr(v)} ${v === 1 ? one : many}`;
const toneBox: Record<string, string> = {
  info: "border-info-line bg-info-soft", success: "border-success-line bg-success-soft", warning: "border-warning-line bg-warning-soft",
  danger: "border-danger-line bg-danger-soft", neutral: "border-line bg-surface-alt",
};
const toneText: Record<string, string> = { info: "text-info", success: "text-success", warning: "text-warning", danger: "text-danger", neutral: "text-muted" };

const isLeftStopped = (label: string) => label !== "to do";

/** Scraped, failed and still to do: one bar and one line of counts. */
function Outcome({ scraped, failed, left, total, leftLabel = "to do" }: { scraped: number; failed: number; left: number; total: number; leftLabel?: string }) {
  const pct = (v: number) => (total ? (v / total) * 100 : 0);
  const items = [
    { k: "scraped", v: scraped, cls: "bg-success-fill" },
    { k: "failed", v: failed, cls: "bg-danger-fill" },
    { k: leftLabel, v: left, cls: isLeftStopped(leftLabel) ? "bg-line-strong" : "bg-info-fill/50" },
  ];
  return (
    <div data-testid="run-outcome">
      <div className="flex h-2 overflow-hidden rounded-full bg-track">
        {items.map((x) => x.v > 0 && <div key={x.k} className={`h-2 ${x.cls} transition-[width]`} style={{ width: `${pct(x.v)}%` }} />)}
      </div>
      <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-[12.5px] text-muted">
        {items.filter((x) => x.v > 0).map((x) => <span key={x.k} className="inline-flex items-center gap-1.5"><span className={`h-2 w-2 rounded-full ${x.cls}`} />
          <span className={`font-medium tabular-nums ${x.k === "failed" ? "text-danger" : "text-ink"}`}>{inr(x.v)}</span>{x.k}</span>)}
      </div>
    </div>
  );
}

/** The run's state in one line, progress, timing and what happened when. */
type Now = { product_link_id: number; try: number; started_at: string; batch_number: number; product_name: string | null } | null;

/** The one link loading right now, with a ticking timer (links are scraped one at a time). */
function NowLoading({ now }: { now: NonNullable<Now> }) {
  const [, tick] = useState(0);
  useEffect(() => { const t = setInterval(() => tick((x) => x + 1), 1000); return () => clearInterval(t); }, []);
  const sec = Math.max(0, Math.round((Date.now() - new Date(now.started_at).getTime()) / 1000));
  return (
    <div className="flex items-center gap-2.5 rounded-lg border border-line bg-surface px-3 py-2 text-[13px]" data-testid="now-loading">
      <Spinner className="h-4 w-4 shrink-0" />
      <span className="shrink-0 text-faint">Now loading</span>
      <span className="min-w-0 flex-1 truncate font-medium text-ink" title={now.product_name ?? undefined}>{now.product_name ?? `Link ${now.product_link_id}`}</span>
      {now.try > 1 && <Pill tone="warning">Try {now.try} of 3</Pill>}
      <span className={`shrink-0 tabular-nums ${sec > 45 ? "text-warning" : "text-muted"}`}>{sec} s</span>
    </div>
  );
}

function Status({ r, q, batches, failures, now }: { r: any; q: Queue; batches: any[]; failures: Failure[]; now?: Now }) {
  const open = r.batches_open > 0;
  const running = batches.find((b) => b.status === "running");
  const isAborted = String(r.status).toLowerCase() === "aborted";
  const failedTried = failures.filter((f) => !f.retrying).length;
  const scraped = r.results, left = open ? q.links_left : isAborted ? Math.max(0, r.links - scraped - failedTried) : 0;
  const failed = Math.max(0, r.links - scraped - left);
  const reasons = groupReasons(failures.filter((f) => !f.retrying).map((f) => f.error));
  const waitSec = open && !q.paused && !(running && q.busy) && q.ahead > 0 ? q.wait_seconds : 0;
  const leftSec = q.left_seconds;
  const finishAt = new Date(Date.now() + (waitSec + leftSec) * 1000).toISOString();
  const elapsed = q.started_at ? ((open ? Date.now() : new Date(q.finished_at ?? q.last_result_at ?? q.started_at).getTime()) - new Date(q.started_at).getTime()) / 1000 : null;
  const why = reasons.map((x) => `${x.title.toLowerCase()} (${inr(x.n)})`).join(", ");
  // Finished: how long it took and when, in one line.
  const took = elapsed !== null ? ` in ${duration(elapsed)}${q.started_at ? ` · ${clock(q.started_at)} to ${clock(q.finished_at ?? q.last_result_at)}` : ""}` : "";
  const retryingNow = failures.filter((f) => f.retrying).length;
  const perMin = q.sec_per_link > 0 ? 60 / q.sec_per_link : 0;
  // Nothing saved for a while although a batch is running: say so plainly instead of a spinner that never changes.
  const lastAt = q.last_result_at ?? q.started_at;
  const idleSec = lastAt ? (Date.now() - new Date(lastAt).getTime()) / 1000 : 0;
  const stuck = open && !q.paused && !!running && idleSec > 300;

  const state =
    isAborted && !open ? { tone: "danger", icon: <Ban className="h-4 w-4" />, title: "Aborted", text: `${n(scraped, "link")} scraped, ${inr(left)} not scraped. "Scrape the rest" starts them again.` }
    : isAborted ? { tone: "danger", icon: <Spinner className="h-4 w-4" />, title: "Aborting", text: "Pages loading now finish; nothing new starts." }
    : q.paused ? { tone: "warning", icon: <CirclePause className="h-4 w-4" />, title: "Paused", text: "Press Resume to carry on where it stopped." }
    : !open && !r.links ? { tone: "neutral", icon: <Clock className="h-4 w-4" />, title: "No links", text: "" }
    : !open && failed === 0 ? { tone: "success", icon: <CircleCheck className="h-4 w-4" />, title: "Finished", text: `${inr(scraped)} of ${n(r.links, "link")} scraped${took}` }
    : !open && scraped === 0 ? { tone: "danger", icon: <CircleX className="h-4 w-4" />, title: "Failed", text: `No link could be scraped${why ? `: ${why}` : ""}${took}` }
    : !open ? { tone: "warning", icon: <TriangleAlert className="h-4 w-4" />, title: "Finished", text: `${inr(scraped)} of ${n(r.links, "link")} scraped, ${inr(failed)} failed${why ? ` (${why})` : ""}${took}` }
    : running && q.busy ? { tone: "info", icon: <Spinner className="h-4 w-4" />, title: "Scraping", text: `Batch ${running.batch_number} of ${running.batch_total_count}, one link at a time${retryingNow ? `; ${n(retryingNow, "slow link")} will be tried again` : ""}. Updates every 3 seconds.` }
    : q.ahead > 0 ? { tone: "neutral", icon: <Hourglass className="h-4 w-4" />, title: "Queued", text: `${n(q.links_ahead, "link")} of earlier runs first.` }
    : q.busy ? { tone: "neutral", icon: <Hourglass className="h-4 w-4" />, title: "Queued", text: "Starts when the current batch finishes." }
    : { tone: "neutral", icon: <Spinner className="h-4 w-4" />, title: "Starting", text: "" };

  const tile = (k: string, v: React.ReactNode) => (
    <div key={k}><div className="text-[12px] text-faint">{k}</div><div className="mt-0.5 text-[14px] font-medium tabular-nums text-ink">{v}</div></div>);
  return (
    <div className="space-y-4">
      <div className={`flex items-center gap-2.5 rounded-lg border px-3 py-2 text-[13px] ${toneBox[state.tone]}`} data-testid="run-state">
        <span className={`shrink-0 ${toneText[state.tone]}`}>{state.icon}</span>
        <span className="font-semibold text-ink">{state.title}</span>
        {state.text && <span className="min-w-0 text-muted">{state.text}</span>}
      </div>
      {open && !q.paused && now && <NowLoading now={now} />}
      {open && <Outcome scraped={scraped} failed={failed} left={left} total={r.links} />}
      {stuck && <div className="rounded-lg border border-warning-line bg-warning-soft px-3 py-2 text-[12.5px] text-ink" data-testid="run-slow">
        <span className="font-semibold">No new price for {duration(idleSec)}.</span> <span className="text-muted">Pages are loading slowly through the proxy or Browserless is busy. Slow pages are tried again on a fresh browser (up to 3 tries); nothing needs doing unless this lasts over 15 minutes.</span>
      </div>}
      {open && <div className="grid grid-cols-3 gap-x-6 gap-y-3">
        {tile("Time left", q.paused ? "Paused" : `~${duration(waitSec + leftSec)}`)}
        {tile("Done by", q.paused ? "-" : clock(finishAt))}
        {tile("Speed", <span title="One link at a time; links finished per minute, slow pages and retries included">{`~${inr(perMin, perMin < 10 ? 1 : 0)} links/min`}</span>)}
      </div>}
    </div>
  );
}

/** Links that got no price, grouped by reason in plain words, each with the exact error. */
function Failures({ id, run, failures, onRetry, retrying }: { id: string; run: any; failures: Failure[]; onRetry?: () => void; retrying: boolean }) {
  const groups = groupReasons(failures.filter((f) => !f.retrying).map((f) => f.error));
  const cols: Col[] = [
    { key: "product_name", label: "Product", grow: true, render: (f) => f.product_id ? <Link to={`/products/${f.product_id}`} className="font-medium text-ink hover:underline">{f.product_name}</Link> : <span className="text-faint">Link {f.product_link_id}</span> },
    { key: "product_link_id", label: "Link", kind: "int", align: "left", className: "text-faint" },
    { key: "reason", label: "What went wrong", value: (f) => reasonOf(f.error).title, render: (f) => <span className="inline-flex flex-wrap items-center gap-1.5"><span className="text-danger">{reasonOf(f.error).title}</span>{f.retrying && <Pill tone="info">Trying again</Pill>}</span> },
    { key: "tries", label: "Tries", kind: "int" },
    { key: "failed_at", label: "When", kind: "datetime" },
    { key: "error", label: "Details", render: (f) => <span className="text-[12px] text-faint" title={f.error}>{f.error}</span> },
    { key: "url", label: "URL", kind: "link" },
    { key: "channel_name", label: "Channel", value: (f) => channelLabel(f.channel_name), exportOnly: true },
    { key: "brand", label: "Brand", value: (f) => titleCase(f.brand), exportOnly: true },
    { key: "category_name", label: "Category", value: (f) => titleCase(f.category_name), exportOnly: true },
    { key: "hana_code", label: "Hana code", exportOnly: true },
    { key: "product_id", label: "Product ID", kind: "int", align: "left", exportOnly: true },
    { key: "batch_number", label: "Batch", kind: "int", align: "left", exportOnly: true },
  ];
  return (
    <Card title="Links that could not be scraped" count={plural(failures.length, "link")} bodyClass=""
      actions={<>
        <ExportMenu endpoint={`runs/${id}`} params={{}} cols={cols} rowsOf={(d) => d.failures ?? []} title={`Links that could not be scraped, run ${id}`}
          sheet="FAILED" file={`failed_links_run_${id}`} what="Every link of this run that could not be scraped." note={`${channelLabel(run?.channel_name) || "All channels"} · ${run?.type ?? ""} run of ${dateTime(run?.run_date)}`} />
        {onRetry && <button className="btn btn-sm" onClick={onRetry} disabled={retrying}><RotateCcw className="h-4 w-4" />Retry failed links</button>}
      </>}>
      {groups.length > 0 && (
        <div className="grid gap-2 border-b border-line p-4 sm:grid-cols-2">
          {groups.map((g) => (
            <div key={g.key} className="rounded-lg border border-danger-line bg-danger-soft px-3 py-2 text-[12.5px]">
              <div className="font-semibold text-ink">{g.title} <span className="font-normal text-muted">· {n(g.n, "link")}</span></div>
              <div className="text-muted">{g.hint}</div>
            </div>))}
        </div>)}
      <DataTable embedded cols={cols} rows={failures} total={failures.length} rowKey="product_link_id" maxHeight="24rem" empty={{ title: "No failed links" }} />
    </Card>
  );
}

function Detail({ id }: { id: string }) {
  const nav = useNavigate();
  const openProduct = (pid: number) => nav(`/products/${pid}`);
  const q = useQuery({ queryKey: ["run", id], queryFn: () => api(`runs/${id}`),
    refetchInterval: (query) => { const d = query.state.data as any; return d?.run?.batches_open || (d?.run?.batches > 0 && ["started", "in progress"].includes(String(d?.run?.status ?? "").toLowerCase())) ? (d?.queue?.paused ? 15000 : 3000) : false; } });
  const refresh = () => { void queryClient.invalidateQueries({ queryKey: ["run", id] }); void queryClient.invalidateQueries({ queryKey: ["list", "runs"] }); };
  const retry = useMutation({
    mutationFn: () => api(`runs/${id}/retry`, { method: "POST", body: {} }),
    onSuccess: (r) => { toast.success(r.requeued ? `${n(r.requeued, "failed link")} ${r.requeued === 1 ? "is" : "are"} back in the queue.` : "No failed links to retry."); refresh(); },
    onError: (e) => toast.error((e as Error).message),
  });
  const pause = useMutation({
    mutationFn: () => api(`runs/${id}/pause`, { method: "POST", body: {} }),
    onSuccess: () => { toast.success("Run paused. Pages loading right now finish; no new link starts until you resume."); refresh(); },
    onError: (e) => toast.error((e as Error).message),
  });
  const abort = useMutation({
    mutationFn: () => api(`runs/${id}/abort`, { method: "POST", body: {} }),
    onSuccess: () => { toast.success("Run aborted. Pages loading right now finish; nothing else is scraped."); refresh(); },
    onError: (e) => toast.error((e as Error).message),
  });
  const confirmAbort = async () => {
    if (await confirmAction({ title: `Abort run #${id}?`, tone: "danger", confirmLabel: "Abort run",
      body: "Scraping stops for good: waiting links are dropped and pages loading now finish. Prices already saved are kept. You can scrape the rest later from this page." })) abort.mutate();
  };
  const resume = useMutation({
    mutationFn: () => api(`runs/${id}/resume`, { method: "POST", body: {} }),
    onSuccess: () => { toast.success("Run resumed. It carries on where it stopped."); refresh(); },
    onError: (e) => toast.error((e as Error).message),
  });
  // While this run has work waiting and nothing is scraping, restart the worker (an invocation was cut off at its time
  // limit, or the hand-over to the next one was lost). The server does nothing when a batch is already running.
  const stalled = !!q.data?.run?.batches_open && q.data?.queue && !q.data.queue.busy && !q.data.queue.paused && String(q.data.run.status).toLowerCase() !== "aborted";
  useEffect(() => {
    if (!stalled) return;
    const t = setTimeout(() => void api("scrape/continue", { method: "POST", body: {} }).then(() => q.refetch()).catch(() => {}), 1500);
    return () => clearTimeout(t);
  }, [stalled, q.dataUpdatedAt]); // eslint-disable-line react-hooks/exhaustive-deps
  if (q.isLoading) return <div className="card"><Loading /></div>;
  if (q.error) return <div className="card"><ErrorState error={q.error} retry={() => q.refetch()} /></div>;
  const { run: r, batches, results, queue, failures = [] } = q.data as { run: any; batches: any[]; results: any[]; queue: Queue; failures: Failure[] };
  const open = r.batches_open > 0;
  const failedLinks = failures.filter((f) => !f.retrying).length;
  const isAborted = String(r.status).toLowerCase() === "aborted";
  const canRetry = !open && (failedLinks > 0 || r.batches_failed > 0 || (isAborted && r.results < r.links));
  const download = async (format: "xlsx" | "pdf") => {
    try {
      const all = await api(`runs/${id}?all=1`);
      await downloadAs(format, { title: `Scrape run ${r.run_id} ${channelLabel(r.channel_name)}`, sheet: String(r.channel_name ?? "run").toUpperCase(), cols: RESULT_COLS, rows: all.results, note: `${r.type ?? ""} run of ${dateTime(r.run_date)}` });
    } catch (e) { toast.error((e as Error).message); }
  };
  return (
    <div className="space-y-4">
      <section className="card p-5">
        <div className="flex flex-wrap items-start gap-3">
          <div className="min-w-0 flex-1 basis-64">
            <div className="text-[12px] text-faint">Scrape run #{r.run_id}</div>
            <h2 className="mt-0.5 text-[17px] font-semibold text-ink">{channelLabel(r.channel_name) || "All channels"}, {dateTime(r.run_date)}</h2>
            <div className="mt-1.5 flex flex-wrap gap-1.5"><RunStatus v={!open && ["started", "in progress"].includes(runStatus(r)) && r.batches > 0 ? (r.results > 0 ? "done" : "failed") : runStatus(r)} />{r.type && <Pill>{r.type}</Pill>}
              <Pill>{n(r.batches, "batch", "batches")}</Pill>{r.results > 0 && <Pill>{inr(r.in_stock)} in stock{r.results > r.in_stock ? `, ${inr(r.results - r.in_stock)} out of stock` : ""}</Pill>}</div>
          </div>
          <div className="flex flex-wrap gap-2">
            {open && !queue?.paused && !isAborted && <button className="btn" onClick={() => pause.mutate()} disabled={pause.isPending} data-testid="pause-run"><Pause className="h-4 w-4" />{pause.isPending ? "Pausing..." : "Pause"}</button>}
            {queue?.paused && <button className="btn-primary" onClick={() => resume.mutate()} disabled={resume.isPending} data-testid="resume-run"><Play className="h-4 w-4" />{resume.isPending ? "Resuming..." : "Resume"}</button>}
            {open && !isAborted && <button className="btn text-danger" onClick={() => void confirmAbort()} disabled={abort.isPending} data-testid="abort-run"><Ban className="h-4 w-4" />{abort.isPending ? "Aborting..." : "Abort"}</button>}
            {canRetry && (isAborted || !failures.length) && <button className="btn" onClick={() => retry.mutate()} disabled={retry.isPending}><RotateCcw className="h-4 w-4" />{isAborted ? "Scrape the rest" : "Retry failed links"}</button>}
            <button className="btn" onClick={() => void download("xlsx")} disabled={!r.results}><Download className="h-4 w-4" />Excel</button>
            <button className="btn" onClick={() => void download("pdf")} disabled={!r.results}><FileText className="h-4 w-4" />PDF</button>
            {/* Excel above is this run (one channel). Every channel of that day together lives on Scrape Product Results. */}
            <Link className="btn" to={`/results?channel=all&from=${istDayOf(r.run_date)}&to=${istDayOf(r.run_date)}`} title="The latest price of every link on every channel that day, in one file">
              <Table2 className="h-4 w-4" />Every channel in one file</Link>
          </div>
        </div>
        {queue && r.batches > 0
          ? <div className="mt-4 border-t border-line pt-4"><Status r={r} q={queue} batches={batches} failures={failures} now={(q.data as any).now ?? null} /></div>
          : <div className="mt-4 border-t border-line pt-4 text-[13px] text-muted">{inr(r.results)} results saved. This older run has no batch records, so there is no progress to show.</div>}
      </section>
      {failures.length > 0 && <Failures id={id} run={r} failures={failures} onRetry={canRetry ? () => retry.mutate() : undefined} retrying={retry.isPending} />}
      <Card title="Batches" count={plural(batches.length, "batch", "batches")} bodyClass="">
        <DataTable embedded cols={BATCH_COLS} rows={batches} total={batches.length} rowKey="scrape_batch_id" maxHeight="20rem" empty={{ title: "No batches", hint: "Older runs have no batch records." }} />
      </Card>
      <Card title="Results of this run" count={results.length >= 500 ? `first 500 of ${inr(r.results)}` : plural(results.length, "result")} bodyClass="">
        <DataTable embedded cols={RESULT_COLS} rows={results} total={r.results} rowKey="scrape_result_id" maxHeight="32rem" onEdit={(x: any) => openProduct(x.product_id)} editLabel="Open the product to edit" empty={{ title: open ? (queue?.paused ? "Paused before any price was saved" : "Scraping has not saved results yet") : "No prices saved", hint: open ? "This page refreshes by itself while the run is going." : failures.length ? "Every link failed; see the list above." : undefined }} />
      </Card>
    </div>
  );
}

export default function Runs() {
  const { id } = useParams();
  const nav = useNavigate();
  const loc = useLocation();
  const [f, set, active] = useUrlState({ status: "", channel: "", type: "", from: "", to: "" });
  const params = { status: f.status, channel: f.channel, type: f.type, from: f.from, to: f.to };
  const list = useList("runs", params);
  const s = list.meta?.stats, c = list.meta?.counts as Record<string, number> | undefined;
  const filtered = active.some((k) => k !== "status");
  const clear = () => set({ channel: null, type: null, from: null, to: null });
  const allCount = c ? Object.values(c).reduce((a, b) => a + b, 0) : null;

  return (
    <div className="page">
      <PageHeader title="Scrape Run Results" subtitle="Every scraping run, its batches and what it found.">
        <ExportMenu endpoint="runs" params={params} cols={LIST_COLS} title="Scrape runs" />
        <Link to="/scraping" className="btn-primary">New run</Link>
      </PageHeader>
      <Tabs ariaLabel="Status" active={f.status || "all"} onChange={(k) => nav(`/runs${urlWith(loc.search, { status: k === "all" ? null : k })}`)} items={[
        { key: "all", label: "All", count: allCount }, { key: "started", label: "Started", count: c ? c.started ?? 0 : null }, { key: "in progress", label: "In progress", count: c ? c["in progress"] ?? 0 : null }, { key: "paused", label: "Paused", count: c ? c.paused ?? 0 : null },
        { key: "done", label: "Done", count: c ? c.done ?? 0 : null }, { key: "failed", label: "Failed", count: c ? c.failed ?? 0 : null }, { key: "aborted", label: "Aborted", count: c ? c.aborted ?? 0 : null }]} />
      <FilterBar active={filtered} onClear={clear}>
        <DateRange label="Run" from={f.from} to={f.to} onFrom={(v) => set({ from: v || null })} onTo={(v) => set({ to: v || null })} className="w-full sm:w-auto" />
        <Select className="w-full sm:w-40" ariaLabel="Channel" placeholder="All channels" value={f.channel} onChange={(v) => set({ channel: v || null })} options={["amazon", "flipkart", "instamart", "zepto"].map((x) => ({ value: x, label: channelLabel(x) }))} />
        <Select className="w-full sm:w-40" ariaLabel="Type" placeholder="Any type" value={f.type} onChange={(v) => set({ type: v || null })} options={["Scheduled", "Manual", "On Demand"].map((x) => ({ value: x.toLowerCase(), label: x }))} />
      </FilterBar>
      <StatStrip loading={list.isFetching} items={[
        { label: "Runs", value: s ? inr(s.total) : "-" },
        { label: "Links queued", value: s ? inr(s.links) : "-" },
        { label: "Results saved", value: s ? inr(s.results) : "-" },
        { label: "Failed batches", value: s ? inr(s.failed_batches) : "-", tone: s?.failed_batches ? "danger" : undefined },
      ]} />
      {list.error ? <div className="card"><ErrorState error={list.error} retry={() => list.refetch()} /></div> : (
        <SplitView selected={!!id} onBack={() => nav(`/runs${loc.search}`)}
          list={<SplitList title="Runs" count={plural(list.total, "run")} rows={list.rows} rowKey={(r: any) => r.run_id} activeId={id ?? null} onPick={(r: any) => nav(`/runs/${r.run_id}${loc.search}`)}
            loading={list.isLoading} fetching={list.isFetching} pager={list.pager}
            empty={filtered || f.status ? <EmptyState title="Nothing matches these filters" action={<button className="btn btn-sm" onClick={() => { clear(); set({ status: null }); }}>Clear filters</button>} /> : <EmptyState title="No runs yet" hint="Start one on the Scraping page." />}
            render={(r: any) => (
              <SplitItem title={`Run #${r.run_id} · ${channelLabel(r.channel_name) || "All channels"}`} right={<RunStatus v={runStatus(r)} />}
                meta={<><span>{dateTime(r.run_date)}</span><span>·</span><span className="truncate">{r.type ?? "-"}</span></>}
                metaRight={<>{inr(r.results)} / {inr(r.links)} links{!r.batches_open && r.batches > 0 && r.links > r.results && String(r.status).toLowerCase() !== "aborted" ? <span className="text-danger"> · {inr(r.links - r.results)} failed</span> : null}</>}>
                {r.links > 0 && r.results < r.links && ["started", "in progress", "paused"].includes(runStatus(r)) &&
                  <div className="mt-1.5 h-1 rounded-full bg-track"><div className="h-1 rounded-full bg-bronze" style={{ width: `${Math.round((r.results / r.links) * 100)}%` }} /></div>}
              </SplitItem>)} />}
          detail={id ? <Detail id={id} /> : <NothingSelected what="a run" />} />)}
    </div>
  );
}
