// Shown instead of the app after signing in with a temporary password (new account or reset by an admin).
// The server refuses everything else until the person has set their own password.
import { useAuth } from "@/lib/auth";
import { ChangePasswordForm } from "@/components/UserMenu";

export function SetOwnPassword() {
  const { user, signOut } = useAuth();
  return (
    <main className="grid min-h-dvh place-items-center bg-canvas px-5 py-10">
      <div className="w-full max-w-[420px]">
        <div className="mb-6 flex items-center gap-3">
          <img src="/brand/mark.svg" alt="" className="h-10 w-10" />
          <div className="leading-tight"><div className="text-[15px] font-bold tracking-[0.08em] text-bronze">MADHUKAR</div><div className="text-[12px] text-muted">Price Tracker</div></div>
        </div>
        <section className="card p-6">
          <h1 className="text-[22px] font-semibold tracking-tight text-ink">Choose your own password</h1>
          <p className="mb-4 mt-1.5 text-[13.5px] text-muted">Welcome, {user?.name.split(" ")[0]}. You signed in with a temporary password; replace it to continue.</p>
          <ChangePasswordForm id="set-own-password" first onDone={() => undefined} />
          <button className="btn-primary mt-4 h-10 w-full" form="set-own-password">Set password and continue</button>
        </section>
        <button className="mx-auto mt-4 block text-[13px] text-muted underline-offset-2 hover:underline" onClick={() => void signOut()}>Sign out</button>
      </div>
    </main>
  );
}
