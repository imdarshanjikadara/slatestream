// The product master as an editable sheet: every column of the old Google Sheet, edited in place.
// Click a cell (or move with the arrow keys and press Enter) to edit; Enter or leaving the cell saves, Esc cancels, Tab saves
// and moves right. Each save is one PATCH /api/products/:id (audited), and the calculated prices come back from the server.
import { Fragment, useEffect, useMemo, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { Check, ExternalLink, Loader2, Pencil, SquareArrowOutUpRight } from "lucide-react";
import { api, queryClient } from "@/lib/api";
import { channelLabel, inr, money, titleCase } from "@/lib/format";
import { ChoiceMenu, ComboMenu } from "@/components/ui/ChoiceMenu";
import { toast } from "@/components/overlays";
import { ActiveStatus, Pill } from "@/components/Pill";
import { DAYS, MODES, MONTHS, modeFields, modeLabel, modeOf, type ScrapingMode } from "@/components/ScrapingMode";
import { DERIVED_HELP } from "../../shared/pricing";

type Row = Record<string, any>;
import type { Opt } from "@/components/ui/ChoiceMenu";
type Kind = "id" | "name" | "text" | "combo" | "select" | "money" | "pct" | "bool" | "multi" | "calc" | "link" | "status" | "mode";
export type GridCol = { key: string; label: string; group: string; kind: Kind; w: number; mono?: boolean; options?: () => Opt[]; labels?: string[]; channel?: string; hint?: string };

const GST: Opt[] = [0, 5, 12, 18, 28].map((n) => ({ value: String(n), label: `${n}%` }));
const DATES = Array.from({ length: 31 }, (_, i) => String(i + 1));

/** Column layout of the sheet (same order and names as the product master download). */
export function gridColumns(lookups: { brands: string[]; categories: { id: number; name: string }[]; phs: string[] }): GridCol[] {
  const calc = (key: keyof typeof DERIVED_HELP, label: string): GridCol => ({ key, label, group: "Pricing", kind: "calc", w: 112, hint: DERIVED_HELP[key] });
  return [
    { key: "product_id", label: "ID", group: "Product", kind: "id", w: 64 },
    { key: "name", label: "Name", group: "Product", kind: "name", w: 280 },
    { key: "brand", label: "Brand", group: "Product", kind: "combo", w: 130, options: () => lookups.brands.map((b) => ({ value: b, label: b })) },
    { key: "category_id", label: "Category", group: "Product", kind: "select", w: 170, options: () => lookups.categories.map((c) => ({ value: String(c.id), label: titleCase(c.name) })) },
    { key: "hana_code", label: "Hana code", group: "Product", kind: "text", w: 112, mono: true },
    { key: "ph", label: "PH", group: "Product", kind: "combo", w: 110, options: () => lookups.phs.map((b) => ({ value: b, label: b })) },
    { key: "is_active", label: "Status", group: "Product", kind: "status", w: 104 },
    // Every day (regular) or on a schedule, never both: one column. The schedule columns apply only "On a schedule".
    { key: "scraping_mode", label: "Scraping", group: "Scraping", kind: "mode", w: 132 },
    { key: "scraping_schedule_weekly", label: "Week-wise (days)", group: "Scraping", kind: "multi", w: 150, labels: DAYS, hint: "Days of the week, when scraping is on a schedule" },
    { key: "scraping_schedule_monthly", label: "Month-wise (dates)", group: "Scraping", kind: "multi", w: 140, labels: DATES, hint: "Dates of the month, when scraping is on a schedule" },
    { key: "months_to_scrape", label: "Year-wise (months)", group: "Scraping", kind: "multi", w: 160, labels: MONTHS, hint: "Months of the year (none = every month), when scraping is on a schedule" },
    { key: "mrp", label: "MRP", group: "Pricing", kind: "money", w: 104 },
    { key: "direct_discount", label: "Direct disc. %", group: "Pricing", kind: "pct", w: 96 },
    { key: "dealer_landing", label: "Dealer landing", group: "Pricing", kind: "money", w: 116 },
    { key: "dp_margin_percent", label: "DP margin %", group: "Pricing", kind: "pct", w: 96 },
    calc("mop", "MOP"),
    { key: "scheme_1", label: "Scheme 1", group: "Pricing", kind: "money", w: 96 },
    { key: "scheme_2", label: "Scheme 2", group: "Pricing", kind: "money", w: 96 },
    { key: "scheme_3", label: "Scheme 3", group: "Pricing", kind: "money", w: 96 },
    calc("total_scheme", "Total scheme"),
    calc("net_landing", "Net landing"),
    { key: "retail_margin_percent", label: "Retail margin %", group: "Pricing", kind: "pct", w: 104 },
    calc("retail_margin", "Retail margin"),
    calc("mop_scheme", "MOP scheme"),
    { key: "trigger_price_percent", label: "Trigger %", group: "Pricing", kind: "pct", w: 88 },
    calc("trigger_price", "Trigger price"),
    { key: "gst_percent", label: "GST", group: "Pricing", kind: "select", w: 76, options: () => GST },
    ...["amazon", "flipkart", "instamart", "zepto"].map((c): GridCol => ({ key: `${c}_url`, label: channelLabel(c), group: "Channel links", kind: "link", w: 150, channel: c })),
  ];
}

const EDITABLE = new Set<Kind>(["name", "text", "combo", "select", "money", "pct", "bool", "multi", "link", "status", "mode"]);
const SCHEDULE_PARTS = new Set(["scraping_schedule_weekly", "scraping_schedule_monthly", "months_to_scrape"]);
const MODE_OPTS: Opt[] = MODES.map((m) => ({ value: m.value, label: m.label }));
/** The value a cell shows and edits (the scraping mode comes from two fields). */
const valueOf = (c: GridCol, r: Row) => (c.kind === "mode" ? modeOf(r) : r[c.key]);
const STICKY = 3; // selection box, ID and Name stay in view while scrolling sideways
// Very soft per-channel colours for the link cards.
export const CHANNEL_TONE: Record<string, string> = {
  amazon: "border-[#f3dcae] bg-[#fffaf0] text-[#8a5a00]",
  flipkart: "border-[#cfdcf6] bg-[#f5f8ff] text-[#2747a0]",
  instamart: "border-[#f5d3c3] bg-[#fff7f2] text-[#9a4a1f]",
  zepto: "border-[#ded2f4] bg-[#faf7ff] text-[#5b3fa0]",
};

const list = (v: unknown) => String(v ?? "").split(",").map((s) => s.trim()).filter(Boolean);
const num = (v: unknown) => { const n = Number(v); return v === null || v === undefined || v === "" || !Number.isFinite(n) ? null : n; };

function display(c: GridCol, r: Row): React.ReactNode {
  const v = valueOf(c, r);
  const empty = <span className="text-faint">–</span>;
  // Schedule parts of a product that is not on a schedule do not apply: shown faded.
  if (SCHEDULE_PARTS.has(c.key) && modeOf(r) !== "scheduled") return list(v).length ? <span className="opacity-40" title="Not used: scraping is not on a schedule">{display({ ...c, key: c.key }, { ...r, regular_scraping: false, scheduled_scraping: true })}</span> : empty;
  switch (c.kind) {
    case "mode": return <Pill tone={v === "regular" ? "success" : v === "scheduled" ? "info" : "neutral"}>{modeLabel(v)}</Pill>;
    case "id": return <span className="text-faint tabular-nums">{v}</span>;
    case "money": case "calc": return num(v) === null ? empty : <span className="tabular-nums">{money(v)}</span>;
    case "pct": return num(v) === null ? empty : <span className="tabular-nums">{inr(v, Number.isInteger(Number(v)) ? 0 : 2)}%</span>;
    case "select": {
      if (c.key === "category_id") return r.category_name ? titleCase(r.category_name) : empty;
      return num(v) === null ? empty : `${inr(v)}%`;
    }
    case "bool": return <span className={`inline-grid h-4 w-4 place-items-center rounded border ${v ? "border-bronze bg-bronze text-white" : "border-line-strong bg-surface"}`}>{v && <Check className="h-3 w-3" strokeWidth={3} />}</span>;
    case "status": return <ActiveStatus active={!!v} />;
    case "multi": {
      const on = list(v);
      if (!on.length) return empty;
      const lab = (x: string) => c.labels?.[Number(x) - 1] ?? x;
      const chip = (t: string) => <span key={t} className="rounded-md border border-gold-line/60 bg-gold/15 px-1.5 text-[11px] font-medium leading-5 text-ink">{t}</span>;
      // One line per row: everything chosen reads as a phrase, otherwise the first chips and "+n".
      if (c.labels && on.length === c.labels.length) return chip(c.key === "months_to_scrape" ? "Every month" : c.key === "scraping_schedule_weekly" ? "Every day" : "Every date");
      const room = Math.max(1, Math.floor((c.w - 24) / 46));
      const cut = on.length > room ? room - 1 : on.length;
      return <span className="flex gap-1 whitespace-nowrap" title={on.map(lab).join(", ")}>{on.slice(0, cut).map((x) => chip(lab(x)))}{on.length > cut && <span className="text-[11px] leading-5 text-faint">+{on.length - cut}</span>}</span>;
    }
    case "link": {
      if (!v) return <span className="inline-flex rounded-md border border-dashed border-line-strong px-2 text-[12px] leading-6 text-faint">+ Add link</span>;
      return (
        <span className={`inline-flex max-w-full items-center gap-1.5 rounded-md border px-2 text-[12px] font-medium leading-6 ${CHANNEL_TONE[c.channel!]}`} title={String(v)}>
          <span className="truncate">{channelLabel(c.channel!)}</span>
          <a href={String(v)} target="_blank" rel="noopener noreferrer" onClick={(e) => e.stopPropagation()} aria-label={`Open ${channelLabel(c.channel!)} page`} className="opacity-70 hover:opacity-100"><ExternalLink className="h-3 w-3" /></a>
        </span>);
    }
    default: return v === null || v === undefined || v === "" ? empty : <span className={c.mono ? "font-mono text-[12.5px]" : ""}>{String(v)}</span>;
  }
}

/** What one cell edit sends to PATCH /api/products/:id. */
function patchFor(c: GridCol, value: unknown): Record<string, unknown> {
  if (c.kind === "link") return { links: { [c.channel!]: String(value ?? "").trim() } };
  if (c.kind === "status") return { is_active: value === true || value === "true" };
  if (c.kind === "money" || c.kind === "pct") { const s = String(value ?? "").replace(/[₹,%\s]/g, ""); return { [c.key]: s === "" ? null : s }; }
  if (c.kind === "multi") return { [c.key]: list(value) };
  if (c.kind === "mode") return modeFields(value as ScrapingMode);
  return { [c.key]: value };
}

type Edit = { id: number; key: string; draft: unknown };

export function ProductGrid({ rows, loading, selected, onSelect, cols, maxHeight = "calc(100dvh - 300px)", footer }: {
  rows: Row[]; loading?: boolean; selected: Set<number>; onSelect: (s: Set<number>) => void; cols: GridCol[]; maxHeight?: string; footer?: React.ReactNode;
}) {
  const [over, setOver] = useState<Record<number, Row>>({});      // saved edits on top of the loaded rows
  const [edit, setEdit] = useState<Edit | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [flash, setFlash] = useState<string | null>(null);
  const [focus, setFocus] = useState<{ r: number; c: number } | null>(null);
  const gridRef = useRef<HTMLDivElement>(null);
  const anchor = useRef<HTMLElement | null>(null);
  const shown = useMemo(() => rows.map((r) => (over[r.product_id] ? { ...r, ...over[r.product_id] } : r)), [rows, over]);
  useEffect(() => setOver({}), [rows]);

  const left = (i: number) => [0, 36, 100][i] ?? 0;   // offsets of the sticky columns
  const width = 36 + cols.reduce((s, c) => s + c.w, 0) + 44;
  const groups = useMemo(() => cols.reduce<{ name: string; w: number }[]>((g, c, i) => {
    if (i < 2) return g;      // ID and Name sit under the sticky group cell
    const last = g[g.length - 1];
    if (last?.name === c.group) last.w += c.w; else g.push({ name: c.group, w: c.w });
    return g;
  }, []), [cols]);

  const cellEl = (r: number, c: number) => gridRef.current?.querySelector<HTMLElement>(`[data-r="${r}"][data-c="${c}"]`);
  const move = (r: number, c: number) => {
    const rr = Math.max(0, Math.min(r, shown.length - 1)), cc = Math.max(0, Math.min(c, cols.length - 1));
    setFocus({ r: rr, c: cc });
    requestAnimationFrame(() => cellEl(rr, cc)?.focus());
  };

  const save = async (row: Row, c: GridCol, value: unknown, then?: () => void) => {
    const id = row.product_id, k = `${id}:${c.key}`;
    const before = valueOf(c, row);
    const same = c.kind === "multi" ? list(before).join(",") === list(value).join(",")
      : (c.kind === "money" || c.kind === "pct") ? num(String(value ?? "").replace(/[₹,%\s]/g, "")) === num(before)
      : String(before ?? "") === String(value ?? "");
    setEdit(null);
    if (same) { then?.(); return; }
    // Shown at once; the server's answer (with recalculated prices) replaces it.
    setOver((o) => ({ ...o, [id]: { ...o[id], ...(c.kind === "mode" ? modeFields(value as ScrapingMode) : { [c.key]: c.kind === "multi" ? list(value).join(",") : value }), ...(c.key === "category_id" ? { category_name: c.options?.().find((x) => x.value === String(value))?.label } : {}) } }));
    setBusy(k);
    try {
      const saved = await api<Row>(`products/${id}`, { method: "PATCH", body: patchFor(c, value) });
      setOver((o) => ({ ...o, [id]: { ...o[id], ...saved, ...(c.kind === "link" ? { [c.key]: String(value ?? "").trim() || null } : {}), category_name: o[id]?.category_name ?? row.category_name } }));
      setFlash(k); setTimeout(() => setFlash((f) => (f === k ? null : f)), 1200);
      if (c.kind === "link" || c.kind === "status") void queryClient.invalidateQueries({ queryKey: ["list", "products"] });
      void queryClient.invalidateQueries({ queryKey: ["product", String(id)] });
      // A new brand or product head becomes a suggestion for the next cells.
      if (c.key === "brand") void queryClient.invalidateQueries({ queryKey: ["lookup", "brands"] });
      if (c.key === "ph") void queryClient.invalidateQueries({ queryKey: ["lookup", "phs"] });
    } catch (e) {
      setOver((o) => ({ ...o, [id]: { ...o[id], ...(c.kind === "mode" ? modeFields(before as ScrapingMode) : { [c.key]: before }) } }));
      toast.error(`${c.label}: ${(e as Error).message}`);
    } finally {
      setBusy((b) => (b === k ? null : b));
      then?.();
    }
  };

  const start = (ri: number, ci: number, el: HTMLElement, seed?: string) => {
    const c = cols[ci], row = shown[ri];
    if (!EDITABLE.has(c.kind)) return;
    if (c.kind === "bool") { void save(row, c, !row[c.key]); return; }
    anchor.current = el;
    const v = valueOf(c, row);
    setEdit({ id: row.product_id, key: c.key, draft: seed ?? (c.kind === "multi" ? list(v) : c.kind === "status" ? String(!!v) : v ?? "") });
  };

  const onGridKey = (e: React.KeyboardEvent) => {
    if (edit || !focus) return;
    const { r, c } = focus;
    if (e.key === "ArrowDown") { e.preventDefault(); move(r + 1, c); }
    else if (e.key === "ArrowUp") { e.preventDefault(); move(r - 1, c); }
    else if (e.key === "ArrowRight") { e.preventDefault(); move(r, c + 1); }
    else if (e.key === "ArrowLeft") { e.preventDefault(); move(r, c - 1); }
    else if (e.key === "Enter" || e.key === "F2") { e.preventDefault(); const el = cellEl(r, c); if (el) start(r, c, el); }
    else if (e.key === " " && cols[c].kind === "bool") { e.preventDefault(); void save(shown[r], cols[c], !shown[r][cols[c].key]); }
    else if (e.key.length === 1 && !e.metaKey && !e.ctrlKey && ["name", "text", "combo", "money", "pct", "link"].includes(cols[c].kind)) {
      const el = cellEl(r, c); if (el) { e.preventDefault(); start(r, c, el, e.key); }
    }
  };

  const editor = (row: Row, c: GridCol, ri: number, ci: number) => {
    if (!edit) return null;
    const close = (ok: boolean, next?: "tab" | "down") => {
      const after = () => (next === "tab" ? move(ri, ci + 1) : next === "down" ? move(ri + 1, ci) : move(ri, ci));
      if (ok) void save(row, c, edit.draft, after); else { setEdit(null); after(); }
    };
    if (c.kind === "select" || c.kind === "status" || c.kind === "multi" || c.kind === "mode") {
      const opts = c.kind === "status" ? [{ value: "true", label: "Active" }, { value: "false", label: "Inactive (switched off)" }] : c.kind === "mode" ? MODE_OPTS
        : c.kind === "multi" ? c.labels!.map((l, i) => ({ value: String(i + 1), label: l })) : c.options!();
      const value = c.kind === "multi" ? (edit.draft as string[]) : [String(edit.draft ?? "")];
      return <ChoiceMenu anchor={anchor} options={opts} multiple={c.kind === "multi"} value={value} columns={c.kind === "multi" ? (c.key === "scraping_schedule_monthly" ? 7 : 4) : 1}
        onPick={(v) => setEdit((x) => x && { ...x, draft: c.kind === "multi" ? v : v[0] })}
        onClose={(ok) => {
          // Single choice: the pick lands in state on the next render, so save the chosen value directly.
          if (ok && c.kind !== "multi") setEdit((x) => { if (x) void save(row, c, x.draft, () => move(ri, ci)); return null; });
          else close(ok);
        }} />;
    }
    if (c.kind === "combo") return (
      <>
        <span className="pointer-events-none absolute inset-0 z-[5] border-2 border-focus" />
        <ComboMenu anchor={anchor} options={c.options!()} value={String(edit.draft ?? "")}
          onSave={(v) => { setEdit(null); void save(row, c, v, () => move(ri, ci)); }} onCancel={() => { setEdit(null); move(ri, ci); }} />
      </>);
    return (
      <>
        <input autoFocus className={`absolute inset-0 z-[5] h-full w-full rounded-none border-2 border-focus bg-surface px-2 text-[13px] text-ink outline-none ${c.kind === "money" || c.kind === "pct" ? "text-right tabular-nums" : ""} ${c.mono ? "font-mono" : ""}`}
          inputMode={c.kind === "money" || c.kind === "pct" ? "decimal" : c.kind === "link" ? "url" : undefined} spellCheck={c.kind === "name"}
          placeholder={c.kind === "link" ? `https://www.${c.channel === "amazon" ? "amazon.in" : c.channel === "instamart" ? "swiggy.com/instamart" : c.channel === "zepto" ? "zeptonow.com" : "flipkart.com"}/...` : undefined}
          value={String(edit.draft ?? "")} onChange={(e) => setEdit({ ...edit, draft: e.target.value })}
          onFocus={(e) => { if (typeof edit.draft === "string" && edit.draft.length > 1) e.target.select(); }}
          onBlur={() => close(true)}
          onKeyDown={(e) => {
            if (e.key === "Enter") { e.preventDefault(); close(true, "down"); }
            else if (e.key === "Escape") { e.preventDefault(); close(false); }
            else if (e.key === "Tab") { e.preventDefault(); close(true, "tab"); }
          }} />
      </>
    );
  };

  const allOn = shown.length > 0 && shown.every((r) => selected.has(r.product_id));
  const stick = (i: number) => (i < STICKY ? { position: "sticky" as const, left: left(i), zIndex: 2 } : undefined);

  return (
    <div className="card overflow-hidden">
      <div ref={gridRef} className="overflow-auto" style={{ maxHeight }} role="grid" aria-label="Products" aria-rowcount={shown.length} onKeyDown={onGridKey}>
        <table className="border-separate border-spacing-0 text-[13px]" style={{ width, tableLayout: "fixed" }}>
          <colgroup><col style={{ width: 36 }} />{cols.map((c) => <col key={c.key} style={{ width: c.w }} />)}<col style={{ width: 44 }} /></colgroup>
          <thead className="sticky top-0 z-[4]">
            <tr className="text-[11px] font-semibold uppercase tracking-wider text-faint">
              <th colSpan={3} className="sticky left-0 z-[3] border-b border-line bg-surface-alt px-3 py-1.5 text-left">Product</th>
              {/* Group labels stay readable while the sheet scrolls sideways (sticky just right of the frozen columns). */}
              {groups.map((g, i) => <th key={i} colSpan={cols.filter((c, j) => j >= 2 && c.group === g.name).length} className="border-b border-l border-line bg-surface-alt py-1.5 text-left">
                <span className="sticky inline-block px-3" style={{ left: 36 + cols[0].w + cols[1].w }}>{i === 0 ? "Details" : g.name}</span></th>)}
              <th className="sticky right-0 z-[3] border-b border-l border-line bg-surface-alt" />
            </tr>
            <tr>
              <th className="sticky left-0 z-[3] border-b border-line bg-surface px-2.5 py-2" style={{ left: 0 }}>
                <input type="checkbox" aria-label="Select all shown" checked={allOn} ref={(el) => { if (el) el.indeterminate = !allOn && shown.some((r) => selected.has(r.product_id)); }}
                  onChange={() => { const n = new Set(selected); shown.forEach((r) => (allOn ? n.delete(r.product_id) : n.add(r.product_id))); onSelect(n); }} />
              </th>
              {cols.map((c, i) => (
                <th key={c.key} scope="col" title={c.hint} style={stick(i + 1) ? { ...stick(i + 1), zIndex: 3 } : undefined}
                  className={`border-b border-line bg-surface px-2.5 py-2 text-left text-[12px] font-medium whitespace-nowrap ${c.kind === "calc" ? "text-faint italic" : "text-muted"} ${["money", "pct", "calc"].includes(c.kind) ? "text-right" : ""} ${i + 1 === STICKY - 1 + 1 ? "shadow-[1px_0_0_var(--color-line)]" : ""}`}>
                  {c.label}{c.kind === "calc" && <span className="ml-1 not-italic text-[10px] text-faint">calc</span>}
                </th>))}
              <th scope="col" className="sticky right-0 z-[3] border-b border-l border-line bg-surface"><span className="sr-only">Open</span></th>
            </tr>
          </thead>
          <tbody>
            {loading && !shown.length && Array.from({ length: 8 }, (_, i) => (
              <tr key={`s${i}`}><td colSpan={cols.length + 1} className="border-b border-line px-3 py-2.5"><div className="h-4 animate-pulse rounded bg-track" /></td></tr>))}
            {shown.map((row, ri) => {
              const on = selected.has(row.product_id);
              // The row being edited (a cell editor open, or the keyboard on it) stands out clearly from hover and selection.
              const current = (!!edit && edit.id === row.product_id) || (!!focus && focus.r === ri && gridRef.current?.contains(document.activeElement));
              return (
                <tr key={row.product_id} role="row" className={`group ${current ? "[&>td]:!bg-editing [&>td:first-child]:shadow-[inset_3px_0_0_var(--color-gold-line)]" : on ? "[&>td]:bg-accent-soft" : "[&>td]:bg-surface hover:[&>td]:bg-hover-row"}`}>
                  <td className="sticky left-0 z-[2] border-b border-line px-2.5" style={{ left: 0 }}>
                    <input type="checkbox" aria-label={`Select ${row.name}`} checked={on} onChange={() => { const n = new Set(selected); if (on) n.delete(row.product_id); else n.add(row.product_id); onSelect(n); }} />
                  </td>
                  {cols.map((c, ci) => {
                    const k = `${row.product_id}:${c.key}`;
                    const editing = !!edit && edit.id === row.product_id && edit.key === c.key;
                    const canEdit = EDITABLE.has(c.kind);
                    const isFocus = !!focus && focus.r === ri && focus.c === ci;
                    return (
                      <td key={c.key} role="gridcell" data-r={ri} data-c={ci} tabIndex={isFocus || (!focus && ri === 0 && ci === 1) ? 0 : -1} aria-readonly={!canEdit || undefined}
                        style={stick(ci + 1)} title={c.kind === "calc" ? c.hint : undefined}
                        onFocus={() => setFocus({ r: ri, c: ci })}
                        onClick={(e) => { setFocus({ r: ri, c: ci }); if (!editing && canEdit) start(ri, ci, e.currentTarget); }}
                        className={`relative h-10 border-b border-line px-2.5 outline-none ${ci > 0 && ci < STICKY - 1 ? "" : ""} ${ci === STICKY - 2 ? "shadow-[1px_0_0_var(--color-line)]" : ""}
                          ${["money", "pct", "calc"].includes(c.kind) ? "text-right" : ""} ${c.kind === "calc" ? "!bg-surface-alt text-muted" : ""} ${canEdit ? "cursor-cell" : ""}
                          ${flash === k ? "!bg-success-soft transition-colors" : ""} focus-visible:shadow-[inset_0_0_0_2px_var(--color-focus)]`}>
                        <div className={`flex min-w-0 items-center gap-1.5 overflow-hidden ${["money", "pct", "calc"].includes(c.kind) ? "justify-end" : ""} ${c.kind === "name" ? "font-medium text-ink" : ""}`}>
                          <span className="min-w-0 truncate" title={c.kind === "name" ? row.name : undefined}>{display(c, row)}</span>
                          {c.kind === "name" && <Link to={`/products/${row.product_id}`} onClick={(e) => e.stopPropagation()} aria-label={`Open ${row.name}`} title="Open the product page"
                            className="ml-auto shrink-0 text-faint opacity-0 hover:text-ink group-hover:opacity-100 focus:opacity-100"><SquareArrowOutUpRight className="h-3.5 w-3.5" /></Link>}
                          {busy === k && <Loader2 className="h-3.5 w-3.5 shrink-0 animate-spin text-faint" aria-label="Saving" />}
                        </div>
                        {editing && editor(row, c, ri, ci)}
                      </td>);
                  })}
                  <td className="sticky right-0 z-[2] border-b border-l border-line px-1.5 text-center">
                    <Link to={`/products/${row.product_id}`} className="btn-icon inline-grid h-7 w-7 text-muted" aria-label={`Edit ${row.name} on its own page`} title="Open the full product form"><Pencil className="h-3.5 w-3.5" /></Link>
                  </td>
                </tr>);
            })}
          </tbody>
        </table>
      </div>
      {footer}
    </div>
  );
}

/** Legend under the sheet: what the colours and the "calc" columns mean. */
export function GridLegend() {
  return (
    <p className="text-[12px] text-faint">
      Click a cell to edit; Enter saves and moves down, Tab saves and moves right, Esc cancels. Arrow keys move between cells.
      Columns marked <span className="italic">calc</span> are worked out from the prices and percentages and cannot be typed.
      {Object.keys(CHANNEL_TONE).map((c, i) => <Fragment key={c}>{i === 0 ? " Links: " : " "}<span className={`rounded border px-1.5 ${CHANNEL_TONE[c]}`}>{channelLabel(c)}</span></Fragment>)}
    </p>
  );
}
