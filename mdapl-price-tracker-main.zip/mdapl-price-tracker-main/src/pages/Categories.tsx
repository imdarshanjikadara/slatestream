// Product Categories (the old app screen "productCategories"): master data list; a row opens its detail page.
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useMutation } from "@tanstack/react-query";
import { Plus, SquareArrowOutUpRight, Trash2 } from "lucide-react";
import { api, queryClient, useList } from "@/lib/api";
import { useUrlState } from "@/lib/hooks";
import { inr } from "@/lib/format";
import { PageHeader, StatStrip, Tabs, ErrorState, Field } from "@/components/common";
import { DataTable, ExportMenu, type Col } from "@/components/DataTable";
import { FilterBar, SearchBox } from "@/components/FilterBar";
import { ActiveStatus } from "@/components/Pill";
import { Dialog, confirmAction, toast } from "@/components/overlays";

const COLS: Col[] = [
  { key: "category_id", label: "#", kind: "int", align: "left", className: "text-faint" },
  { key: "name", label: "Name", grow: true, edit: { type: "text", required: true, maxLength: 120 },
    render: (r) => <span className="flex items-center gap-1.5"><span className="font-medium">{r.name}</span>
      <Link to={`/categories/${r.category_id}`} onClick={(e) => e.stopPropagation()} aria-label={`Open ${r.name}`} title="Open the category page"
        className="text-faint opacity-0 hover:text-ink group-hover:opacity-100 focus:opacity-100"><SquareArrowOutUpRight className="h-3.5 w-3.5" /></Link></span> },
  { key: "products", label: "Products", kind: "int", total: true },
  { key: "links", label: "Active links", kind: "int", total: true },
  { key: "is_active", label: "Status", value: (r) => (r.is_active ? "Active" : "Inactive"), render: (r) => <ActiveStatus active={r.is_active} />,
    edit: { type: "select", options: [{ value: "true", label: "Active" }, { value: "false", label: "Inactive" }] } },
  { key: "updated_at", label: "Updated", kind: "date" },
];

export function NewCategoryDialog({ open, onClose, onCreated }: { open: boolean; onClose: () => void; onCreated?: (row: any) => void }) {
  const [name, setName] = useState("");
  const m = useMutation({
    mutationFn: () => api("categories", { body: { name } }),
    onSuccess: (row) => { toast.success(`Category "${row.name}" added.`); void queryClient.invalidateQueries({ queryKey: ["list", "categories"] }); void queryClient.invalidateQueries({ queryKey: ["lookup", "categories"] }); setName(""); onClose(); onCreated?.(row); },
  });
  return (
    <Dialog open={open} onClose={() => { m.reset(); onClose(); }} title="Add Product Category"
      footer={<><button className="btn-ghost" onClick={onClose}>Cancel</button><button className="btn-primary" form="new-category" disabled={!name.trim() || m.isPending}>{m.isPending ? "Saving..." : "Add category"}</button></>}>
      <form id="new-category" onSubmit={(e) => { e.preventDefault(); if (name.trim()) m.mutate(); }} className="space-y-3">
        {m.error && <div className="notice notice-danger">{(m.error as Error).message}</div>}
        <Field label="Category name" htmlFor="cat-name"><input id="cat-name" className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="Enter category name" autoFocus maxLength={120} /></Field>
      </form>
    </Dialog>
  );
}

export default function Categories() {
  const nav = useNavigate();
  const [f, set, active] = useUrlState({ status: "active", q: "" });
  const params = { status: f.status, q: f.q };
  const list = useList("categories", params);
  const [adding, setAdding] = useState(false);
  const counts = list.meta?.counts, stats = list.meta?.stats;
  // Inline edit (pencil at the end of the row): rename, or switch a category on or off.
  const saveRow = async (r: any, ch: Record<string, string>) => {
    if ("is_active" in ch && ch.is_active === "false" && r.products > 0
      && !(await confirmAction({ title: `Make "${r.name}" inactive?`, body: `It has ${inr(r.products)} products. They stay as they are; the category is hidden from the active list and pickers.`, confirmLabel: "Make inactive" }))) return false;
    await api(`categories/${r.category_id}`, { method: "PATCH", body: { ...("name" in ch ? { name: ch.name } : {}), ...("is_active" in ch ? { is_active: ch.is_active === "true" } : {}) } });
    void queryClient.invalidateQueries({ queryKey: ["lookup", "categories"] });
    await queryClient.invalidateQueries({ queryKey: ["list", "categories"] });
  };

  const [sel, setSel] = useState<Set<number>>(new Set());
  const deleteSelected = async () => {
    const rows = list.rows.filter((r: any) => sel.has(r.category_id)), n = sel.size;
    const products = rows.reduce((s: number, r: any) => s + (r.products ?? 0), 0);
    const what = `${inr(n)} ${n === 1 ? "category" : "categories"}`;
    if (!(await confirmAction({ title: `Delete ${what}?`, tone: "danger", confirmLabel: `Delete ${what}`,
      body: `${products ? `Their products stay, without a category; give them a new one on the Products page. ` : ""}An admin can restore ${n === 1 ? "it" : "them"} from the Audit log within 30 days. To only hide a category, make it inactive instead.` }))) return;
    let done = 0;
    for (const id of sel) {
      try { await api(`categories/${id}`, { method: "DELETE" }); done++; } catch (e) { toast.error((e as Error).message); }
    }
    if (done) toast.success(`${inr(done)} ${done === 1 ? "category" : "categories"} deleted.`);
    setSel(new Set());
    void queryClient.invalidateQueries({ queryKey: ["lookup", "categories"] });
    void queryClient.invalidateQueries({ queryKey: ["list", "categories"] });
  };

  return (
    <div className="page">
      <PageHeader title="Product Categories" subtitle="Categories group the products whose prices are tracked.">
        <ExportMenu endpoint="categories" params={params} cols={COLS} title="Product Categories" />
        <button className="btn-primary" onClick={() => setAdding(true)}><Plus className="h-4 w-4" />Add Product Category</button>
      </PageHeader>
      <Tabs ariaLabel="Status" active={f.status} onChange={(k) => set({ status: k })} items={[
        { key: "active", label: "Active", count: counts?.active }, { key: "inactive", label: "Inactive", count: counts?.inactive }, { key: "all", label: "All", count: counts?.all }]} />
      <StatStrip loading={list.isFetching} items={[
        { label: "Total Product Categories", value: counts ? inr(counts.active) : "-", unit: "active" },
        { label: "Products in them", value: stats ? inr(stats.products) : "-" },
        { label: "Active product links", value: stats ? inr(stats.links) : "-" },
      ]} />
      <FilterBar active={active.includes("q")} onClear={() => set({ q: null })}>
        <SearchBox value={f.q} onChange={(v) => set({ q: v })} placeholder="Search categories" />
      </FilterBar>
      {sel.size > 0 && (
        <div className="card flex flex-wrap items-center gap-2 border-accent-line bg-accent-soft px-4 py-2.5 text-[13px]">
          <span className="font-medium">{inr(sel.size)} {sel.size === 1 ? "category" : "categories"} selected</span>
          <button className="btn-ghost btn-sm" onClick={() => setSel(new Set())}>Clear selection</button>
          <button className="btn-danger btn-sm ml-auto" onClick={() => void deleteSelected()}><Trash2 className="h-4 w-4" />Delete selected</button>
        </div>)}
      {list.error ? <div className="card"><ErrorState error={list.error} retry={() => list.refetch()} /></div> :
        <DataTable cols={COLS} rows={list.rows} rowKey="category_id" selected={sel} onSelect={setSel} loading={list.isLoading} fetching={list.isFetching} pager={list.pager}
          onRowClick={(r) => nav(`/categories/${r.category_id}`)} onSave={saveRow} filtersActive={!!f.q} onClearFilters={() => set({ q: null })}
          empty={{ title: f.status === "inactive" ? "No inactive categories" : "No categories yet", hint: "Add a category to start grouping products.", action: <button className="btn btn-sm" onClick={() => setAdding(true)}>Add category</button> }} />}
      <NewCategoryDialog open={adding} onClose={() => setAdding(false)} />
    </div>
  );
}
