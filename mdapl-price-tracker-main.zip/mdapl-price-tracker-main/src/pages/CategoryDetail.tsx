// One category (the old app: editProductCategoryModal -> updateCategories), with its products.
import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Pencil, Trash2 } from "lucide-react";
import { api, queryClient } from "@/lib/api";
import { dateTime, inr, plural } from "@/lib/format";
import { Card, ErrorState, Field, Loading, PageHeader, StatStrip } from "@/components/common";
import { DataTable, type Col } from "@/components/DataTable";
import { ActiveStatus } from "@/components/Pill";
import { Dialog, confirmAction, toast } from "@/components/overlays";

const PCOLS: Col[] = [
  { key: "name", label: "Product", grow: true, render: (r) => <span className="font-medium">{r.name}</span> },
  { key: "brand", label: "Brand" },
  { key: "hana_code", label: "Hana code", kind: "mono" },
  { key: "mrp", label: "MRP", kind: "money" },
  { key: "mop", label: "MOP", kind: "money" },
  { key: "links", label: "Links", kind: "int" },
  { key: "is_active", label: "Status", render: (r) => <ActiveStatus active={r.is_active} /> },
];

export default function CategoryDetail() {
  const { id } = useParams();
  const nav = useNavigate();
  const q = useQuery({ queryKey: ["category", id], queryFn: () => api(`categories/${id}`) });
  const [renaming, setRenaming] = useState(false);
  const [name, setName] = useState("");
  const done = (msg: string) => { toast.success(msg); void queryClient.invalidateQueries({ queryKey: ["category", id] }); void queryClient.invalidateQueries({ queryKey: ["list", "categories"] }); void queryClient.invalidateQueries({ queryKey: ["lookup", "categories"] }); };
  const save = useMutation({ mutationFn: (body: any) => api(`categories/${id}`, { method: "PATCH", body }) });
  if (q.isLoading) return <Loading />;
  if (q.error) return <div className="card"><ErrorState error={q.error} retry={() => q.refetch()} /></div>;
  const c = q.data.category, products = q.data.products as any[];
  const activeProducts = products.filter((p) => p.is_active);

  const toggle = async () => {
    const off = c.is_active;
    if (!(await confirmAction({ title: off ? `Deactivate ${c.name}?` : `Reactivate ${c.name}?`, body: off ? "It disappears from the category pickers. Its products keep their category. You can reactivate it any time." : "It appears in the category pickers again.", confirmLabel: off ? "Deactivate" : "Reactivate", tone: off ? "danger" : "default" }))) return;
    save.mutate({ is_active: !off }, { onSuccess: () => done(off ? "Category deactivated." : "Category reactivated."), onError: (e) => toast.error((e as Error).message) });
  };

  const remove = async () => {
    if (!(await confirmAction({ title: `Delete ${c.name}?`, tone: "danger", confirmLabel: "Delete category",
      body: products.length ? `Its ${plural(products.length, "product")} stay, without a category; give them a new one on the Products page. An admin can restore the category from the Audit log within 30 days.` : "An admin can restore it from the Audit log within 30 days." }))) return;
    try {
      await api(`categories/${id}`, { method: "DELETE" });
      toast.success(`Category "${c.name}" deleted.`);
      void queryClient.invalidateQueries();
      nav("/categories");
    } catch (e) { toast.error((e as Error).message); }
  };

  return (
    <div className="page">
      <PageHeader title={c.name} breadcrumb={[{ to: "/categories", label: "Product Categories" }]} status={<ActiveStatus active={c.is_active} />} subtitle={`Category #${c.category_id}`}>
        <button className="btn-danger" onClick={() => void remove()}><Trash2 className="h-4 w-4" />Delete</button>
        <button className="btn" onClick={toggle}>{c.is_active ? "Deactivate" : "Reactivate"}</button>
        <button className="btn-primary" onClick={() => { setName(c.name); setRenaming(true); }}><Pencil className="h-4 w-4" />Rename</button>
      </PageHeader>
      <StatStrip items={[
        { label: "Active products", value: inr(activeProducts.length) },
        { label: "Inactive products", value: inr(products.length - activeProducts.length) },
        { label: "Active links", value: inr(activeProducts.reduce((s, p) => s + p.links, 0)) },
      ]} />
      <div className="grid items-stretch gap-4 lg:grid-cols-[20rem_minmax(0,1fr)]">
        <Card title="Details">
          <dl className="dl">
            <dt>Name</dt><dd>{c.name}</dd>
            <dt>Status</dt><dd><ActiveStatus active={c.is_active} /></dd>
            <dt>Created</dt><dd>{dateTime(c.created_at)}</dd>
            <dt>Last updated</dt><dd>{dateTime(c.updated_at)}</dd>
          </dl>
        </Card>
        <Card title="Products in this category" count={plural(products.length, "product")} bodyClass="">
          <DataTable embedded cols={PCOLS} rows={products} total={products.length} rowKey="product_id" onRowClick={(r) => nav(`/products/${r.product_id}`)} onEdit={(r) => nav(`/products/${r.product_id}`)} editLabel="Open the product to edit"
            empty={{ title: "No products in this category yet", hint: "Products get their category on the product page." }} maxHeight="32rem" />
        </Card>
      </div>
      <Dialog open={renaming} onClose={() => setRenaming(false)} title={`Edit ${c.name}`}
        footer={<><button className="btn-ghost" onClick={() => setRenaming(false)}>Cancel</button><button className="btn-primary" form="rename" disabled={!name.trim() || save.isPending}>{save.isPending ? "Saving..." : "Update"}</button></>}>
        <form id="rename" className="space-y-3" onSubmit={(e) => { e.preventDefault(); save.mutate({ name }, { onSuccess: () => { setRenaming(false); done("Category renamed."); } }); }}>
          {save.error && <div className="notice notice-danger">{(save.error as Error).message}</div>}
          <Field label="Category name" htmlFor="rename-name"><input id="rename-name" className="input" value={name} onChange={(e) => setName(e.target.value)} autoFocus maxLength={120} /></Field>
        </form>
      </Dialog>
    </div>
  );
}
