// Dashboard (the old app screen "Dashboard").
import { keepPreviousData, useQuery } from "@tanstack/react-query";
import { ExternalLink } from "lucide-react";
import { api, qs } from "@/lib/api";
import { useScrapeWindow, useUrlState } from "@/lib/hooks";
import { channelLabel, dateLong, inr, istDay, money, titleCase } from "@/lib/format";
import { Notice, PageHeader, StatStrip, Tabs, ErrorState } from "@/components/common";
import { Pill } from "@/components/Pill";
import { DateRange } from "@/components/ui/DateRange";
import { Select } from "@/components/ui/Select";
import { Bars, ChartCard, LineChart, Split } from "@/components/Charts";
import { FilterBar } from "@/components/FilterBar";

const CHANNELS = ["amazon", "flipkart", "instamart", "zepto"];

export function useConfig() {
  return useQuery({ queryKey: ["config"], queryFn: () => api<{ proxyDashboardUrl: string }>("meta/config"), staleTime: Infinity });
}

function Integrations() {
  const q = useQuery({ queryKey: ["integrations"], queryFn: () => api<{ key: string; label: string; ok: boolean }[]>("meta/integrations"), staleTime: 60_000 });
  if (!q.data) return null;
  return (
    <div className="flex max-w-full flex-wrap items-center gap-1.5 lg:flex-nowrap" aria-label="Integration status">
      {q.data.map((i) => <Pill key={i.key} tone={i.ok ? "success" : "warning"} title={i.ok ? `${i.label}: connected` : `${i.label}: not connected`}>{i.label}{i.ok ? "" : ": not connected"}</Pill>)}
    </div>
  );
}

export default function Dashboard() {
  const [f, set, active] = useUrlState({ from: "", to: "", channel: "amazon", category: "" });
  const w = useScrapeWindow();
  const picked = !!(f.from || f.to);
  const from = f.from || w.from, to = f.to || w.to;
  const params = { from, to, channel: f.channel, category: f.category || null };
  const q = useQuery({ queryKey: ["dashboard", qs(params)], queryFn: () => api(`dashboard${qs(params)}`), placeholderData: keepPreviousData, enabled: w.ready });
  const cats = useQuery({ queryKey: ["lookup", "categories"], queryFn: () => api<{ id: number; name: string }[]>("lookups/categories"), staleTime: 300_000 });
  const cfg = useConfig();
  const d = q.data;
  const s = d?.stats;
  const catName = cats.data?.find((c) => c.id === Number(f.category || d?.category))?.name;

  return (
    <div className="page">
      <PageHeader title="Dashboard" subtitle={`Prices scraped from ${channelLabel(f.channel)} and the other channels, for the dates picked below.`}>
        <Integrations />
      </PageHeader>
      <FilterBar active={active.some((k) => k === "from" || k === "to")} onClear={() => set({ from: null, to: null })}
        right={cfg.data && <a className="btn" href={cfg.data.proxyDashboardUrl} target="_blank" rel="noopener noreferrer"><ExternalLink className="h-4 w-4" />Decodo Proxy Balance</a>}>
        <DateRange label="Scraped" from={from} to={to} onFrom={(v) => set({ from: v || null })} onTo={(v) => set({ to: v || null })} className="w-full sm:w-auto" />
      </FilterBar>
      {w.stale && !picked && <Notice tone="warning">Nothing has been scraped since {dateLong(w.stale)} ({Math.round((Date.parse(istDay(0)) - Date.parse(w.stale)) / 86400000)} days ago), so this shows the 7 days up to then. New prices arrive once Browserless and the Decodo proxy are connected.</Notice>}
      <Tabs ariaLabel="Channel" active={f.channel} onChange={(k) => set({ channel: k })} items={CHANNELS.map((c) => ({ key: c, label: channelLabel(c), count: d?.channelCounts?.[c] ?? null }))} />
      {q.error ? <div className="card"><ErrorState error={q.error} retry={() => q.refetch()} /></div> : (
        <StatStrip loading={q.isFetching} items={[
          { label: "Products below MOP", value: s ? inr(s.breached) : "-", tone: s?.breached ? "danger" : undefined, hint: "Active products whose latest price in the period is below their MOP" },
          { label: "Unique products scraped", value: s ? inr(s.scraped) : "-", hint: "Links with at least one scrape in the period" },
          { label: "MOP breach rate", value: s?.breachRate !== null && s?.breachRate !== undefined ? `${inr(s.breachRate, 1)}%` : "-", hint: "Priced below their trigger price, out of the products checked" },
          { label: "Links available", value: s ? inr(s.links) : "-", unit: s ? `${inr(s.activeLinks)} active` : undefined },
          { label: "Avg price change, 7 days", value: s?.avgPriceChange !== null && s?.avgPriceChange !== undefined ? money(s.avgPriceChange) : "-", hint: "Average price last 7 days minus the average before, per product" },
        ]} />)}
      <div className="grid gap-4 lg:grid-cols-2">
        <ChartCard title="Price Trend Over Time" subtitle={catName ? `Average scraped price per day, ${titleCase(catName)}` : "Average scraped price per day"}
          actions={<Select size="sm" className="w-44" ariaLabel="Category" value={f.category || String(d?.category ?? "")} onChange={(v) => set({ category: v || null })}
            options={(cats.data ?? []).map((c) => ({ value: String(c.id), label: titleCase(c.name) }))} placeholder="Category" required />}>
          <LineChart data={(d?.trend ?? []).map((t: any) => ({ x: t.date, y: Number(t.avg_price) }))} prefix="₹" />
        </ChartCard>
        <ChartCard title="Channel Comparison" subtitle="Average scraped price per channel">
          <Bars data={(d?.channels ?? []).map((c: any) => ({ label: channelLabel(c.channel_name), value: Number(c.avg_price) }))} prefix="₹" />
        </ChartCard>
        <ChartCard title="Discount Over Time" subtitle="Average discount per day, all channels">
          <LineChart data={(d?.discount ?? []).map((t: any) => ({ x: t.date, y: Number(t.avg_discount) }))} suffix="%" />
        </ChartCard>
        <ChartCard title="Category Distribution" subtitle="Active products per category">
          <Split parts={(d?.categories ?? []).map((c: any) => ({ label: titleCase(c.category_name), value: c.product_count }))} />
        </ChartCard>
      </div>
    </div>
  );
}
