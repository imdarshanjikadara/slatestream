// One product: the old app's editProductModal (+ addProductsModal for /products/new) as a page, with the links table
// (modalFrame1) and the product's recent scrapes.
import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Plus, Trash2 } from "lucide-react";
import { api, queryClient } from "@/lib/api";
import { alertPrice, computePricing, DERIVED_HELP, isBreach, type Derived } from "../../shared/pricing";
import { istDate, nextDue } from "../../shared/schedule";
import { ago, channelLabel, dateLong, dateTime, inr, money, plural } from "@/lib/format";
import { Card, ErrorState, Field, Loading, PageHeader } from "@/components/common";
import { DataTable, type Col } from "@/components/DataTable";
import { ActiveStatus, Availability, Pill } from "@/components/Pill";
import { Select } from "@/components/ui/Select";
import { confirmAction, toast } from "@/components/overlays";
import { useLookups } from "./Products";
import { NewCategoryDialog } from "./Categories";

const CH = ["amazon", "flipkart", "instamart", "zepto"] as const;
/** What the daily scheduled run will do with this product, from the form as it is now. */
function ScheduleSummary({ f }: { f: Record<string, any> }) {
  const p = { ...f, scraping_schedule_weekly: (f.scraping_schedule_weekly ?? []).join(","), months_to_scrape: (f.months_to_scrape ?? []).join(",") };
  const next = nextDue(p), today = istDate();
  const when = !next ? null : next.y === today.y && next.m === today.m && next.d === today.d ? "today" : dateLong(`${next.y}-${String(next.m).padStart(2, "0")}-${String(next.d).padStart(2, "0")}T12:00:00+05:30`);
  const at = ` at ${timeLabel(f.scrape_time)} India time`;
  const text = f.regular_scraping ? `Scraped every day${at} (regular scraping).`
    : !f.scheduled_scraping ? "Not in the daily scheduled run. Scraped only on demand or in a manual full run."
    : when ? `Next scheduled scrape: ${when}${at}.` : "The schedule never falls on a date (check the months and dates), so it is not in the daily run.";
  return <p className="rounded-md border border-dashed border-line px-3 py-2 text-[13px] text-muted" data-testid="schedule-summary">{text}</p>;
}

export { DAYS, MONTHS, Toggles } from "@/components/ScrapingMode";
import { ScheduleParts, ScrapingModePicker, TimePicker, listOf, modeFields, modeOf, timeLabel } from "@/components/ScrapingMode";
const TEXT = ["name", "brand", "description", "hana_code", "ph", "scraping_schedule_monthly"] as const;
const NUM = ["mrp", "gst_percent", "direct_discount", "dealer_landing", "scheme_1", "scheme_2", "scheme_3", "dp_margin_percent", "retail_margin_percent", "trigger_price_percent"] as const;
type Form = Record<string, any>;

function toForm(p: any, links: any[]): Form {
  const f: Form = { category_id: p?.category_id ? String(p.category_id) : "", regular_scraping: !!p?.regular_scraping, scheduled_scraping: !!p?.scheduled_scraping,
    scraping_schedule_weekly: p?.scraping_schedule_weekly ? String(p.scraping_schedule_weekly).split(",").map((s: string) => s.trim()).filter(Boolean) : [],
    months_to_scrape: p?.months_to_scrape ? String(p.months_to_scrape).split(",").map((s: string) => s.trim()).filter(Boolean) : [], scrape_time: p?.scrape_time ?? "06:00" };
  for (const k of TEXT) f[k] = p?.[k] ?? "";
  for (const k of NUM) f[k] = p?.[k] === null || p?.[k] === undefined ? "" : String(p[k]);
  for (const c of CH) f[`link_${c}`] = links.find((l) => l.channel_name === c && l.is_active)?.url ?? "";
  return f;
}
function toBody(f: Form, gen: Set<string>) {
  const body: Form = { category_id: f.category_id ? Number(f.category_id) : null, regular_scraping: f.regular_scraping, scheduled_scraping: f.scheduled_scraping,
    scraping_schedule_weekly: f.scraping_schedule_weekly, months_to_scrape: f.months_to_scrape, scrape_time: f.scrape_time };
  for (const k of TEXT) body[k] = f[k];
  for (const k of NUM) if (!gen.has(k)) body[k] = f[k] === "" ? null : f[k];
  body.links = Object.fromEntries(CH.map((c) => [c, f[`link_${c}`]]));
  return body;
}

function Num({ label, k, f, set, prefix, gen }: { label: string; k: string; f: Form; set: (p: Form) => void; prefix?: string; gen: Set<string> }) {
  const ro = gen.has(k);
  return (
    <Field label={label} htmlFor={k} hint={ro ? "Calculated by the database" : undefined}>
      <div className="relative">
        {prefix && <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-[13px] text-faint">{prefix}</span>}
        <input id={k} inputMode="decimal" className={`input ${prefix ? "pl-7" : ""} text-right tabular-nums`} value={f[k]} disabled={ro}
          onChange={(e) => set({ [k]: e.target.value.replace(/[^\d.]/g, "") })} placeholder="0" />
      </div>
    </Field>
  );
}

/** A calculated field: read-only, recalculated as the inputs change, with its formula underneath. */
function Calc({ label, k, f }: { label: string; k: keyof Derived; f: Form }) {
  const v = computePricing(f)[k];
  return (
    <Field label={label} hint={DERIVED_HELP[k]}>
      <div className="flex h-9 items-center justify-end rounded-lg border border-dashed border-line-strong bg-surface-alt px-3 text-[13.5px] font-medium tabular-nums text-ink" aria-label={`${label} (calculated)`}>{money(v)}</div>
    </Field>
  );
}

const HCOLS: Col[] = [
  { key: "created_at", label: "Scraped", kind: "datetime" },
  { key: "channel_name", label: "Channel", value: (r) => channelLabel(r.channel_name) },
  { key: "price", label: "Price", kind: "money" },
  { key: "mrp", label: "Scraped MRP", kind: "money" },
  { key: "discount", label: "Discount", kind: "pct" },
  { key: "availability", label: "Availability", render: (r) => <Availability v={r.availability} /> },
  { key: "seller", label: "Seller", grow: true },
];

export default function ProductDetail() {
  const { id } = useParams();
  const isNew = !id;
  const nav = useNavigate();
  const lk = useLookups();
  const q = useQuery({ queryKey: ["product", id], queryFn: () => api(`products/${id}`), enabled: !isNew });
  const gen = useMemo(() => new Set<string>(q.data?.generated ?? []), [q.data]);
  const initial = useMemo(() => toForm(q.data?.product, q.data?.links ?? []), [q.data]);
  const [f, setF] = useState<Form>(initial);
  const [addingCat, setAddingCat] = useState(false);
  useEffect(() => setF(initial), [initial]);
  const set = (p: Form) => setF((o) => ({ ...o, ...p }));
  const dirty = JSON.stringify(f) !== JSON.stringify(initial);
  const refresh = () => { void queryClient.invalidateQueries({ queryKey: ["product", id] }); void queryClient.invalidateQueries({ queryKey: ["list"] }); };

  const save = useMutation({
    mutationFn: () => api(isNew ? "products" : `products/${id}`, { method: isNew ? "POST" : "PATCH", body: toBody(f, gen) }),
    onSuccess: (p) => { toast.success(isNew ? `Product "${p.name}" added.` : "Changes saved."); refresh(); if (isNew) nav(`/products/${p.product_id}`, { replace: true }); },
  });
  const remove = useMutation({ mutationFn: () => api(`products/${id}`, { method: "DELETE" }), onSuccess: () => { toast.success("Product deleted. It can be restored from the Audit log for 30 days."); refresh(); nav("/products"); } });
  const reactivate = useMutation({ mutationFn: () => api(`products/${id}`, { method: "PATCH", body: { is_active: true } }), onSuccess: () => { toast.success("Product reactivated."); refresh(); } });
  const toggleLink = useMutation({ mutationFn: (l: any) => api(`links/${l.product_link_id}`, { method: "PATCH", body: { is_active: !l.is_active } }), onSuccess: () => { toast.success("Link updated."); refresh(); }, onError: (e) => toast.error((e as Error).message) });

  if (!isNew && q.isLoading) return <Loading />;
  if (!isNew && q.error) return <div className="card"><ErrorState error={q.error} retry={() => q.refetch()} /></div>;
  const p = q.data?.product;
  const links: any[] = q.data?.links ?? [];
  const history: any[] = q.data?.history ?? [];

  const LCOLS: Col[] = [
    { key: "channel_name", label: "Channel", render: (r) => <span className="font-medium">{channelLabel(r.channel_name)}</span> },
    { key: "url", label: "URL", kind: "link" },
    { key: "last_price", label: "Last price", kind: "money" },
    { key: "last_availability", label: "Availability", render: (r) => (r.last_availability ? <Availability v={r.last_availability} /> : <span className="text-faint">-</span>) },
    { key: "last_scraped_at", label: "Last scraped", render: (r) => <span title={dateTime(r.last_scraped_at)}>{r.last_scraped_at ? ago(r.last_scraped_at) : "Never"}</span> },
    { key: "scrapes", label: "Scrapes", kind: "int" },
    { key: "is_active", label: "Link", render: (r) => <button className="btn btn-sm" onClick={(e) => { e.stopPropagation(); toggleLink.mutate(r); }}>{r.is_active ? "Switch off" : "Switch on"}</button> },
  ];

  const submit = (e: React.FormEvent) => { e.preventDefault(); save.mutate(); };
  return (
    <>
    <form className="page pb-20" onSubmit={submit} noValidate>
      <PageHeader title={isNew ? "New product" : p.name} breadcrumb={[{ to: "/products", label: "Products" }]}
        status={!isNew && <ActiveStatus active={p.is_active} />} subtitle={!isNew ? `Product #${p.product_id} · last updated ${dateTime(p.updated_at)}` : "Product details, channel links, schedule and pricing."}>
        {!isNew && (p.is_active
          ? <button type="button" className="btn-danger" onClick={async () => { if (await confirmAction({ title: `Delete ${p.name}?`, body: "The product is switched off and leaves every list and scraping run. It can be restored from the Audit log for 30 days.", confirmLabel: "Delete product", tone: "danger" })) remove.mutate(); }}><Trash2 className="h-4 w-4" />Delete</button>
          : <button type="button" className="btn" onClick={() => reactivate.mutate()}>Reactivate</button>)}
      </PageHeader>
      {save.error && <div className="notice notice-danger" role="alert">{(save.error as Error).message}</div>}

      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="Product details">
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Name" htmlFor="name" className="sm:col-span-2"><input id="name" className="input" value={f.name} onChange={(e) => set({ name: e.target.value })} placeholder="Enter name" required /></Field>
            <Field label="Brand" htmlFor="brand"><input id="brand" className="input" value={f.brand} onChange={(e) => set({ brand: e.target.value })} list="brands" /></Field>
            <Field label="Category">
              <div className="flex gap-2">
                <Select className="min-w-0 flex-1" ariaLabel="Category" placeholder="Select a category" value={f.category_id} onChange={(v) => set({ category_id: v })} required
                  options={(lk.categories.data ?? []).map((c) => ({ value: String(c.id), label: c.name }))} />
                <button type="button" className="btn w-9 px-0" onClick={() => setAddingCat(true)} aria-label="Add a category" title="Add a category"><Plus className="h-4 w-4" /></button>
              </div>
            </Field>
            <Field label="Hana code" htmlFor="hana_code"><input id="hana_code" className="input font-mono" value={f.hana_code} onChange={(e) => set({ hana_code: e.target.value })} /></Field>
            <Field label="Product head (PH)" htmlFor="ph"><input id="ph" className="input" value={f.ph} onChange={(e) => set({ ph: e.target.value })} /></Field>
            <Field label="Description" htmlFor="description" className="sm:col-span-2"><textarea id="description" rows={2} className="input" value={f.description} onChange={(e) => set({ description: e.target.value })} /></Field>
          </div>
          <datalist id="brands">{(lk.brands.data ?? []).map((b) => <option key={b} value={b} />)}</datalist>
        </Card>
        <Card title="Pricing details">
          <div className="grid gap-3 sm:grid-cols-3">
            <Num label="MRP" k="mrp" prefix="₹" f={f} set={set} gen={gen} />
            <Num label="GST percent" k="gst_percent" prefix="%" f={f} set={set} gen={gen} />
            <Num label="Direct discount" k="direct_discount" prefix="%" f={f} set={set} gen={gen} />
            <Num label="Dealer landing" k="dealer_landing" prefix="₹" f={f} set={set} gen={gen} />
            <Num label="DP margin percent" k="dp_margin_percent" prefix="%" f={f} set={set} gen={gen} />
            <Calc label="MOP" k="mop" f={f} />
            <Num label="Retail margin percent" k="retail_margin_percent" prefix="%" f={f} set={set} gen={gen} />
            <Calc label="Net landing" k="net_landing" f={f} />
            <Calc label="Retail margin" k="retail_margin" f={f} />
            <Calc label="MOP scheme" k="mop_scheme" f={f} />
            <Num label="Trigger price percent" k="trigger_price_percent" prefix="%" f={f} set={set} gen={gen} />
            <Calc label="Trigger price" k="trigger_price" f={f} />
          </div>
        </Card>
        <Card title="Product links">
          <div className="grid gap-3">
            {CH.map((c) => (
              <Field key={c} label={`${channelLabel(c)} product URL`} htmlFor={`link_${c}`}>
                <input id={`link_${c}`} className="input" inputMode="url" value={f[`link_${c}`]} onChange={(e) => set({ [`link_${c}`]: e.target.value })} placeholder={`https://www.${c === "instamart" ? "swiggy.com/instamart" : c === "zepto" ? "zeptonow.com" : c + (c === "amazon" ? ".in" : ".com")}/...`} spellCheck={false} />
              </Field>))}
            <p className="text-[12px] text-faint">Clearing a box switches that channel's link off; its scrape history is kept.</p>
          </div>
        </Card>
        <Card title="Scraping schedule">
          <div className="space-y-4">
            <ScrapingModePicker value={modeOf(f)} onChange={(m) => set(modeFields(m))} />
            {modeOf(f) !== "off" && <TimePicker value={f.scrape_time} onChange={(v) => set({ scrape_time: v })} />}
            {modeOf(f) === "scheduled" && <ScheduleParts weekly={f.scraping_schedule_weekly} months={f.months_to_scrape} monthly={listOf(f.scraping_schedule_monthly)}
              onWeekly={(v) => set({ scraping_schedule_weekly: v })} onMonths={(v) => set({ months_to_scrape: v })} onMonthly={(v) => set({ scraping_schedule_monthly: v.join(",") })} />}
            <ScheduleSummary f={f} />
          </div>
        </Card>
        <Card title="Product attributes" className="lg:col-span-2">
          <div className="grid gap-3 sm:grid-cols-4">
            <Num label="Scheme 1" k="scheme_1" prefix="₹" f={f} set={set} gen={gen} />
            <Num label="Scheme 2" k="scheme_2" prefix="₹" f={f} set={set} gen={gen} />
            <Num label="Scheme 3" k="scheme_3" prefix="₹" f={f} set={set} gen={gen} />
            <Calc label="Total scheme" k="total_scheme" f={f} />
          </div>
        </Card>
      </div>

      {!isNew && <>
        <Card title="Channel links" count={plural(links.length, "link")} bodyClass="">
          <DataTable embedded cols={LCOLS} rows={links} total={links.length} rowKey="product_link_id" empty={{ title: "No links yet", hint: "Add a URL under Product links and save." }} />
        </Card>
        <Card title="Recent scrapes" count={history.length ? `latest ${inr(history.length)}` : undefined} bodyClass=""
          actions={alertPrice(p) > 0 && <span className="text-[12px] text-faint">Breach below {money(alertPrice(p))}</span>}>
          <DataTable embedded cols={HCOLS.map((c) => { const below = (r: any) => isBreach(r.price, p); return c.key === "price" ? { ...c, render: (r: any) => <span className={below(r) ? "font-medium text-danger" : ""}>{r.price > 0 ? money(r.price) : "-"}</span> } : c.key === "availability" ? { ...c, render: (r: any) => <span className="inline-flex gap-1.5"><Availability v={r.availability} />{below(r) && <Pill tone="danger">Below MOP</Pill>}</span> } : c; })}
            rows={history} total={history.length} rowKey="scrape_result_id" maxHeight="28rem" empty={{ title: "Not scraped yet", hint: "Scrapes appear here after the next run on a channel with a link." }} />
        </Card>
      </>}

      <div className="no-print fixed inset-x-0 bottom-0 z-20 border-t border-line bg-surface/95 px-4 py-3 shadow-[0_-6px_16px_rgb(16_24_40/0.06)] backdrop-blur lg:left-60">
        <div className="mx-auto flex max-w-[1500px] items-center justify-end gap-2">
          <span className="mr-auto text-[12.5px] text-faint">{dirty ? "Unsaved changes" : isNew ? "Fill in the details, then add the product." : "All changes saved"}</span>
          {dirty && !isNew && <button type="button" className="btn-ghost" onClick={() => setF(initial)}>Discard</button>}
          <button className="btn-primary" disabled={(!dirty && !isNew) || save.isPending}>{save.isPending ? "Saving..." : isNew ? "Add product" : "Save changes"}</button>
        </div>
      </div>
    </form>
    <NewCategoryDialog open={addingCat} onClose={() => setAddingCat(false)} onCreated={(c) => set({ category_id: String(c.category_id) })} />
    </>
  );
}
