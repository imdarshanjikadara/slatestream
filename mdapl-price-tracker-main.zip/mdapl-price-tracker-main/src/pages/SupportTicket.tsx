// One support request: its conversation with the team, files, status and when to expect a reply. New messages show
// at once as "Sending…"; a failed one stays where it was typed with a Retry (its client_msg_id stops doubles). The
// thread checks for replies every 15 seconds while it is open.
import { useEffect, useMemo, useRef, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { useMutation, useQuery } from "@tanstack/react-query";
import { FileText, Paperclip, RotateCw, Send } from "lucide-react";
import { api, queryClient } from "@/lib/api";
import { ACCEPT, ago, categoryLabel, fileSize, filePayload, fileUrl, newKey, priorityOf, ref, STATUS, when } from "@/lib/support";
import { acceptFiles, FileChips, pastedFiles } from "@/components/FilePicker";
import { ErrorState, Loading, Notice, PageHeader, Spinner } from "@/components/common";
import { Pill } from "@/components/Pill";
import { toast } from "@/components/overlays";
import { NotConnected, notConnected } from "./Support";

const isMac = typeof navigator !== "undefined" && /Mac|iPhone|iPad/.test(navigator.platform);
type File_ = { attachment_id: number; message_id: number | null; file_name: string; content_type: string; size_bytes: number };
type Message = { message_id: number; author: string; author_name: string; author_type: "user" | "agent" | "system"; body: string | null; created_at: string };
type Detail = { ticket: any; messages: Message[]; files: File_[]; me: string; other_read_at: string | null };
type Pending = { client_msg_id: string; body: string; files: File[]; state: "sending" | "failed"; error?: string; at: string };

function Files({ files }: { files: File_[] }) {
  if (!files.length) return null;
  return (
    <div className="mt-2 flex flex-wrap gap-2">
      {files.map((f) => f.content_type?.startsWith("image/")
        ? <a key={f.attachment_id} href={fileUrl(f.attachment_id)} target="_blank" rel="noreferrer" title={f.file_name} className="block overflow-hidden rounded-lg border border-line bg-surface">
            <img src={fileUrl(f.attachment_id)} alt={f.file_name} loading="lazy" className="h-28 w-40 object-cover" /></a>
        : <a key={f.attachment_id} href={fileUrl(f.attachment_id)} target="_blank" rel="noreferrer"
            className="flex max-w-full items-center gap-2 rounded-lg border border-line bg-surface px-2 py-1.5 text-[12.5px] hover:border-line-hover">
            <FileText className="h-4 w-4 shrink-0 text-faint" /><span className="min-w-0 truncate text-ink">{f.file_name}</span><span className="shrink-0 text-faint">{fileSize(f.size_bytes)}</span></a>)}
    </div>
  );
}

/** One detail in the row above the thread: a small label over a one-line value. */
function Cell({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="min-w-0">
      <div className="text-[12px] text-faint">{label}</div>
      <div className="mt-1 flex h-8 min-w-0 items-center truncate text-[13.5px] text-ink">{children || <span className="text-faint">-</span>}</div>
    </div>
  );
}

function Bubble({ mine, who, at, children, foot }: { mine: boolean; who: string; at: string; children: React.ReactNode; foot?: React.ReactNode }) {
  return (
    <div className={`flex ${mine ? "justify-end" : "justify-start"}`}>
      <div className="max-w-[85%] sm:max-w-[75%]">
        <div className={`rounded-2xl px-3.5 py-2.5 text-[13.5px] leading-relaxed text-ink ${mine ? "rounded-br-md bg-accent-soft" : "rounded-bl-md border border-line bg-surface"}`}>{children}</div>
        <div className={`mt-1 px-1 text-[11.5px] text-faint ${mine ? "text-right" : ""}`}>{who} · {at}{foot}</div>
      </div>
    </div>
  );
}

export default function SupportTicket() {
  const id = Number(useParams().id);
  const q = useQuery({ queryKey: ["support", "ticket", id], queryFn: () => api<Detail>(`support/tickets/${id}`), refetchInterval: 15_000, retry: false, enabled: Number.isInteger(id) && id > 0 });
  const [text, setText] = useState("");
  const [files, setFiles] = useState<File[]>([]);
  const [pending, setPending] = useState<Pending[]>([]);
  const fileInput = useRef<HTMLInputElement>(null);
  const thread = useRef<HTMLDivElement>(null);
  const refresh = () => queryClient.invalidateQueries({ queryKey: ["support"] });
  const status = useMutation({
    mutationFn: (s: string) => api(`support/tickets/${id}/status`, { body: { status: s } }),
    onSuccess: () => void refresh(), onError: (e) => toast.error((e as Error).message),
  });

  // Starts at the latest message, and follows new ones.
  const count = (q.data?.messages.length ?? 0) + pending.length;
  useEffect(() => { const el = thread.current; if (el) el.scrollTop = el.scrollHeight; }, [count]);

  const send = async (p: Pending) => {
    setPending((x) => x.map((y) => (y.client_msg_id === p.client_msg_id ? { ...p, state: "sending", error: undefined } : y)));
    try {
      const r = await api<{ message: Message }>(`support/tickets/${id}/messages`, { body: { client_msg_id: p.client_msg_id, body: p.body, files: p.files.length > 0 } });
      for (const f of p.files) await api(`support/tickets/${id}/attachments`, { body: { ...(await filePayload(f)), message_id: r.message.message_id } });
      await refresh();
      setPending((x) => x.filter((y) => y.client_msg_id !== p.client_msg_id));
    } catch (e) {
      setPending((x) => x.map((y) => (y.client_msg_id === p.client_msg_id ? { ...y, state: "failed", error: (e as Error).message } : y)));
    }
  };
  const submit = () => {
    if (!text.trim() && !files.length) return;
    const p: Pending = { client_msg_id: newKey(), body: text.trim(), files, state: "sending", at: new Date().toISOString() };
    setPending((x) => [...x, p]); setText(""); setFiles([]);
    void send(p);
  };

  const byMessage = useMemo(() => {
    const m = new Map<number | null, File_[]>();
    for (const f of q.data?.files ?? []) m.set(f.message_id ?? null, [...(m.get(f.message_id ?? null) ?? []), f]);
    return m;
  }, [q.data?.files]);

  if (q.isLoading) return <div className="page"><Loading /></div>;
  if (notConnected(q.error)) return <div className="page"><PageHeader title="Support" breadcrumb={[{ to: "/support", label: "Support" }]} /><NotConnected /></div>;
  if (q.error || !q.data) return <div className="page"><PageHeader title="Request" breadcrumb={[{ to: "/support", label: "Support" }]} /><div className="card"><ErrorState error={q.error ?? new Error("Request not found")} retry={() => q.refetch()} /></div></div>;
  const data = q.data, t = data.ticket;
  const mine = (author: string) => author === data.me;
  const s = STATUS[t.status] ?? STATUS.open;
  const p = priorityOf(t.priority);
  const closed = t.status === "closed";
  const lastMine = [...data.messages].reverse().find((m) => m.author_type !== "system" && mine(m.author));
  const seen = !!lastMine && !!data.other_read_at && new Date(data.other_read_at) >= new Date(lastMine.created_at);

  return (
    <div className="page page-fill">
      <PageHeader title={t.title} breadcrumb={[{ to: "/support", label: "Support" }]} status={<Pill tone={s.tone} dot={s.dot} title={s.hint}>{s.label}</Pill>}
        subtitle={<>{ref(t.ticket_id)} · raised by {t.created_by_name} {ago(t.created_at).toLowerCase()}</>} />

      {/* The request at a glance, in one row above the conversation. */}
      <div className="card grid shrink-0 grid-cols-2 items-end gap-x-6 gap-y-3 px-4 py-3 sm:grid-cols-3 lg:grid-cols-[repeat(5,minmax(0,1fr))_auto]">
        <Cell label="About">{categoryLabel(t.category)}</Cell>
        <Cell label="Part of the app">{t.area}</Cell>
        <Cell label="Priority">{`${p.label} · ${p.reply}`}</Cell>
        <Cell label="Opened">{when(t.created_at)}</Cell>
        {!closed && <Cell label={t.first_reply_at ? "Resolution target" : "First reply due"}>{when(t.first_reply_at ? t.resolve_due_at : t.first_reply_due_at)}</Cell>}
        {!closed && t.status !== "resolved" && <button className="btn-ghost justify-self-start lg:justify-self-end" disabled={status.isPending} onClick={() => status.mutate("closed")}>{status.isPending && <Spinner className="h-3.5 w-3.5" />}Withdraw request</button>}
      </div>

      <div className="card flex min-h-[420px] flex-1 flex-col lg:min-h-0">
        {t.status === "waiting_client" && <Notice tone="warning" className="m-4 mb-0 shrink-0" title="We need a bit more information">Reply below and the request goes back to the team.</Notice>}
        {t.status === "resolved" && (
          <Notice tone="success" className="m-4 mb-0 shrink-0" title="Marked resolved"
            action={<><button className="btn btn-sm" disabled={status.isPending} onClick={() => status.mutate("closed")}>Yes, it's fixed</button><button className="btn btn-sm" disabled={status.isPending} onClick={() => status.mutate("in_progress")}>Still an issue</button></>}>
            Still an issue? Reply to reopen it. It closes by itself after 7 days.
          </Notice>)}

        <div ref={thread} className="grid min-h-0 flex-1 content-start gap-4 overflow-y-auto p-4" aria-live="polite">
          <Bubble mine={mine(t.created_by)} who={t.created_by_name} at={when(t.created_at)}>
            <div className="whitespace-pre-wrap break-words">{t.description}</div>
            <Files files={byMessage.get(null) ?? []} />
          </Bubble>
          {data.messages.filter((m) => !(m.author_type === "system" && m.body === "Request received.")).map((m) => m.author_type === "system"
            ? <div key={m.message_id} className="flex items-center gap-3 text-[12px] text-faint"><span className="h-px flex-1 bg-line" /><span className="text-center">{(m.body ?? "").replace(/\.$/, "")} · {ago(m.created_at).toLowerCase()}</span><span className="h-px flex-1 bg-line" /></div>
            : <Bubble key={m.message_id} mine={mine(m.author)} at={when(m.created_at)} who={`${m.author_name}${m.author_type === "agent" ? " · Support" : ""}`}
                foot={m === lastMine && !pending.length ? (seen ? " · Seen" : " · Sent") : undefined}>
                {m.body && <div className="whitespace-pre-wrap break-words">{m.body}</div>}
                <Files files={byMessage.get(m.message_id) ?? []} />
              </Bubble>)}
          {pending.map((m) => (
            <Bubble key={m.client_msg_id} mine who="You" at={when(m.at)}
              foot={m.state === "sending" ? " · Sending…" : <> · <span className="text-danger">Not sent</span> <button type="button" className="inline-flex items-center gap-1 text-ink underline underline-offset-2" onClick={() => void send(m)}><RotateCw className="h-3 w-3" />Retry</button></>}>
              {m.body && <div className="whitespace-pre-wrap break-words">{m.body}</div>}
              {m.files.length > 0 && <div className="mt-2"><FileChips files={m.files} /></div>}
              {m.error && <div className="mt-1 text-[12px] text-danger">{m.error}</div>}
            </Bubble>))}
        </div>

        {closed ? (
          <div className="flex shrink-0 flex-wrap items-center gap-3 border-t border-line px-4 py-3 text-[13px] text-muted">
            This request is closed.<Link to="/support/new" className="btn btn-sm ml-auto">Start a new request</Link>
          </div>
        ) : (
          <div className="sticky bottom-0 shrink-0 rounded-b-[inherit] border-t border-line bg-surface p-3">
            <textarea aria-label="Write a reply" rows={2} value={text} onChange={(e) => setText(e.target.value)} maxLength={4000}
              onPaste={(e) => { const f = pastedFiles(e); if (f.length) { e.preventDefault(); setFiles((x) => acceptFiles(f, x)); } }}
              onKeyDown={(e) => { if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) { e.preventDefault(); submit(); } }}
              placeholder="Write a reply…" className="input max-h-48 resize-none" />
            {files.length > 0 && <div className="mt-2"><FileChips files={files} onRemove={(i) => setFiles(files.filter((_, j) => j !== i))} /></div>}
            <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-2">
              <button type="button" className="btn-ghost" onClick={() => fileInput.current?.click()}><Paperclip className="h-4 w-4" />Attach</button>
              <input ref={fileInput} type="file" multiple hidden accept={ACCEPT} onChange={(e) => { const add = [...(e.target.files ?? [])]; e.target.value = ""; setFiles((x) => acceptFiles(add, x)); }} />
              <span className="ml-auto hidden text-[12px] text-faint sm:inline">
                {t.status === "waiting_client" || t.status === "resolved" ? "Sending moves it back to the team · " : null}
                <kbd className="rounded border border-line bg-surface-alt px-1.5 py-px font-sans text-[11px] text-muted">{isMac ? "⌘" : "Ctrl"} Enter</kbd> to send
              </span>
              <button type="button" className="btn-primary ml-auto w-28 sm:ml-0" disabled={!text.trim() && !files.length} onClick={submit}><Send className="h-4 w-4" />Send</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
