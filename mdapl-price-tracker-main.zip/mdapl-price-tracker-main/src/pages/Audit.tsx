// Audit log (reference: audit/page.tsx + AuditRow): every change, who made it, device, IP, time, field-by-field
// before/after in a dialog, and restore of deletions within 30 days.
import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { ChevronRight, RotateCcw } from "lucide-react";
import { api, queryClient, useList } from "@/lib/api";
import { useUrlState } from "@/lib/hooks";
import { dateTimeFull, inr } from "@/lib/format";
import { useAuth } from "@/lib/auth";
import { EmptyState, ErrorState, Loading, PageHeader, Tabs } from "@/components/common";
import { Pagination } from "@/components/DataTable";
import { FilterBar, SearchBox } from "@/components/FilterBar";
import { Select } from "@/components/ui/Select";
import { DateRange } from "@/components/ui/DateRange";
import { Pill } from "@/components/Pill";
import { Dialog, confirmAction, toast } from "@/components/overlays";

const TABLE_LABEL: Record<string, string> = {
  product_categories: "Category", products: "Product", product_links: "Product link", scrape_runs: "Scrape run", scrape_run_batches: "Scrape batch",
  scrape_results: "Scrape result", mop_breach_reports: "MOP breach report", mop_breach_report_items: "MOP report line", app_users: "Team member",
};
const ACTION_LABEL: Record<string, string> = { insert: "Added", update: "Edited", delete: "Deleted", soft_delete: "Deleted", restore: "Restored" };
const tableLabel = (t: string) => TABLE_LABEL[t] ?? t.replace(/_/g, " ");
const field = (k: string) => k.replace(/_id$/, " ID").replace(/_/g, " ").replace(/^\w/, (c) => c.toUpperCase());
const show = (v: unknown) => (v === null || v === undefined || v === "" ? "empty" : typeof v === "boolean" ? (v ? "Yes" : "No") : Array.isArray(v) ? v.join(", ") : typeof v === "object" ? JSON.stringify(v) : /^\d{4}-\d{2}-\d{2}T/.test(String(v)) ? dateTimeFull(v) : String(v));
// Who made a change: the person's name ("Disha"), or what the system part was. Names come with the list.
let NAMES: Record<string, string> = {};
const actorLabel = (a: string) => (a === "database" ? "System change" : a === "system:scraper" ? "Scraper" : a === "system:scheduler" ? "Scheduler" : a === "system:setup" ? "Setup"
  : NAMES[a?.toLowerCase()] ?? (a?.includes("@") ? a.split("@")[0].replace(/[._-]+/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()) : a));
const ACTION_DOT: Record<string, "danger" | "info" | "success" | "neutral"> = { delete: "danger", soft_delete: "danger", restore: "info", insert: "success", update: "neutral" };

function device(ua?: string | null) {
  if (!ua) return null;
  const os = /iPhone/.test(ua) ? "iPhone" : /iPad/.test(ua) ? "iPad" : /Android/.test(ua) ? "Android" : /Windows/.test(ua) ? "Windows" : /Mac OS X/.test(ua) ? "Mac" : /Linux/.test(ua) ? "Linux" : "Unknown system";
  const br = /Edg\//.test(ua) ? "Edge" : /CriOS|Chrome\//.test(ua) ? "Chrome" : /FxiOS|Firefox\//.test(ua) ? "Firefox" : /Safari\//.test(ua) ? "Safari" : /curl/.test(ua) ? "Script" : "Browser";
  return `${br} on ${os}`;
}

function useRestore(after?: () => void) {
  return useMutation({
    mutationFn: (id: number) => api(`audit/${id}/restore`, { method: "POST", body: {} }),
    onSuccess: (r) => { toast.success(r.message); void queryClient.invalidateQueries(); after?.(); },
    onError: (e) => toast.error((e as Error).message),
  });
}

function EntryDialog({ id, onClose }: { id: number | null; onClose: () => void }) {
  const q = useQuery({ queryKey: ["audit", id], queryFn: () => api(`audit/${id}`), enabled: !!id });
  const restore = useRestore(onClose);
  const e = q.data;
  const deleted = e && (e.action === "delete" || e.action === "soft_delete");
  const changes = e && (e.action === "update" || e.action === "restore") ? Object.keys(e.new_data ?? {}).map((k) => ({ k, from: e.old_data?.[k], to: e.new_data?.[k] })) : [];
  const snapshot = e && (e.action === "insert" ? e.new_data : deleted ? e.old_data : null);
  return (
    <Dialog open={!!id} onClose={onClose} wide title={e ? `${ACTION_LABEL[e.action]} ${tableLabel(e.table_name).toLowerCase()} #${e.row_pk}` : "Change"}
      footer={e && deleted && (e.restored_at ? <Pill tone="info">Restored {dateTimeFull(e.restored_at)} by {actorLabel(e.restored_by)}</Pill>
        : e.restorable ? <button className="btn-primary" disabled={restore.isPending} onClick={async () => { if (await confirmAction({ title: e.together > 1 ? `Restore this and the ${e.together - 1} other records deleted with it?` : "Restore this record?", body: "It goes back into its list.", confirmLabel: "Restore" })) restore.mutate(e.id); }}><RotateCcw className="h-4 w-4" />{e.together > 1 ? `Restore ${e.together}` : "Restore"}</button>
        : <span className="text-[12.5px] text-faint">Deleted more than 30 days ago; it can no longer be restored here.</span>)}>
      {q.isLoading ? <Loading /> : q.error ? <ErrorState error={q.error} /> : e && (
        <div className="space-y-4 text-[13px]">
          <dl className="dl">
            <dt>When</dt><dd>{dateTimeFull(e.at)}</dd>
            <dt>By</dt><dd>{actorLabel(e.actor)}{e.actor?.includes("@") && <span className="ml-1.5 text-faint">{e.actor}</span>}</dd>
            <dt>Device</dt><dd>{device(e.user_agent) ?? <span className="text-faint">Not recorded</span>}</dd>
            <dt>IP address</dt><dd className={e.ip ? "font-mono text-[12.5px]" : "text-faint"}>{e.ip ?? (e.actor.startsWith("system") || e.actor === "database" ? "Not applicable (system change)" : "Not recorded")}</dd>
            <dt>Record</dt><dd>{tableLabel(e.table_name)} #{e.row_pk}</dd>
          </dl>
          {changes.length > 0 && (
            <div className="overflow-x-auto rounded-lg border border-line">
              <table className="tbl w-full text-[13px]"><thead className="bg-surface-alt text-left text-[12px] text-faint"><tr><th className="px-3 py-2 font-medium">Field</th><th className="px-3 py-2 font-medium">Before</th><th className="px-3 py-2 font-medium">After</th></tr></thead>
                <tbody className="divide-y divide-line">{changes.map((c) => <tr key={c.k} className="align-top"><td className="px-3 py-2 text-muted">{field(c.k)}</td><td className="px-3 py-2 break-words [overflow-wrap:anywhere]">{show(c.from)}</td><td className="px-3 py-2 break-words [overflow-wrap:anywhere]">{show(c.to)}</td></tr>)}</tbody></table>
            </div>)}
          {snapshot && (
            <div>
              <div className="mb-2 text-[12px] font-medium text-muted">{deleted ? "The record as it was" : "The record as added"}</div>
              <dl className="dl rounded-lg border border-line p-3">
                {Object.entries(snapshot).filter(([, v]) => v !== null && v !== "").map(([k, v]) => <div key={k} className="contents"><dt>{field(k)}</dt><dd className="[overflow-wrap:anywhere]">{show(v)}</dd></div>)}
              </dl>
            </div>)}
        </div>)}
    </Dialog>
  );
}

export default function Audit() {
  const { user } = useAuth();
  const [f, set, active] = useUrlState({ tab: "all", table: "", action: "", actor: "", record: "", from: "", to: "" });
  const params = { tab: f.tab, table: f.table, action: f.action, actor: f.actor, record: f.record, from: f.from, to: f.to };
  const list = useList("audit", params, user?.role === "admin");
  if (list.meta?.names) NAMES = list.meta.names;
  const [open, setOpen] = useState<number | null>(null);
  const restore = useRestore();
  if (user?.role !== "admin") return <div className="card"><EmptyState title="This page does not exist" /></div>;
  const filtered = active.some((k) => k !== "tab");
  const clear = () => set({ table: null, action: null, actor: null, record: null, from: null, to: null });
  const COLS = "sm:grid sm:grid-cols-[12.5rem_6.5rem_minmax(0,1fr)_13rem_7rem_1.25rem] sm:items-start sm:gap-x-4";

  return (
    <div className="page">
      <PageHeader title="Audit log" subtitle="Every change to the records, who made it, from which device, and when. Deleted records can be restored for 30 days." />
      <Tabs ariaLabel="View" active={f.tab} onChange={(k) => set({ tab: k, action: null })} items={[{ key: "all", label: "All changes" }, { key: "deleted", label: "Deleted" }]} />
      <FilterBar active={filtered} onClear={clear}>
        <Select className="w-full sm:w-48" ariaLabel="Record type" placeholder="All record types" value={f.table} onChange={(v) => set({ table: v || null })}
          options={(list.meta?.tables ?? Object.keys(TABLE_LABEL)).map((t: string) => ({ value: t, label: tableLabel(t) }))} />
        {f.tab === "all" && <Select className="w-full sm:w-40" ariaLabel="Change" placeholder="Any change" value={f.action} onChange={(v) => set({ action: v || null })}
          options={[{ value: "insert", label: "Added" }, { value: "update", label: "Edited" }, { value: "soft_delete", label: "Deleted (switched off)" }, { value: "delete", label: "Deleted (removed)" }, { value: "restore", label: "Restored" }]} />}
        <Select className="w-full sm:w-56" ariaLabel="Changed by" placeholder="Changed by anyone" value={f.actor} onChange={(v) => set({ actor: v || null })}
          options={(list.meta?.actors ?? []).map((a: string) => ({ value: a, label: actorLabel(a) }))} />
        <SearchBox value={f.record} onChange={(v) => set({ record: v.replace(/\D/g, "") })} placeholder="Record #" className="w-full sm:w-36" ariaLabel="Record number" />
        <DateRange label="Changed" from={f.from} to={f.to} onFrom={(v) => set({ from: v || null })} onTo={(v) => set({ to: v || null })} className="w-full sm:w-auto" />
      </FilterBar>
      <section className="card overflow-hidden">
        <div className="card-head"><h2 className="card-title">{f.tab === "deleted" ? "Deleted records" : "Changes"}</h2><span className="count">{inr(list.total)} {list.total === 1 ? "entry" : "entries"}</span><span className="ml-auto hidden text-[12px] text-faint sm:inline">Click a row to see every detail</span></div>
        {list.error ? <ErrorState error={list.error} retry={() => list.refetch()} /> : list.isLoading ? <Loading /> : list.rows.length ? <>
          <div className={`hidden border-b border-line bg-surface-alt px-4 py-2 text-[12px] font-medium text-faint ${COLS}`}><span>When</span><span>Change</span><span>Record</span><span className="text-right">By</span><span className="text-right">Restore</span><span /></div>
          <div className={`divide-y divide-line transition-opacity ${list.isFetching ? "opacity-60" : ""}`}>
            {list.rows.map((r: any) => {
              const deleted = r.action === "delete" || r.action === "soft_delete";
              return (
                <div key={r.id} className={`relative px-4 py-3 text-[13px] transition-colors hover:bg-surface-alt ${COLS}`}>
                  <button type="button" className="absolute inset-0 cursor-pointer focus-visible:outline-offset-[-2px]" onClick={() => setOpen(r.id)} aria-label={`Show details of change ${r.id}`} />
                  <div className="pointer-events-none tabular-nums text-faint">{dateTimeFull(r.at)}</div>
                  <div className="pointer-events-none mt-0.5 sm:mt-0"><span className="inline-flex items-center gap-1.5"><span className={`dot ${{ danger: "bg-danger-fill", info: "bg-info-fill", success: "bg-success-fill", neutral: "bg-line-hover" }[ACTION_DOT[r.action]]}`} />{ACTION_LABEL[r.action]}</span></div>
                  <div className="pointer-events-none mt-0.5 min-w-0 break-words [overflow-wrap:anywhere] sm:mt-0">
                    <span className="font-medium">{tableLabel(r.table_name)} #{r.row_pk}</span>{r.title && <span className="text-faint"> {r.title}</span>}
                    {r.preview && <span className="block text-faint">{Object.entries(r.preview as Record<string, [unknown, unknown]>).map(([k, [a, b]]) => `${field(k)} ${show(a)} to ${show(b)}`).join(", ")}{r.fields?.length > 2 ? `, and ${r.fields.length - 2} more` : ""}</span>}
                  </div>
                  <div className="pointer-events-none mt-0.5 min-w-0 break-words text-faint sm:mt-0 sm:text-right">{actorLabel(r.actor)}{r.ip && <span className="block font-mono text-[12px]">{r.ip}</span>}</div>
                  <div className="relative z-10 mt-2 sm:mt-0 sm:text-right">
                    {deleted && (r.restored_at ? <Pill tone="info">Restored</Pill>
                      : r.restorable ? <button className="btn btn-sm" disabled={restore.isPending} onClick={async () => { if (await confirmAction({ title: "Restore this record?", body: "It goes back into its list.", confirmLabel: "Restore" })) restore.mutate(r.id); }}><RotateCcw className="h-3.5 w-3.5" />Restore</button>
                      : <span className="text-[12px] text-faint" title="Deleted more than 30 days ago">Too old</span>)}
                  </div>
                  <ChevronRight className="pointer-events-none absolute right-4 top-3.5 h-4 w-4 text-faint sm:static sm:mt-0.5" />
                </div>);
            })}
          </div>
          <Pagination pager={list.pager} shown={list.rows.length} />
        </> : filtered ? <EmptyState title="No changes match these filters" hint="Changes exist, but the filters hide them." action={<button className="btn btn-sm" onClick={clear}>Clear filters</button>} />
          : <EmptyState title={f.tab === "deleted" ? "Nothing has been deleted yet" : "No changes recorded yet"} hint={f.tab === "deleted" ? undefined : "Every save, edit and delete from now on appears here."} />}
      </section>
      <EntryDialog id={open} onClose={() => setOpen(null)} />
    </div>
  );
}
