// Import products from Excel or CSV: the old product sheet, a price list (HANA code, MRP, DP) or a link list.
// The file is read in the browser, columns are matched to product fields, the server shows every change before
// anything is saved, then applies the valid rows in one go (all recorded in the Audit log).
import { useMemo, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { useMutation } from "@tanstack/react-query";
import { FileSpreadsheet, Upload } from "lucide-react";
import { api, queryClient } from "@/lib/api";
import { inr, money } from "@/lib/format";
import { Card, EmptyState, PageHeader, StatStrip, Tabs } from "@/components/common";
import { DataTable, type Col } from "@/components/DataTable";
import { Select } from "@/components/ui/Select";
import { Pill } from "@/components/Pill";
import { confirmAction, toast } from "@/components/overlays";
import { downloadMaster } from "./ProductBulk";

type Target = { key: string; label: string; aliases: string[] };
const IGNORE = "";
const CALC = "__calc";
// Header names are compared lower-case with spaces and symbols removed ("MRP (₹)" -> "mrp", "HANA Code" -> "hanacode").
const TARGETS: Target[] = [
  { key: "product_id", label: "Product ID", aliases: ["productid", "id"] },
  { key: "hana_code", label: "Hana code", aliases: ["hanacode", "hana", "hanacodes", "itemcode", "sku"] },
  { key: "name", label: "Name", aliases: ["name", "productname"] },
  { key: "brand", label: "Brand", aliases: ["brand"] },
  { key: "category_name", label: "Category name", aliases: ["categoryname", "category"] },
  { key: "category_id", label: "Category ID", aliases: ["categoryid"] },
  { key: "description", label: "Description", aliases: [] },
  { key: "ph", label: "Product head (PH)", aliases: ["ph", "producthead"] },
  { key: "product_is_active", label: "Active (TRUE/FALSE)", aliases: ["productisactive", "isactive", "active"] },
  { key: "mrp", label: "MRP", aliases: ["mrp"] },
  { key: "dealer_landing", label: "Dealer landing (DP)", aliases: ["dealerlanding", "dp", "dealerprice", "landing"] },
  { key: "direct_discount", label: "Direct discount %", aliases: ["directdiscount", "discount"] },
  { key: "gst_percent", label: "GST %", aliases: ["gstpercent", "gst"] },
  { key: "dp_margin_percent", label: "DP margin %", aliases: ["dpmarginpercent", "dpmargin"] },
  { key: "scheme_1", label: "Scheme 1", aliases: ["scheme1"] },
  { key: "scheme_2", label: "Scheme 2", aliases: ["scheme2"] },
  { key: "scheme_3", label: "Scheme 3", aliases: ["scheme3"] },
  { key: "retail_margin_percent", label: "Retail margin %", aliases: ["retailmarginpercent"] },
  { key: "trigger_price_percent", label: "Trigger price %", aliases: ["triggerpricepercent"] },
  { key: "regular_scraping", label: "Regular scraping", aliases: ["regularscraping"] },
  { key: "scheduled_scraping", label: "Scheduled scraping", aliases: ["scheduledscraping"] },
  { key: "scraping_schedule_weekly", label: "Weekly days (1-7)", aliases: ["scrapingscheduleweekly", "weekly"] },
  { key: "months_to_scrape", label: "Months to scrape (1-12)", aliases: ["monthstoscrape", "months"] },
  { key: "scraping_schedule_monthly", label: "Monthly dates (1-31)", aliases: ["scrapingschedulemonthly", "monthly"] },
  { key: "amazon_url", label: "Amazon link", aliases: ["amazonurl", "amazon", "amazonlink"] },
  { key: "flipkart_url", label: "Flipkart link", aliases: ["flipkarturl", "flipkart", "flipkartlink"] },
  { key: "instamart_url", label: "Instamart link", aliases: ["instamarturl", "instamart", "instamartlink"] },
  { key: "zepto_url", label: "Zepto link", aliases: ["zeptourl", "zepto", "zeptolink"] },
];
// Columns the app calculates or assigns itself: shown, never imported.
const CALCULATED = new Set(["mop", "totalscheme", "netlanding", "retailmargin", "mopscheme", "triggerprice", "amazonproductlinkid", "flipkartproductlinkid",
  "instamartproductlinkid", "zeptoproductlinkid", "createdat", "updatedat"]);
// Calculated columns sent along only to fill a blank percentage (old rows with "=V2*0.2" instead of a retail margin %).
const FILL_FROM: Record<string, string> = { mop: "__calc_mop", retailmargin: "__calc_retail_margin", triggerprice: "__calc_trigger_price" };
const norm = (h: string) => h.toLowerCase().replace(/\(.*?\)/g, "").replace(/[^a-z0-9]/g, "");
// "Description" is never guessed: in the old sheets it held product names, and importing it by accident would overwrite them.
const guess = (h: string) => { const n = norm(h); if (CALCULATED.has(n)) return CALC; return TARGETS.find((t) => t.key !== "description" && (t.aliases.includes(n) || norm(t.key) === n))?.key ?? IGNORE; };

type Sheet = { name: string; headers: string[]; rows: unknown[][]; headerRow: number };

function cellValue(v: any): unknown {
  if (v === null || v === undefined) return null;
  if (typeof v === "object") {
    if (v instanceof Date) return v.toISOString().slice(0, 10);
    if ("error" in v) return null;                          // #N/A, #REF! ...: treated as an empty cell
    if ("formula" in v || "sharedFormula" in v || "result" in v) return cellValue(v.result);   // formula: its last calculated value
    if ("hyperlink" in v) {                                 // the cell's own number or URL wins; a label like "Amazon" gives its link
      const t = cellValue(v.text);
      return typeof t === "number" || (typeof t === "string" && /^https?:\/\//i.test(t.trim())) || !v.hyperlink ? t : v.hyperlink;
    }
    if ("richText" in v) return v.richText.map((x: any) => x.text).join("");
    if ("text" in v) return cellValue(v.text);
    return null;
  }
  return v;
}

function parseCsv(text: string): unknown[][] {
  const out: string[][] = []; let row: string[] = [], cell = "", q = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) { if (c === '"' && text[i + 1] === '"') { cell += '"'; i++; } else if (c === '"') q = false; else cell += c; }
    else if (c === '"') q = true;
    else if (c === ",") { row.push(cell); cell = ""; }
    else if (c === "\n" || c === "\r") { if (c === "\r" && text[i + 1] === "\n") i++; row.push(cell); out.push(row); row = []; cell = ""; }
    else cell += c;
  }
  if (cell || row.length) { row.push(cell); out.push(row); }
  return out;
}

/** The header row is the first of the top 10 rows that names at least two known columns. */
function toSheet(name: string, grid: unknown[][]): Sheet | null {
  const idx = grid.slice(0, 10).findIndex((r) => r.filter((c) => typeof c === "string" && guess(c) && guess(c) !== CALC).length >= 2);
  if (idx < 0) return null;
  const headers = grid[idx].map((c, i) => (c === null || c === undefined || c === "" ? `Column ${i + 1}` : String(c).trim()));
  const rows = grid.slice(idx + 1).filter((r) => r.some((c) => c !== null && c !== undefined && String(c).trim() !== ""));
  return { name, headers, rows, headerRow: idx + 1 };
}

async function readFile(file: File): Promise<Sheet[]> {
  if (/\.csv$/i.test(file.name)) { const s = toSheet(file.name, parseCsv(await file.text())); return s ? [s] : []; }
  if (!/\.xlsx$/i.test(file.name)) throw new Error("Use an Excel .xlsx file or a .csv file. (Save .xls files as .xlsx first.)");
  const ExcelJS = (await import("exceljs")).default;
  const wb = new ExcelJS.Workbook();
  await wb.xlsx.load(await file.arrayBuffer());
  const sheets: Sheet[] = [];
  wb.eachSheet((ws) => {
    if (ws.state !== "visible") return;
    const grid: unknown[][] = [];
    ws.eachRow({ includeEmpty: true }, (row, n) => { const vals = (row.values as unknown[]).slice(1).map(cellValue); grid[n - 1] = vals; });
    const s = toSheet(ws.name, Array.from(grid, (r) => r ?? []));
    if (s) sheets.push(s);
  });
  return sheets;
}

const show = (field: string, v: unknown) => {
  if (v === null || v === undefined || v === "") return "empty";
  if (typeof v === "boolean") return v ? "Yes" : "No";
  if (typeof v === "number" && /mrp|landing|scheme|mop|margin$|price$/.test(field) && !/percent/.test(field)) return money(v);
  return String(v);
};

export default function ProductImport() {
  const nav = useNavigate();
  const [sheets, setSheets] = useState<Sheet[] | null>(null);
  const [fileName, setFileName] = useState("");
  const [sheetName, setSheetName] = useState("");
  const [map, setMap] = useState<Record<number, string>>({});
  const [createMissing, setCreateMissing] = useState(false);
  const [updateDuplicates, setUpdateDuplicates] = useState(false);
  const [preview, setPreview] = useState<any>(null);
  const [view, setView] = useState("changes");
  const [reading, setReading] = useState(false);
  const sheet = sheets?.find((s) => s.name === sheetName) ?? null;

  const pick = async (file: File | undefined) => {
    if (!file) return;
    setReading(true); setPreview(null);
    try {
      const list = await readFile(file);
      if (!list.length) throw new Error("No sheet in this file has recognisable column names (for example product_id, hana_code, name, MRP, DP).");
      const best = list.find((s) => /^products$/i.test(s.name)) ?? list[0];
      setSheets(list); setFileName(file.name); choose(best);
    } catch (e) { toast.error((e as Error).message); }
    finally { setReading(false); }
  };
  const choose = (s: Sheet) => { setSheetName(s.name); setMap(Object.fromEntries(s.headers.map((h, i) => [i, guess(h)]))); setPreview(null); };

  const mapped = useMemo(() => {
    if (!sheet) return [];
    const used = Object.entries(map).filter(([, k]) => k && k !== CALC);
    return sheet.rows.map((r, i) => {
      const o: Record<string, unknown> = { __row: sheet.headerRow + 1 + i };
      for (const [ci, k] of used) { const v = r[Number(ci)]; if (v !== null && v !== undefined && String(v).trim() !== "") o[k] = typeof v === "string" ? v.trim() : v; }
      sheet.headers.forEach((h, ci) => { const f = map[ci] === CALC && FILL_FROM[norm(h)]; if (f && typeof r[ci] === "number") o[f] = r[ci]; });
      return o;
    });
  }, [sheet, map]);
  const keys = new Set(Object.values(map).filter((k) => k && k !== CALC));
  const dupTargets = [...keys].filter((k) => Object.values(map).filter((x) => x === k).length > 1);
  const canMatch = keys.has("product_id") || keys.has("hana_code") || (createMissing && keys.has("name"));

  const previewM = useMutation({ mutationFn: (withCreate?: boolean) => api("products/import", { body: { rows: mapped, createMissing: withCreate ?? createMissing, updateDuplicates } }), onSuccess: (d) => { setPreview(d); setView(d.summary.create + d.summary.update ? (d.summary.update ? "changes" : "new") : d.summary.duplicates ? "duplicates" : d.summary.errors ? "errors" : "changes"); }, onError: (e) => toast.error((e as Error).message) });
  const applyM = useMutation({
    mutationFn: () => api("products/import", { body: { rows: mapped, createMissing, updateDuplicates, apply: true } }),
    onSuccess: (d) => {
      void queryClient.invalidateQueries();
      toast.success(`Import done: ${inr(d.applied.created)} products added, ${inr(d.applied.updated)} updated${d.applied.categories ? `, ${inr(d.applied.categories)} categories added` : ""}${d.summary.errors ? `; ${inr(d.summary.errors)} rows with problems were skipped` : ""}${d.summary.duplicates ? `; ${inr(d.summary.duplicates)} duplicates were not added` : ""}.`);
      setPreview(null); setSheets(null); nav("/products");
    },
    onError: (e) => toast.error((e as Error).message),
  });

  const rows: any[] = preview?.rows ?? [];
  // Rows that failed only because their product is not saved yet: one tick brings them in.
  const missing = rows.filter((r) => r.action === "error" && /Tick "Add new products"/.test(r.error ?? "")).length;
  const shown = rows.filter((r) => (view === "changes" ? r.action === "update" : view === "new" ? r.action === "create" : view === "errors" ? r.action === "error" : view === "duplicates" ? r.action === "duplicate" : r.action === "unchanged"));
  const PCOLS: Col[] = [
    { key: "row", label: "Row", kind: "int", align: "left", className: "text-faint" },
    { key: "name", label: "Product", render: (r) => <span className="font-medium">{r.product_id ? `#${r.product_id} ` : ""}{r.name ?? "-"}</span> },
    { key: "action", label: "Result", render: (r) => r.action === "error" ? <Pill tone="danger">Problem</Pill> : r.action === "duplicate" ? <Pill tone="warning">Duplicate, not added</Pill> : r.action === "create" ? <Pill tone="info">New</Pill> : r.action === "update" ? <Pill>{`${r.changes.length} ${r.changes.length === 1 ? "change" : "changes"}`}</Pill> : <Pill>Unchanged</Pill> },
    { key: "changes", label: "What changes", grow: true, render: (r) => r.error ? <span className={r.action === "duplicate" ? "text-warning" : "text-danger"}>{r.error}</span> : r.changes.length || r.notes?.length ? (<>
      {r.notes?.map((n: string) => <div key={n} className="py-0.5 text-[12.5px] text-warning">{n}</div>)}
      {!!r.changes.length && (
      <ul className="space-y-0.5 py-1 text-[12.5px]">{r.changes.map((c: any) => <li key={c.field}><span className="text-faint">{c.label}:</span> {r.action === "create" ? show(c.field, c.to) : <>{show(c.field, c.from)} <span className="text-faint">to</span> <span className="font-medium">{show(c.field, c.to)}</span></>}</li>)}</ul>)}</>) : <span className="text-faint">Same as saved</span> },
  ];
  // Filters carried over from the Products page: the master download follows them.
  const [sp] = useSearchParams();
  const filters = Object.fromEntries(["status", "q", "brand", "category", "link"].map((k) => [k, sp.get(k)]).filter(([, v]) => v));
  const filtered = Object.keys(filters).length > 0;
  const master = () => void downloadMaster(filters, filtered ? "the filters of the Products page" : "");
  const s = preview?.summary;
  const toApply = s ? s.create + s.update : 0;

  return (
    <div className="page">
      <PageHeader title="Import products" breadcrumb={[{ to: "/products", label: "Products" }]}
        subtitle="Bring in the product master, a price list (HANA code, MRP, DP) or a link list from Excel or CSV. You see every change before anything is saved.">
        <button className="btn" onClick={master}><FileSpreadsheet className="h-4 w-4" />{filtered ? "Download filtered product master" : "Download product master"}</button>
      </PageHeader>

      <Card title="1. Choose the file">
        <label className={`flex cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-line-strong px-4 py-8 text-center transition-colors hover:border-line-hover hover:bg-surface-alt ${reading ? "opacity-60" : ""}`}
          onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); void pick(e.dataTransfer.files[0]); }}>
          <Upload className="h-6 w-6 text-faint" />
          <span className="text-[13.5px] font-medium text-ink">{reading ? "Reading the file..." : fileName ? `${fileName}: choose another file` : "Drop an Excel (.xlsx) or CSV file here, or click to choose"}</span>
          <span className="text-[12px] text-faint">Rows are matched by product_id, else by hana code. A blank cell leaves that field as it is.</span>
          <input type="file" accept=".xlsx,.csv" className="sr-only" onChange={(e) => { void pick(e.target.files?.[0]); e.target.value = ""; }} />
        </label>
        {sheets && sheets.length > 1 && (
          <div className="mt-4 flex flex-wrap items-center gap-2 text-[13px]"><span className="text-muted">Sheet:</span>
            <Select className="w-64" required ariaLabel="Sheet" value={sheetName} onChange={(v) => choose(sheets.find((x) => x.name === v)!)} options={sheets.map((x) => ({ value: x.name, label: `${x.name} (${inr(x.rows.length)} rows)` }))} />
          </div>)}
      </Card>

      {sheet && (
        <Card title="2. Check the columns" count={`${inr(sheet.rows.length)} rows in ${sheet.name}`}>
          <div className="overflow-x-auto">
            <table className="tbl w-full text-[13px]">
              <thead className="bg-surface-alt text-left text-[12px] text-faint"><tr><th className="px-3 py-2 font-medium">Column in the file</th><th className="px-3 py-2 font-medium">First value</th><th className="w-72 px-3 py-2 font-medium">Goes into</th></tr></thead>
              <tbody className="divide-y divide-line">
                {sheet.headers.map((h, i) => (
                  <tr key={i}>
                    <td className="px-3 py-1.5 font-medium">{h}</td>
                    <td className="max-w-[18rem] truncate px-3 py-1.5 text-muted">{String(sheet.rows.find((r) => r[i] !== null && r[i] !== undefined && r[i] !== "")?.[i] ?? "")}</td>
                    <td className="px-3 py-1.5">{map[i] === CALC ? <span className="text-[12.5px] text-faint">{FILL_FROM[norm(h)] ? "Calculated by the app; fills a blank %" : "Calculated by the app (not imported)"}</span> :
                      <Select size="sm" ariaLabel={`Field for ${h}`} placeholder="Do not import" value={map[i] ?? ""} onChange={(v) => { setMap((m) => ({ ...m, [i]: v })); setPreview(null); }}
                        options={TARGETS.map((t) => ({ value: t.key, label: t.label }))} />}</td>
                  </tr>))}
              </tbody>
            </table>
          </div>
          <div className="mt-4 flex flex-wrap items-center gap-x-6 gap-y-3">
            <label className="inline-flex items-center gap-2 text-[13.5px]"><input type="checkbox" checked={createMissing} onChange={(e) => { setCreateMissing(e.target.checked); setPreview(null); }} />Add new products (and categories) for rows that match nothing</label>
            {createMissing && <label className="inline-flex items-center gap-2 text-[13.5px]" title="A row whose product is already saved (same name, hana code or link) is never added twice. Ticked: the row updates the saved product instead."><input type="checkbox" checked={updateDuplicates} onChange={(e) => { setUpdateDuplicates(e.target.checked); setPreview(null); }} />Update the saved product when a row repeats one</label>}
            <button className="btn-primary ml-auto" disabled={!canMatch || !!dupTargets.length || previewM.isPending || !mapped.length} onClick={() => previewM.mutate()}>{previewM.isPending ? "Checking..." : "Preview changes"}</button>
          </div>
          {!canMatch && <p className="mt-2 text-[12.5px] text-warning">Map a Product ID or Hana code column so rows can be matched to products.</p>}
          {dupTargets.length > 0 && <p className="mt-2 text-[12.5px] text-warning">Two columns go into the same field ({dupTargets.join(", ")}). Set one of them to "Do not import".</p>}
        </Card>)}

      {preview && <>
        <StatStrip items={[
          { label: "Rows read", value: inr(s.rows) },
          { label: "Products to update", value: inr(s.update) },
          { label: "New products", value: inr(s.create) },
          { label: "Unchanged", value: inr(s.unchanged) },
          { label: "Duplicates, not added", value: inr(s.duplicates ?? 0), tone: s.duplicates ? "warning" : undefined },
          { label: "Rows with problems", value: inr(s.errors), tone: s.errors ? "danger" : undefined },
        ]} />
        {missing > 0 && !createMissing && (
          <div className="notice notice-warning flex flex-wrap items-center gap-x-3 gap-y-2 text-[13px]">
            <span className="min-w-0 flex-1">{inr(missing)} {missing === 1 ? "row is for a product that is not saved yet" : "rows are for products that are not saved yet"}, so {missing === 1 ? "it is" : "they are"} under Problems. Add them as new products to bring {missing === 1 ? "it" : "them"} in.</span>
            <button className="btn btn-sm" disabled={previewM.isPending} onClick={() => { setCreateMissing(true); previewM.mutate(true); }}>
              {previewM.isPending ? "Checking..." : "Add new products and preview again"}</button>
          </div>)}
        {s.notes > 0 && <div className="notice notice-warning text-[13px]">{inr(s.notes)} {s.notes === 1 ? "row has a channel link that already belongs to another product" : "rows have a channel link that already belongs to another product"}. A link belongs to one product, so {s.notes === 1 ? "that link is" : "those links are"} left where {s.notes === 1 ? "it is" : "they are"}; everything else in the row is still imported. The note is on the row, under Updates or Unchanged.</div>}
        {s.duplicates > 0 && <div className="notice notice-warning text-[13px]">{inr(s.duplicates)} {s.duplicates === 1 ? "row repeats a product" : "rows repeat products"} already saved (or another row of this file). {s.duplicates === 1 ? "It is" : "They are"} not added, so no product is ever saved twice. See the Duplicates tab{!updateDuplicates && createMissing ? `, or tick "Update the saved product when a row repeats one" to apply ${s.duplicates === 1 ? "its" : "their"} values to the saved product` : ""}.</div>}
        <div className="flex flex-wrap items-center gap-3">
          <Tabs ariaLabel="Preview" active={view} onChange={setView} items={[{ key: "changes", label: "Updates", count: s.update }, { key: "new", label: "New", count: s.create }, { key: "duplicates", label: "Duplicates", count: s.duplicates ?? 0 }, { key: "errors", label: "Problems", count: s.errors }, { key: "unchanged", label: "Unchanged", count: s.unchanged }]} />
          <div className="ml-auto flex items-center gap-2">
            {(s.errors > 0 || s.duplicates > 0) && toApply > 0 && <span className="text-[12.5px] text-faint">Duplicates and rows with problems are skipped.</span>}
            <button className="btn-primary" disabled={!toApply || applyM.isPending} onClick={async () => {
              if (await confirmAction({ title: `Apply ${inr(toApply)} ${toApply === 1 ? "change" : "changes"}?`, body: `${inr(s.update)} products are updated${s.create ? ` and ${inr(s.create)} added` : ""}${s.errors ? `; ${inr(s.errors)} rows with problems are skipped` : ""}${s.duplicates ? `; ${inr(s.duplicates)} duplicates are not added` : ""}. Every change is recorded in the Audit log.`, confirmLabel: "Apply" })) applyM.mutate();
            }}>{applyM.isPending ? "Applying..." : `Apply ${inr(toApply)} ${toApply === 1 ? "change" : "changes"}`}</button>
          </div>
        </div>
        {shown.length ? <DataTable cols={PCOLS} rows={shown} total={shown.length} rowKey="row" maxHeight="60vh" />
          : <div className="card"><EmptyState title={view === "errors" ? "No problems" : "Nothing in this group"} compact /></div>}
      </>}

      {!sheet && !reading && (
        <Card title="What can be imported">
          <ul className="list-disc space-y-1.5 pl-5 text-[13px] text-muted">
            <li><span className="font-medium text-ink">The product master</span> (the old Products sheet, or the file from <button className="underline" onClick={master}>Download product master</button>): every field, matched by product_id.</li>
            <li><span className="font-medium text-ink">A price list</span> with HANA Code, MRP and DP columns: updates MRP and dealer landing by hana code, and MOP and trigger price are recalculated.</li>
            <li><span className="font-medium text-ink">A link list</span> with HANA code and amazon / flipkart columns: adds or replaces the channel links.</li>
            <li>MOP, total scheme, net landing, retail margin, MOP scheme and trigger price are always calculated by the app, so those columns are not imported.</li>
          </ul>
          <p className="mt-3 text-[12.5px] text-faint">Need one product? <Link to="/products/new" className="underline">Add it here</Link>. Many products at once? Tick them on the Products page and use Edit selected.</p>
        </Card>)}
    </div>
  );
}
