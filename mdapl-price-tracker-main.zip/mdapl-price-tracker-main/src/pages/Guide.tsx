// User guide: a docs-style help centre for every screen, step and flow. Content lives in src/lib/guide.ts.
// Desktop: [topics | article | On this page]; phones: a "☰ Group › Title" button opens the topics in a drawer.
import { Fragment, useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { Link, useNavigate, useParams, useSearchParams } from "react-router-dom";
import {
  AlertTriangle, ArrowLeft, ArrowRight, ArrowUpRight, BookOpen, BrainCircuit, CalendarClock, Compass, Database, FileUp, FolderTree, History, Info, Layers, LayoutDashboard, LifeBuoy,
  Lightbulb, Link2, ListChecks, LogIn, Mail, Menu, MessageSquare, MonitorCheck, Navigation, Package, Plug, ScanSearch, Search, Server, ShieldAlert, ShieldCheck, ShoppingBag,
  ShoppingCart, Store, Table2, Tags, ThumbsDown, ThumbsUp, UserCog, Wrench, X, Zap, type LucideIcon,
} from "lucide-react";
import { AI_IDEAS, AI_SUMMARY, BUTTONS, GUIDE, TERMS, type Article, type Block } from "@/lib/guide";

type Icon = LucideIcon;
// Each topic's icon; the same as the app's menu where the screen has one there.
const ICONS: Record<string, Icon> = {
  "how-it-works": Compass, "signing-in": LogIn, "finding-your-way": Navigation, dashboard: LayoutDashboard, categories: FolderTree, products: Layers,
  "product-page": Package, import: FileUp, scraping: ScanSearch, schedules: CalendarClock, "your-schedule": CalendarClock, results: Table2, "mop-reports": ShieldAlert, runs: ListChecks,
  team: ShieldCheck, audit: History, account: UserCog, support: LifeBuoy, messages: MessageSquare, troubleshooting: Wrench, statuses: Tags, services: Plug,
};
const STACK_ICONS: Record<string, Icon> = { ShoppingCart, ShoppingBag, Store, Zap, LifeBuoy, Server, Database, MonitorCheck };
const iconOf = (id: string): Icon => ICONS[id] ?? BookOpen;
const SITE = "https://smallbaydigital.com";
// The "Open …" button names the screen it goes to, as the menu does.
const OPEN_LABEL: Record<string, string> = { "/": "Dashboard", "/products/new": "New product", "/products/import": "Import products", "/support": "Help and support" };
const DOMAIN = "web-scraper.madhukart.com";
const slug = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
const store = {
  get: (k: string) => { try { return localStorage.getItem(k); } catch { return null; } },
  set: (k: string, v: string) => { try { localStorage.setItem(k, v); } catch { /* storage blocked */ } },
};

// ───────────────────────────── Inline text: button chips and glossary tooltips
const esc = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
const WORDS = [...new Set([...BUTTONS, ...Object.keys(TERMS)])].sort((a, b) => b.length - a.length);
const WORD_RE = new RegExp(`(?<![\\w])(${WORDS.map(esc).join("|")})(?![\\w])`, "g");
const BUTTON_SET = new Set(BUTTONS);

/** Text with button names as chips and the first use of each glossary word (per article) with a tooltip.
 *  A plain function with the article's own `seen` set, so StrictMode's second render starts fresh. */
function inline(text: string, seen: Set<string>): React.ReactNode[] {
  const out: React.ReactNode[] = [];
  let last = 0, i = 0;
  for (const m of text.matchAll(WORD_RE)) {
    const w = m[0], at = m.index ?? 0;
    if (at > last) out.push(text.slice(last, at));
    if (BUTTON_SET.has(w)) out.push(<span key={i++} className="mx-px inline-flex items-center whitespace-nowrap rounded-md border border-line-strong bg-surface-alt px-1.5 py-px align-baseline text-[0.86em] font-medium leading-snug text-ink">{w}</span>);
    else if (TERMS[w] && !seen.has(w.toLowerCase())) { seen.add(w.toLowerCase()); out.push(<Term key={i++} word={w} tip={TERMS[w]} />); }
    else out.push(w);
    last = at + w.length;
  }
  if (last < text.length) out.push(text.slice(last));
  return out;
}

function Term({ word, tip }: { word: string; tip: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const [pos, setPos] = useState<{ left: number; top: number; below: boolean; width: number } | null>(null);
  const pointer = useRef<string | null>(null);
  const open = () => {
    const r = ref.current?.getClientRects()[0];
    if (!r) return;
    const width = Math.min(280, window.innerWidth - 24);
    const left = Math.min(Math.max(12, r.left + r.width / 2 - width / 2), window.innerWidth - 12 - width);
    const below = r.top < 130;
    setPos({ left, width, below, top: below ? r.bottom + 8 : r.top - 8 });
  };
  const close = () => setPos(null);
  useEffect(() => {
    if (!pos) return;
    window.addEventListener("scroll", close, true); window.addEventListener("resize", close);
    return () => { window.removeEventListener("scroll", close, true); window.removeEventListener("resize", close); };
  }, [pos]);
  return (
    <>
      <span ref={ref} tabIndex={0} role="button" aria-expanded={!!pos} aria-label={`${word}: ${tip}`}
        className="cursor-help underline decoration-faint decoration-dotted decoration-[1.5px] underline-offset-[3px] outline-none focus-visible:rounded-sm focus-visible:bg-accent-soft"
        onPointerDown={(e) => { pointer.current = e.pointerType; }}
        onPointerEnter={(e) => { if (e.pointerType === "mouse") open(); }}
        onPointerLeave={(e) => { if (e.pointerType === "mouse") close(); }}
        onFocus={() => { if (!pointer.current) open(); }}
        onBlur={() => { pointer.current = null; close(); }}
        onClick={() => { if (pointer.current && pointer.current !== "mouse") { if (pos) close(); else open(); } pointer.current = pointer.current === "mouse" ? null : pointer.current; }}
        onKeyDown={(e) => { if (e.key === "Escape") close(); }}>{word}</span>
      {pos && createPortal(
        <span role="tooltip" className="pointer-events-none fixed z-[200] rounded-lg bg-brand px-3 py-2 text-[12.5px] font-normal leading-snug text-white shadow-[var(--shadow-pop)]"
          style={{ left: pos.left, width: pos.width, top: pos.top, transform: pos.below ? undefined : "translateY(-100%)" }}>
          <span className="mb-0.5 block font-semibold text-gold">{word}</span>{tip}
        </span>, document.body)}
    </>
  );
}

// ───────────────────────────── Blocks
const TONE = {
  info: { label: "Note", icon: Info, box: "border-info-line bg-info-soft", text: "text-info" },
  success: { label: "Tip", icon: Lightbulb, box: "border-success-line bg-success-soft", text: "text-success" },
  warning: { label: "Important", icon: AlertTriangle, box: "border-warning-line bg-warning-soft", text: "text-warning" },
};

function Figure({ name, caption, onOpen }: { name: string; caption: string; onOpen: (src: string, caption: string) => void }) {
  const src = `/guide/${name}.jpg`;
  return (
    <figure className="my-6">
      <button type="button" onClick={() => onOpen(src, caption)} className="block w-full overflow-hidden rounded-xl border border-line bg-surface text-left shadow-card transition-shadow hover:shadow-pop" aria-label={`Enlarge: ${caption}`}>
        <span className="flex items-center gap-1.5 border-b border-line bg-surface-alt px-3 py-2">
          <span className="h-2.5 w-2.5 rounded-full bg-[#f87171]" /><span className="h-2.5 w-2.5 rounded-full bg-[#fbbf24]" /><span className="h-2.5 w-2.5 rounded-full bg-[#34d399]" />
          <span className="mx-auto truncate rounded-md border border-line bg-surface px-3 py-0.5 text-[11.5px] text-faint">{DOMAIN}</span><span className="w-[42px]" />
        </span>
        <img src={src} alt={caption} loading="lazy" decoding="async" className="block w-full" />
      </button>
      <figcaption className="mt-2 text-center text-[12.5px] text-faint">{caption}</figcaption>
    </figure>
  );
}

/** One block. A plain function called while the article renders (not a component), so the `seen` set is used once per
 *  render even under StrictMode, which renders components twice. */
function renderBlock(b: Block, aid: string, seen: Set<string>, onImage: (src: string, caption: string) => void): React.ReactNode {
  const t = (s: string) => inline(s, seen);
  if ("h" in b) {
    const id = slug(b.h);
    return (
      <h2 id={id} className="group mt-10 mb-3 scroll-mt-6 text-[21px] font-semibold tracking-tight text-ink">
        <a href={`#/guide/${aid}?h=${id}`} className="inline-flex items-center gap-2" onClick={(e) => { e.preventDefault(); scrollToId(id); history.replaceState(null, "", `#/guide/${aid}?h=${id}`); }}>
          {b.h}<Link2 className="h-4 w-4 text-faint opacity-0 transition-opacity group-hover:opacity-100" aria-hidden />
        </a>
      </h2>);
  }
  if ("p" in b) return <p className="my-3 text-[15px] leading-[1.7] text-muted">{t(b.p)}</p>;
  if ("list" in b) return <ul className="my-3 space-y-2 pl-1">{b.list.map((x, i) => <li key={i} className="flex gap-3 text-[15px] leading-[1.65] text-muted"><span className="mt-[0.7em] h-1.5 w-1.5 shrink-0 rounded-full bg-gold-line" /><span className="min-w-0">{t(x)}</span></li>)}</ul>;
  if ("steps" in b) return (
    <ol className="my-4">
      {b.steps.map((x, i) => (
        <li key={i} className="relative flex gap-4 pb-4 last:pb-0">
          {i < b.steps.length - 1 && <span className="absolute left-[13px] top-7 bottom-0 w-px bg-line-strong" aria-hidden />}
          <span className="relative grid h-7 w-7 shrink-0 place-items-center rounded-full border border-gold-line bg-accent-soft text-[12.5px] font-semibold text-ink">{i + 1}</span>
          <span className="min-w-0 pt-[3px] text-[15px] leading-[1.65] text-muted">{t(x)}</span>
        </li>))}
    </ol>);
  if ("flow" in b) return (
    <div className="my-5 flex flex-wrap items-center gap-x-2 gap-y-2.5" aria-label="Flow">
      {b.flow.map((x, i) => (
        <Fragment key={i}>
          <span className={`rounded-full border px-3 py-1 text-[13px] font-medium ${i === b.flow.length - 1 ? "border-gold-line bg-gold text-on-gold" : "border-line-strong bg-surface text-ink"}`}>{x}</span>
          {i < b.flow.length - 1 && <ArrowRight className="h-4 w-4 shrink-0 text-faint" aria-hidden />}
        </Fragment>))}
    </div>);
  if ("table" in b) return (
    <div className="my-5 overflow-x-auto rounded-xl border border-line">
      <table className="w-full text-left text-[14px]">
        <thead className="bg-surface-alt"><tr>{b.table.head.map((h) => <th key={h} className="whitespace-nowrap border-b border-line px-4 py-2.5 text-[12.5px] font-semibold text-muted">{h}</th>)}</tr></thead>
        <tbody className="divide-y divide-line">{b.table.rows.map((r, i) => <tr key={i} className="align-top">{r.map((c, j) => <td key={j} className={`px-4 py-2.5 leading-relaxed ${j === 0 ? "font-medium text-ink" : "text-muted"}`}>{t(c)}</td>)}</tr>)}</tbody>
      </table>
    </div>);
  if ("note" in b) {
    const k = TONE[b.tone ?? "info"];
    return (
      <div className={`my-5 flex gap-3 rounded-xl border px-4 py-3 ${k.box}`} role="note">
        <k.icon className={`mt-0.5 h-[18px] w-[18px] shrink-0 ${k.text}`} />
        <div className="min-w-0 text-[14.5px] leading-[1.6] text-ink"><span className={`mr-1.5 font-semibold ${k.text}`}>{k.label}</span>{t(b.note)}</div>
      </div>);
  }
  if ("img" in b) return <Figure name={b.img} caption={b.caption} onOpen={onImage} />;
  if ("topics" in b) return (
    <div className="my-5 grid gap-3 sm:grid-cols-2">
      {b.topics.map((id) => { const a = GUIDE.find((x) => x.id === id); if (!a) return null; const I = iconOf(id);
        return (
          <Link key={id} to={`/guide/${id}`} className="group flex items-start gap-3 rounded-xl border border-line bg-surface p-4 transition-colors hover:border-gold-line hover:bg-accent-soft/40">
            <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-accent-soft text-bronze"><I className="h-[18px] w-[18px]" /></span>
            <span className="min-w-0 flex-1"><span className="flex items-center gap-1 text-[14px] font-semibold text-ink">{a.title}<ArrowRight className="h-3.5 w-3.5 -translate-x-1 text-bronze opacity-0 transition-all group-hover:translate-x-0 group-hover:opacity-100" /></span>
              <span className="mt-0.5 line-clamp-2 block text-[13px] leading-snug text-faint">{a.summary}</span></span>
          </Link>); })}
    </div>);
  if ("stack" in b) return (
    <div className="my-5 grid gap-3 sm:grid-cols-2">
      {b.stack.map((s, i) => {
        const I = STACK_ICONS[s.icon] ?? Plug;
        // An odd last card takes the whole row.
        const wide = b.stack.length % 2 === 1 && i === b.stack.length - 1 ? "sm:col-span-2" : "";
        const body = <>
          <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg border border-line bg-surface-alt text-muted"><I className="h-[18px] w-[18px]" /></span>
          <span className="min-w-0 flex-1"><span className="flex items-start gap-1 text-[14px] font-semibold leading-snug text-ink">{s.name}{s.url && <ArrowUpRight className="mt-[3px] h-3.5 w-3.5 shrink-0 text-faint group-hover:text-ink" />}</span>
            <span className="mt-0.5 block text-[13px] leading-snug text-faint">{s.does}</span></span>
        </>;
        return s.url
          ? <a key={s.name} href={s.url} target="_blank" rel="noopener noreferrer" className={`group flex items-start gap-3 rounded-xl border border-line bg-surface p-4 transition-colors hover:border-line-hover hover:bg-surface-alt ${wide}`}>{body}</a>
          : <div key={s.name} className={`flex items-start gap-3 rounded-xl border border-line bg-surface p-4 ${wide}`}>{body}</div>;
      })}
    </div>);
  if ("credit" in b) {
    const c = b.credit;
    return (
      <div className="my-6 flex flex-col gap-4 rounded-2xl border border-line bg-surface-alt p-5 sm:flex-row sm:items-start">
        <img src={c.logo} alt={`${c.name} logo`} className="h-14 w-14 shrink-0 rounded-xl" />
        <div className="min-w-0">
          <div className="text-[11px] font-semibold uppercase tracking-wider text-faint">Designed and built by</div>
          <div className="mt-0.5 text-[16px] font-semibold text-ink">{c.name}</div>
          <p className="mt-1 text-[14.5px] leading-[1.6] text-muted">{c.text}</p>
          <div className="mt-3 flex flex-wrap gap-2">
            <a href={c.url} target="_blank" rel="noopener noreferrer" className="btn btn-sm"><ArrowUpRight className="h-4 w-4" />Visit site</a>
            {c.email && <a href={`mailto:${c.email}`} className="btn btn-sm"><Mail className="h-4 w-4" />{c.email}</a>}
          </div>
        </div>
      </div>);
  }
  return null;
}

function scrollToId(id: string, smooth = true) {
  const el = document.getElementById(id);
  if (!el) return;
  window.scrollTo({ top: el.getBoundingClientRect().top + window.scrollY - (window.innerWidth < 1024 ? 72 : 24), behavior: smooth ? "smooth" : "auto" });
}

// ───────────────────────────── Search
type Hit = { article: Article; heading: string | null; snippet: string };
const textOf = (b: Block): string => "h" in b ? b.h : "p" in b ? b.p : "steps" in b ? b.steps.join(" ") : "list" in b ? b.list.join(" ") : "flow" in b ? b.flow.join(" ")
  : "table" in b ? [...b.table.head, ...b.table.rows.flat()].join(" ") : "note" in b ? b.note : "img" in b ? b.caption : "stack" in b ? b.stack.map((s) => `${s.name} ${s.does}`).join(" ")
  : "credit" in b ? b.credit.text : "";
const INDEX = GUIDE.flatMap((a) => {
  const sections: { article: Article; heading: string | null; text: string }[] = [{ article: a, heading: null, text: `${a.title} ${a.summary}` }];
  for (const b of a.blocks) { if ("h" in b) sections.push({ article: a, heading: b.h, text: b.h }); else sections[sections.length - 1].text += ` ${textOf(b)}`; }
  return sections;
});
function search(q: string): Hit[] {
  const words = q.toLowerCase().split(/\s+/).filter(Boolean);
  if (!words.length) return [];
  const hits = INDEX.filter((s) => { const t = s.text.toLowerCase(); return words.every((w) => t.includes(w)); })
    .map((s) => {
      const t = s.text, at = t.toLowerCase().indexOf(words[0]);
      const titleHit = words.every((w) => `${s.article.title} ${s.heading ?? ""}`.toLowerCase().includes(w));
      return { article: s.article, heading: s.heading, snippet: (at > 40 ? "…" : "") + t.slice(Math.max(0, at - 40), at + 90).trim() + "…", score: titleHit ? 0 : 1 };
    });
  return hits.sort((a, b) => a.score - b.score).slice(0, 12);
}

// ───────────────────────────── Page
const GROUPS = [...new Set(GUIDE.map((a) => a.group))];

function TopicList({ active, onPick }: { active: string; onPick?: () => void }) {
  const [q, setQ] = useState("");
  const nav = useNavigate();
  const hits = useMemo(() => search(q), [q]);
  const go = (h: Hit) => { setQ(""); onPick?.(); nav(`/guide/${h.article.id}${h.heading ? `?h=${slug(h.heading)}` : ""}`); };
  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="shrink-0 px-4 pb-3 pt-5">
        <Link to="/guide" onClick={onPick} className="flex items-center gap-2.5 px-1">
          <span className="grid h-8 w-8 place-items-center rounded-lg bg-brand text-gold"><BookOpen className="h-4 w-4" /></span>
          <span className="leading-tight"><span className="block text-[14.5px] font-semibold text-ink">User guide</span><span className="block text-[11.5px] text-faint">MDAPL Price Tracker</span></span>
        </Link>
        <div className="relative mt-4">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-faint" />
          <input className="input pl-9" type="search" placeholder="Search the guide" aria-label="Search the guide" value={q} onChange={(e) => setQ(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter" && hits[0]) go(hits[0]); if (e.key === "Escape") setQ(""); }} />
        </div>
      </div>
      <div className="scroll-pane min-h-0 flex-1 overflow-y-auto px-3 pb-5">
        {q.trim() ? (
          <div role="listbox" aria-label="Search results">
            <div className="px-2 pb-2 text-[12px] text-faint">{hits.length ? `${hits.length} ${hits.length === 1 ? "result" : "results"}` : "Nothing found. Try another word."}</div>
            {hits.map((h, i) => { const I = iconOf(h.article.id);
              return (
                <button key={i} type="button" role="option" aria-selected={false} onClick={() => go(h)} className="flex w-full gap-2.5 rounded-lg px-2 py-2 text-left hover:bg-hover">
                  <I className="mt-0.5 h-4 w-4 shrink-0 text-bronze" />
                  <span className="min-w-0"><span className="block text-[13px] font-medium leading-snug text-ink">{h.article.group} › {h.heading ?? h.article.title}</span>
                    <span className="line-clamp-2 block text-[12px] leading-snug text-faint">{h.snippet}</span></span>
                </button>); })}
          </div>
        ) : (
          <nav aria-label="Guide topics">
            {GROUPS.map((g) => (
              <div key={g} className="mb-4">
                <div className="px-2 pb-1.5 text-[11px] font-semibold uppercase tracking-wider text-faint">{g}</div>
                {GUIDE.filter((a) => a.group === g).map((a) => { const I = iconOf(a.id), on = a.id === active;
                  return (
                    <Link key={a.id} to={`/guide/${a.id}`} onClick={onPick} aria-current={on ? "page" : undefined}
                      className={`flex items-center gap-2.5 border-l-2 py-1.5 pl-3 pr-2 text-[13.5px] transition-colors ${on ? "border-gold-line bg-accent-soft/60 font-medium text-bronze" : "border-transparent text-muted hover:border-line-strong hover:text-ink"}`}>
                      <I className={`h-4 w-4 shrink-0 ${on ? "text-bronze" : "text-faint"}`} />{a.title}
                    </Link>); })}
              </div>))}
            <a href={SITE} target="_blank" rel="noopener noreferrer" className="mt-2 block rounded-xl border border-line bg-gradient-to-br from-accent-soft to-surface p-3.5 transition-colors hover:border-gold-line">
              <span className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-wider text-bronze"><BrainCircuit className="h-3.5 w-3.5" />AI workflows</span>
              <span className="mt-1.5 block text-[13px] leading-snug text-ink">{AI_SUMMARY}</span>
              <span className="mt-2 block text-[12.5px] font-medium text-bronze">Built by SmallBay Digital →</span>
            </a>
          </nav>)}
      </div>
    </div>
  );
}

function AiBanner({ index }: { index: number }) {
  const [hidden, setHidden] = useState(() => store.get("guide-ai-banner") === "hidden");
  if (hidden) return null;
  const idea = AI_IDEAS[index % AI_IDEAS.length];
  return (
    <div className="relative mb-8 flex gap-3.5 rounded-xl border border-accent-line bg-gradient-to-r from-accent-soft to-surface p-4 pr-10" data-testid="ai-banner">
      <span className="grid h-10 w-10 shrink-0 place-items-center rounded-lg bg-brand text-gold"><BrainCircuit className="h-5 w-5" /></span>
      <div className="min-w-0">
        <div className="text-[11px] font-semibold uppercase tracking-wider text-bronze">AI workflow idea</div>
        <div className="mt-0.5 text-[14.5px] font-semibold text-ink">{idea.title}</div>
        <p className="mt-0.5 text-[13.5px] leading-snug text-muted">{idea.text}</p>
        <a href={SITE} target="_blank" rel="noopener noreferrer" className="mt-1.5 inline-block text-[13px] font-medium text-bronze hover:underline">Built by SmallBay Digital. Talk to us →</a>
      </div>
      <button type="button" className="btn-icon absolute right-2 top-2 h-7 w-7" aria-label="Hide this idea" onClick={() => { store.set("guide-ai-banner", "hidden"); setHidden(true); }}><X className="h-4 w-4" /></button>
    </div>
  );
}

function Feedback({ id }: { id: string }) {
  const key = `guide-feedback-${id}`;
  const [v, setV] = useState(() => store.get(key));
  useEffect(() => setV(store.get(key)), [key]);
  const pick = (x: string) => { store.set(key, x); setV(x); };
  return (
    <div className="mt-12 flex flex-wrap items-center gap-3 border-t border-line pt-6 text-[14px] text-muted">
      <span>{v ? "Thanks for telling us." : "Was this page helpful?"}</span>
      <div className="flex gap-2">
        {([["yes", "Yes", ThumbsUp], ["no", "No", ThumbsDown]] as const).map(([k, l, I]) => (
          <button key={k} type="button" aria-pressed={v === k} onClick={() => pick(k)}
            className={`btn btn-sm ${v === k ? "border-gold-line bg-accent-soft" : ""}`}><I className="h-3.5 w-3.5" />{l}</button>))}
      </div>
    </div>
  );
}

function OnThisPage({ headings }: { headings: string[] }) {
  const [current, setCurrent] = useState<string | null>(null);
  useEffect(() => {
    let raf = 0;
    const onScroll = () => { cancelAnimationFrame(raf); raf = requestAnimationFrame(() => {
      let cur: string | null = null;
      for (const h of headings) { const el = document.getElementById(slug(h)); if (el && el.getBoundingClientRect().top < 140) cur = h; }
      if (window.innerHeight + window.scrollY >= document.documentElement.scrollHeight - 4 && headings.length) cur = headings[headings.length - 1];
      setCurrent(cur ?? headings[0] ?? null);
    }); };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => { window.removeEventListener("scroll", onScroll); cancelAnimationFrame(raf); };
  }, [headings]);
  if (!headings.length) return null;
  return (
    <nav aria-label="On this page" className="sticky top-0 max-h-dvh overflow-y-auto py-10 pr-6">
      <div className="mb-3 text-[12px] font-semibold uppercase tracking-wider text-faint">On this page</div>
      <ul className="space-y-0.5 border-l border-line">
        {headings.map((h) => (
          <li key={h}><a href={`#${slug(h)}`} onClick={(e) => { e.preventDefault(); scrollToId(slug(h)); }}
            className={`-ml-px block border-l-2 py-1 pl-3 text-[13px] leading-snug transition-colors ${current === h ? "border-gold-line font-medium text-bronze" : "border-transparent text-faint hover:text-ink"}`}>{h}</a></li>))}
      </ul>
    </nav>
  );
}

export default function Guide() {
  const { id } = useParams();
  const [sp] = useSearchParams();
  const index = Math.max(0, GUIDE.findIndex((a) => a.id === id));
  const a = GUIDE[index];
  const [drawer, setDrawer] = useState(false);
  const [lightbox, setLightbox] = useState<{ src: string; caption: string } | null>(null);
  const headings = useMemo(() => a.blocks.flatMap((b) => ("h" in b ? [b.h] : [])), [a]);
  const h = sp.get("h");
  useEffect(() => { document.title = `${a.title} · User guide`; return () => { document.title = "MDAPL Price Tracker"; }; }, [a]);
  useEffect(() => {
    if (h) requestAnimationFrame(() => scrollToId(h, false)); else window.scrollTo({ top: 0 });
  }, [a.id, h]);
  useEffect(() => {
    if (!lightbox) return;
    const k = (e: KeyboardEvent) => { if (e.key === "Escape") setLightbox(null); };
    document.addEventListener("keydown", k);
    return () => document.removeEventListener("keydown", k);
  }, [lightbox]);
  const prev = GUIDE[index - 1], next = GUIDE[index + 1];
  const I = iconOf(a.id);
  const seen = new Set<string>();   // per render: the first use of each glossary word gets its tooltip
  const openLabel = a.to ? `Open ${OPEN_LABEL[a.to] ?? a.title}` : null;

  return (
    <div className="min-h-dvh bg-surface lg:grid lg:grid-cols-[270px_minmax(0,1fr)] 2xl:grid-cols-[270px_minmax(0,1fr)_230px]">
      <aside className="hidden border-r border-line bg-surface-alt/50 lg:block">
        <div className="sticky top-0 h-dvh"><TopicList active={a.id} /></div>
      </aside>

      <div className="min-w-0">
        <div className="sticky top-14 z-20 border-b border-line bg-surface/95 px-4 py-2 backdrop-blur lg:hidden">
          <button type="button" className="flex w-full min-w-0 items-center gap-2 rounded-lg px-1 py-1.5 text-left text-[13.5px]" onClick={() => setDrawer(true)} aria-label="Open the guide topics">
            <Menu className="h-4 w-4 shrink-0 text-muted" /><span className="shrink-0 text-faint">{a.group}</span><span className="text-faint">›</span><span className="min-w-0 truncate font-medium text-ink">{a.title}</span>
          </button>
        </div>
        <article className="mx-auto max-w-[720px] px-4 pb-16 pt-6 sm:px-8 lg:pt-10">
          <AiBanner index={index} />
          <header>
            <div className="flex items-center gap-2 text-[13px] font-medium text-bronze">
              <span className="grid h-7 w-7 place-items-center rounded-lg bg-accent-soft"><I className="h-4 w-4" /></span>{a.group}
            </div>
            <div className="mt-3 flex flex-wrap items-start justify-between gap-x-4 gap-y-3">
              <h1 className="min-w-0 text-[34px] font-semibold leading-[1.15] tracking-tight text-ink">{a.title}</h1>
              {a.to && openLabel && <Link to={a.to} className="btn mt-1.5"><ArrowUpRight className="h-4 w-4" />{openLabel}</Link>}
            </div>
            <p className="mt-3 text-[17px] leading-relaxed text-muted">{a.summary}</p>
          </header>
          <div className="mt-6">{a.blocks.map((b, i) => <Fragment key={`${a.id}-${i}`}>{renderBlock(b, a.id, seen, (src, caption) => setLightbox({ src, caption }))}</Fragment>)}</div>
          <Feedback id={a.id} />
          <div className="mt-8 grid gap-3 sm:grid-cols-2">
            {prev ? <Link to={`/guide/${prev.id}`} className="group rounded-xl border border-line p-4 transition-colors hover:border-gold-line hover:bg-accent-soft/40">
              <span className="flex items-center gap-1 text-[12px] text-faint"><ArrowLeft className="h-3.5 w-3.5" />Previous</span><span className="mt-1 block text-[14.5px] font-semibold text-ink">{prev.title}</span></Link> : <span className="hidden sm:block" />}
            {next && <Link to={`/guide/${next.id}`} className="group rounded-xl border border-line p-4 text-right transition-colors hover:border-gold-line hover:bg-accent-soft/40">
              <span className="flex items-center justify-end gap-1 text-[12px] text-faint">Next<ArrowRight className="h-3.5 w-3.5" /></span><span className="mt-1 block text-[14.5px] font-semibold text-ink">{next.title}</span></Link>}
          </div>
          <footer className="mt-10 flex flex-wrap items-center justify-center gap-x-2 gap-y-1 text-[13px] text-faint">
            <span>Need more help? <Link to="/support/new" className="font-medium text-ink underline decoration-line-strong underline-offset-2 hover:decoration-ink">Raise a request</Link></span>
            <span aria-hidden>·</span>
            <a href={SITE} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 hover:text-ink"><img src="/guide/sbd-logo.png" alt="" className="h-4 w-4 rounded" />Built by SmallBay Digital</a>
          </footer>
        </article>
      </div>

      <aside className="hidden 2xl:block"><OnThisPage headings={headings} /></aside>

      {drawer && <>
        <div className="dialog-backdrop fixed inset-0 z-40 lg:hidden" onClick={() => setDrawer(false)} />
        <div className="fixed inset-y-0 left-0 z-50 w-[85vw] max-w-[320px] bg-surface shadow-dialog lg:hidden" role="dialog" aria-label="Guide topics">
          <button type="button" className="btn-icon absolute right-2 top-3" onClick={() => setDrawer(false)} aria-label="Close topics"><X className="h-4 w-4" /></button>
          <TopicList active={a.id} onPick={() => setDrawer(false)} />
        </div>
      </>}
      {lightbox && createPortal(
        <div className="fixed inset-0 z-[150] grid cursor-zoom-out place-items-center bg-[rgb(17_24_39/0.8)] p-4" onClick={() => setLightbox(null)} role="dialog" aria-label={lightbox.caption}>
          <figure className="max-h-full max-w-[1400px]"><img src={lightbox.src} alt={lightbox.caption} className="max-h-[85dvh] w-auto rounded-lg shadow-dialog" />
            <figcaption className="mt-3 text-center text-[13px] text-white/80">{lightbox.caption} · Esc or click to close</figcaption></figure>
        </div>, document.body)}
    </div>
  );
}
