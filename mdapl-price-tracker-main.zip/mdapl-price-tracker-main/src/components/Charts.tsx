// Small dependency-free charts (reference: Charts.tsx) plus a line chart. Navy for data, neutral for the rest.
import { useEffect, useRef, useState } from "react";
import { dayShort, inr } from "@/lib/format";

const BRAND = "var(--color-bronze)";
const fmt = (n: number) => (n >= 100000 ? `${(n / 1000).toFixed(0)}k` : n >= 10000 ? `${(n / 1000).toFixed(1)}k` : inr(Math.round(n)));
const NoData = () => <div className="grid h-44 place-items-center text-[13px] text-faint">No data for this period</div>;

export function ChartCard({ title, subtitle, children, actions }: { title: string; subtitle?: string; children: React.ReactNode; actions?: React.ReactNode }) {
  return (
    <section className="card flex h-full w-full flex-col p-4">
      <div className="mb-3 flex flex-wrap items-start gap-2"><div className="min-w-0 flex-1"><h2 className="card-title">{title}</h2>{subtitle && <div className="meta">{subtitle}</div>}</div>{actions}</div>
      <div className="flex flex-1 flex-col justify-end">{children}</div>
    </section>
  );
}

export function Bars({ data, height = 200, prefix = "" }: { data: { label: string; value: number }[]; height?: number; prefix?: string }) {
  const max = Math.max(1, ...data.map((d) => d.value));
  if (!data.length) return <NoData />;
  return (
    <div className="flex items-end gap-3" style={{ height }} role="img" aria-label={data.map((d) => `${d.label} ${prefix}${inr(d.value)}`).join(", ")}>
      {data.map((d) => (
        <div key={d.label} className="flex h-full min-w-0 flex-1 flex-col items-center justify-end gap-1" title={`${d.label}: ${prefix}${inr(d.value, 2)}`}>
          <span className="text-[11px] tabular-nums text-muted">{prefix}{fmt(d.value)}</span>
          <div className="w-full max-w-14 rounded-t-[3px]" style={{ height: `${Math.max(d.value ? 2 : 0, (d.value / max) * (height - 44))}px`, background: BRAND, opacity: 0.85 }} />
          <span className="w-full truncate text-center text-[12px] text-faint">{d.label}</span>
        </div>))}
    </div>
  );
}

/** Share of a whole as one bar with a legend (category distribution). */
export function Split({ parts }: { parts: { label: string; value: number }[] }) {
  const total = parts.reduce((s, p) => s + p.value, 0) || 1;
  if (!parts.length) return <NoData />;
  // Shades of the logo bronze/yellow, then greys: enough to tell neighbours apart without a rainbow.
  const shades = ["#6f500f", "#8a6417", "#a87a1e", "#c99a2e", "#e0b52a", "#f9cf1f", "#fbe07a", "#fdefb8", "#6b7280", "#9ca3af", "#d1d5db", "#e5e7eb"];
  return (
    <div>
      <div className="flex h-3 overflow-hidden rounded-full">{parts.map((p, i) => <div key={p.label} style={{ width: `${(p.value / total) * 100}%`, background: shades[i % shades.length] }} title={`${p.label}: ${p.value}`} />)}</div>
      <div className="mt-3 grid gap-x-6 gap-y-1.5 sm:grid-cols-2">
        {parts.map((p, i) => (
          <div key={p.label} className="flex items-center gap-2 text-[12px]">
            <span className="h-2.5 w-2.5 shrink-0 rounded-sm" style={{ background: shades[i % shades.length] }} /><span className="min-w-0 truncate text-muted">{p.label}</span>
            <span className="ml-auto font-medium tabular-nums">{inr(p.value)}</span><span className="w-10 text-right text-faint">{Math.round((p.value / total) * 100)}%</span>
          </div>))}
      </div>
    </div>
  );
}

/** Line over days, with a light area, gridlines, axis labels and a hover readout. */
export function LineChart({ data, height = 200, prefix = "", suffix = "" }: { data: { x: string; y: number }[]; height?: number; prefix?: string; suffix?: string }) {
  const [hover, setHover] = useState<number | null>(null);
  const box = useRef<HTMLDivElement>(null);
  const [w, setW] = useState(600);
  useEffect(() => {
    const el = box.current; if (!el) return;
    const ro = new ResizeObserver(() => setW(Math.max(260, Math.round(el.clientWidth))));
    ro.observe(el); return () => ro.disconnect();
  }, [data.length > 0]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!data.length) return <NoData />;
  const W = w, H = height, padL = 44, padR = 8, padT = 10, padB = 22;
  const ys = data.map((d) => d.y);
  let lo = Math.min(...ys), hi = Math.max(...ys);
  if (lo === hi) { lo = lo * 0.95; hi = hi * 1.05 || 1; }
  const span = hi - lo; lo -= span * 0.1; hi += span * 0.1;
  const x = (i: number) => padL + (data.length === 1 ? (W - padL - padR) / 2 : (i / (data.length - 1)) * (W - padL - padR));
  const y = (v: number) => padT + (1 - (v - lo) / (hi - lo)) * (H - padT - padB);
  const path = data.map((d, i) => `${i ? "L" : "M"}${x(i).toFixed(1)},${y(d.y).toFixed(1)}`).join(" ");
  const area = `${path} L${x(data.length - 1).toFixed(1)},${H - padB} L${x(0).toFixed(1)},${H - padB} Z`;
  const ticks = [0, 0.5, 1].map((t) => lo + (hi - lo) * t);
  const every = Math.max(1, Math.ceil(data.length / Math.max(2, Math.floor(W / 80))));
  const h = hover !== null ? data[hover] : null;
  return (
    <div className="relative" ref={box}>
      <svg viewBox={`0 0 ${W} ${H}`} className="block w-full overflow-visible" height={H} role="img" aria-label={data.map((d) => `${dayShort(d.x)} ${prefix}${inr(d.y, 1)}${suffix}`).join(", ")}
        onMouseLeave={() => setHover(null)}
        onMouseMove={(e) => { const r = (e.currentTarget as SVGSVGElement).getBoundingClientRect(); const px = ((e.clientX - r.left) / r.width) * W; let best = 0; data.forEach((_, i) => { if (Math.abs(x(i) - px) < Math.abs(x(best) - px)) best = i; }); setHover(best); }}>
        {ticks.map((t) => <g key={t}><line x1={padL} x2={W - padR} y1={y(t)} y2={y(t)} stroke="var(--color-line)" /><text x={padL - 6} y={y(t) + 4} textAnchor="end" fontSize="11" fill="var(--color-faint)">{prefix}{fmt(t)}{suffix}</text></g>)}
        <path d={area} fill={BRAND} opacity={0.07} />
        <path d={path} fill="none" stroke={BRAND} strokeWidth={2} strokeLinejoin="round" strokeLinecap="round" />
        {data.map((d, i) => i % every === 0 || i === data.length - 1 ? <text key={d.x} x={x(i)} y={H - 4} textAnchor="middle" fontSize="11" fill="var(--color-faint)">{dayShort(d.x)}</text> : null)}
        {h && <><line x1={x(hover!)} x2={x(hover!)} y1={padT} y2={H - padB} stroke="var(--color-line-strong)" /><circle cx={x(hover!)} cy={y(h.y)} r={4} fill={BRAND} stroke="white" strokeWidth={2} /></>}
      </svg>
      {h && <div className="pointer-events-none absolute right-0 top-0 rounded-md border border-line bg-surface px-2 py-1 text-[12px] shadow-card"><span className="text-faint">{dayShort(h.x)}</span> <span className="font-medium tabular-nums">{prefix}{inr(h.y, 1)}{suffix}</span></div>}
    </div>
  );
}
