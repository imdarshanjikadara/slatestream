// A crash while drawing a page shows this panel instead of a blank screen, and is reported to Sentry.
import { Component } from "react";
import { reportError } from "@/lib/sentry";

export class ErrorBoundary extends Component<{ children: React.ReactNode; full?: boolean }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() { return { failed: true }; }
  componentDidCatch(error: unknown, info: { componentStack?: string | null }) {
    console.error(error);
    reportError(error, { componentStack: info.componentStack });
  }
  render() {
    if (!this.state.failed) return this.props.children;
    return (
      <div className={`grid place-items-center px-5 ${this.props.full ? "min-h-dvh bg-canvas" : "py-24"}`} role="alert">
        <div className="max-w-sm text-center">
          <h1 className="text-[18px] font-semibold text-ink">Something went wrong on this page</h1>
          <p className="mt-1.5 text-[13.5px] text-muted">It has been reported. Reload to try again; your saved work is not affected.</p>
          <button className="btn-primary mt-4" onClick={() => window.location.reload()}>Reload</button>
        </div>
      </div>
    );
  }
}
