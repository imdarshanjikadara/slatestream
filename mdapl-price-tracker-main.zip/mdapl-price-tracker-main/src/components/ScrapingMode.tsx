// How a product is picked up by the daily scheduled run: every day (regular), on a schedule, or not at all.
// Regular and scheduled are one choice, never both. The schedule itself is week-wise (days of the week), month-wise
// (dates of the month) and year-wise (months of the year), and only applies when the product is on a schedule.

export const DAYS = ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"];
export const MONTHS = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];

export function Toggles({ labels, value, onChange, ariaLabel, compact }: { labels: string[]; value: string[]; onChange: (v: string[]) => void; ariaLabel: string; compact?: boolean }) {
  return (
    <div className="flex flex-wrap gap-1.5" role="group" aria-label={ariaLabel}>
      {labels.map((l, i) => {
        const v = String(i + 1), on = value.includes(v);
        return <button key={l} type="button" aria-pressed={on} onClick={() => onChange(on ? value.filter((x) => x !== v) : [...value, v].sort((a, b) => Number(a) - Number(b)))}
          className={`h-8 rounded-lg border text-[12px] font-medium transition-colors ${compact ? "w-9" : "min-w-[3.25rem] px-2.5"} ${on ? "border-gold-line bg-gold text-on-gold" : "border-line-strong bg-surface text-muted hover:border-line-hover hover:text-ink"}`}>{l}</button>;
      })}
    </div>
  );
}

export type ScrapingMode = "regular" | "scheduled" | "off";
export const modeOf = (r: { regular_scraping?: unknown; scheduled_scraping?: unknown }): ScrapingMode =>
  r.regular_scraping ? "regular" : r.scheduled_scraping ? "scheduled" : "off";
export const modeFields = (m: ScrapingMode) => ({ regular_scraping: m === "regular", scheduled_scraping: m === "scheduled" });

export const MODES: { value: ScrapingMode; label: string; hint: string }[] = [
  { value: "regular", label: "Every day", hint: "Regular scraping: in every daily run." },
  { value: "scheduled", label: "On a schedule", hint: "Only on the days, dates and months chosen below." },
  { value: "off", label: "Not scheduled", hint: "Scraped only on demand or in a manual full run." },
];
export const modeLabel = (m: ScrapingMode) => MODES.find((x) => x.value === m)!.label;

const DATES = Array.from({ length: 31 }, (_, i) => String(i + 1));

export function ScrapingModePicker({ value, onChange, name = "scraping-mode" }: { value: ScrapingMode | ""; onChange: (m: ScrapingMode) => void; name?: string }) {
  return (
    <div role="radiogroup" aria-label="Scraping" className="grid gap-2 sm:grid-cols-3">
      {MODES.map((m) => {
        const on = value === m.value;
        return (
          <label key={m.value} className={`flex cursor-pointer gap-2.5 rounded-lg border px-3 py-2.5 transition-colors ${on ? "border-gold-line bg-accent-soft shadow-[inset_0_0_0_1px_var(--color-gold-line)]" : "border-line-strong hover:border-line-hover hover:bg-surface-alt"}`}>
            <input type="radio" name={name} className="mt-0.5" checked={on} onChange={() => onChange(m.value)} />
            <span className="min-w-0"><span className="block text-[13.5px] font-medium text-ink">{m.label}</span><span className="block text-[12px] text-faint">{m.hint}</span></span>
          </label>);
      })}
    </div>
  );
}

/** The schedule of a product on a schedule: week-wise, month-wise and year-wise, each optional. */
export function ScheduleParts({ weekly, monthly, months, onWeekly, onMonthly, onMonths, disabled }: {
  weekly: string[]; monthly: string[]; months: string[]; onWeekly: (v: string[]) => void; onMonthly: (v: string[]) => void; onMonths: (v: string[]) => void; disabled?: boolean;
}) {
  const part = (title: string, hint: string, el: React.ReactNode) => (
    <div className="space-y-1.5">
      <div className="text-[13px] font-medium text-ink">{title} <span className="font-normal text-faint">{hint}</span></div>
      {el}
    </div>);
  return (
    <fieldset disabled={disabled} className={`space-y-3 rounded-lg border border-line bg-surface-alt/60 p-3 ${disabled ? "opacity-50" : ""}`}>
      {part("Week-wise", "days of the week", <Toggles ariaLabel="Days of the week" labels={DAYS} value={weekly} onChange={onWeekly} />)}
      {part("Month-wise", "dates of the month (30 or 31 falls on the last day of shorter months)", <Toggles ariaLabel="Dates of the month" labels={DATES} value={monthly} onChange={onMonthly} compact />)}
      {part("Year-wise", "months of the year (none = every month)", <Toggles ariaLabel="Months of the year" labels={MONTHS} value={months} onChange={onMonths} />)}
      <p className="text-[12px] text-faint">No days and no dates: every day of the chosen months.</p>
    </fieldset>
  );
}

import { Select } from "@/components/ui/Select";

/** "15:30" -> "3:30 PM". Blank -> the default, 6:00 AM. */
export function timeLabel(t: unknown) {
  const s = /^\d{2}:\d{2}$/.test(String(t ?? "")) ? String(t) : "06:00";
  const [h, m] = s.split(":").map(Number);
  return `${h % 12 || 12}:${String(m).padStart(2, "0")} ${h < 12 ? "AM" : "PM"}`;
}
const TIMES = Array.from({ length: 96 }, (_, i) => { const v = `${String(Math.floor(i / 4)).padStart(2, "0")}:${String((i % 4) * 15).padStart(2, "0")}`; return { value: v, label: `${timeLabel(v)}${v === "06:00" ? " (default)" : ""}` }; });

/** Time of day (India time) the daily automatic run scrapes the product, in 15-minute steps. */
export function TimePicker({ value, onChange, id }: { value: string; onChange: (v: string) => void; id?: string }) {
  return (
    <div className="space-y-1.5" id={id}>
      <div className="text-[13px] font-medium text-ink">Time of day <span className="font-normal text-faint">India time; the scrape starts within about 15 minutes of it</span></div>
      <Select className="w-full sm:w-56" ariaLabel="Time of day" required value={value || "06:00"} onChange={onChange} options={TIMES} />
    </div>
  );
}

export const listOf = (v: unknown) => String(v ?? "").split(/[,\s]+/).map((s) => s.trim()).filter(Boolean);
