// App shell: navy sidebar with the old app's grouping (Dashboard; PRODUCTS; SCRAPING), plus SYSTEM for the audit log.
// Active item is a soft fill, never a side bar. Phones get a top bar and a slide-in menu.
import { useEffect, useState } from "react";
import { Link, NavLink, Outlet, useLocation } from "react-router-dom";
import { useIsFetching } from "@tanstack/react-query";
import { BookOpen, CalendarClock, FolderTree, History, Layers, LayoutDashboard, LifeBuoy, ListChecks, Menu, ScanSearch, ShieldAlert, ShieldCheck, Table2, X } from "lucide-react";
import { LAST_PAGE, useSupportSummary } from "@/lib/support";
import { useAuth } from "@/lib/auth";
import { UserMenu } from "./UserMenu";
import { ErrorBoundary } from "./ErrorBoundary";
import { setSentryUser } from "@/lib/sentry";
import { PREFETCH } from "@/lib/prefetch";
import { useFixedTitle } from "@/lib/hooks";

type Item = { to: string; label: string; icon: React.ComponentType<{ className?: string }>; admin?: boolean };
export const NAV: { group: string | null; admin?: boolean; items: Item[] }[] = [
  { group: null, items: [{ to: "/", label: "Dashboard", icon: LayoutDashboard }] },
  { group: "Products", items: [{ to: "/categories", label: "Product Categories", icon: FolderTree }, { to: "/products", label: "Products", icon: Layers }] },
  { group: "Scraping", items: [
    { to: "/scraping", label: "Scraping", icon: ScanSearch },
    { to: "/schedule", label: "Your Schedule", icon: CalendarClock },
    { to: "/results", label: "Scrape Product Results", icon: Table2 },
    { to: "/mop-reports", label: "MOP Breach Reports", icon: ShieldAlert },
    { to: "/runs", label: "Scrape Run Results", icon: ListChecks },
  ] },
  { group: "System", items: [{ to: "/team", label: "Team & access", icon: ShieldCheck }, { to: "/audit", label: "Audit log", icon: History, admin: true }] },
];

function Brand() {
  return (
    <Link to="/" className="flex h-16 items-center gap-2.5 border-b border-white/10 px-5" aria-label="Madhukar Domestic Appliances Price Tracker, home">
      <img src="/brand/mark.svg" alt="" className="h-9 w-9 shrink-0" />
      <div className="leading-tight"><div className="text-[14px] font-bold tracking-[0.08em] text-[#F2C94C]">MADHUKAR</div><div className="text-[11px] text-white/60">Price Tracker</div></div>
    </Link>
  );
}

export function Layout() {
  useFixedTitle();
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  const loc = useLocation();
  useEffect(() => setOpen(false), [loc.pathname]);
  // The last page outside Help and support goes with a new request, so the team knows where the problem was.
  useEffect(() => { if (!loc.pathname.startsWith("/support")) try { sessionStorage.setItem(LAST_PAGE, loc.pathname + loc.search); } catch { /* storage blocked */ } }, [loc.pathname, loc.search]);
  useEffect(() => setSentryUser(user ? { id: user.id, email: user.email, role: user.role } : null), [user?.id, user?.email, user?.role]); // eslint-disable-line react-hooks/exhaustive-deps
  const busy = useIsFetching() > 0;
  const groups = NAV.filter((g) => !g.admin || user?.role === "admin").map((g) => ({ ...g, items: g.items.filter((i) => !i.admin || user?.role === "admin") }));
  const current = groups.flatMap((g) => g.items).filter((i) => (i.to === "/" ? loc.pathname === "/" : loc.pathname.startsWith(i.to))).sort((a, b) => b.to.length - a.to.length)[0];

  const nav = (
    <nav className="scroll-on-brand flex-1 overflow-y-auto px-3 py-3" aria-label="Main">
      {groups.map((g, gi) => (
        <div key={gi} className="mb-4">
          {g.group && <div className="flex items-center gap-2 px-2 pb-1.5 text-[11px] font-semibold uppercase tracking-wider text-white/50">{g.group}<span className="h-px flex-1 bg-white/10" /></div>}
          {g.items.map((i) => {
            const Icon = i.icon;
            const active = i === current;
            return (
              <NavLink key={i.to} to={i.to} onMouseEnter={() => PREFETCH[i.to]?.()} onFocus={() => PREFETCH[i.to]?.()} aria-current={active ? "page" : undefined}
                className={`group flex items-center gap-2.5 rounded-lg px-2 py-1.5 text-[13.5px] transition ${active ? "bg-white/10 font-medium text-white [&>svg]:text-gold" : "text-white/75 hover:bg-white/[0.07] hover:text-white"}`}>
                <Icon className={`h-[18px] w-[18px] shrink-0 ${active ? "text-white" : "text-white/50 group-hover:text-white/80"}`} />{i.label}
              </NavLink>);
          })}
        </div>))}
    </nav>
  );
  // Help and support stays pinned above the signed-in user, with a badge for new replies (checked every minute).
  const summary = useSupportSummary();
  const unread = summary.data?.unread ?? 0;
  const onSupport = loc.pathname.startsWith("/support");
  const onGuide = loc.pathname.startsWith("/guide");
  const footer = (
    <div className="border-t border-white/10 p-3">
      <NavLink to="/guide" aria-current={onGuide ? "page" : undefined}
        className={`group mb-0.5 flex items-center gap-2.5 rounded-lg px-2 py-1.5 text-[13.5px] transition ${onGuide ? "bg-white/10 font-medium text-white" : "text-white/75 hover:bg-white/[0.07] hover:text-white"}`}>
        <BookOpen className={`h-[18px] w-[18px] shrink-0 ${onGuide ? "text-gold" : "text-white/50 group-hover:text-white/80"}`} />User guide
      </NavLink>
      <NavLink to="/support" aria-current={onSupport ? "page" : undefined}
        className={`group mb-2 flex items-center gap-2.5 rounded-lg px-2 py-1.5 text-[13.5px] transition ${onSupport ? "bg-white/10 font-medium text-white" : "text-white/75 hover:bg-white/[0.07] hover:text-white"}`}>
        <LifeBuoy className={`h-[18px] w-[18px] shrink-0 ${onSupport ? "text-gold" : "text-white/50 group-hover:text-white/80"}`} />Help and support
        {unread > 0 && <span className="ml-auto min-w-[1.25rem] rounded-full bg-gold px-1.5 text-center text-[11px] font-semibold leading-5 text-on-gold" aria-label={`${unread} new ${unread === 1 ? "reply" : "replies"}`}>{unread}</span>}
      </NavLink>
      <UserMenu />
    </div>);

  return (
    <>
      <a href="#main" className="skip-link">Skip to content</a>
      {busy && <div className="no-print fixed inset-x-0 top-0 z-[100] h-0.5"><div className="nav-progress h-full bg-gold" /></div>}
      <div className="min-h-screen lg:flex">
        <div className="no-print sticky top-0 z-30 flex h-14 items-center gap-3 border-b border-line bg-surface px-4 lg:hidden">
          <button onClick={() => setOpen(true)} className="btn btn-sm w-9 px-0" aria-label="Menu"><Menu className="h-4 w-4" /></button>
          <div className="min-w-0 truncate text-[14px] font-semibold text-ink">{onGuide ? "User guide" : current?.label ?? (onSupport ? "Help and support" : "MDAPL")}</div>
          {unread > 0 && <Link to="/support" className="ml-auto inline-flex items-center gap-1.5 rounded-full bg-gold px-2 text-[12px] font-semibold leading-6 text-on-gold"><LifeBuoy className="h-3.5 w-3.5" />{unread}</Link>}
        </div>
        {open && <div className="dialog-backdrop fixed inset-0 z-40 lg:hidden" onClick={() => setOpen(false)} />}
        <aside className={`no-print fixed inset-y-0 left-0 z-50 flex w-64 flex-col bg-brand transition-transform lg:sticky lg:top-0 lg:h-screen lg:w-60 lg:translate-x-0 ${open ? "translate-x-0" : "-translate-x-full"}`}>
          {open && <button className="absolute right-2 top-4 rounded-lg p-1.5 text-white/70 hover:bg-white/10 lg:hidden" onClick={() => setOpen(false)} aria-label="Close menu"><X className="h-4 w-4" /></button>}
          <Brand />{nav}{footer}
        </aside>
        {/* The User guide uses the whole content area (its own columns are sticky), so no padding or max width there. */}
        <main id="main" tabIndex={-1} className={`min-w-0 flex-1 outline-none ${onGuide ? "" : "px-4 py-5 sm:px-6 lg:px-8 lg:py-7"}`}>
          {onGuide ? <ErrorBoundary key={loc.pathname}><Outlet /></ErrorBoundary>
            : <div className="mx-auto max-w-[1500px]"><ErrorBoundary key={loc.pathname}><Outlet /></ErrorBoundary></div>}
        </main>
      </div>
    </>
  );
}
