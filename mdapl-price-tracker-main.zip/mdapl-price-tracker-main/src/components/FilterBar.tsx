// One filter row for every list (reference: FilterBar). Filters apply as they change and live in the URL;
// Clear appears only when something is set.
import { Search, X } from "lucide-react";
import { useDebouncedUrlValue } from "@/lib/hooks";

export function FilterBar({ children, active, onClear, right }: { children: React.ReactNode; active?: boolean; onClear?: () => void; right?: React.ReactNode }) {
  return (
    <div className="no-print flex flex-wrap items-center gap-2" role="search">
      {children}
      {active && onClear && <button type="button" className="btn-ghost" onClick={onClear}><X className="h-4 w-4" />Clear</button>}
      {right && <div className="ml-auto flex flex-wrap items-center gap-2">{right}</div>}
    </div>
  );
}

/** Search box: types freely, writes to the URL after a short pause. */
export function SearchBox({ value, onChange, placeholder = "Search", className = "w-full sm:w-64", ariaLabel }: { value: string; onChange: (v: string) => void; placeholder?: string; className?: string; ariaLabel?: string }) {
  const [text, setText] = useDebouncedUrlValue(value, onChange);
  return (
    <div className={`relative ${className}`}>
      <Search className="pointer-events-none absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-faint" />
      <input value={text} onChange={(e) => setText(e.target.value)} placeholder={placeholder} aria-label={ariaLabel ?? placeholder} className="input pl-8 pr-8" type="search" />
      {text && <button type="button" onClick={() => { setText(""); onChange(""); }} className="absolute right-1.5 top-1/2 -translate-y-1/2 rounded p-1 text-faint hover:text-ink" aria-label="Clear search"><X className="h-3.5 w-3.5" /></button>}
    </div>
  );
}
