// Dialog, in-app confirm and toasts (reference: Modal.tsx, ConfirmDialog.tsx, Toaster.tsx).
import { useEffect, useRef, useState } from "react";
import { X, CheckCircle2, AlertTriangle, Info } from "lucide-react";

export function Dialog({ open, onClose, title, children, footer, wide }: { open: boolean; onClose: () => void; title: React.ReactNode; children: React.ReactNode; footer?: React.ReactNode; wide?: boolean | "xl" }) {
  const ref = useRef<HTMLDialogElement>(null);
  useEffect(() => { const d = ref.current; if (!d) return; if (open && !d.open) d.showModal(); else if (!open && d.open) d.close(); }, [open]);
  return (
    <dialog ref={ref} onClose={onClose} onCancel={(e) => { e.preventDefault(); onClose(); }} onMouseDown={(e) => { if (e.target === ref.current) onClose(); }}
      className={`m-auto w-[calc(100%-2rem)] ${wide === "xl" ? "max-w-5xl" : wide ? "max-w-3xl" : "max-w-lg"} dialog-panel p-0 backdrop:bg-[rgb(17_24_39/0.45)]`}>
      {open && <>
        <div className="flex items-center justify-between gap-3 border-b border-line px-5 py-4">
          <h2 className="dialog-title min-w-0 break-words">{title}</h2>
          <button type="button" className="btn-icon -mr-1.5" onClick={onClose} aria-label="Close"><X className="h-4 w-4" /></button>
        </div>
        <div className="max-h-[72vh] overflow-y-auto p-5">{children}</div>
        {footer && <div className="flex flex-wrap justify-end gap-2 border-t border-line px-5 py-3">{footer}</div>}
      </>}
    </dialog>
  );
}

type ConfirmReq = { title: string; body?: React.ReactNode; confirmLabel?: string; tone?: "danger" | "default"; resolve: (ok: boolean) => void };
let pushConfirm: ((r: ConfirmReq) => void) | null = null;
export const confirmAction = (o: Omit<ConfirmReq, "resolve">) => new Promise<boolean>((resolve) => (pushConfirm ? pushConfirm({ ...o, resolve }) : resolve(window.confirm(o.title))));

export function ConfirmHost() {
  const [req, setReq] = useState<ConfirmReq | null>(null);
  const ref = useRef<HTMLDialogElement>(null);
  const ok = useRef<HTMLButtonElement>(null);
  useEffect(() => { pushConfirm = setReq; return () => { pushConfirm = null; }; }, []);
  // A native modal dialog, so it opens in the top layer above any other open dialog.
  useEffect(() => { const d = ref.current; if (!d) return; if (req && !d.open) { d.showModal(); ok.current?.focus(); } else if (!req && d.open) d.close(); }, [req]);
  const done = (v: boolean) => { req?.resolve(v); setReq(null); };
  return (
    <dialog ref={ref} role="alertdialog" aria-modal="true" aria-labelledby="confirm-title" onCancel={(e) => { e.preventDefault(); done(false); }}
      onMouseDown={(e) => { if (e.target === ref.current) done(false); }} className="m-auto w-[calc(100%-2rem)] max-w-md dialog-panel p-0 backdrop:bg-[rgb(17_24_39/0.45)]">
      {req && <>
        <div className="px-5 py-4"><h2 id="confirm-title" className="dialog-title">{req.title}</h2>{req.body && <div className="mt-2 text-[13.5px] leading-relaxed text-muted">{req.body}</div>}</div>
        <div className="flex flex-wrap justify-end gap-2 border-t border-line px-5 py-3">
          <button className="btn-ghost" onClick={() => done(false)}>Cancel</button>
          <button ref={ok} className={req.tone === "danger" ? "btn-danger-solid" : "btn-primary"} onClick={() => done(true)}>{req.confirmLabel ?? "Confirm"}</button>
        </div>
      </>}
    </dialog>
  );
}

type Toast = { id: number; tone: "success" | "error" | "info"; text: React.ReactNode };
let pushToast: ((t: Omit<Toast, "id">) => void) | null = null;
export const toast = {
  success: (text: React.ReactNode) => pushToast?.({ tone: "success", text }),
  error: (text: React.ReactNode) => pushToast?.({ tone: "error", text }),
  info: (text: React.ReactNode) => pushToast?.({ tone: "info", text }),
};

export function Toaster() {
  const [list, setList] = useState<Toast[]>([]);
  useEffect(() => {
    let id = 0;
    pushToast = (t) => { const n = ++id; setList((l) => [...l.slice(-3), { ...t, id: n }]); setTimeout(() => setList((l) => l.filter((x) => x.id !== n)), t.tone === "error" ? 8000 : 5000); };
    return () => { pushToast = null; };
  }, []);
  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-4 z-[90] flex flex-col items-center gap-2 px-4 sm:items-end sm:pr-6" aria-live="polite">
      {list.map((t) => (
        <div key={t.id} className="pop pointer-events-auto flex w-full max-w-sm items-start gap-2.5 px-3.5 py-3 text-[13.5px]" role={t.tone === "error" ? "alert" : "status"}>
          {t.tone === "success" ? <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-success" /> : t.tone === "error" ? <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-danger" /> : <Info className="mt-0.5 h-4 w-4 shrink-0 text-faint" />}
          <div className="min-w-0 flex-1 text-ink">{t.text}</div>
          <button className="-m-1 rounded p-1 text-faint hover:text-ink" onClick={() => setList((l) => l.filter((x) => x.id !== t.id))} aria-label="Dismiss"><X className="h-3.5 w-3.5" /></button>
        </div>))}
    </div>
  );
}
