// Files to attach to a support request or reply: drop them, pick them, or paste a screenshot. Images show a small
// preview. Big photos are allowed here; they are shrunk when they are sent.
import { useEffect, useRef, useState } from "react";
import { FileText, Paperclip, X } from "lucide-react";
import { ACCEPT, fileSize, MAX_FILE, MAX_FILES } from "@/lib/support";
import { toast } from "./overlays";

export function acceptFiles(add: File[], have: File[]) {
  const ok: File[] = [];
  for (const f of add) {
    if (have.length + ok.length >= MAX_FILES) { toast.info(`Up to ${MAX_FILES} files at a time.`); break; }
    if (f.size > MAX_FILE && !f.type.startsWith("image/")) { toast.error(`${f.name} is over 3 MB.`); continue; }
    ok.push(f);
  }
  return [...have, ...ok];
}

/** Screenshots pasted into a text box land as files. */
export const pastedFiles = (e: React.ClipboardEvent) => [...e.clipboardData.files];

export function FileChips({ files, onRemove }: { files: File[]; onRemove?: (i: number) => void }) {
  // Made in the effect so StrictMode's second run gets fresh URLs, not revoked ones.
  const [urls, setUrls] = useState<(string | null)[]>([]);
  useEffect(() => {
    const made = files.map((f) => (f.type.startsWith("image/") ? URL.createObjectURL(f) : null));
    setUrls(made);
    return () => made.forEach((u) => u && URL.revokeObjectURL(u));
  }, [files]);
  if (!files.length) return null;
  return (
    <ul className="flex flex-wrap gap-2">
      {files.map((f, i) => (
        <li key={`${f.name}-${i}`} className="flex max-w-full items-center gap-2 rounded-lg border border-line bg-surface py-1 pl-1 pr-1.5 text-[12.5px]">
          {urls[i] ? <img src={urls[i]!} alt="" className="h-8 w-8 shrink-0 rounded object-cover" />
            : <span className="grid h-8 w-8 shrink-0 place-items-center rounded bg-surface-alt"><FileText className="h-4 w-4 text-faint" /></span>}
          <span className="min-w-0"><span className="block max-w-[180px] truncate text-ink">{f.name}</span><span className="text-faint">{fileSize(f.size)}</span></span>
          {onRemove && <button type="button" className="btn-icon h-6 w-6" aria-label={`Remove ${f.name}`} onClick={() => onRemove(i)}><X className="h-3.5 w-3.5" /></button>}
        </li>))}
    </ul>
  );
}

export function DropZone({ files, onChange }: { files: File[]; onChange: (f: File[]) => void }) {
  const input = useRef<HTMLInputElement>(null);
  const [over, setOver] = useState(false);
  return (
    <div>
      <div role="button" tabIndex={0} onClick={() => input.current?.click()} onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && input.current?.click()}
        onDragOver={(e) => { e.preventDefault(); setOver(true); }} onDragLeave={() => setOver(false)}
        onDrop={(e) => { e.preventDefault(); setOver(false); onChange(acceptFiles([...e.dataTransfer.files], files)); }}
        className={`flex cursor-pointer flex-col items-center gap-1 rounded-lg border border-dashed px-4 py-5 text-center transition-colors ${over ? "border-gold-line bg-accent-soft" : "border-line-strong hover:border-line-hover hover:bg-surface-alt"}`}>
        <Paperclip className="h-4 w-4 text-faint" />
        <span className="text-[13px] font-medium text-ink">Add screenshots or files</span>
        <span className="text-[12px] text-faint">Drop them here, click to choose, or paste a screenshot in the description. Up to {MAX_FILES}, 3 MB each.</span>
      </div>
      <input ref={input} type="file" multiple hidden accept={ACCEPT} onChange={(e) => { onChange(acceptFiles([...(e.target.files ?? [])], files)); e.target.value = ""; }} />
      {files.length > 0 && <div className="mt-2"><FileChips files={files} onRemove={(i) => onChange(files.filter((_, j) => j !== i))} /></div>}
    </div>
  );
}
