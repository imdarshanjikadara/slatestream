// User menu at the foot of the sidebar: who is signed in, Team & access and Scraper connection (admins), Change password, Sign out.
import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { useMutation, useQuery } from "@tanstack/react-query";
import { ChevronsUpDown, ExternalLink, KeyRound, LogOut, PlugZap, ShieldCheck } from "lucide-react";
import { api, queryClient } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { Field } from "@/components/common";
import { Pill } from "@/components/Pill";
import { Dialog, toast } from "@/components/overlays";
import { reportError, sentryEnabled } from "@/lib/sentry";
import { channelLabel } from "@/lib/format";

export const initials = (name?: string) => (name ?? "?").split(/\s+/).map((w) => w[0]).slice(0, 2).join("").toUpperCase();

export function UserMenu() {
  const { user, signOut } = useAuth();
  const [open, setOpen] = useState(false);
  const [dialog, setDialog] = useState<"password" | "scraper" | null>(null);
  const box = useRef<HTMLDivElement>(null);
  const isAdmin = user?.role === "admin";

  useEffect(() => {
    if (!open) return;
    const away = (e: MouseEvent) => { if (!box.current?.contains(e.target as Node)) setOpen(false); };
    const key = (e: KeyboardEvent) => { if (e.key === "Escape") { setOpen(false); box.current?.querySelector<HTMLButtonElement>("[aria-haspopup]")?.focus(); } };
    document.addEventListener("mousedown", away); document.addEventListener("keydown", key);
    box.current?.querySelector<HTMLElement>("[role=menuitem]")?.focus();
    return () => { document.removeEventListener("mousedown", away); document.removeEventListener("keydown", key); };
  }, [open]);
  // Up/Down move between the items, as in a native menu.
  const onMenuKey = (e: React.KeyboardEvent) => {
    if (e.key !== "ArrowDown" && e.key !== "ArrowUp") return;
    e.preventDefault();
    const items = [...(box.current?.querySelectorAll<HTMLElement>("[role=menuitem]") ?? [])];
    const i = items.indexOf(document.activeElement as HTMLElement);
    items[(i + (e.key === "ArrowDown" ? 1 : -1) + items.length) % items.length]?.focus();
  };
  const pick = (fn: () => void) => () => { setOpen(false); fn(); };
  const item = "flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-left text-[13.5px] text-ink outline-none hover:bg-hover focus-visible:bg-hover";

  return (
    <div ref={box} className="relative">
      {open && (
        <div role="menu" aria-label="Account" onKeyDown={onMenuKey} className="absolute bottom-full left-0 right-0 z-50 mb-2 overflow-hidden rounded-xl border border-line bg-surface shadow-[var(--shadow-pop)]">
          <div className="flex items-center justify-between gap-2 border-b border-line px-3.5 py-3">
            <span className="text-[12.5px] text-muted">Signed in as</span>
            <Pill tone={isAdmin ? "success" : "neutral"}>{isAdmin ? "Admin" : "Staff"}</Pill>
          </div>
          <div className="p-1.5">
            {isAdmin && <>
              <Link role="menuitem" to="/team" className={item} onClick={() => setOpen(false)}><ShieldCheck className="h-4 w-4 text-faint" />Team &amp; access</Link>
              <button role="menuitem" className={item} onClick={pick(() => setDialog("scraper"))}><PlugZap className="h-4 w-4 text-faint" />Scraper connection</button>
              <div className="my-1.5 h-px bg-line" />
            </>}
            <button role="menuitem" className={item} onClick={pick(() => setDialog("password"))}><KeyRound className="h-4 w-4 text-faint" />Change password</button>
            <button role="menuitem" className={`${item} text-danger`} onClick={pick(() => void signOut())}><LogOut className="h-4 w-4" />Sign out</button>
          </div>
        </div>)}
      <button aria-haspopup="menu" aria-expanded={open} onClick={() => setOpen((o) => !o)}
        className={`flex w-full items-center gap-2.5 rounded-xl px-2 py-2 text-left transition ${open ? "bg-white/12 ring-1 ring-gold/70" : "hover:bg-white/[0.07]"}`}>
        <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-white/10 text-[12px] font-semibold text-white">{initials(user?.name)}</span>
        <span className="min-w-0 flex-1 leading-tight"><span className="block truncate text-[13px] font-medium text-white">{user?.name}</span><span className="block truncate text-[11px] text-white/55">{user?.email}</span></span>
        <ChevronsUpDown className="h-4 w-4 shrink-0 text-white/50" />
      </button>
      <ChangePasswordDialog open={dialog === "password"} onClose={() => setDialog(null)} />
      {isAdmin && <ScraperDialog open={dialog === "scraper"} onClose={() => setDialog(null)} />}
    </div>
  );
}

/** Current + new password (twice). Used in the dialog and on the "set your own password" screen after a temporary one. */
export function ChangePasswordForm({ id, onDone, first }: { id: string; onDone: () => void; first?: boolean }) {
  const { user } = useAuth();
  const [f, setF] = useState({ current: "", next: "", again: "" });
  const m = useMutation({
    mutationFn: () => api("auth/password", { body: { current: f.current, next: f.next } }),
    onSuccess: async () => { setF({ current: "", next: "", again: "" }); await queryClient.invalidateQueries({ queryKey: ["me"] }); toast.success("Password changed. Other devices are signed out."); onDone(); },
  });
  const mismatch = !!f.again && f.next !== f.again;
  const short = !!f.next && f.next.length < 10;
  const sameAsEmail = !!f.next && f.next.trim().toLowerCase() === user?.email;
  const ok = f.current && f.next && !mismatch && !short && !sameAsEmail && f.next === f.again;
  const input = (k: keyof typeof f, label: string, hint?: React.ReactNode, auto = "new-password") => (
    <Field label={label} htmlFor={`${id}-${k}`} hint={hint}>
      <input id={`${id}-${k}`} type="password" className="input" autoComplete={auto} value={f[k]} onChange={(e) => setF((o) => ({ ...o, [k]: e.target.value }))} />
    </Field>
  );
  return (
    <form id={id} className="space-y-3" onSubmit={(e) => { e.preventDefault(); if (ok && !m.isPending) m.mutate(); }}>
      {m.error && <div className="notice notice-danger">{(m.error as Error).message}</div>}
      {input("current", first ? "Temporary password" : "Current password", undefined, "current-password")}
      {input("next", "New password", short ? <span className="text-danger">Use at least 10 characters.</span> : sameAsEmail ? <span className="text-danger">Do not use your email.</span> : "At least 10 characters. A few unrelated words work well.")}
      {input("again", "New password again", mismatch ? <span className="text-danger">The two new passwords are different.</span> : undefined)}
    </form>
  );
}

export function ChangePasswordDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  return (
    <Dialog open={open} onClose={onClose} title="Change password"
      footer={<><button className="btn-ghost" onClick={onClose}>Cancel</button><button className="btn-primary" form="change-password">Change password</button></>}>
      <p className="mb-3 text-[13px] text-muted">You stay signed in here; any other device you use is signed out.</p>
      <ChangePasswordForm id="change-password" onDone={onClose} />
    </Dialog>
  );
}

type Settings = { simulated: boolean; browserless: { configured: boolean; host: string | null }; proxy: { configured: boolean; host: string | null; login: boolean }; directChannels?: string[]; sentry: boolean; dashboardUrl: string };
type Test = { ok: boolean; ms: number; exit?: { ip?: string; country?: string; city?: string; isp?: string }; error?: string; simulated?: boolean };

/** What the scraper is set up with (hosts only, never secrets) and a live check through Browserless and the Decodo proxy. */
function ScraperDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const q = useQuery({ queryKey: ["scraper-settings"], queryFn: () => api<Settings>("meta/scraper"), enabled: open });
  const t = useMutation({ mutationFn: () => api<Test>("meta/scraper-test", { body: {} }) });
  // One test error from this browser (side=browser) and one from the server (side=server), both to Sentry project mdapl-web.
  const st = useMutation({
    mutationFn: async () => { reportError(new Error("Test error from Scraper connection (safe to resolve)")); return api<{ sent: boolean }>("meta/sentry-test", { body: {} }); },
    onSuccess: (r) => toast.success(r.sent || sentryEnabled ? `Test errors sent${r.sent ? "" : " from this browser only"}. They appear in Sentry (mdapl-web) within a minute, and tech@ gets an email.` : "Error monitoring is off here (it runs on the live site only)."),
    onError: (e) => toast.error((e as Error).message),
  });
  useEffect(() => { if (!open) t.reset(); }, [open]); // eslint-disable-line react-hooks/exhaustive-deps
  const s = q.data;
  const row = (label: string, ok: boolean | undefined, detail: React.ReactNode) => (
    <div className="flex items-start justify-between gap-3 border-b border-line py-2.5 last:border-0">
      <div className="min-w-0"><div className="text-[13.5px] font-medium text-ink">{label}</div><div className="truncate text-[12.5px] text-muted">{detail}</div></div>
      <Pill tone={ok ? "success" : "warning"}>{ok ? "Set" : "Not set"}</Pill>
    </div>
  );
  const indian = t.data?.exit?.country && /india/i.test(t.data.exit.country);
  return (
    <Dialog open={open} onClose={onClose} title="Scraper connection"
      footer={<>
        {s && <a className="btn-ghost mr-auto" href={s.dashboardUrl} target="_blank" rel="noopener noreferrer"><ExternalLink className="h-4 w-4" />Decodo dashboard</a>}
        <button className="btn-ghost" onClick={onClose}>Close</button>
        <button className="btn-primary" disabled={t.isPending || !s} onClick={() => t.mutate()}><PlugZap className="h-4 w-4" />{t.isPending ? "Testing (up to a minute)..." : "Test connection"}</button>
      </>}>
      {q.error && <div className="notice notice-danger mb-3">{(q.error as Error).message}</div>}
      {s?.simulated && <div className="notice notice-neutral mb-3">Demo mode: scraping is simulated, nothing is sent to Browserless or Decodo.</div>}
      {s && <div className="mb-4">
        {row("Browserless", s.browserless.configured, s.browserless.host ?? "BROWSERLESS_URL / BROWSERLESS_TOKEN")}
        {row("Decodo residential proxy", s.proxy.configured, s.proxy.host ? `${s.proxy.host}${s.proxy.login ? ", login set" : ", login missing"}` : "SCRAPE_PROXY_SERVER / USERNAME / PASSWORD")}
        {!!s.directChannels?.length && <div className="border-b border-line py-2.5 text-[12.5px] text-muted">
          <span className="font-medium text-ink">Read without the proxy:</span> {s.directChannels.map((c) => channelLabel(c)).join(", ")}. Their bot check refuses an address that changes between requests.
        </div>}
        <div className="flex items-start justify-between gap-3 py-2.5">
          <div className="min-w-0"><div className="text-[13.5px] font-medium text-ink">Error monitoring (Sentry)</div>
            <div className="text-[12.5px] text-muted">{s.sentry ? "Crashes and scraper failures are reported." : "Off here; on for the live site."} <button className="underline underline-offset-2 hover:text-ink disabled:opacity-50" disabled={st.isPending} onClick={() => st.mutate()}>{st.isPending ? "Sending..." : "Send test errors"}</button></div></div>
          <Pill tone={s.sentry ? "success" : "neutral"}>{s.sentry ? "On" : "Off"}</Pill>
        </div>
      </div>}
      <p className="text-[12.5px] text-muted">The test opens Decodo's IP check page in Browserless through the proxy, like a real scrape, and shows where the request came out. The keys themselves are only in Vercel and never shown here.</p>
      {t.data && (t.data.ok
        ? <div className={`notice ${indian || t.data.simulated ? "notice-success" : "notice-warning"} mt-3`}>
            <div className="font-semibold">{indian || t.data.simulated ? "Connected" : "Connected, but not through India"}</div>
            Exit {t.data.exit?.ip ?? "?"}, {[t.data.exit?.city, t.data.exit?.country].filter(Boolean).join(", ")}{t.data.exit?.isp ? ` (${t.data.exit.isp})` : ""}, in {(t.data.ms / 1000).toFixed(1)} s.
            {!indian && !t.data.simulated && " Set the proxy location to India in Decodo, or Amazon and Flipkart may show other prices."}
          </div>
        : <div className="notice notice-danger mt-3"><div className="font-semibold">Not connected</div>{t.data.error}</div>)}
      {t.error && <div className="notice notice-danger mt-3">{(t.error as Error).message}</div>}
    </Dialog>
  );
}
