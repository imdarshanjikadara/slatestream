// Status pills: dot + soft fill + hairline border. Normal states are neutral; amber/red only when something needs attention.
export type Tone = "neutral" | "success" | "warning" | "danger" | "info";
const DOT: Record<Tone, string> = { neutral: "bg-line-hover", success: "bg-success-fill", warning: "bg-warning-fill", danger: "bg-danger-fill", info: "bg-info-fill" };

export function Pill({ tone = "neutral", children, title, dot = true }: { tone?: Tone; children: React.ReactNode; title?: string; dot?: boolean }) {
  return <span className={`pill pill-${tone}`} title={title}>{dot && <span className={`dot ${DOT[tone]}`} />}{children}</span>;
}

/** Availability as scraped. In stock is the normal state (neutral); not available needs attention. */
export function Availability({ v }: { v: unknown }) {
  const s = String(v ?? "Unknown");
  const tone: Tone = s === "In Stock" ? "neutral" : s === "Limited Stock" ? "warning" : s === "Unknown" ? "neutral" : "danger";
  return <Pill tone={tone}>{s}</Pill>;
}

/** Scrape run and batch status. A run without batch records (made by the old the old app workflows) that still says Started
 *  or In progress a day later never finished: it shows as "Not finished" instead of looking busy forever. */
export const runStatus = (r: { status?: unknown; batches?: number; run_date?: unknown; created_at?: unknown }) => {
  const s = String(r.status ?? "").toLowerCase();
  const age = Date.now() - new Date(String(r.run_date ?? r.created_at ?? "")).getTime();
  return !r.batches && (s === "started" || s === "in progress") && age > 86_400_000 ? "not finished" : s;
};
export function RunStatus({ v }: { v: unknown }) {
  const s = String(v ?? "").toLowerCase();
  if (s === "not finished") return <Pill tone="warning" title="An older run that was never finished and has no progress records.">Not finished</Pill>;
  const label = s === "in progress" ? "In progress" : s === "running" ? "Running" : s ? s[0].toUpperCase() + s.slice(1) : "Unknown";
  // Finished is green (like Active), work happening now blue, failed red, waiting grey.
  const tone: Tone = s === "failed" ? "danger" : s === "in progress" || s === "running" ? "info" : s === "done" ? "success" : s === "paused" ? "warning" : s === "aborted" ? "danger" : "neutral";
  return <Pill tone={tone}>{label}</Pill>;
}

/** On / off of a record: the same pill in every table and in the products sheet. */
export function ActiveStatus({ active, on = "Active", off = "Inactive" }: { active: boolean; on?: string; off?: string }) {
  return <Pill tone={active ? "success" : "neutral"}>{active ? on : off}</Pill>;
}

export function MopFlag({ below }: { below: boolean }) {
  return below ? <Pill tone="danger">Below MOP</Pill> : null;
}
