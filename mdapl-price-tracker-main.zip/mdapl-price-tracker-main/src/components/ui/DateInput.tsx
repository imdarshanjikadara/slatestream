import { useEffect, useMemo, useRef, useState } from "react";
import { useFloating } from "./useFloating";

const pad = (n: number) => String(n).padStart(2, "0");
const iso = (d: Date) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const parse = (s?: string) => { if (!s || !/^\d{4}-\d{2}-\d{2}/.test(s)) return null; const [y, m, d] = s.slice(0, 10).split("-").map(Number); return new Date(y, m - 1, d); };
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

// App-themed date picker (replaces the browser date control). Value is 'YYYY-MM-DD'.
export function DateInput({ name, value, defaultValue, onChange, required, placeholder = "Select date", className = "", size = "md", ariaLabel }: {
  name?: string; value?: string; defaultValue?: string; onChange?: (v: string) => void; required?: boolean; placeholder?: string; className?: string; size?: "sm" | "md"; ariaLabel?: string;
}) {
  const [inner, setInner] = useState(defaultValue ?? "");
  const v = value !== undefined ? value : inner;
  const sel = parse(v);
  const [open, setOpen] = useState(false);
  const [view, setView] = useState(() => sel ?? new Date());
  const root = useRef<HTMLDivElement>(null);
  const trigger = useRef<HTMLButtonElement>(null);
  const float = useFloating(open, trigger, 330, 272);
  useEffect(() => { if (open) setView(sel ?? new Date()); }, [open]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (!open) return;
    const close = (e: MouseEvent) => { if (!root.current?.contains(e.target as Node)) setOpen(false); };
    const esc = (e: KeyboardEvent) => { if (e.key === "Escape") { e.stopPropagation(); setOpen(false); } };
    document.addEventListener("mousedown", close); document.addEventListener("keydown", esc, true);
    return () => { document.removeEventListener("mousedown", close); document.removeEventListener("keydown", esc, true); };
  }, [open]);
  const set = (d: Date | null) => { const s = d ? iso(d) : ""; if (value === undefined) setInner(s); onChange?.(s); setOpen(false); };
  const days = useMemo(() => {
    const first = new Date(view.getFullYear(), view.getMonth(), 1);
    const start = new Date(first); start.setDate(1 - ((first.getDay() + 6) % 7)); // Monday first
    return Array.from({ length: 42 }, (_, i) => { const d = new Date(start); d.setDate(start.getDate() + i); return d; });
  }, [view]);
  const today = iso(new Date());
  const h = size === "sm" ? "h-8 text-[13px]" : "h-9 text-[13.5px]";

  return (
    <div ref={root} className={`relative ${className}`}>
      {name && <input type="hidden" name={name} value={v} />}
      {required && <input tabIndex={-1} aria-hidden className="pointer-events-none absolute inset-0 opacity-0" required value={v} onChange={() => {}} onFocus={() => setOpen(true)} />}
      <button ref={trigger} type="button" aria-label={ariaLabel} onClick={() => setOpen((o) => !o)}
        className={`flex w-full items-center justify-between gap-2 rounded-lg border bg-surface px-3 text-left outline-none transition ${h} ${open ? "border-focus shadow-[0_0_0_1px_var(--color-focus)]" : "border-line-strong hover:border-line-hover"}`}>
        <span className={`min-w-0 truncate whitespace-nowrap ${sel ? "text-ink" : "text-faint"}`}>{sel ? `${pad(sel.getDate())} ${MONTHS[sel.getMonth()]} ${sel.getFullYear()}` : placeholder}</span>
        <svg viewBox="0 0 20 20" className="h-4 w-4 text-faint" fill="none" stroke="currentColor" strokeWidth={1.6}><path d="M4 6h12v10H4zM4 9h12M7 4v3M13 4v3" /></svg>
      </button>
      {open && (
        <div style={float} className="pop z-[120] overflow-auto p-3">
          <div className="mb-2 flex items-center justify-between">
            <button type="button" className="rounded-md px-2 py-1 text-faint hover:bg-hover" onClick={() => setView(new Date(view.getFullYear(), view.getMonth() - 1, 1))} aria-label="Previous month">‹</button>
            <div className="text-[13.5px] font-semibold">{MONTHS[view.getMonth()]} {view.getFullYear()}</div>
            <button type="button" className="rounded-md px-2 py-1 text-faint hover:bg-hover" onClick={() => setView(new Date(view.getFullYear(), view.getMonth() + 1, 1))} aria-label="Next month">›</button>
          </div>
          <div className="grid grid-cols-7 text-center text-[11px] font-medium text-faint">{["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"].map((d) => <div key={d} className="py-1">{d}</div>)}</div>
          <div className="grid grid-cols-7 gap-0.5">
            {days.map((d) => {
              const s = iso(d), inMonth = d.getMonth() === view.getMonth(), isSel = v === s, isToday = s === today;
              return <button type="button" key={s} onClick={() => set(d)}
                className={`h-8 rounded-lg text-[13px] ${isSel ? "bg-gold font-semibold text-on-gold" : isToday ? "font-semibold text-ink ring-1 ring-line-strong" : inMonth ? "text-ink hover:bg-hover" : "text-line-hover hover:bg-surface-alt"}`}>{d.getDate()}</button>;
            })}
          </div>
          <div className="mt-2 flex justify-between border-t border-line pt-2">
            <button type="button" className="text-[12px] font-medium text-ink hover:underline" onClick={() => set(new Date())}>Today</button>
            {!required && <button type="button" className="text-[12px] text-faint hover:underline" onClick={() => set(null)}>Clear</button>}
          </div>
        </div>)}
    </div>
  );
}
