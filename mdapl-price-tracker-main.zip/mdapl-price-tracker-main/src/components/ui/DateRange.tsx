import { DateInput } from "./DateInput";

/** Two joined date inputs that never wrap apart. The placeholder names the field, so several ranges stay readable. */
export function DateRange({ label, from, to, onFrom, onTo, nameFrom, nameTo, size = "md", className = "" }: {
  label: string; from?: string; to?: string; onFrom?: (v: string) => void; onTo?: (v: string) => void;
  nameFrom?: string; nameTo?: string; size?: "sm" | "md"; className?: string;
}) {
  const controlled = onFrom !== undefined;
  return (
    // The "from" box is as wide as its placeholder ("Dispatched from") plus the calendar icon, so the text never wraps.
    <div className={`flex min-w-0 items-center ${className}`} role="group" aria-label={`${label} range`} style={{ ["--from-w" as string]: `calc(${label.length + 5}ch + 3rem)` }}>
      <DateInput size={size} className="min-w-0 flex-1 sm:w-[max(9rem,var(--from-w))] sm:flex-none [&>button]:rounded-r-none" placeholder={`${label} from`} name={nameFrom}
        {...(controlled ? { value: from ?? "", onChange: onFrom } : { defaultValue: from })} ariaLabel={`${label} from`} />
      <DateInput size={size} className="-ml-px min-w-0 flex-1 sm:w-[9.5rem] sm:flex-none [&>button]:rounded-l-none" placeholder="to" name={nameTo}
        {...(controlled ? { value: to ?? "", onChange: onTo } : { defaultValue: to })} ariaLabel={`${label} to`} />
    </div>
  );
}
