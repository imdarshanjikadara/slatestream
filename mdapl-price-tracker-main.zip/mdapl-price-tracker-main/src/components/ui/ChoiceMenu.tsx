// Floating editors shared by every editable table (the products sheet and the in-place edits of other tables):
// a list for single or multiple choice, and a type-ahead box (type anything, or pick a value already in use).
// Both sit against the viewport, so a scrolling table never clips them.
import { useEffect, useMemo, useRef, useState } from "react";
import { Check } from "lucide-react";
import { useFloating } from "./useFloating";

export type Opt = { value: string; label: string };

/** A small floating list for single or multiple choice, placed against the viewport so the sheet's scroll does not cut it off. */
export function ChoiceMenu({ anchor, options, multiple, value, onPick, onClose, columns = 1 }: {
  anchor: React.RefObject<HTMLElement | null>; options: Opt[]; multiple?: boolean; value: string[]; onPick: (v: string[]) => void; onClose: (save: boolean) => void; columns?: number;
}) {
  const [sel, setSel] = useState(value);
  const [q, setQ] = useState("");
  const [hi, setHi] = useState(0);
  const box = useRef<HTMLDivElement>(null);
  const search = useRef<HTMLInputElement>(null), listEl = useRef<HTMLDivElement>(null);
  const style = useFloating(true, anchor, 320, columns > 1 ? 300 : undefined);
  // Placed (and made visible) just after mounting: take the keyboard once it can.
  useEffect(() => { const f = requestAnimationFrame(() => (search.current ?? listEl.current)?.focus()); return () => cancelAnimationFrame(f); }, []);
  const shown = useMemo(() => (q ? options.filter((o) => o.label.toLowerCase().includes(q.toLowerCase())) : options), [options, q]);
  useEffect(() => {
    const away = (e: MouseEvent) => { if (!box.current?.contains(e.target as Node)) onClose(true); };
    document.addEventListener("mousedown", away);
    return () => document.removeEventListener("mousedown", away);
  }, [onClose]);
  useEffect(() => { if (multiple) onPick(sel); }, [sel]); // eslint-disable-line react-hooks/exhaustive-deps
  const toggle = (v: string) => multiple ? setSel((s) => (s.includes(v) ? s.filter((x) => x !== v) : [...s, v].sort((a, b) => Number(a) - Number(b)))) : (onPick([v]), onClose(true));
  const key = (e: React.KeyboardEvent) => {
    if (e.key === "Escape") { e.preventDefault(); onClose(false); }
    else if (e.key === "ArrowDown") { e.preventDefault(); setHi((h) => Math.min(h + (columns > 1 ? columns : 1), shown.length - 1)); }
    else if (e.key === "ArrowUp") { e.preventDefault(); setHi((h) => Math.max(h - (columns > 1 ? columns : 1), 0)); }
    else if (e.key === "ArrowRight" && columns > 1) { e.preventDefault(); setHi((h) => Math.min(h + 1, shown.length - 1)); }
    else if (e.key === "ArrowLeft" && columns > 1) { e.preventDefault(); setHi((h) => Math.max(h - 1, 0)); }
    else if (e.key === " " && multiple) { e.preventDefault(); if (shown[hi]) toggle(shown[hi].value); }
    else if (e.key === "Enter") { e.preventDefault(); if (multiple) onClose(true); else if (shown[hi]) toggle(shown[hi].value); }
  };
  return (
    <div ref={box} style={style} className="z-[70] overflow-hidden rounded-xl border border-line bg-surface shadow-[var(--shadow-pop)]" onKeyDown={key} role="dialog" aria-label={multiple ? "Choose any" : "Choose one"}>
      {options.length > 8 && columns === 1 && <input ref={search} className="input m-2 h-8 w-[calc(100%-1rem)] text-[13px]" placeholder="Search" value={q} onChange={(e) => { setQ(e.target.value); setHi(0); }} />}
      <div role="listbox" aria-multiselectable={multiple || undefined} tabIndex={options.length > 8 && columns === 1 ? -1 : 0} ref={listEl}
        className={`min-h-0 overflow-y-auto p-1.5 outline-none ${columns > 1 ? "grid gap-1" : ""}`} style={columns > 1 ? { gridTemplateColumns: `repeat(${columns}, minmax(0, 1fr))` } : undefined}>
        {shown.map((o, i) => {
          const on = sel.includes(o.value);
          return (
            <button key={o.value} type="button" role="option" aria-selected={on} onMouseEnter={() => setHi(i)} onClick={() => toggle(o.value)}
              className={columns > 1
                ? `h-8 rounded-lg border text-[12px] font-medium ${on ? "border-gold-line bg-gold text-on-gold" : "border-line-strong bg-surface text-muted hover:text-ink"} ${i === hi ? "ring-2 ring-focus/40" : ""}`
                : `flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-left text-[13px] ${i === hi ? "bg-hover" : ""} ${on ? "font-medium text-ink" : "text-muted"}`}>
              {columns === 1 && <span className="grid h-4 w-4 place-items-center">{on && <Check className="h-3.5 w-3.5 text-bronze" />}</span>}{o.label}
            </button>);
        })}
        {!shown.length && <div className="px-2.5 py-2 text-[13px] text-faint">No match</div>}
      </div>
      {multiple && <div className="flex items-center justify-between gap-2 border-t border-line px-2.5 py-2">
        <button type="button" className="text-[12px] text-muted hover:text-ink" onClick={() => setSel([])}>Clear</button>
        <button type="button" className="btn-primary btn-sm" onClick={() => onClose(true)}>Done</button>
      </div>}
    </div>
  );
}


/** Free text with suggestions (brand, product head...): Enter keeps what is typed, or the highlighted suggestion. */
export function ComboMenu({ anchor, options, value, onSave, onCancel, placeholder }: {
  anchor: React.RefObject<HTMLElement | null>; options: Opt[]; value: string; onSave: (v: string) => void; onCancel: () => void; placeholder?: string;
}) {
  const [text, setText] = useState(value);
  const [hi, setHi] = useState(-1);
  const box = useRef<HTMLDivElement>(null);
  const done = useRef(false);
  const input = useRef<HTMLInputElement>(null);
  const style = useFloating(true, anchor, 300);
  // The panel is placed (and made visible) just after it mounts; focus the box once it can take focus.
  useEffect(() => { const f = requestAnimationFrame(() => input.current?.focus()); return () => cancelAnimationFrame(f); }, []);
  const shown = useMemo(() => {
    const t = text.trim().toLowerCase();
    return (t ? options.filter((o) => o.label.toLowerCase().includes(t)) : options).slice(0, 50);
  }, [options, text]);
  const finish = (v: string | null) => { if (done.current) return; done.current = true; if (v === null) onCancel(); else onSave(v.trim()); };
  useEffect(() => {
    const away = (e: MouseEvent) => { if (!box.current?.contains(e.target as Node)) finish(text); };
    document.addEventListener("mousedown", away);
    return () => document.removeEventListener("mousedown", away);
  }); // re-bound each render so it saves the latest text
  const key = (e: React.KeyboardEvent) => {
    if (e.key === "Escape") { e.preventDefault(); finish(null); }
    else if (e.key === "ArrowDown") { e.preventDefault(); setHi((h) => Math.min(h + 1, shown.length - 1)); }
    else if (e.key === "ArrowUp") { e.preventDefault(); setHi((h) => Math.max(h - 1, -1)); }
    else if (e.key === "Enter" || e.key === "Tab") { e.preventDefault(); finish(hi >= 0 && shown[hi] ? shown[hi].value : text); }
  };
  const exact = options.some((o) => o.label.toLowerCase() === text.trim().toLowerCase());
  return (
    <div ref={box} style={style} className="z-[70] overflow-hidden rounded-xl border border-line bg-surface shadow-[var(--shadow-pop)]" onKeyDown={key} role="dialog" aria-label="Type or choose">
      <input ref={input} className="input m-2 h-8 w-[calc(100%-1rem)] text-[13px]" placeholder={placeholder ?? "Type or choose"} value={text}
        onFocus={(e) => { const n = e.target.value.length; if (n > 1) e.target.select(); else e.target.setSelectionRange(n, n); }} onChange={(e) => { setText(e.target.value); setHi(-1); }} />
      <div role="listbox" className="min-h-0 overflow-y-auto p-1.5 pt-0">
        {text.trim() && !exact && <button type="button" role="option" aria-selected={hi === -1} onMouseEnter={() => setHi(-1)} onClick={() => finish(text)}
          className={`flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-left text-[13px] ${hi === -1 ? "bg-hover" : ""} text-ink`}>
          <span className="grid h-4 w-4 place-items-center text-faint">+</span>Use “{text.trim()}”</button>}
        {shown.map((o, i) => {
          const on = o.value.toLowerCase() === value.toLowerCase();
          return (
            <button key={o.value} type="button" role="option" aria-selected={on} onMouseEnter={() => setHi(i)} onClick={() => finish(o.value)}
              className={`flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-left text-[13px] ${i === hi ? "bg-hover" : ""} ${on ? "font-medium text-ink" : "text-muted"}`}>
              <span className="grid h-4 w-4 place-items-center">{on && <Check className="h-3.5 w-3.5 text-bronze" />}</span>{o.label}
            </button>);
        })}
        {!shown.length && !text.trim() && <div className="px-2.5 py-2 text-[13px] text-faint">Nothing in use yet: type a value</div>}
      </div>
    </div>
  );
}
