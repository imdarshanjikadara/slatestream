import { useEffect, useId, useMemo, useRef, useState } from "react";
import { useFloating } from "./useFloating";

export type Option = { value: string; label: string };

// App-themed dropdown (replaces the OS/browser <select> popup). Works controlled (value/onChange)
// or inside plain forms (name + defaultValue -> hidden input). Search appears automatically for long lists.
export function Select({ name, value, defaultValue, onChange, options, placeholder = "Select", required, className = "", size = "md", ariaLabel, disabled }: {
  name?: string; value?: string; defaultValue?: string; onChange?: (v: string) => void; options: Option[]; placeholder?: string;
  required?: boolean; className?: string; size?: "sm" | "md"; ariaLabel?: string; disabled?: boolean;
}) {
  const [inner, setInner] = useState(defaultValue ?? "");
  const v = value !== undefined ? value : inner;
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const [hi, setHi] = useState(0);
  const root = useRef<HTMLDivElement>(null);
  const listId = useId();
  const trigger = useRef<HTMLButtonElement>(null);
  const float = useFloating(open, trigger, 320);
  const searchable = options.length > 8;
  const shown = useMemo(() => (q ? options.filter((o) => o.label.toLowerCase().includes(q.toLowerCase())) : options), [options, q]);
  const current = options.find((o) => o.value === v);

  useEffect(() => {
    if (!open) return;
    const close = (e: MouseEvent) => { if (!root.current?.contains(e.target as Node)) setOpen(false); };
    // Escape at document level: Safari does not focus buttons on click, so key events may not reach this element.
    const esc = (e: KeyboardEvent) => { if (e.key === "Escape") { e.stopPropagation(); setOpen(false); } };
    document.addEventListener("mousedown", close); document.addEventListener("keydown", esc, true);
    return () => { document.removeEventListener("mousedown", close); document.removeEventListener("keydown", esc, true); };
  }, [open]);
  useEffect(() => { if (open) { setHi(Math.max(0, shown.findIndex((o) => o.value === v))); } else setQ(""); }, [open]); // eslint-disable-line react-hooks/exhaustive-deps

  const pick = (o: Option) => { if (value === undefined) setInner(o.value); onChange?.(o.value); setOpen(false); };
  const key = (e: React.KeyboardEvent) => {
    if (e.key === "ArrowDown") { e.preventDefault(); if (!open) setOpen(true); else setHi((h) => Math.min(shown.length - 1, h + 1)); }
    else if (e.key === "ArrowUp") { e.preventDefault(); setHi((h) => Math.max(0, h - 1)); }
    else if (e.key === "Enter") { if (open && shown[hi]) { e.preventDefault(); pick(shown[hi]); } else if (!open) { e.preventDefault(); setOpen(true); } }
  };
  const h = size === "sm" ? "h-8 text-[13px]" : "h-9 text-[13.5px]";

  return (
    <div ref={root} className={`relative ${className}`} onKeyDown={key}>
      {name && <input type="hidden" name={name} value={v} />}
      {required && <input tabIndex={-1} aria-hidden className="pointer-events-none absolute inset-0 opacity-0" required value={v} onChange={() => {}} onFocus={() => setOpen(true)} />}
      <button ref={trigger} type="button" disabled={disabled} aria-haspopup="listbox" aria-expanded={open} aria-controls={listId} aria-label={ariaLabel}
        onClick={() => setOpen((o) => !o)}
        className={`flex w-full items-center justify-between gap-2 rounded-lg border bg-surface px-3 text-left outline-none transition ${h} ${open ? "border-focus shadow-[0_0_0_1px_var(--color-focus)]" : "border-line-strong hover:border-line-hover"} disabled:opacity-50`}>
        <span title={current?.label} className={`truncate ${current ? "text-ink" : "text-faint"}`}>{current?.label ?? placeholder}</span>
        <svg viewBox="0 0 20 20" className={`h-4 w-4 shrink-0 text-faint transition ${open ? "rotate-180" : ""}`} fill="none" stroke="currentColor" strokeWidth={1.8}><path d="M6 8l4 4 4-4" /></svg>
      </button>
      {open && (
        <div style={float} className="pop z-[120] overflow-hidden">
          {searchable && <div className="shrink-0 border-b border-line p-1.5"><input autoFocus value={q} onChange={(e) => { setQ(e.target.value); setHi(0); }} placeholder="Search" className="input h-8 text-[13px]" /></div>}
          <ul id={listId} role="listbox" className="min-h-0 flex-1 overflow-auto overscroll-contain py-1">
            {!required && v && <li><button type="button" className="w-full px-3 py-1.5 text-left text-[13px] text-faint hover:bg-surface-alt" onClick={() => pick({ value: "", label: "" })}>Clear</button></li>}
            {shown.map((o, i) => (
              <li key={o.value} role="option" aria-selected={o.value === v}>
                <button type="button" onMouseEnter={() => setHi(i)} onClick={() => pick(o)}
                  className={`flex w-full items-center justify-between px-3 py-1.5 text-left text-[13.5px] ${i === hi ? "bg-accent-soft text-ink" : "text-ink"} ${o.value === v ? "font-semibold" : ""}`}>
                  <span className="min-w-0 break-words">{o.label}</span>{o.value === v && <span className="shrink-0">✓</span>}
                </button>
              </li>))}
            {!shown.length && <li className="px-3 py-3 text-center text-[13px] text-faint">No matches</li>}
          </ul>
        </div>)}
    </div>
  );
}

/** The same control for several choices at once: tick as many as you like, and a row matching any ticked one is shown.
 *  Values are kept in the order of `options`, so the summary reads the same whatever order they were ticked in. */
export function MultiSelect({ value, onChange, options, placeholder = "Any", hint, className = "", size = "md", ariaLabel }: {
  value: string[]; onChange: (v: string[]) => void; options: Option[]; placeholder?: string; hint?: string;
  className?: string; size?: "sm" | "md"; ariaLabel?: string;
}) {
  const [open, setOpen] = useState(false);
  const root = useRef<HTMLDivElement>(null);
  const trigger = useRef<HTMLButtonElement>(null);
  const listId = useId();
  const float = useFloating(open, trigger, 340);
  useEffect(() => {
    if (!open) return;
    const close = (e: MouseEvent) => { if (!root.current?.contains(e.target as Node)) setOpen(false); };
    const esc = (e: KeyboardEvent) => { if (e.key === "Escape") { e.stopPropagation(); setOpen(false); trigger.current?.focus(); } };
    document.addEventListener("mousedown", close); document.addEventListener("keydown", esc, true);
    return () => { document.removeEventListener("mousedown", close); document.removeEventListener("keydown", esc, true); };
  }, [open]);
  const on = new Set(value);
  const picked = options.filter((o) => on.has(o.value));
  const toggle = (v: string) => { const next = on.has(v) ? value.filter((x) => x !== v) : [...value, v]; onChange(options.filter((o) => next.includes(o.value)).map((o) => o.value)); };
  const h = size === "sm" ? "h-8 text-[13px]" : "h-9 text-[13.5px]";
  const label = picked.length === 0 ? placeholder : picked.length === 1 ? picked[0].label : `${picked[0].label} +${picked.length - 1}`;

  return (
    <div ref={root} className={`relative ${className}`}>
      <button ref={trigger} type="button" aria-haspopup="listbox" aria-expanded={open} aria-controls={listId} aria-label={ariaLabel} onClick={() => setOpen((o) => !o)}
        className={`flex w-full items-center justify-between gap-2 rounded-lg border bg-surface px-3 text-left outline-none transition ${h} ${open ? "border-focus shadow-[0_0_0_1px_var(--color-focus)]" : "border-line-strong hover:border-line-hover"}`}>
        <span title={picked.map((o) => o.label).join(", ") || undefined} className={`truncate ${picked.length ? "text-ink" : "text-faint"}`}>{label}</span>
        <svg viewBox="0 0 20 20" className={`h-4 w-4 shrink-0 text-faint transition ${open ? "rotate-180" : ""}`} fill="none" stroke="currentColor" strokeWidth={1.8}><path d="M6 8l4 4 4-4" /></svg>
      </button>
      {open && (
        <div style={float} className="pop z-[120] overflow-hidden">
          {hint && <div className="shrink-0 border-b border-line px-3 py-2 text-[11.5px] text-faint">{hint}</div>}
          <ul id={listId} role="listbox" aria-multiselectable className="min-h-0 flex-1 overflow-auto overscroll-contain py-1">
            {options.map((o) => (
              <li key={o.value} role="option" aria-selected={on.has(o.value)}>
                <label className="flex w-full cursor-pointer items-center gap-2.5 px-3 py-1.5 text-[13.5px] text-ink hover:bg-surface-alt">
                  <input type="checkbox" checked={on.has(o.value)} onChange={() => toggle(o.value)} />
                  <span className="min-w-0 break-words">{o.label}</span>
                </label>
              </li>))}
          </ul>
          {picked.length > 0 && <div className="flex shrink-0 items-center justify-between gap-2 border-t border-line px-3 py-2">
            <span className="text-[12px] text-faint">{picked.length} chosen</span>
            <button type="button" className="btn-ghost btn-sm" onClick={() => onChange([])}>Clear</button>
          </div>}
        </div>)}
    </div>
  );
}
