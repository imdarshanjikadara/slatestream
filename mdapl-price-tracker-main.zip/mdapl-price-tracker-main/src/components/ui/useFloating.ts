import { useLayoutEffect, useState } from "react";

// Positions a floating panel against the viewport (position: fixed), so a scrolling dialog or a card with
// overflow hidden cannot clip it. Flips above the trigger when there is no room below; clamps to the screen.
export function useFloating(open: boolean, trigger: React.RefObject<HTMLElement | null>, panelH: number, panelW?: number) {
  const [style, setStyle] = useState<React.CSSProperties>({ position: "fixed", visibility: "hidden" });
  useLayoutEffect(() => {
    if (!open) return;
    const place = () => {
      const el = trigger.current; if (!el) return;
      const r = el.getBoundingClientRect();
      const w = Math.max(panelW ?? r.width, 192);
      const below = window.innerHeight - r.bottom - 12, above = r.top - 12;
      const up = below < Math.min(panelH, 220) && above > below;
      const left = Math.min(Math.max(8, r.left), window.innerWidth - w - 8);
      // Never taller than the space actually free on the chosen side: the list scrolls inside instead of running off-screen.
      const maxHeight = Math.max(120, Math.min(panelH, up ? above : below));
      setStyle({ position: "fixed", left, width: w, maxHeight, display: "flex", flexDirection: "column", ...(up ? { bottom: window.innerHeight - r.top + 4 } : { top: r.bottom + 4 }) });
    };
    place();
    window.addEventListener("scroll", place, true); window.addEventListener("resize", place);
    return () => { window.removeEventListener("scroll", place, true); window.removeEventListener("resize", place); };
  }, [open, trigger, panelH, panelW]);
  return style;
}
