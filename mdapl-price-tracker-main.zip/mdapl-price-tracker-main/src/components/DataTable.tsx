// Server-paged table (reference: DataTable.tsx). Fills its card; the `grow` column takes the spare width,
// so there is never a blank filler column. Rows come a page at a time (see Pagination).
import { useEffect, useRef, useState } from "react";
import { ChevronDown, ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight, Download, ExternalLink, Pencil, Printer } from "lucide-react";
import { dateLong, dateTime, inr, money, pct } from "@/lib/format";
import { downloadCsv, downloadXlsx, printRows, type ExportCol, type Kind } from "@/lib/exportTable";
import { PER_PAGE, fetchAll, type Pager } from "@/lib/api";
import { EmptyState, Spinner } from "./common";
import { toast } from "./overlays";
import { ChoiceMenu, ComboMenu } from "./ui/ChoiceMenu";
import { Select } from "./ui/Select";

export type Col<R = any> = ExportCol & {
  align?: "left" | "right" | "center";
  /** Takes the spare width of the table (one per table, usually the name). */
  grow?: boolean;
  render?: (r: R) => React.ReactNode;
  /** Edited in place, like a cell of the products sheet: click the cell (or the row's pencil). Text is typed in the cell,
   *  "select" opens the choice list, "combo" a type-ahead of `options`. The value edited is the raw field. */
  edit?: { type: "text" | "select" | "combo"; options?: { value: string; label: string }[]; required?: boolean; maxLength?: number };
  /** Not shown on screen, only exported. */
  exportOnly?: boolean;
  noExport?: boolean;
  className?: string;
};

const RIGHT = new Set<Kind | undefined>(["int", "num", "money", "pct"]);
export function cellText(kind: Kind | undefined, v: unknown): React.ReactNode {
  if (v === null || v === undefined || v === "") return <span className="text-faint">-</span>;
  switch (kind) {
    case "int": return inr(v);
    case "num": return inr(v, Number.isInteger(Number(v)) ? 0 : 2);
    case "money": return money(v);
    case "pct": return pct(v, Number.isInteger(Number(v)) ? 0 : 1);
    case "date": return dateLong(v);
    case "datetime": return dateTime(v);
    case "bool": return v ? "Yes" : <span className="text-faint">No</span>;
    case "mono": return <span className="font-mono text-[12px]">{String(v)}</span>;
    // A short "URL" link (the full address on hover), not the whole address in the table.
    case "link": return <a href={String(v)} target="_blank" rel="noopener noreferrer" title={String(v)} onClick={(e) => e.stopPropagation()}
      className="inline-flex items-center gap-1 font-medium text-info hover:underline">URL<ExternalLink className="h-3 w-3" /></a>;
    default: return String(v);
  }
}

export function DataTable<R extends Record<string, any>>({ cols, rows, total, rowKey, loading, fetching, pager, onRowClick, activeKey,
  selected, onSelect, empty, filtersActive, onClearFilters, maxHeight, embedded, footer, onSave, onEdit, editLabel }: {
  cols: Col<R>[]; rows: R[]; /** Unpaged lists: how many there are when only some are shown. */ total?: number; rowKey: keyof R & string; loading?: boolean; fetching?: boolean; /** Server paging (useList().pager). */ pager?: Pager;
  onRowClick?: (r: R) => void; activeKey?: string | number | null;
  selected?: Set<number>; onSelect?: (next: Set<number>) => void;
  empty?: { title?: string; hint?: React.ReactNode; action?: React.ReactNode }; filtersActive?: boolean; onClearFilters?: () => void;
  maxHeight?: string; embedded?: boolean; footer?: React.ReactNode;
  /** In-place editing: one cell at a time, saved as soon as it is left (return false to keep the old value). */
  onSave?: (r: R, changes: Record<string, string>) => Promise<unknown>;
  /** The pencil opens the record instead (no editable columns). */ onEdit?: (r: R) => void; editLabel?: string;
}) {
  // One cell edited at a time, as in the products sheet: Enter or leaving the cell saves, Esc cancels.
  const [cell, setCell] = useState<{ row: string; col: string } | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [flash, setFlash] = useState<string | null>(null);
  const anchor = useRef<HTMLElement | null>(null);
  const cancelled = useRef(false);
  const tableRef = useRef<HTMLTableElement>(null);
  const editable = !!onSave && cols.some((c) => c.edit);
  const rawOf = (c: Col<R>, r: R) => { const v = r[c.key]; return v === null || v === undefined ? "" : String(v); };
  const idOf = (r: R) => String(r[rowKey]);
  const open = (r: R, c: Col<R>, el: HTMLElement) => { if (busy) return; anchor.current = el; cancelled.current = false; setCell({ row: idOf(r), col: c.key }); };
  const commit = async (r: R, c: Col<R>, value: string) => {
    setCell(null);
    const tag = `${idOf(r)}:${c.key}`;
    const back = () => requestAnimationFrame(() => tableRef.current?.querySelector<HTMLElement>(`[data-cell="${CSS.escape(tag)}"]`)?.focus());
    if (value === rawOf(c, r)) { back(); return; }
    if (c.edit?.required && !value.trim()) { toast.error(`${c.label} cannot be empty.`); back(); return; }
    setBusy(tag);
    try {
      if ((await onSave!(r, { [c.key]: value })) !== false) { setFlash(tag); setTimeout(() => setFlash((f) => (f === tag ? null : f)), 1200); }
    } catch (e) { toast.error(`${c.label}: ${(e as Error).message}`); }
    finally { setBusy(null); back(); }
  };
  const editor = (r: R, c: Col<R>) => {
    const e = c.edit!, value = rawOf(c, r);
    const frame = <span className="pointer-events-none absolute inset-0 z-[5] border-2 border-focus" />;
    if (e.type === "select") {
      let picked = value;
      return <>{frame}<ChoiceMenu anchor={anchor} options={e.options ?? []} value={[value]} onPick={(v) => { picked = v[0]; }}
        onClose={(ok) => (ok ? void commit(r, c, picked) : setCell(null))} /></>;
    }
    if (e.type === "combo") return <>{frame}<ComboMenu anchor={anchor} options={e.options ?? []} value={value} onSave={(v) => void commit(r, c, v)} onCancel={() => setCell(null)} /></>;
    return (
      <input autoFocus aria-label={c.label} defaultValue={value} maxLength={e.maxLength} onFocus={(x) => x.target.select()}
        className="absolute inset-0 z-[5] h-full w-full rounded-none border-2 border-focus bg-surface px-3 text-[13px] text-ink outline-none first:pl-4"
        onBlur={(x) => { if (cancelled.current) { cancelled.current = false; return; } void commit(r, c, x.target.value); }}
        onKeyDown={(x) => {
          if (x.key === "Enter") { x.preventDefault(); (x.target as HTMLInputElement).blur(); }
          else if (x.key === "Escape") { x.preventDefault(); cancelled.current = true; setCell(null); }
        }} />);
  };
  const shown = cols.filter((c) => !c.exportOnly);
  const align = (c: Col<R>) => ({ left: "text-left", right: "text-right", center: "text-center" })[c.align ?? (RIGHT.has(c.kind) ? "right" : "left")];
  const keyOf = (r: R) => Number(r[rowKey]);
  const pageKeys = rows.map(keyOf);
  const allOn = !!selected && pageKeys.length > 0 && pageKeys.every((k) => selected.has(k));
  const someOn = !!selected && pageKeys.some((k) => selected.has(k));
  const head = useRef<HTMLInputElement>(null);
  useEffect(() => { if (head.current) head.current.indeterminate = someOn && !allOn; }, [someOn, allOn]);
  const actions = editable || !!onEdit;
  const span = shown.length + (onSelect ? 1 : 0) + (actions ? 1 : 0);

  return (
    <div className={embedded ? "" : "card overflow-hidden"}>
      <div className={`overflow-auto transition-opacity ${fetching && !loading ? "opacity-60" : ""}`} style={{ maxHeight }}>
        <table ref={tableRef} className="tbl w-full text-[13px]">
          <thead className={`${maxHeight ? "sticky top-0 z-10" : ""} bg-surface-alt`}>
            <tr className="border-b border-line">
              {onSelect && <th className="w-10 px-3 no-print"><input ref={head} type="checkbox" aria-label="Select all rows shown" checked={allOn}
                onChange={(e) => { const n = new Set(selected); pageKeys.forEach((k) => (e.target.checked ? n.add(k) : n.delete(k))); onSelect(n); }} /></th>}
              {shown.map((c) => <th key={c.key} className={`whitespace-nowrap px-3 py-2.5 text-[12px] font-medium text-faint first:pl-4 ${align(c)} ${c.grow ? "w-full" : ""}`}>{c.label}</th>)}
              {actions && <th className="no-print sticky right-0 w-px bg-surface-alt shadow-[inset_1px_0_0_var(--color-line)] px-3 py-2.5 text-right text-[12px] font-medium text-faint"><span className="sr-only">Edit</span></th>}
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {loading && !rows.length && <tr><td colSpan={span} className="py-12 text-center"><span className="inline-flex items-center gap-2 text-[13px] text-faint"><Spinner />Loading...</span></td></tr>}
            {rows.map((r) => {
              const k = keyOf(r);
              const isActive = activeKey !== undefined && activeKey !== null && String(activeKey) === String(r[rowKey]);
              const isEditing = cell?.row === idOf(r) || (!!busy && busy.startsWith(`${idOf(r)}:`));
              return (
                <tr key={idOf(r)} onClick={onRowClick && !isEditing ? () => onRowClick(r) : undefined} aria-selected={isActive || undefined}
                  className={`group transition-colors ${onRowClick && !isEditing ? "cursor-pointer" : ""} ${isEditing ? "bg-editing [&>td:first-child]:shadow-[inset_3px_0_0_var(--color-gold-line)]" : isActive || selected?.has(k) ? "bg-accent-soft" : "hover:bg-hover-row"}`}>
                  {onSelect && <td className="w-10 px-3 no-print" onClick={(e) => e.stopPropagation()}>
                    <input type="checkbox" aria-label={`Select row ${k}`} checked={!!selected?.has(k)} onChange={() => { const n = new Set(selected); n.has(k) ? n.delete(k) : n.add(k); onSelect(n); }} /></td>}
                  {shown.map((c) => {
                    const canEdit = editable && !!c.edit, tag = `${idOf(r)}:${c.key}`;
                    const on = cell?.row === idOf(r) && cell.col === c.key;
                    return (
                      <td key={c.key} data-cell={canEdit ? tag : undefined} tabIndex={canEdit ? 0 : undefined} title={canEdit && !on ? `Click to edit ${c.label.toLowerCase()}` : undefined}
                        onClick={canEdit ? (e) => { e.stopPropagation(); if (!on) open(r, c, e.currentTarget); } : undefined}
                        onKeyDown={canEdit && !on ? (e) => { if (e.key === "Enter" || e.key === "F2") { e.preventDefault(); open(r, c, e.currentTarget); } } : undefined}
                        className={`relative h-10 px-3 py-1.5 outline-none first:pl-4 ${c.grow ? "min-w-[11rem]" : "whitespace-nowrap"} ${align(c)} ${c.className ?? ""}
                          ${canEdit ? "cursor-cell focus-visible:shadow-[inset_0_0_0_2px_var(--color-focus)]" : ""} ${flash === tag ? "!bg-success-soft transition-colors" : ""}`}>
                        <span className="flex items-center gap-1.5">
                          <span className="min-w-0 flex-1">{c.render ? c.render(r) : cellText(c.kind, c.value ? c.value(r) : r[c.key])}</span>
                          {busy === tag && <Spinner className="h-3.5 w-3.5 shrink-0" />}
                        </span>
                        {on && editor(r, c)}
                      </td>);
                  })}
                  {actions && <td className={`no-print sticky right-0 px-2 py-1 text-right shadow-[inset_1px_0_0_var(--color-line)] ${isEditing ? "bg-editing" : "bg-surface group-hover:bg-hover-row"}`} onClick={(e) => e.stopPropagation()}>
                    <button type="button" className="btn-icon h-7 w-7 text-muted" aria-label={editLabel ?? "Edit"} title={editLabel ?? (editable ? "Edit this row (or click a cell)" : "Open to edit")}
                      onClick={(e) => {
                        if (!editable) { onEdit?.(r); return; }
                        // The pencil starts on the row's first editable cell, like clicking it.
                        const first = shown.find((c) => c.edit);
                        const td = e.currentTarget.closest("tr")?.querySelector<HTMLElement>(`[data-cell="${CSS.escape(`${idOf(r)}:${first!.key}`)}"]`);
                        if (first && td) open(r, first, td);
                      }}><Pencil className="h-3.5 w-3.5" /></button>
                  </td>}
                </tr>);
            })}
            {!loading && !rows.length && <tr><td colSpan={span} className="p-0">
              {filtersActive ? <EmptyState title="Nothing matches these filters" hint="Records exist, but the filters or search hide them." action={onClearFilters && <button className="btn btn-sm" onClick={onClearFilters}>Clear filters</button>} />
                : <EmptyState title={empty?.title ?? "Nothing here yet"} hint={empty?.hint} action={empty?.action} />}
            </td></tr>}
          </tbody>
        </table>
      </div>
      <Pagination pager={pager} shown={rows.length} total={total} extra={footer} />
    </div>
  );
}

/** Footer of a paged list: "Rows 1 to 25 of 748", the page size, and first / previous / "Page 1 of 30" / next / last. */
export function Pagination({ pager, shown = 0, total: all, extra, compact, className = "" }: { pager?: Pager; /** Rows on screen (and how many there are), for an unpaged list. */ shown?: number; total?: number;
  extra?: React.ReactNode; /** Narrow lists (split views): the controls take their own line. */ compact?: boolean; className?: string }) {
  // Unpaged lists use the same words and layout, without the page controls.
  const b = (n: number) => <b className="font-semibold text-ink">{inr(n)}</b>;
  if (!pager) return shown || extra ? <div className={`no-print flex flex-wrap items-center gap-x-4 gap-y-2 border-t border-line px-4 py-2.5 text-[12.5px] text-muted ${className}`}>
    {shown ? <span className="tabular-nums">Rows {b(1)} to {b(shown)} of {b(all !== undefined && all > shown ? all : shown)}</span> : null}{extra}</div> : null;
  const { page, per, total, pageCount, setPage, setPer, loading } = pager;
  if (!total && !extra) return null;
  const first = total ? (page - 1) * per + 1 : 0, last = Math.min(page * per, total);
  const go = (p: number) => setPage(Math.min(Math.max(p, 1), pageCount));
  const Nav = ({ to, label, icon: Icon, off }: { to: number; label: string; icon: typeof ChevronLeft; off: boolean }) => (
    <button type="button" className="btn-icon border border-line-strong bg-surface text-muted" aria-label={label} title={label} disabled={off} onClick={() => go(to)}><Icon className="h-4 w-4" /></button>
  );
  return (
    <nav aria-label="Pages" className={`no-print flex flex-wrap items-center gap-x-4 gap-y-2 border-t border-line px-4 py-2.5 text-[12.5px] text-muted ${className}`}>
      <span className="mr-auto flex items-center gap-2 tabular-nums" aria-live="polite">
        <span>Rows <b className="font-semibold text-ink">{inr(first)}</b> to <b className="font-semibold text-ink">{inr(last)}</b> of <b className="font-semibold text-ink">{inr(total)}</b></span>
        {loading && <Spinner className="h-3.5 w-3.5" />}
      </span>
      {extra}
      <div className="flex items-center gap-2 whitespace-nowrap">Per page
        <Select size="sm" className="w-[4.75rem]" ariaLabel="Rows per page" required value={String(per)} onChange={(v) => setPer(Number(v))} options={PER_PAGE.map((n) => ({ value: String(n), label: String(n) }))} />
      </div>
      {/* Phones and split views: the page buttons take their own line, spread across it. */}
      <div className={`flex items-center gap-1.5 ${compact ? "w-full justify-between" : "w-full justify-between sm:w-auto sm:justify-start"}`}>
        <span className="flex gap-1.5">
          <Nav to={1} label="First page" icon={ChevronsLeft} off={page <= 1} />
          <Nav to={page - 1} label="Previous page" icon={ChevronLeft} off={page <= 1} />
        </span>
        <span className="px-1.5 whitespace-nowrap tabular-nums">Page <b className="font-semibold text-ink">{inr(page)}</b> of <b className="font-semibold text-ink">{inr(pageCount)}</b></span>
        <span className="flex gap-1.5">
          <Nav to={page + 1} label="Next page" icon={ChevronRight} off={page >= pageCount} />
          <Nav to={pageCount} label="Last page" icon={ChevronsRight} off={page >= pageCount} />
        </span>
      </div>
    </nav>
  );
}

/** Export menu: fetches every row matching the current filters (or only the ticked rows, when some are ticked),
 *  then Excel (formatted, totals), PDF, CSV or Print. */
export function ExportMenu({ endpoint, params, cols, title, sheet, file, note, rowsOf, selected, rowKey, what }: {
  endpoint: string; params: Record<string, any>; cols: Col[]; title: string; sheet?: string; file?: string; note?: string;
  /** What the menu says it exports, when "every row matching the filters" is not it. */ what?: string;
  /** Pick the rows out of a non-list response. */ rowsOf?: (data: any) => any[];
  /** Ticked rows (ids in `rowKey`): when any are ticked, only those are exported. */ selected?: Set<number>; rowKey?: string;
}) {
  const picked = selected && selected.size > 0 && rowKey ? selected : null;
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const close = (e: MouseEvent | KeyboardEvent) => { if (e instanceof KeyboardEvent ? e.key === "Escape" : !ref.current?.contains(e.target as Node)) setOpen(false); };
    document.addEventListener("mousedown", close); document.addEventListener("keydown", close);
    return () => { document.removeEventListener("mousedown", close); document.removeEventListener("keydown", close); };
  }, [open]);
  const exportCols = cols.filter((c) => !c.noExport);
  const run = (kind: "xlsx" | "pdf" | "csv" | "print") => async () => {
    setOpen(false); setBusy(true);
    try {
      // A selection goes to the server as only=ids (short enough for a web address up to 1,500 ids); a bigger one is cut
      // out of the filtered rows here.
      const small = picked && picked.size <= 1500;
      const data = await fetchAll(endpoint, small ? { ...params, only: [...picked].join(",") } : params);
      let rows: any[] = rowsOf ? rowsOf(data) : data.rows;
      if (picked && !small) rows = rows.filter((r) => picked.has(Number(r[rowKey!])));
      const input = { title, cols: exportCols, rows, sheet, file, note: picked ? `${inr(rows.length)} selected ${rows.length === 1 ? "row" : "rows"}${note ? `. ${note}` : ""}` : note };
      if (kind === "xlsx") await downloadXlsx(input);
      else if (kind === "pdf") await (await import("@/lib/exportPdf")).downloadPdf(input);
      else if (kind === "csv") downloadCsv(input); else printRows(input);
    } catch (e) {
      toast.error((e as Error).message || "The export failed. Try again.");
    } finally { setBusy(false); }
  };
  return (
    <div ref={ref} className="relative">
      <button type="button" className="btn btn-sm" onClick={() => setOpen((o) => !o)} aria-haspopup="menu" aria-expanded={open} disabled={busy}>
        {busy ? <Spinner className="h-3.5 w-3.5" /> : <Download className="h-4 w-4" />}<span>{busy ? "Preparing" : picked ? `Export ${inr(picked.size)} selected` : "Export"}</span><ChevronDown className="h-3.5 w-3.5 text-faint" />
      </button>
      {open && (
        <div role="menu" className="pop absolute right-0 z-30 mt-1 w-60 overflow-hidden py-1">
          <div className="border-b border-line px-3 pb-2 pt-1 text-[11.5px] text-faint">{picked ? `Only the ${inr(picked.size)} ticked ${picked.size === 1 ? "row" : "rows"}. Clear the ticks to export every row matching the filters.` : what ?? "Every row matching the filters."}</div>
          <MenuItem onClick={run("xlsx")} title="Excel workbook (.xlsx)" sub="Formatted, with totals" />
          <MenuItem onClick={run("pdf")} title="PDF (.pdf)" sub="A4 landscape, ready to share or print" />
          <MenuItem onClick={run("csv")} title="CSV (.csv)" sub="Plain values, opens anywhere" />
          <MenuItem onClick={run("print")} title={<span className="inline-flex items-center gap-1.5"><Printer className="h-3.5 w-3.5" />Print</span>} sub="A4 page of every matching row" />
        </div>)}
    </div>
  );
}
const MenuItem = ({ onClick, title, sub }: { onClick: () => void; title: React.ReactNode; sub: string }) => (
  <button type="button" role="menuitem" className="flex w-full flex-col items-start px-3 py-2 text-left hover:bg-hover" onClick={onClick}>
    <span className="text-[13.5px] font-medium text-ink">{title}</span><span className="text-[12px] text-faint">{sub}</span>
  </button>
);
