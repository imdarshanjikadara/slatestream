// "New version available": after a deploy, open tabs still run the old code. Every 2 minutes, and whenever the tab
// comes back into view, /version.json is checked against the version this page was built as; when they differ, a card
// offers to reload. A page chunk that no longer exists on the server (vite:preloadError) means the same thing.
import { useEffect, useState } from "react";
import { RefreshCw, X } from "lucide-react";

declare const __APP_VERSION__: string;
const EVERY_MS = 120_000;

export function UpdatePrompt() {
  const [stale, setStale] = useState(false);
  const [later, setLater] = useState(false);
  useEffect(() => {
    if (!import.meta.env.PROD) return;
    let last = 0;
    const check = async () => {
      if (document.visibilityState !== "visible" || Date.now() - last < 30_000) return;
      last = Date.now();
      try {
        const r = await fetch(`/version.json?t=${Date.now()}`, { cache: "no-store" });
        const v = r.ok ? (await r.json()).version : null;
        if (v && v !== __APP_VERSION__) setStale(true);
      } catch { /* offline: try again later */ }
    };
    const onChunk = () => setStale(true);
    const t = setInterval(check, EVERY_MS);
    document.addEventListener("visibilitychange", check);
    window.addEventListener("focus", check);
    window.addEventListener("vite:preloadError", onChunk);
    void check();
    return () => { clearInterval(t); document.removeEventListener("visibilitychange", check); window.removeEventListener("focus", check); window.removeEventListener("vite:preloadError", onChunk); };
  }, []);
  // "Later" hides the card for 30 minutes.
  useEffect(() => { if (!later) return; const t = setTimeout(() => setLater(false), 30 * 60_000); return () => clearTimeout(t); }, [later]);
  if (!stale || later) return null;
  return (
    <div role="alert" className="no-print fixed inset-x-4 bottom-4 z-50 sm:left-auto sm:right-6 sm:bottom-6 sm:w-[22rem]">
      <div className="pop flex items-start gap-3 p-4">
        <span className="mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-full bg-gold text-on-gold"><RefreshCw className="h-4 w-4" /></span>
        <div className="min-w-0 flex-1">
          <div className="text-[14px] font-semibold text-ink">New version available</div>
          <p className="mt-0.5 text-[12.5px] text-muted">The app was updated. Reload to get the latest changes; anything not saved on this page is lost.</p>
          <div className="mt-3 flex gap-2">
            <button className="btn-primary btn-sm" onClick={() => window.location.reload()}><RefreshCw className="h-3.5 w-3.5" />Reload now</button>
            <button className="btn-ghost btn-sm" onClick={() => setLater(true)}>Later</button>
          </div>
        </div>
        <button className="btn-icon -mr-1 -mt-1" aria-label="Close" onClick={() => setLater(true)}><X className="h-4 w-4" /></button>
      </div>
    </div>
  );
}
