// Split view for the working pages: the filtered list on the left, the full record on the right, the record id in the URL.
// On phones the list and the record take turns (Back returns to the list).
import { ArrowLeft } from "lucide-react";
import { EmptyState, Spinner } from "./common";
import { Pagination } from "./DataTable";
import type { Pager } from "@/lib/api";

export function SplitView({ list, detail, selected, onBack }: { list: React.ReactNode; detail: React.ReactNode; selected: boolean; onBack: () => void }) {
  // Wide screens: both sides are one fixed height (the screen's) and stay in view while the page scrolls; each side
  // scrolls inside itself, so the list and the record line up with no gaps under the shorter one.
  return (
    <div className="grid gap-4 lg:sticky lg:top-4 lg:h-[calc(100dvh-2rem)] lg:min-h-[32rem] lg:grid-cols-[minmax(20rem,26rem)_minmax(0,1fr)]">
      <div className={`min-h-0 ${selected ? "hidden lg:block" : ""}`}>{list}</div>
      <div className={`scroll-pane min-h-0 lg:-mr-2 lg:overflow-y-auto lg:pr-2 ${selected ? "" : "hidden lg:block"}`}>
        {selected && <button className="btn-ghost -ml-2 mb-2 lg:hidden" onClick={onBack}><ArrowLeft className="h-4 w-4" />Back to the list</button>}
        {detail}
      </div>
    </div>
  );
}

/** One row of a split-view list, the same on every page: title and its key value on the first line, details and the
 *  date or count on the second (never wrapping onto a third), then anything extra. */
export function SplitItem({ title, right, meta, metaRight, children }: { title: React.ReactNode; right?: React.ReactNode; meta?: React.ReactNode; metaRight?: React.ReactNode; children?: React.ReactNode }) {
  return (
    <div className="min-w-0">
      <div className="flex items-start gap-2">
        <span className="line-clamp-2 min-w-0 flex-1 text-[13.5px] font-medium leading-snug text-ink">{title}</span>
        {right && <span className="shrink-0">{right}</span>}
      </div>
      {(meta || metaRight) && (
        <div className="mt-1 flex items-center gap-2 text-[12px] text-faint">
          <span className="flex min-w-0 flex-1 items-center gap-1.5 overflow-hidden whitespace-nowrap">{meta}</span>
          {metaRight && <span className="shrink-0 whitespace-nowrap tabular-nums">{metaRight}</span>}
        </div>)}
      {children}
    </div>
  );
}

/** The left list: a card of compact rows that fills its side and scrolls inside on wide screens. */
export function SplitList<R>({ title, count, rows, rowKey, activeId, onPick, render, loading, fetching, pager, empty, actions }: {
  title: React.ReactNode; count?: React.ReactNode; rows: R[]; rowKey: (r: R) => string | number; activeId?: string | null; onPick: (r: R) => void;
  render: (r: R) => React.ReactNode; loading?: boolean; fetching?: boolean; pager?: Pager;
  empty: React.ReactNode; actions?: React.ReactNode;
}) {
  return (
    <section className="card flex flex-col overflow-hidden lg:h-full">
      <div className="card-head"><h2 className="card-title">{title}</h2>{count !== undefined && <span className="count">{count}</span>}{fetching && <Spinner className="h-3.5 w-3.5" />}{actions && <div className="ml-auto flex items-center gap-2">{actions}</div>}</div>
      <div className={`scroll-pane min-h-0 flex-1 overflow-y-auto transition-opacity ${fetching && !loading ? "opacity-60" : ""}`}>
        {loading && !rows.length ? <div className="flex items-center justify-center gap-2 py-12 text-[13px] text-faint"><Spinner />Loading...</div>
          : !rows.length ? empty
          : <ul className="divide-y divide-line" role="listbox" aria-label={typeof title === "string" ? title : "Records"}>
            {rows.map((r) => {
              const k = String(rowKey(r)), on = activeId === k;
              return (
                <li key={k} role="option" aria-selected={on}>
                  <button type="button" onClick={() => onPick(r)} className={`block w-full px-4 py-3 text-left transition-colors ${on ? "bg-accent-soft" : "hover:bg-surface-alt"}`}>{render(r)}</button>
                </li>);
            })}
          </ul>}
      </div>
      <Pagination pager={pager} shown={rows.length} compact />
    </section>
  );
}

export const NothingSelected = ({ what }: { what: string }) => (
  <div className="card"><EmptyState title={`Select ${what}`} hint="Pick one from the list to see every detail here." /></div>
);
