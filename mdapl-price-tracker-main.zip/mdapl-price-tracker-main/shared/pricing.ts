// Pricing columns that are calculated, never typed. The formulas match every row of the product master
// (the database values in Products_Append), used by the server on every save and by the form for a live preview.
export const PRICING_INPUTS = ["dealer_landing", "dp_margin_percent", "scheme_1", "scheme_2", "scheme_3", "retail_margin_percent", "trigger_price_percent"] as const;
export const DERIVED = ["mop", "total_scheme", "net_landing", "retail_margin", "mop_scheme", "trigger_price"] as const;
export type Derived = Record<(typeof DERIVED)[number], number>;

const n = (v: unknown) => { const x = Number(v); return Number.isFinite(x) ? x : 0; };
const r2 = (v: number) => Math.round(v * 100) / 100;

export function computePricing(p: Record<string, unknown>): Derived {
  const dl = n(p.dealer_landing);
  const total_scheme = n(p.scheme_1) + n(p.scheme_2) + n(p.scheme_3);
  const net_landing = dl - total_scheme;
  const retail_margin = (net_landing * n(p.retail_margin_percent)) / 100;
  const mop_scheme = net_landing + retail_margin;
  return {
    mop: r2((dl * (100 + n(p.dp_margin_percent))) / 100),                     // dealer landing × (100 + DP margin %)
    total_scheme: r2(total_scheme),                                            // scheme 1 + 2 + 3
    net_landing: r2(net_landing),                                              // dealer landing − total scheme
    retail_margin: r2(retail_margin),                                          // net landing × retail margin %
    mop_scheme: r2(mop_scheme),                                                // net landing + retail margin
    trigger_price: r2((mop_scheme * (100 - n(p.trigger_price_percent))) / 100), // MOP scheme × (100 − trigger %)
  };
}

/** The price a channel must not go below before it counts as a MOP breach: the trigger price (MOP scheme less the trigger %),
 *  else the MOP scheme, else the MOP. 0 when none is set (then nothing is flagged). Same rule as ALERT_PRICE in server/sql.ts. */
export const alertPrice = (p: Record<string, unknown>) => [p.trigger_price, p.mop_scheme, p.mop].map(Number).find((x) => Number.isFinite(x) && x > 0) ?? 0;
export const isBreach = (price: unknown, p: Record<string, unknown>) => { const a = alertPrice(p), x = Number(price); return a > 0 && x > 0 && x < a; };

export const DERIVED_HELP: Record<(typeof DERIVED)[number], string> = {
  mop: "Dealer landing × (100 + DP margin %)",
  total_scheme: "Scheme 1 + Scheme 2 + Scheme 3",
  net_landing: "Dealer landing − Total scheme",
  retail_margin: "Net landing × Retail margin %",
  mop_scheme: "Net landing + Retail margin",
  trigger_price: "MOP scheme × (100 − Trigger price %)",
};
