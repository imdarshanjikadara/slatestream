// How long scraping takes: links are scraped `concurrency` at a time, each page taking about `pageSec` seconds
// (measured, retries included). Used by the server when a run is created and by the run page while it goes.
export function scrapeSeconds(links: number, pageSec: number, concurrency: number) {
  if (!(links > 0) || !(pageSec > 0)) return 0;
  return Math.ceil(links / Math.max(1, concurrency)) * pageSec;
}
