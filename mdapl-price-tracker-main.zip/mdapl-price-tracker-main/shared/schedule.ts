// When a product is due for the daily scheduled scrape. Used by the scheduler and shown on the product and scraping pages.
// * Regular scraping: every day.
// * Scheduled scraping: in the chosen months (none chosen = every month), on the chosen weekdays (1 = Mon .. 7 = Sun)
//   or dates (a date past the month's end, like 30 or 31, falls on its last day). No days and no dates = every day of those months.
// * Neither: never in the scheduled run; it can still be scraped on demand or in a manual full run.
export type Schedule = {
  regular_scraping?: boolean | null; scheduled_scraping?: boolean | null;
  scraping_schedule_weekly?: string | null; months_to_scrape?: string | null; scraping_schedule_monthly?: string | null;
  scrape_time?: string | null;
};

/** The time of day (India time, "HH:MM") the daily automatic run picks the product up. Not set = 6:00 AM, as it always was. */
export const DEFAULT_TIME = "06:00";
export const timeOf = (p: Schedule) => (p.scrape_time && /^\d{2}:\d{2}$/.test(p.scrape_time) ? p.scrape_time : DEFAULT_TIME);
/** Minutes since midnight India time. */
export function istMinutes(at = new Date()) { const d = new Date(at.getTime() + 330 * 60_000); return d.getUTCHours() * 60 + d.getUTCMinutes(); }
export const hhmm = (min: number) => `${String(Math.floor(min / 60)).padStart(2, "0")}:${String(min % 60).padStart(2, "0")}`;

/** The next automatic scrape, date and time: today if it is due today and its time has not passed, else the next due day. */
export function nextRun(p: Schedule, from = new Date()) {
  const t = timeOf(p), [h, m] = t.split(":").map(Number);
  const today = istDate(from);
  if (isDue(p, today) && h * 60 + m > istMinutes(from)) return { ...today, time: t };
  const n = nextDue(p, new Date(from.getTime() + 86_400_000));
  return n ? { ...n, time: t } : null;
}

export const list = (v: unknown) =>
  String(v ?? "").split(/[,\s]+/).map((x) => Math.trunc(Number(x))).filter((n) => Number.isInteger(n) && n > 0);

/** The calendar date in India (the business runs on IST), as y/m/d. */
export function istDate(at = new Date()) {
  const d = new Date(at.getTime() + 330 * 60_000);
  return { y: d.getUTCFullYear(), m: d.getUTCMonth() + 1, d: d.getUTCDate(), dow: ((d.getUTCDay() + 6) % 7) + 1 };
}

export function isDue(p: Schedule, day = istDate()) {
  if (p.regular_scraping) return true;
  if (!p.scheduled_scraping) return false;
  const months = list(p.months_to_scrape), days = list(p.scraping_schedule_weekly), dates = list(p.scraping_schedule_monthly);
  if (months.length && !months.includes(day.m)) return false;
  if (!days.length && !dates.length) return true;
  if (days.includes(day.dow)) return true;
  const last = new Date(Date.UTC(day.y, day.m, 0)).getUTCDate();
  return dates.some((n) => n === day.d || (n > last && day.d === last));
}

/** The next IST date (today included) the product is due, within a year; null when it never is. */
export function nextDue(p: Schedule, from = new Date()) {
  for (let i = 0; i < 366; i++) {
    const at = new Date(from.getTime() + i * 86_400_000);
    const day = istDate(at);
    if (isDue(p, day)) return day;
  }
  return null;
}
