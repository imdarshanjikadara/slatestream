// The only Vercel function: every /api/* path is rewritten here (vercel.json) and routed in server/router.ts.
// Sentry is imported first so it starts when the module loads (no --import instrument file on Vercel functions).
import { flushSentry } from "../server/sentry.js";
import type { IncomingMessage, ServerResponse } from "node:http";
import { handle } from "../server/router.js";

export const config = { maxDuration: 300 };

export default async function handler(req: IncomingMessage, res: ServerResponse) {
  // The rewrite keeps the original path in the URL; older runtimes pass it as ?path=.
  try {
    await handle(req, res);
  } finally {
    // The response has already been sent; this only keeps the function alive until reported errors are delivered.
    await flushSentry();
  }
}
