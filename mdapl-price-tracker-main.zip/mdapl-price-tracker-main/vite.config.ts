import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import { sentryVitePlugin } from "@sentry/vite-plugin";
import { fileURLToPath } from "node:url";

// Source maps go to Sentry (project mdapl-web) only when SENTRY_AUTH_TOKEN is set in the Vercel build; they are deleted
// from the output after upload, so they are never served.
const uploadMaps = !!process.env.SENTRY_AUTH_TOKEN;
const release = process.env.VERCEL_GIT_COMMIT_SHA ?? "";
// This build's version, also written to /version.json: an open tab compares the two and offers to reload when they differ.
const version = release || `build-${Date.now()}`;
const versionFile = { name: "version-file", apply: "build" as const,
  generateBundle(this: any) { this.emitFile({ type: "asset", fileName: "version.json", source: JSON.stringify({ version }) }); } };

export default defineConfig({
  plugins: [react(), tailwindcss(), versionFile,
    ...(uploadMaps ? [sentryVitePlugin({ org: "smallbay-digital", project: "mdapl-web", authToken: process.env.SENTRY_AUTH_TOKEN, telemetry: false,
      release: release ? { name: release } : undefined, sourcemaps: { filesToDeleteAfterUpload: ["dist/**/*.map"] } })] : [])],
  define: { __SENTRY_RELEASE__: JSON.stringify(release), __APP_VERSION__: JSON.stringify(version) },
  resolve: { alias: { "@": fileURLToPath(new URL("./src", import.meta.url)) } },
  server: { port: 5173, proxy: { "/api": { target: "http://localhost:3001", xfwd: true } } },
  build: {
    sourcemap: uploadMaps ? "hidden" : false,
    chunkSizeWarningLimit: 1200,
    rollupOptions: { output: { manualChunks: { react: ["react", "react-dom", "react-router-dom"], query: ["@tanstack/react-query"] } } },
  },
});
