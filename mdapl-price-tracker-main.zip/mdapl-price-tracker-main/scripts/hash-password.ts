// Prints one APP_USERS entry with a scrypt hash. The password is read from the terminal without echo.
// Usage: npm run hash-password -- someone@mdapl.in "Full Name" [admin|staff]
import { createInterface } from "node:readline";
import { hashPassword } from "../server/auth.js";

const [email, name, role = "admin"] = process.argv.slice(2);
if (!email || !name) {
  console.error('Usage: npm run hash-password -- someone@mdapl.in "Full Name" [admin|staff]');
  process.exit(1);
}

function ask(q: string): Promise<string> {
  return new Promise((resolve) => {
    const rl = createInterface({ input: process.stdin, output: process.stdout, terminal: true });
    const out = rl as unknown as { _writeToOutput: (s: string) => void; output: NodeJS.WriteStream };
    let muted = false;
    out._writeToOutput = (s: string) => { if (!muted) out.output.write(s); };
    rl.question(q, (a) => { rl.close(); process.stdout.write("\n"); resolve(a); });
    muted = true;
  });
}

const pw = process.env.PASSWORD ?? (await ask("Password (min 10 characters): "));
if (pw.length < 10) { console.error("Use at least 10 characters."); process.exit(1); }
const entry = { email: email.toLowerCase(), name, role: role === "staff" ? "staff" : "admin", hash: hashPassword(pw) };
console.log("\nAdd this object to the APP_USERS JSON array in Vercel:\n");
console.log(JSON.stringify(entry));
