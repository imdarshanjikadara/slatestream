// End-to-end check of accounts against the demo API on a fresh database: user menu, Team & access, temporary and own
// passwords, sessions ending on reset / switch-off, the scraper connection test, and no password hashes in the audit log.
// Run with the dev servers up: node scripts/verify-team.mjs
import { createRequire } from "node:module";
const { chromium } = createRequire(import.meta.url)("playwright");
const B = "http://localhost:5173";
const b = await chromium.launch();
const ok = (c, m) => { console.log(c ? "ok  " : "FAIL", m); if (!c) process.exitCode = 1; };
const errs = [];
const login = async (p, email, pw) => { await p.goto(`${B}/#/login`); await p.fill("#email", email); await p.fill("#password", pw); await p.click("button:has-text('Sign in')"); };

// Admin: menu, add a person, scraper test
const ac = await b.newContext({ viewport: { width: 1440, height: 900 } }); const a = await ac.newPage(); a.on("pageerror", (e) => errs.push(e.message));
await login(a, "demo@mdapl.local", "demo1234"); await a.waitForSelector("main#main");
await a.getByRole("button", { name: /Demo User/ }).click();
await a.getByRole("menu").waitFor(); await a.screenshot({ path: "scripts/.out/um-menu.png", clip: { x: 0, y: 500, width: 480, height: 400 } });
ok(await a.getByRole("menuitem", { name: "Team & access" }).isVisible() && await a.getByRole("menuitem", { name: "Scraper connection" }).isVisible(), "admin menu has Team & access and Scraper connection");
await a.keyboard.press("Escape"); ok(!(await a.getByRole("menu").isVisible().catch(() => false)), "Escape closes the menu");
await a.getByRole("button", { name: /Demo User/ }).click(); await a.getByRole("menuitem", { name: "Scraper connection" }).click();
await a.getByRole("button", { name: "Test connection" }).click(); await a.getByText("Connected").first().waitFor({ timeout: 15000 });
await a.screenshot({ path: "scripts/.out/um-scraper.png" }); ok(true, "scraper test answers (demo: simulated)");
await a.getByRole("button", { name: "Close", exact: true }).first().click();
await a.goto(`${B}/#/team`); await a.getByRole("button", { name: "Add a person" }).click();
await a.fill("#p-name", "Pranav Kumar"); await a.fill("#p-email", "pranav@mdapl.in");
await a.getByRole("button", { name: "Add and create password" }).click();
const temp = (await a.getByTestId("temp-password").innerText()).trim(); ok(temp.length === 14, "temporary password shown once (14 chars)");
await a.screenshot({ path: "scripts/.out/um-temp.png" });
await a.getByRole("button", { name: "Done" }).click(); await a.waitForTimeout(400);
await a.screenshot({ path: "scripts/.out/um-team.png" });

// New person: forced to set a password, API refuses other calls until then
const sc = await b.newContext({ viewport: { width: 1280, height: 800 } }); const s = await sc.newPage(); s.on("pageerror", (e) => errs.push(e.message));
await login(s, "pranav@mdapl.in", temp); await s.getByText("Choose your own password").waitFor();
const blocked = await s.evaluate(async () => (await fetch("/api/products")).status); ok(blocked === 403, `API blocked before own password (${blocked})`);
await s.screenshot({ path: "scripts/.out/um-setpw.png" });
await s.fill("#set-own-password-current", temp); await s.fill("#set-own-password-next", "pranav-own-pass-1"); await s.fill("#set-own-password-again", "pranav-own-pass-1");
await s.getByRole("button", { name: "Set password and continue" }).click(); await s.waitForSelector("main#main", { timeout: 15000 });
ok(true, "own password set, app opens");
ok(!(await s.getByRole("link", { name: "Audit log" }).isVisible().catch(() => false)), "staff sees no Audit log");
await s.goto(`${B}/#/team`); await s.getByRole("heading", { name: "Team & access" }).waitFor(); await s.waitForTimeout(600);
ok(!(await s.getByRole("button", { name: "Add a person" }).isVisible().catch(() => false)) && !(await s.getByRole("button", { name: /^Actions for/ }).count()), "staff sees the team read-only: no add, switch off or set password");
await s.getByRole("button", { name: /Pranav Kumar/ }).click(); ok(!(await s.getByRole("menuitem", { name: "Team & access" }).isVisible().catch(() => false)), "staff menu has no admin items");
await s.getByRole("menuitem", { name: "Change password" }).click();
await s.fill("#change-password-current", "pranav-own-pass-1"); await s.fill("#change-password-next", "pranav-own-pass-2"); await s.fill("#change-password-again", "pranav-own-pass-2");
const pw = s.waitForResponse((x) => x.url().includes("/api/auth/password")); await s.getByRole("dialog").getByRole("button", { name: "Change password" }).click(); ok((await pw).status() === 200, "password change accepted"); await s.waitForTimeout(300);
const meAfter = await s.evaluate(async () => (await fetch("/api/auth/me")).json()); ok(meAfter.user?.email === "pranav@mdapl.in", "still signed in here after changing password " + JSON.stringify(meAfter));
const teamStaff = await s.evaluate(async () => (await fetch("/api/team")).status); ok(teamStaff === 200, `staff can read the team list (${teamStaff})`);
const staffWrite = await s.evaluate(async () => { const t = await (await fetch("/api/team")).json(); const other = t.find((x) => x.email !== "pranav@mdapl.in");
  return [(await fetch(`/api/team/${other.user_id}`, { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify({ is_active: false }) })).status,
    (await fetch("/api/team", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ name: "X", email: "x@y.in", role: "staff" }) })).status,
    (await fetch(`/api/team/${other.user_id}`, { method: "DELETE" })).status]; });
ok(staffWrite.every((x) => x === 403), `staff cannot switch off, add or remove (${staffWrite})`);

// Admin resets Pranav: his session ends at once (same server)
await a.reload(); await a.getByRole("button", { name: "Actions for Pranav Kumar" }).click(); await a.getByRole("menuitem", { name: /^Temporary password/ }).click();
await a.getByRole("alertdialog").getByRole("button", { name: "Create temporary password" }).click();
const temp2 = (await a.getByTestId("temp-password").innerText()).trim(); await a.getByRole("button", { name: "Done" }).click();
const me2 = await s.evaluate(async () => (await fetch("/api/auth/me")).json()); ok(!me2.user, "reset ends the person's open session");
// Switch off: cannot sign in
await a.getByRole("button", { name: "Actions for Pranav Kumar" }).click(); await a.getByRole("menuitem", { name: /^Switch off access/ }).click();
await a.getByRole("alertdialog").getByRole("button", { name: "Switch off" }).click(); await a.waitForTimeout(600);
await s.reload(); await s.waitForSelector("#email"); await login(s, "pranav@mdapl.in", temp2); await s.waitForTimeout(800); ok(await s.getByText("do not match").isVisible(), "switched-off person cannot sign in");
// Admin sets a password directly, then removes a person
await a.getByRole("button", { name: "Actions for Pranav Kumar" }).click(); await a.getByRole("menuitem", { name: /^Switch access on/ }).click(); await a.waitForTimeout(600);
await a.getByRole("button", { name: "Actions for Pranav Kumar" }).click(); await a.getByRole("menuitem", { name: /^Set password/ }).click();
await a.fill("#set-pw", "pranav-admin-set-1"); await a.getByRole("dialog").getByRole("button", { name: "Set password" }).click(); await a.waitForTimeout(800);
await s.reload(); await s.waitForSelector("#email"); await login(s, "pranav@mdapl.in", "pranav-admin-set-1"); await s.waitForTimeout(1000);
ok(await s.getByRole("button", { name: "Set password and continue" }).isVisible().catch(() => false), "admin-set password signs in and asks for an own password");
await a.getByRole("button", { name: "Actions for Pranav Kumar" }).click(); await a.getByRole("menuitem", { name: /^Remove/ }).click();
await a.getByRole("alertdialog").getByRole("button", { name: "Remove" }).click(); await a.waitForTimeout(800);
ok(!(await a.getByRole("row", { name: /Pranav Kumar/ }).count()), "admin removed Pranav from the team");
// Admin cannot lock themselves out
const selfOff = await a.evaluate(async () => { const t = await (await fetch("/api/team")).json(); const me = t.find((x) => x.email === "demo@mdapl.local"); return (await fetch(`/api/team/${me.user_id}`, { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify({ is_active: false }) })).status; });
ok(selfOff === 400, `admin cannot switch off own access (${selfOff})`);
// Audit: changes recorded, never the hash
const audit = await a.evaluate(async () => { const l = await (await fetch("/api/audit?table=app_users")).json(); const d = await Promise.all(l.rows.map((r) => fetch(`/api/audit/${r.id}`).then((x) => x.json()))); return { rows: l.rows, d }; });
const txt = JSON.stringify(audit.d); ok(audit.rows?.length >= 3 && !/scrypt\$|password_hash/.test(txt), `audit has ${audit.rows?.length} team entries and no password hash`);
ok(/"password":"changed"/.test(txt), "audit shows 'password: changed'");
console.log("page errors", errs); await b.close();
