#!/usr/bin/env bash
# Copies the Retool database (schema + data of the public schema) into Supabase.
#
#   OLD_DATABASE_URL  Retool DB connection string (Retool > Resources > retool_db > connection string / "Connect")
#   NEW_DATABASE_URL  Supabase "Session pooler" connection string (Connect > Session pooler, port 5432). Not the
#                     6543 transaction pooler: a restore needs a session. The "Direct connection" also works
#                     where IPv6 is available.
#
#   ./scripts/migrate-retool-to-supabase.sh            dump, restore, enable RLS, compare row counts
#   DUMP_ONLY=1 ./scripts/migrate-retool-to-supabase.sh  only write the dump file
#   FORCE=1 ...                                        restore even when the target already has tables
#
# Needs pg_dump / psql 17 (PG_BIN=/usr/lib/postgresql/17/bin if they are not first on PATH).
set -euo pipefail

: "${OLD_DATABASE_URL:?Set OLD_DATABASE_URL to the Retool DB connection string}"
PG_BIN="${PG_BIN:-}"
PGDUMP="${PG_BIN:+$PG_BIN/}pg_dump"
PSQL="${PG_BIN:+$PG_BIN/}psql"

major() { "$1" --version | sed -E 's/.* ([0-9]+)(\.[0-9]+)*.*/\1/'; }
for bin in "$PGDUMP" "$PSQL"; do
  v=$(major "$bin")
  if [ "$v" -lt "${PG_MIN_MAJOR:-17}" ]; then echo "$bin is version $v; install PostgreSQL 17 client tools (or set PG_BIN)." >&2; exit 1; fi
done

OUT_DIR="${OUT_DIR:-migration-dumps}"
mkdir -p "$OUT_DIR"
STAMP=$(date +%Y%m%d-%H%M%S)
RAW="$OUT_DIR/retool-$STAMP.raw.sql"
DUMP="$OUT_DIR/retool-$STAMP.sql"

echo "1/5  Dumping the Retool database to $RAW"
"$PGDUMP" "$OLD_DATABASE_URL" --schema=public --no-owner --no-privileges --no-comments --quote-all-identifiers -Fp -f "$RAW"

echo "2/5  Preparing the dump for Supabase ($DUMP)"
# * functions as CREATE OR REPLACE, so a re-run does not fail on them
# * public already exists in Supabase; settings that older servers do not know are dropped
sed -E \
  -e 's/^CREATE FUNCTION /CREATE OR REPLACE FUNCTION /' \
  -e '/^CREATE SCHEMA "?public"?;/d' \
  -e '/^SET transaction_timeout/d' \
  "$RAW" > "$DUMP"
echo "     $(grep -c '^CREATE TABLE' "$DUMP") tables, $(grep -c '^CREATE OR REPLACE FUNCTION' "$DUMP") functions, $(du -h "$DUMP" | cut -f1)"
[ "${DUMP_ONLY:-}" = "1" ] && { echo "Dump only: done."; exit 0; }

: "${NEW_DATABASE_URL:?Set NEW_DATABASE_URL to the Supabase session pooler connection string (port 5432)}"
existing=$("$PSQL" "$NEW_DATABASE_URL" -Atc "select count(*) from information_schema.tables where table_schema = 'public' and table_type = 'BASE TABLE'")
if [ "$existing" -gt 0 ] && [ "${FORCE:-}" != "1" ]; then
  echo "The target already has $existing tables in public. Restore into an empty project, or run with FORCE=1." >&2
  exit 1
fi

echo "3/5  Restoring into Supabase (one transaction; nothing is kept if any statement fails)"
"$PSQL" "$NEW_DATABASE_URL" -v ON_ERROR_STOP=1 --single-transaction -q -o /dev/null -f "$DUMP"

echo "4/5  Enabling row level security on every table"
"$PSQL" "$NEW_DATABASE_URL" -v ON_ERROR_STOP=1 -q <<'SQL'
do $$
declare t record;
begin
  for t in select tablename from pg_tables where schemaname = 'public' loop
    execute format('alter table public.%I enable row level security', t.tablename);
  end loop;
end $$;
SQL

echo "5/5  Row counts, old -> new"
tables=$("$PSQL" "$OLD_DATABASE_URL" -Atc "select tablename from pg_tables where schemaname = 'public' order by 1")
printf "%-34s %12s %12s  %s\n" "table" "retool" "supabase" ""
bad=0
for t in $tables; do
  a=$("$PSQL" "$OLD_DATABASE_URL" -Atc "select count(*) from public.\"$t\"")
  b=$("$PSQL" "$NEW_DATABASE_URL" -Atc "select count(*) from public.\"$t\"" 2>/dev/null || echo "missing")
  mark="ok"; [ "$a" != "$b" ] && { mark="DIFFERENT"; bad=1; }
  printf "%-34s %12s %12s  %s\n" "$t" "$a" "$b" "$mark"
done
if [ "$bad" = "1" ]; then echo "Some counts differ. Check the restore output above." >&2; exit 2; fi
echo "All row counts match. Set DATABASE_URL in Vercel to the Supabase transaction pooler (port 6543) and deploy;"
echo "the app adds its audit log, indexes and triggers on first start."
