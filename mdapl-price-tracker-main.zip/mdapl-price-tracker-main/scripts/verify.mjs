// End-to-end run of the main flows against the app in demo mode (npm run dev). Usage: node scripts/verify.mjs [baseUrl]
import { createRequire } from "node:module";
const { chromium } = createRequire(import.meta.url)("playwright");

const BASE = process.argv[2] ?? "http://localhost:5173";
const stamp = Date.now().toString(36).slice(-5);
const results = [];
const step = async (name, fn) => {
  try { await fn(); results.push(["ok", name]); console.log(`ok    ${name}`); }
  catch (e) { results.push(["FAIL", name]); console.log(`FAIL  ${name}\n      ${String(e.message).split("\n")[0]}`); }
};

const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, acceptDownloads: true });
const page = await ctx.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
const go = async (path) => { await page.goto(`${BASE}/#${path}`); await page.waitForLoadState("networkidle"); };
const toast = (text) => page.getByRole("status").filter({ hasText: text }).first().waitFor({ timeout: 15000 });

await step("wrong password shows an error", async () => {
  await go("/login");
  await page.fill("#email", "demo@mdapl.local");
  await page.fill("#password", "wrong-password");
  await page.click("button:has-text('Sign in')");
  await page.getByRole("alert").filter({ hasText: "do not match" }).waitFor();
});
await step("sign in", async () => {
  await page.fill("#password", "demo1234");
  await page.click("button:has-text('Sign in')");
  await page.getByRole("heading", { name: "Dashboard" }).waitFor();
});
await step("one fixed browser tab title", async () => {
  for (const p of ["/", "/products", "/runs"]) { await go(p); if ((await page.title()) !== "MDAPL Price Tracker") throw new Error(`title on ${p}: ${await page.title()}`); }
});
await step("add a category", async () => {
  await go("/categories");
  await page.click("button:has-text('Add Product Category')");
  await page.fill("#cat-name", `E2E Category ${stamp}`);
  await page.click("button:has-text('Add category')");
  await toast("added");
});
await step("duplicate category is refused", async () => {
  await page.click("button:has-text('Add Product Category')");
  await page.fill("#cat-name", `e2e category ${stamp}`);
  await page.click("button:has-text('Add category')");
  await page.locator(".notice-danger").filter({ hasText: "already exists" }).waitFor();
  await page.keyboard.press("Escape");
});
let productUrl = "";
await step("create a product with links", async () => {
  await go("/products/new");
  await page.fill("#name", `E2E PRODUCT ${stamp}`);
  await page.fill("#brand", "Pigeon");
  await page.getByRole("button", { name: "Category", exact: true }).click();
  await page.getByRole("option").filter({ hasText: `E2E Category ${stamp}` }).click();
  await page.fill("#mrp", "2499");
  await page.fill("#dealer_landing", "1500");
  await page.fill("#dp_margin_percent", "10");
  await page.getByText("₹ 1,650").first().waitFor({ timeout: 5000 });   // MOP calculated live: 1500 x 110%
  await page.fill("#link_amazon", "www.amazon.in/dp/E2E" + stamp);
  await page.click("button:has-text('Add product')");
  await toast("added");
  await page.waitForURL(/#\/products\/\d+$/);
  productUrl = page.url();
});
await step("edit and save the product", async () => {
  await page.fill("#mrp", "2599");
  await page.getByText("On a schedule", { exact: true }).click();
  await page.getByRole("button", { name: "WED" }).click();
  await page.click("button:has-text('Save changes')");
  await toast("Changes saved");
  await page.reload(); await page.waitForLoadState("networkidle");
  if ((await page.inputValue("#mrp")) !== "2599") throw new Error("MRP not saved");
  if ((await page.getByRole("button", { name: "WED" }).getAttribute("aria-pressed")) !== "true") throw new Error("weekly day not saved");
});
await step("delete the product (soft delete)", async () => {
  await page.click("button:has-text('Delete')");
  await page.getByRole("alertdialog").getByRole("button", { name: "Delete product" }).click();
  await page.waitForURL(/#\/products$/);
});
await step("audit log shows the delete with IP and device, and restores it", async () => {
  await go("/audit?tab=deleted");
  const row = page.locator("div.relative.px-4", { hasText: `E2E PRODUCT ${stamp}` }).first();
  await row.waitFor();
  await row.locator("button[aria-label^='Show details']").click();
  const dlg = page.locator("dialog[open]");
  await dlg.getByText("IP address").waitFor();
  await dlg.getByText(/on (Linux|Mac|Windows)/).waitFor();
  await dlg.getByRole("button", { name: /Restore/ }).click();
  await page.getByRole("alertdialog").getByRole("button", { name: "Restore" }).click();
  await toast("Restored");
  await page.goto(productUrl); await page.waitForLoadState("networkidle");
  await page.getByText("Active", { exact: true }).first().waitFor();
});
await step("audit log shows field-by-field changes", async () => {
  await go("/audit?table=products&action=update");
  await page.locator("button[aria-label^='Show details']").first().click();
  await page.locator("dialog[open]").getByRole("columnheader", { name: "Before" }).waitFor();
  await page.keyboard.press("Escape");
});
await step("filters live in the URL and survive reload", async () => {
  await go("/products?brand=Gilma&status=all");
  await page.reload(); await page.waitForLoadState("networkidle");
  await page.getByRole("button", { name: "Brand" }).filter({ hasText: "Gilma" }).waitFor();
  const n = await page.locator("tbody tr").count();
  if (!n) throw new Error("no rows");
});
await step("products list pages: next, last, per page, filters reset the page", async () => {
  await go("/products?status=all");
  const rows = page.locator("nav[aria-label='Pages']").first();
  await rows.getByText(/Rows 1 to 25 of/).waitFor();
  await page.click("button[aria-label='Next page']");
  await rows.getByText(/Rows 26 to 50 of/).waitFor();
  if (!page.url().includes("page=2")) throw new Error(`page not in URL: ${page.url()}`);
  await page.reload(); await rows.getByText(/Rows 26 to 50 of/).waitFor();
  await page.click("button[aria-label='Last page']");
  const t = await rows.innerText();
  const [, total] = t.match(/of ([\d,]+)/) ?? [];
  if (!new RegExp(`to ${total} of ${total}`).test(t)) throw new Error(`last page: ${t}`);
  await page.click("nav[aria-label='Pages'] button[aria-label='Rows per page']"); await page.getByRole("option", { name: "50", exact: true }).click();
  await rows.getByText(/Rows 1 to 50 of/).waitFor();
  await page.click("button[aria-label='Next page']");
  await rows.getByText(/Rows 51 to/).waitFor();
  await page.getByRole("searchbox").first().fill("a");
  await rows.getByText(/Rows 1 to/).waitFor();
  await go("/products?status=all");
  await rows.getByText(/Rows 1 to 50 of/).waitFor();   // the page size is remembered
});
await step("export products to Excel", async () => {
  await go("/products");
  await page.click("button:has-text('Export')");
  const [dl] = await Promise.all([page.waitForEvent("download"), page.click("text=Excel workbook (.xlsx)")]);
  if (!dl.suggestedFilename().endsWith(".xlsx")) throw new Error(dl.suggestedFilename());
});
await step("export CSV", async () => {
  await page.click("button:has-text('Export')");
  const [dl] = await Promise.all([page.waitForEvent("download"), page.click("text=CSV (.csv)")]);
  if (!dl.suggestedFilename().endsWith(".csv")) throw new Error(dl.suggestedFilename());
});
let runUrl = "";
await step("scrape selected links on demand", async () => {
  await go("/scraping?channel=flipkart");
  await page.locator("tbody input[type=checkbox]").nth(0).check();
  await page.locator("tbody input[type=checkbox]").nth(1).check();
  await page.click("button:has-text('Scrape Flipkart Links')");
  await toast("Scraping 2 Flipkart links started");
  await page.getByRole("status").getByRole("link", { name: /Follow it/ }).click();
  await page.waitForURL(/#\/runs\/\d+/);
  runUrl = page.url();
});
await step("the run finishes and shows its results", async () => {
  await page.getByTestId("run-state").getByText(/^2 of 2 links scraped in /).waitFor({ timeout: 30000 });
});
await step("start a full run of a channel", async () => {
  await go("/scraping?channel=amazon");
  await page.click("button:has-text('Start full run')");
  await page.fill("#batch-size", "40");
  await page.click("button:has-text('Start run')");
  await toast("created");
});
await step("split view: pick a result, id in the URL", async () => {
  await go("/results?channel=amazon");
  await page.locator("[role=listbox] button").first().click();
  await page.waitForURL(/#\/results\/\d+/);
  await page.getByText("Every scrape in this period").waitFor();
});
await step("generate a MOP breach report (saved + Excel)", async () => {
  await page.click("button:has-text('Generate MOP Breach Report')");
  await page.fill("#remarks", `E2E ${stamp}`);
  const [dl] = await Promise.all([page.waitForEvent("download", { timeout: 30000 }), page.click("button:has-text('Generate and download')")]);
  if (!dl.suggestedFilename().endsWith(".xlsx")) throw new Error(dl.suggestedFilename());
  await toast("MOP breach report saved");
  await go("/mop-reports");
  await page.getByText(`E2E ${stamp}`).first().waitFor();
});
await step("dashboard loads numbers and charts", async () => {
  await go("/?channel=flipkart");
  await page.getByText("Products below MOP").waitFor();
  await page.getByRole("heading", { name: "Price Trend Over Time" }).waitFor();
});
await step("sign out", async () => {
  await page.locator("button[aria-haspopup=menu]").click();
  await page.getByRole("menuitem", { name: "Sign out" }).click();
  await page.getByText("You are signed out.").waitFor();
});

await browser.close();
const failed = results.filter((r) => r[0] === "FAIL").length;
if (errors.length) console.log(`Page errors:\n${errors.join("\n")}`);
console.log(`\n${results.length - failed} passed, ${failed} failed${errors.length ? `, ${errors.length} page errors` : ""}`);
process.exit(failed || errors.length ? 1 : 0);
