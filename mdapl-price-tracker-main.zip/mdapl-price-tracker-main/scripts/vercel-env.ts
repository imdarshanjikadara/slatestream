// Writes the app's sign-in secrets straight into the Vercel project's environment variables, without printing them.
// Used by .github/workflows/setup-vercel-env.yml; can also run locally with the same env vars.
//
//   VERCEL_TOKEN        Vercel account token (Account Settings > Tokens)
//   VERCEL_PROJECT_ID   Project ID (Project > Settings > General), or the project name
//   VERCEL_TEAM_ID      Team ID (Team Settings > General), empty for a personal account
//
//   MODE=secrets   create AUTH_SECRET and CRON_SECRET if missing (ROTATE=1 replaces them; everyone is signed out)
//   MODE=add_user  add or update USER_EMAIL / USER_NAME / USER_ROLE in APP_USERS, password from USER_PASSWORD
//   MODE=remove_user  remove USER_EMAIL from APP_USERS
//   MODE=list_users   list who is in APP_USERS (emails, names, roles only)
import { randomBytes } from "node:crypto";
import { hashPassword } from "../server/auth.js";

const token = process.env.VERCEL_TOKEN, project = process.env.VERCEL_PROJECT_ID, team = process.env.VERCEL_TEAM_ID;
const mode = process.env.MODE ?? "secrets";
const fail = (m: string): never => { console.error(`::error::${m}`); process.exit(1); };
if (!token) fail("VERCEL_TOKEN is not set.");
if (!project) fail("VERCEL_PROJECT_ID is not set.");
const TARGETS = ["production", "preview"];

async function vercel(path: string, init: RequestInit = {}) {
  const sep = path.includes("?") ? "&" : "?";
  const res = await fetch(`https://api.vercel.com${path}${team ? `${sep}teamId=${team}` : ""}`, {
    ...init, headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json", ...(init.headers ?? {}) },
  }).catch((e: Error) => fail(`Could not reach the Vercel API: ${(e as any).cause?.code ?? e.message}`));
  const body = await res.json().catch(() => ({}));
  if (!res.ok) fail(`Vercel API ${res.status}: ${(body as any)?.error?.message ?? "request failed"}`);
  return body as any;
}

type Env = { id: string; key: string; value?: string; target?: string[] };
async function getEnv(key: string): Promise<Env | null> {
  const list = (await vercel(`/v9/projects/${encodeURIComponent(project!)}/env?decrypt=true`)).envs as Env[];
  const found = list.find((e) => e.key === key && (e.target ?? []).includes("production"));
  if (!found) return null;
  // The list may hide values; read the one variable decrypted.
  const one = await vercel(`/v1/projects/${encodeURIComponent(project!)}/env/${found.id}`);
  return { ...found, value: one.value ?? found.value };
}
async function setEnv(key: string, value: string) {
  await vercel(`/v10/projects/${encodeURIComponent(project!)}/env?upsert=true`, {
    method: "POST", body: JSON.stringify({ key, value, type: "encrypted", target: TARGETS }),
  });
}

type Account = { email: string; name: string; role: "admin" | "staff"; hash: string };
async function users(): Promise<Account[]> {
  const e = await getEnv("APP_USERS");
  if (!e?.value) return [];
  try { return JSON.parse(e.value); } catch { return fail("APP_USERS in Vercel is not valid JSON; fix or delete it in the Vercel dashboard first."); }
}

if (mode === "secrets") {
  for (const key of ["AUTH_SECRET", "CRON_SECRET"]) {
    const has = await getEnv(key);
    if (has && process.env.ROTATE !== "1") { console.log(`${key}: already set, kept (tick rotate to replace it)`); continue; }
    await setEnv(key, randomBytes(32).toString("hex"));
    console.log(`${key}: ${has ? "replaced with a new random value" : "created with a random value"} (not shown)`);
  }
} else if (mode === "add_user") {
  const email = (process.env.USER_EMAIL ?? "").trim().toLowerCase();
  const name = (process.env.USER_NAME ?? "").trim() || email;
  const role = process.env.USER_ROLE === "staff" ? "staff" : "admin";
  const password = process.env.USER_PASSWORD ?? "";
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) fail("Enter a valid email.");
  if (password.length < 10) fail("The USER_PASSWORD secret must be set and at least 10 characters long.");
  const list = (await users()).filter((u) => u.email !== email);
  list.push({ email, name, role, hash: hashPassword(password) });
  await setEnv("APP_USERS", JSON.stringify(list));
  console.log(`APP_USERS: ${email} (${name}, ${role}) saved; ${list.length} account(s) in total.`);
} else if (mode === "remove_user") {
  const email = (process.env.USER_EMAIL ?? "").trim().toLowerCase();
  const before = await users();
  const list = before.filter((u) => u.email !== email);
  if (list.length === before.length) fail(`${email} is not in APP_USERS.`);
  await setEnv("APP_USERS", JSON.stringify(list));
  console.log(`APP_USERS: ${email} removed; ${list.length} account(s) left.`);
} else if (mode === "list_users") {
  const list = await users();
  console.log(list.length ? list.map((u) => `${u.email}  ${u.name}  ${u.role}`).join("\n") : "APP_USERS is empty or not set.");
} else {
  fail(`Unknown MODE ${mode}.`);
}
console.log("Redeploy the project in Vercel (Deployments > ... > Redeploy) for changes to take effect.");
