// End-to-end check of the editable products sheet and the Scraping schedule dialog, against the demo API on a fresh database.
// Run with the dev servers up: node scripts/verify-products.mjs
import { createRequire } from "node:module";
const { chromium } = createRequire(import.meta.url)("playwright");
const B = "http://localhost:5173";
const ok = (c, m) => { console.log(c ? "ok  " : "FAIL", m); if (!c) process.exitCode = 1; };
const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1440, height: 900 } });
const errs = []; p.on("pageerror", (e) => errs.push(e.message));
await p.goto(`${B}/#/login`); await p.fill("#email", "demo@mdapl.local"); await p.fill("#password", "demo1234"); await p.click("button:has-text('Sign in')"); await p.waitForSelector("main#main");
await p.goto(`${B}/#/products`); await p.getByRole("grid", { name: "Products" }).waitFor(); await p.waitForTimeout(800);
await p.screenshot({ path: "scripts/.out/grid-1.png" });
const heads = await p.locator("thead tr:nth-child(2) th").allInnerTexts(); ok(heads.length >= 32, `columns shown: ${heads.length}`);
const cell = (r, key) => p.locator(`tbody tr:nth-child(${r}) td[data-c="${heads.findIndex((h) => h.replace(/calc$/, "").trim() === key) - 1}"]`);
const api = (path) => p.evaluate(async (u) => (await fetch(u)).json(), path);
const id = Number((await p.locator("tbody tr:nth-child(1) td[data-c='0']").innerText()).trim());
// money: dealer landing -> MOP recalculated
await cell(1, "Dealer landing").click(); await p.keyboard.press("Control+a"); await p.keyboard.type("2000"); await p.keyboard.press("Enter"); await p.waitForTimeout(900);
let prod = await api(`/api/products/${id}`); prod = prod.product ?? prod;
ok(Number(prod.dealer_landing) === 2000, `dealer landing saved (${prod.dealer_landing})`);
const mopCell = (await cell(1, "MOP").innerText()).replace(/[^\d.]/g, "");
ok(Number(mopCell) === Number(prod.mop) && Number(prod.mop) > 0, `MOP recalculated in the grid (${mopCell} = ${prod.mop})`);
// category select
await cell(1, "Category").click(); await p.getByRole("dialog", { name: "Choose one" }).waitFor();
const target = (await p.getByRole("option").nth(2).innerText()).trim(); await p.getByRole("option").nth(2).click(); await p.waitForTimeout(900);
ok((await cell(1, "Category").innerText()).trim().toLowerCase() === target.toLowerCase(), `category changed to ${target}`);
// scraping mode: one choice, regular and scheduled never both
await cell(1, "Scraping").click(); await p.getByRole("dialog", { name: "Choose one" }).waitFor();
await p.getByRole("option", { name: "On a schedule" }).click(); await p.waitForTimeout(900);
prod = await api(`/api/products/${id}`); prod = prod.product ?? prod;
ok(!!prod.scheduled_scraping && !prod.regular_scraping, "scraping set to On a schedule (regular turned off)");
await cell(1, "Scraping").click(); await p.getByRole("option", { name: "Every day" }).click(); await p.waitForTimeout(900);
prod = await api(`/api/products/${id}`); prod = prod.product ?? prod;
ok(!!prod.regular_scraping && !prod.scheduled_scraping, "scraping set to Every day (scheduled turned off)");
const both = await p.evaluate(async (u) => (await fetch(u, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ regular_scraping: true, scheduled_scraping: true }) })).status, `/api/products/${id}`);
ok(both === 400, `both at once refused (${both})`);
// multi: weekdays MON + FRI
await cell(1, "Week-wise (days)").click(); const dlg = p.getByRole("dialog", { name: "Choose any" }); await dlg.waitFor();
await dlg.getByRole("button", { name: "Clear" }).click(); await dlg.getByRole("option", { name: "MON" }).click(); await dlg.getByRole("option", { name: "FRI" }).click();
await p.screenshot({ path: "scripts/.out/grid-multi.png" });
await dlg.getByRole("button", { name: "Done" }).click(); await p.waitForTimeout(900);
prod = await api(`/api/products/${id}`); prod = prod.product ?? prod;
ok(String(prod.scraping_schedule_weekly) === "1,5", `weekdays saved (${prod.scraping_schedule_weekly})`);
// link: add a Zepto link
await cell(1, "Zepto").click(); await p.keyboard.type("www.zeptonow.com/pn/test/pvid/abc"); await p.keyboard.press("Enter"); await p.waitForTimeout(1200);
const det = await api(`/api/products/${id}`); ok(JSON.stringify(det).includes("zeptonow.com/pn/test/pvid/abc"), "zepto link saved");
// escape cancels
const nameBefore = (await cell(2, "Name").innerText()).trim(); await cell(2, "Name").click(); await p.keyboard.type("XX"); await p.keyboard.press("Escape"); await p.waitForTimeout(300);
ok((await cell(2, "Name").innerText()).trim() === nameBefore, "Esc cancels an edit");
// arrow navigation + Enter opens editor
await cell(3, "Brand").click(); await p.keyboard.press("Escape"); await p.keyboard.press("ArrowRight"); await p.keyboard.press("Enter");
ok(await p.getByRole("dialog", { name: "Choose one" }).isVisible(), "arrow keys move, Enter edits (category menu opened)"); await p.keyboard.press("Escape");
await p.screenshot({ path: "scripts/.out/grid-2.png" });
// Scraping: Update Scraping Schedule
await p.goto(`${B}/#/scraping`); await p.waitForTimeout(1200); await p.getByRole("button", { name: "Update Scraping Schedule" }).click();
const sd = p.getByRole("dialog"); await sd.getByText("Scraping schedule of").waitFor();
ok(p.url().includes("/scraping"), "schedule button stays on Scraping (no redirect)");
ok(!(await sd.getByText("GST %").isVisible().catch(() => false)), "schedule dialog shows schedule fields only");
await p.screenshot({ path: "scripts/.out/sched-dialog.png" });
ok(!(await sd.getByText("Regular scraping", { exact: true }).isVisible().catch(() => false)), "no separate regular / scheduled options");
await sd.getByText("On a schedule", { exact: true }).click(); await sd.getByRole("group", { name: "Days of the week" }).getByRole("button", { name: "WED" }).click();
await p.screenshot({ path: "scripts/.out/sched-dialog.png" });
await sd.getByRole("button", { name: /^Apply to/ }).click(); await p.getByText(/products updated/).waitFor({ timeout: 10000 });
prod = await api(`/api/products/${id}`); prod = prod.product ?? prod;
ok(!!prod.scheduled_scraping && !prod.regular_scraping && String(prod.scraping_schedule_weekly) === "3", "schedule applied: on a schedule, Wednesdays");
console.log("page errors", errs); await b.close();
