// Screenshots of every page, desktop (1440) and phone (390). Usage: node scripts/screens.mjs [baseUrl] [outDir]
// Expects the app running in demo mode (npm run dev) and signs in with the demo account.
import { createRequire } from "node:module";
const { chromium } = createRequire(import.meta.url)("playwright");
import { mkdirSync } from "node:fs";

const BASE = process.argv[2] ?? "http://localhost:5173";
const OUT = process.argv[3] ?? "docs/screenshots";
mkdirSync(OUT, { recursive: true });

const PAGES = [
  ["login", "/login"], ["dashboard", "/"], ["categories", "/categories"], ["category", "/categories/1"], ["products", "/products"], ["product", "/products/1"],
  ["product-new", "/products/new"], ["scraping", "/scraping"], ["results", "/results"], ["result", "/results/1"], ["mop-reports", "/mop-reports"],
  ["mop-report", "/mop-reports/1"], ["runs", "/runs"], ["run", "/runs/59"], ["audit", "/audit"],
];

const browser = await chromium.launch();
const errors = [];
for (const [device, viewport] of [["desktop", { width: 1440, height: 900 }], ["phone", { width: 390, height: 844 }]]) {
  const ctx = await browser.newContext({ viewport, deviceScaleFactor: 1 });
  const page = await ctx.newPage();
  page.on("pageerror", (e) => errors.push(`${device} ${page.url()}: ${e.message}`));
  page.on("console", (m) => { if (m.type() === "error" && !/logo\.png|favicon|404/.test(m.text())) errors.push(`${device} ${page.url()}: ${m.text()}`); });
  await page.goto(`${BASE}/#/login`);
  await page.screenshot({ path: `${OUT}/${device}-login.jpg`, type: "jpeg", quality: 80, fullPage: true });
  await page.fill("#email", "demo@mdapl.local");
  await page.fill("#password", "demo1234");
  await page.click("button:has-text('Sign in')");
  await page.waitForSelector("main#main");
  for (const [name, path] of PAGES.slice(1)) {
    await page.goto(`${BASE}/#${path}`);
    await page.waitForLoadState("networkidle");
    await page.waitForTimeout(400);
    // Horizontal overflow check: the page must never scroll sideways.
    const over = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
    if (over > 1) errors.push(`${device} ${path}: page is ${over}px wider than the screen`);
    await page.screenshot({ path: `${OUT}/${device}-${name}.jpg`, type: "jpeg", quality: 80, fullPage: true });
  }
  await ctx.close();
}
await browser.close();
console.log(errors.length ? `Problems:\n${errors.join("\n")}` : "No console errors, no horizontal overflow.");
